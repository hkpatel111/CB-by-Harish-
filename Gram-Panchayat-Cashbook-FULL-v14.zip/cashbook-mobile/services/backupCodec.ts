/**
 * backupCodec.ts — instruction #17, #18, #19
 *
 * एक ही database को **तीन formats** में backup/restore:
 *   • `.json`  — सीधा JSON (पढ़ने में आसान)
 *   • `.csv`   — `key,value` table (chunked, इसलिए किसी भी size का data समा जाता है)
 *   • `.xlsx`  — एक sheet `cashbook-backup`, rows = `key,value`
 *   • `.zip`   — `backup.json` + `backup.csv` दोनों एक साथ
 *
 * हर format **दोनों तरफ़** चलता है: save भी और restore भी (item #19)।
 */
import { buildXlsx, buildZipArchive } from './xlsx';
import { parseXlsx } from './xlsxread';
import { unzip, bytesToText } from './zipread';

const CHUNK = 24000;
export const BACKUP_SHEET = 'cashbook-backup';
const MARK = 'gpc-cashbook-backup/1';

type Pair = { key: string; value: string };

function toTable(obj: Record<string, unknown>): Pair[] {
  const rows: Pair[] = [{ key: '__format', value: MARK }];
  for (const [k, v] of Object.entries(obj)) {
    const json = JSON.stringify(v === undefined ? null : v);
    for (let i = 0; i < json.length; i += CHUNK) {
      rows.push({ key: i === 0 ? k : '', value: json.slice(i, i + CHUNK) });
    }
  }
  return rows;
}

function fromTable(pairs: Pair[]): Record<string, unknown> | null {
  const out: Record<string, unknown> = {};
  let cur: string | null = null;
  let buf = '';
  let marker = false;
  const flush = () => {
    if (!cur) return;
    if (cur === '__format') {
      if (buf.startsWith('gpc-cashbook-backup')) marker = true;
    } else {
      try {
        out[cur] = JSON.parse(buf);
      } catch {
        out[cur] = buf;
      }
    }
    cur = null;
    buf = '';
  };
  for (const p of pairs) {
    const k = (p.key || '').trim();
    if (k) {
      flush();
      cur = k;
      buf = p.value;
    } else if (cur) {
      buf += p.value;
    }
  }
  flush();
  if (!marker || !('app' in out)) return null;
  return out;
}

/* ─────────────── CSV ─────────────── */

function csvEscape(s: string): string {
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function backupToCsv(obj: Record<string, unknown>): string {
  const lines = ['key,value'];
  for (const p of toTable(obj)) lines.push(`${csvEscape(p.key)},${csvEscape(p.value)}`);
  return `\ufeff${lines.join('\r\n')}\r\n`;
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = '';
  let inQ = false;
  let i = text.charCodeAt(0) === 0xfeff ? 1 : 0;
  while (i < text.length) {
    const ch = text[i];
    if (inQ) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cur += '"';
          i += 2;
          continue;
        }
        inQ = false;
        i += 1;
        continue;
      }
      cur += ch;
      i += 1;
      continue;
    }
    if (ch === '"') {
      inQ = true;
      i += 1;
      continue;
    }
    if (ch === ',') {
      row.push(cur);
      cur = '';
      i += 1;
      continue;
    }
    if (ch === '\r') {
      i += 1;
      continue;
    }
    if (ch === '\n') {
      row.push(cur);
      rows.push(row);
      row = [];
      cur = '';
      i += 1;
      continue;
    }
    cur += ch;
    i += 1;
  }
  if (cur !== '' || row.length) {
    row.push(cur);
    rows.push(row);
  }
  return rows;
}

/* ─────────────── encode ─────────────── */

export function backupToXlsx(obj: Record<string, unknown>): Uint8Array {
  const rows = toTable(obj).map((p) => [p.key, p.value]);
  return buildXlsx([{ name: BACKUP_SHEET, rows }]);
}

/** कोई भी CSV string → असली `.xlsx` (Share FY CSV को असली Excel बनाने के लिए) */
export function csvToXlsx(csv: string, sheetName: string): Uint8Array {
  const name = (sheetName || 'Sheet1').slice(0, 31);
  return buildXlsx([{ name, rows: parseCsv(csv) }]);
}

export function mimeForExt(ext: string): string {
  const e = ext.toLowerCase().replace(/^\./, '');
  if (e === 'xlsx') return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  if (e === 'zip') return 'application/zip';
  if (e === 'csv') return 'text/csv';
  if (e === 'pdf') return 'application/pdf';
  return 'application/json';
}

export function backupToZip(obj: Record<string, unknown>): Uint8Array {
  return buildZipArchive([
    { name: 'backup.json', data: JSON.stringify({ ...obj, exportedAt: new Date().toISOString() }, null, 2) },
    { name: 'backup.csv', data: backupToCsv(obj) },
  ]);
}

/* ─────────────── decode (format detect) ─────────────── */

function fromRows(rows: (string | number | boolean | null | undefined)[][]): Record<string, unknown> | null {
  return fromTable(
    rows.map((r) => ({ key: String(r[0] ?? ''), value: String(r[1] ?? '') }))
  );
}

/** कोई भी backup text (JSON / CSV) → object; नहीं तो null */
export function parseBackupText(text: string): Record<string, unknown> | null {
  const t = text.trim();
  if (!t) return null;
  if (t.startsWith('{')) {
    try {
      const o = JSON.parse(t);
      if (o && typeof o === 'object' && 'app' in o) return o as Record<string, unknown>;
    } catch {
      /* नीचे CSV कोशिश */
    }
  }
  try {
    return fromRows(parseCsv(t));
  } catch {
    return null;
  }
}

/** कोई भी backup फ़ाइल (json / csv / xlsx / zip) → object; नहीं तो null */
export function parseBackupBytes(bytes: Uint8Array): Record<string, unknown> | null {
  // PK.. = zip या xlsx
  if (bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b) {
    try {
      const sheets = parseXlsx(bytes);
      for (const s of sheets) {
        const got = fromRows(s.rows);
        if (got) return got;
      }
    } catch {
      /* zip bundle try करो */
    }
    try {
      const entries = unzip(bytes);
      for (const want of ['backup.json', 'backup.csv', 'cashbook.json', 'data.json']) {
        const e = entries.find((x) => x.name === want || x.name.endsWith(`/${want}`));
        if (e) {
          const got = parseBackupText(bytesToText(e.data));
          if (got) return got;
        }
      }
      // कोई भी .json entry
      for (const e of entries) {
        if (!e.name.toLowerCase().endsWith('.json')) continue;
        const got = parseBackupText(bytesToText(e.data));
        if (got) return got;
      }
    } catch {
      return null;
    }
    return null;
  }
  return parseBackupText(bytesToText(bytes));
}
