/**
 * zipread.ts — उल्टा काम: कोई भी `.zip` / `.xlsx` file पढ़ो।
 *
 * Instruction #15 (बैंक statement Excel अपलोड) और #19 (Excel / CSV / JSON restore)
 * के लिए ज़रूरी। project में कोई zip/inflate library नहीं है इसलिए:
 *   • EOCD → central directory → local header से entries निकाली जाती हैं;
 *   • method 0 = STORE (अपनी files), method 8 = DEFLATE (Excel/PC से आई files)
 *     → यहाँ एक छोटा सा puff-style inflate है (fixed + dynamic Huffman + stored)।
 */

export type ZipEntry = { name: string; data: Uint8Array };

/* ─────────────── DEFLATE (raw) decompressor ─────────────── */

class BitReader {
  private pos = 0;
  private bit = 0;
  constructor(private readonly src: Uint8Array) {}

  bits(n: number): number {
    let val = 0;
    for (let i = 0; i < n; i++) {
      if (this.pos >= this.src.length) throw new Error('inflate: अचानक अंत (unexpected end)');
      const b = (this.src[this.pos] >> this.bit) & 1;
      val |= b << i;
      this.bit += 1;
      if (this.bit === 8) {
        this.bit = 0;
        this.pos += 1;
      }
    }
    return val;
  }

  /** stored block: अगले byte पर align */
  align(): void {
    if (this.bit) {
      this.bit = 0;
      this.pos += 1;
    }
  }

  skipBytes(n: number): void {
    this.align();
    this.pos += n;
  }

  readByte(): number {
    this.align();
    if (this.pos >= this.src.length) throw new Error('inflate: अचानक अंत');
    return this.src[this.pos++];
  }
}

type Huff = { count: number[]; symbol: number[] };

function buildHuff(lengths: number[]): Huff {
  const count = new Array<number>(16).fill(0);
  for (const l of lengths) count[l] += 1;
  count[0] = 0;
  const offs = new Array<number>(16).fill(0);
  for (let i = 1; i < 16; i++) offs[i] = offs[i - 1] + count[i - 1];
  const symbol = new Array<number>(lengths.length).fill(0);
  for (let s = 0; s < lengths.length; s++) {
    const l = lengths[s];
    if (l) symbol[offs[l]++] = s;
  }
  return { count, symbol };
}

function decodeSym(br: BitReader, h: Huff): number {
  let code = 0;
  let first = 0;
  let index = 0;
  for (let len = 1; len <= 15; len++) {
    code |= br.bits(1);
    const cnt = h.count[len];
    if (code - first < cnt) return h.symbol[index + (code - first)];
    index += cnt;
    first = (first + cnt) << 1;
    code <<= 1;
  }
  throw new Error('inflate: गलत Huffman code');
}

const LENS = [
  3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131,
  163, 195, 227, 258,
];
const LEXT = [
  0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0,
];
const DISTS = [
  1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049,
  3073, 4097, 6145, 8193, 12289, 16385, 24577,
];
const DEXT = [
  0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13,
];

class OutBuf {
  buf = new Uint8Array(64 * 1024);
  len = 0;

  private ensure(n: number): void {
    if (this.len + n <= this.buf.length) return;
    let cap = this.buf.length;
    while (cap < this.len + n) cap *= 2;
    const nb = new Uint8Array(cap);
    nb.set(this.buf.subarray(0, this.len));
    this.buf = nb;
  }

  push(b: number): void {
    this.ensure(1);
    this.buf[this.len++] = b;
  }

  match(dist: number, n: number): void {
    this.ensure(n);
    let start = this.len - dist;
    for (let i = 0; i < n; i++) {
      this.buf[this.len + i] = this.buf[start + i];
    }
    this.len += n;
  }

  bytes(): Uint8Array {
    return this.buf.slice(0, this.len);
  }
}

/** raw DEFLATE stream → bytes (gzip/zip ke andar ka format) */
export function inflateRaw(src: Uint8Array): Uint8Array {
  const br = new BitReader(src);
  const out = new OutBuf();
  for (;;) {
    const bfinal = br.bits(1);
    const btype = br.bits(2);
    if (btype === 0) {
      br.align();
      const lo = src[br.readByte()];
      const hi = src[br.readByte()];
      const len = lo | (hi << 8);
      br.readByte();
      br.readByte(); // NLEN
      for (let i = 0; i < len; i++) out.push(br.readByte());
    } else {
      let litH: Huff;
      let distH: Huff;
      if (btype === 1) {
        const lit = new Array<number>(288).fill(8);
        for (let i = 144; i < 256; i++) lit[i] = 9;
        for (let i = 256; i < 280; i++) lit[i] = 7;
        const dist = new Array<number>(30).fill(5);
        litH = buildHuff(lit);
        distH = buildHuff(dist);
      } else if (btype === 2) {
        const hlit = br.bits(5) + 257;
        const hdist = br.bits(5) + 1;
        const hclen = br.bits(4) + 4;
        const order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
        const clen = new Array<number>(19).fill(0);
        for (let i = 0; i < hclen; i++) clen[order[i]] = br.bits(3);
        const clH = buildHuff(clen);
        const all = new Array<number>(hlit + hdist).fill(0);
        for (let i = 0; i < all.length; ) {
          const sym = decodeSym(br, clH);
          if (sym < 16) {
            all[i++] = sym;
          } else if (sym === 16) {
            const prev = all[i - 1];
            let rep = 3 + br.bits(2);
            while (rep-- > 0 && i < all.length) all[i++] = prev;
          } else if (sym === 17) {
            let rep = 3 + br.bits(3);
            while (rep-- > 0 && i < all.length) all[i++] = 0;
          } else {
            let rep = 11 + br.bits(7);
            while (rep-- > 0 && i < all.length) all[i++] = 0;
          }
        }
        litH = buildHuff(all.slice(0, hlit));
        distH = buildHuff(all.slice(hlit));
      } else {
        throw new Error('inflate: अमान्य block type');
      }

      for (;;) {
        const sym = decodeSym(br, litH);
        if (sym === 256) break;
        if (sym < 256) {
          out.push(sym);
          continue;
        }
        const li = sym - 257;
        if (li >= LENS.length) throw new Error('inflate: गलत length code');
        const length = LENS[li] + br.bits(LEXT[li]);
        const dsym = decodeSym(br, distH);
        if (dsym >= DISTS.length) throw new Error('inflate: गलत distance code');
        const dist = DISTS[dsym] + br.bits(DEXT[dsym]);
        if (dist > out.len) throw new Error('inflate: गलत distance');
        out.match(dist, length);
      }
    }
    if (bfinal) break;
  }
  return out.bytes();
}

/* ─────────────── ZIP reader ─────────────── */

function u16(b: Uint8Array, o: number): number {
  return b[o] | (b[o + 1] << 8);
}
function u32(b: Uint8Array, o: number): number {
  return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
}

function utf8Decode(bytes: Uint8Array): string {
  let s = '';
  for (let i = 0; i < bytes.length; ) {
    const c = bytes[i++];
    if (c < 0x80) s += String.fromCharCode(c);
    else if (c < 0xe0) s += String.fromCharCode(((c & 0x1f) << 6) | (bytes[i++] & 0x3f));
    else if (c < 0xf0) {
      s += String.fromCharCode(((c & 0x0f) << 12) | ((bytes[i++] & 0x3f) << 6) | (bytes[i++] & 0x3f));
    } else {
      const cp =
        ((c & 0x07) << 18) |
        ((bytes[i++] & 0x3f) << 12) |
        ((bytes[i++] & 0x3f) << 6) |
        (bytes[i++] & 0x3f);
      const v = cp - 0x10000;
      s += String.fromCharCode(0xd800 + (v >> 10), 0xdc00 + (v & 0x3ff));
    }
  }
  return s;
}

/** कोई भी .zip / .xlsx खोलकर सारे entries लौटाओ (STORE + DEFLATE दोनों) */
export function unzip(buf: Uint8Array): ZipEntry[] {
  // EOCD (0x06054b50) को आख़िरी 64 KB में ढूँढो
  let eocd = -1;
  const from = Math.max(0, buf.length - 66000);
  for (let i = buf.length - 22; i >= from; i--) {
    if (buf[i] === 0x50 && buf[i + 1] === 0x4b && buf[i + 2] === 0x05 && buf[i + 3] === 0x06) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error('यह .zip/.xlsx file नहीं है (EOCD नहीं मिला)');

  const count = u16(buf, eocd + 10);
  let p = u32(buf, eocd + 16);
  const out: ZipEntry[] = [];
  for (let n = 0; n < count && p + 46 <= buf.length; n++) {
    if (u32(buf, p) !== 0x02014b50) break;
    const method = u16(buf, p + 10);
    const csize = u32(buf, p + 20);
    const nameLen = u16(buf, p + 28);
    const extraLen = u16(buf, p + 30);
    const cmtLen = u16(buf, p + 32);
    const local = u32(buf, p + 42);
    const name = utf8Decode(buf.subarray(p + 46, p + 46 + nameLen));
    p += 46 + nameLen + extraLen + cmtLen;

    if (u32(buf, local) !== 0x04034b50) continue;
    const lNameLen = u16(buf, local + 26);
    const lExtraLen = u16(buf, local + 28);
    const dataStart = local + 30 + lNameLen + lExtraLen;
    const raw = buf.subarray(dataStart, dataStart + csize);
    let data: Uint8Array;
    if (method === 0) data = raw.slice();
    else if (method === 8) data = inflateRaw(raw);
    else continue; // कोई और method (bzip2 आदि) — छोड़ दो
    out.push({ name, data });
  }
  return out;
}

/** एक specific entry पढ़ो (मिले तो नहीं तो null) */
export function unzipFile(buf: Uint8Array, name: string): Uint8Array | null {
  for (const e of unzip(buf)) if (e.name === name) return e.data;
  return null;
}

export function bytesToText(b: Uint8Array): string {
  return utf8Decode(b);
}
