/**
 * formats.ts — GP formats from user-provided demo files.
 * हर entry add/edit/cancel पर ये builders re-run होते हैं (ledger-like auto update).
 * Sources: audit formet demo.xlsx, bank statement demo.xlsx,
 *          cc talora chaina mojek.xlsx, ledger.pdf (standard खाता बही)
 */
import type { Bill, MbLine, PakhwadaRoll, Transaction, Work } from '@/types/models';
import { formatINR, sumAmounts } from './pageEngine';

export type FmtHeader = {
  panchayat: string;
  block: string;
  district: string;
  fy: string;
  formName: string;
  extra?: string;
};

function head(h: FmtHeader): string[] {
  const L = [
    `कार्यालय ${h.panchayat}`,
    `पं.समिति — ${h.block}  |  जिला — ${h.district}`,
    `वित्तीय वर्ष: ${h.fy}`,
  ];
  if (h.extra) L.push(h.extra);
  L.push(h.formName);
  return L;
}

function csvJoin(rows: (string | number)[][]) {
  return rows
    .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))
    .join('\n');
}

const R = (n: number) => (Math.round(n * 100) / 100).toFixed(2);

/* ═══════════ 1. गोशवारा — audit demo sheet 1 (वार्षिक आय-व्यय सामान्य रोकड़ बही) ═══════════ */

export type GoswaraRow = {
  /**
   * v11 #12 — cross-link key: `cat:…` (मद/श्रेणी), `work:…` (कार्य), `scheme:…` (योजना)।
   * गोशवारा में इसी पंक्ति पर tap करने पर उसी key का ledger खुलता है।
   */
  key: string;
  name: string;
  inc: number;
  exp: number;
};

export function buildGoswara(
  txs: Pick<
    Transaction,
    | 'type'
    | 'status'
    | 'schemeId'
    | 'amounts'
    | 'categoryId'
    | 'subcategoryId'
    | 'subSubcategoryId'
    | 'party'
    | 'detail'
    | 'workId'
    | 'expenseKind'
  >[],
  categoryNames: Record<string, string>,
  opening: number,
  workNames?: Record<string, string>,
  schemeNames?: Record<string, string>
) {
  const active = txs.filter((t) => t.status === 'active');
  const mad = new Map<string, GoswaraRow>();
  for (const t of active) {
    if (t.type === 'transfer') continue; // नकद→बैंक जमा आय/व्यय नहीं (Part G)
    // E.3: मद = full category path (L1 › L2 › L3)
    const ids = [t.categoryId, t.subcategoryId, t.subSubcategoryId].filter(Boolean) as string[];
    /* v11 #12 — कार्य-पेटे भुगतान अब अलग मद (हर कार्य का अपना ledger),
       बिना श्रेणी वाली entry योजना के नाम से */
    let key: string;
    let name: string;
    if (t.type === 'expense' && t.expenseKind === 'work' && t.workId) {
      key = `work:${t.workId}`;
      name = `कार्य: ${(workNames && workNames[t.workId]) || t.workId}`;
    } else if (ids.length) {
      key = `cat:${ids.join('/')}`;
      name = ids.map((id) => categoryNames[id] || id).join(' › ');
    } else {
      key = `scheme:${t.schemeId}`;
      name = `योजना: ${(schemeNames && schemeNames[t.schemeId]) || t.schemeId}`;
    }
    if (!mad.has(key)) {
      mad.set(key, { key, name, inc: 0, exp: 0 });
    }
    const e = mad.get(key)!;
    const tot = sumAmounts(t.amounts);
    if (t.type === 'income') e.inc += tot;
    else if (t.type === 'expense') e.exp += tot;
  }
  const aayYog = active.filter((t) => t.type === 'income').reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const vyayYog = active.filter((t) => t.type === 'expense').reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const mahayog = opening + aayYog;
  return {
    rows: [...mad.values()],
    aayYog,
    vyayYog,
    prarambhikNagad: opening,
    mahayog,
    antSheshNagad: mahayog - vyayYog,
  };
}

export function goswaraCsv(g: ReturnType<typeof buildGoswara>, h: FmtHeader) {
  const rows: (string | number)[][] = head(h).map((t) => [t]);
  rows.push([]);
  rows.push(['क्र.', 'नाम मद', 'आय', 'व्यय']);
  g.rows.forEach((r, i) => rows.push([i + 1, r.name, R(r.inc), R(r.exp)]));
  rows.push(['', 'आय योग', R(g.aayYog), '']);
  rows.push(['', 'व्यय योग', '', R(g.vyayYog)]);
  rows.push(['', 'प्रारम्भिक शेष नगद', R(g.prarambhikNagad), '']);
  rows.push(['', 'महायोग', R(g.mahayog), '']);
  rows.push(['', 'अंतिम शेष नगद', R(g.antSheshNagad), '']);
  rows.push(['', 'प्रारम्भिक शेष बैंक', '', '']); // bank module se auto
  rows.push(['', 'अंतिम शेष बैंक', '', '']);
  rows.push([]);
  rows.push(['हस्ताक्षर', '', '', '']);
  rows.push(['सरपंच', '', '', '']);
  rows.push(['ग्राम विकास अधिकारी', '', '', '']);
  return csvJoin(rows);
}

/* ═══════════ 2. प्रपत्र-1 — SFC/TFC/FFC/BRGF कार्य विवरण (audit demo sheet 2) ═══════════ */

export type Prapt1Row = {
  workName: string;
  schemeName: string;
  fsRef: string;
  fsLakh: number;
  priorExpense: number;
  yearExpense: number;
  totalExpense: number;
  status: string;
  mulyaankan: number;
  mbRef: string;
  labourAmount: number;
  materialAmount: number;
};

export function buildPrapt1(
  works: Work[],
  mbLines: MbLine[],
  txs: Pick<Transaction, 'type' | 'status' | 'workId' | 'amounts' | 'schemeId'>[],
  fundNames: Record<string, string>,
  priorFor: (w: Work) => number
): Prapt1Row[] {
  return works.map((w) => {
    const labour = mbLines.filter((m) => m.workId === w.id && m.kind !== 'material').reduce((s, m) => s + m.qty * m.rate, 0);
    const material = mbLines.filter((m) => m.workId === w.id && m.kind === 'material').reduce((s, m) => s + m.qty * m.rate, 0);
    const yearExp = txs
      .filter((t) => t.status === 'active' && t.type === 'expense' && t.workId === w.id)
      .reduce((s, t) => s + sumAmounts(t.amounts), 0);
    const prior = priorFor(w);
    return {
      workName: w.name,
      schemeName: fundNames[w.schemeId] || w.schemeId,
      fsRef: w.sanctionRef || '—',
      fsLakh: (w.fsAmount || 0) / 100000, // FS वित्तीय स्वीकृति राशि → लाख (D24)
      priorExpense: prior,
      yearExpense: yearExp,
      totalExpense: prior + yearExp,
      status: w.status === 'completed' ? 'पूर्ण' : 'प्रगतिरत',
      mulyaankan: labour + material, // MB valuation
      mbRef: `MB ${mbLines.filter((m) => m.workId === w.id).length} lines`,
      labourAmount: labour,
      materialAmount: material,
    };
  });
}

export function prapt1Csv(rows: Prapt1Row[], h: FmtHeader) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  out.push([
    'क्र.',
    'कार्य का नाम',
    'योजना का नाम',
    'वित्तीय स्वीकृति क्रमांक/दिनांक',
    'स्वीकृत राशि (लाख)',
    'पूर्व में किया गया व्यय',
    'आलोच्य वर्ष में व्यय',
    'आलोच्य वर्ष तक कुल व्यय',
    'कार्य की स्थिति',
    'मूल्यांकन राशि',
    'MB संदर्भ',
    'श्रम राशि',
    'सामग्री राशि',
  ]);
  rows.forEach((r, i) =>
    out.push([
      i + 1,
      r.workName,
      r.schemeName,
      r.fsRef,
      r.fsLakh,
      R(r.priorExpense),
      R(r.yearExpense),
      R(r.totalExpense),
      r.status,
      R(r.mulyaankan),
      r.mbRef,
      R(r.labourAmount),
      R(r.materialAmount),
    ])
  );
  return csvJoin(out);
}

/* ═══════════ 3. प्रपत्र-4 — निर्माण कार्यों पर व्यय की गयी सामग्री राशि (audit demo sheet 3) ═══════════ */

export type Prapt4Row = { name: string; qty: number; unit: string; rate: number; cost: number };

export function buildPrapt4(mbLines: MbLine[]): Prapt4Row[] {
  const byItem = new Map<string, Prapt4Row>();
  for (const m of mbLines.filter((x) => x.kind === 'material')) {
    const key = m.itemName.trim() || 'अन्य';
    if (!byItem.has(key)) byItem.set(key, { name: key, qty: 0, unit: '', rate: m.rate, cost: 0 });
    const e = byItem.get(key)!;
    e.qty += m.qty;
    e.rate = m.rate || e.rate;
    e.cost += m.qty * m.rate;
  }
  return [...byItem.values()];
}

export function prapt4Csv(rows: Prapt4Row[], h: FmtHeader) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  out.push(['नाम सामग्री', 'मात्रा', 'इकाई', 'दर', 'कीमत', 'योग']);
  rows.forEach((r) => out.push([r.name, r.qty, r.unit, R(r.rate), R(r.cost), R(r.cost)]));
  const tot = rows.reduce((s, r) => s + r.cost, 0);
  out.push(['योग', '', '', '', R(tot), R(tot)]);
  return csvJoin(out);
}

/* ═══════════ 4. Bank statement grid (bank demo) — tag → post pipeline ke saath ═══════════ */

export function bankStatementCsv(
  lines: { date: string; narration: string; side: string; amount: number; instrument: string; schemeId: string | null; postedTxnId: string | null }[],
  h: FmtHeader
) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  /* v12 #26 — बैंक विवरण में अब **चलता शेष (Running balance)** column भी है */
  out.push(['दिनांक', 'विवरण', 'जमा/नाम', 'राशि', 'चेक/इन्स्ट्रूमेंट', 'चलता शेष (Running Balance)', 'योजना टैग', 'पोस्ट']);
  let run = 0;
  lines.forEach((l) => {
    run += l.side === 'credit' ? l.amount : -l.amount;
    out.push([
      l.date,
      l.narration,
      l.side === 'credit' ? 'जमा' : 'नाम',
      R(l.amount),
      l.instrument || '—',
      R(Math.round(run * 100) / 100),
      l.schemeId || '—',
      l.postedTxnId ? 'हाँ' : 'नहीं',
    ]);
  });
  return csvJoin(out);
}

/* ═══════════ 5. Ledger — standard GP खाता बही (ledger.pdf layout) ═══════════ */

export type LedgerRow = {
  date: string;
  ref: string;
  folio: string;
  party: string;
  detail: string;
  debit: number;
  credit: number;
  running: number;
  /** v13 #10 — किस entry से यह पंक्ति बनी; उस पर tap → सीधा उसी कैशबुक पन्ने पर */
  txnId?: string;
  /** v14 / L1-3 — उस entry का **CB पृष्ठ** (पन्ना नं. · तारीख़); tap → वही पन्ना खुले */
  pageRef?: string;
};

/* ═══════════ v13 #10 — L.F. (Ledger Folio): प्रति-मद auto नंबर ═══════════
   • पहली बार जो मद दिखता है = L.F. 1, दूसरा नया मद = L.F. 2 … (पूरे FY में)
   • कैशबुक की L.F. कॉलम, Excel शीट और खाता बही — तीनों यही संख्या दिखाते हैं
   • किसी भी entry के L.F. पर tap → उसी मद का ledger खुले                          */
export function madKeyOf(t: { workId?: string | null; categoryId?: string | null; schemeId?: string | null }): string {
  if (t.workId) return 'work:' + t.workId;
  if (t.categoryId) return 'cat:' + t.categoryId;
  if (t.schemeId) return 'scheme:' + t.schemeId;
  return 'other';
}

/** पहली बार दिखने के क्रम में हर नए मद को 1,2,3… का folio */
export function buildFolioMap(txs: Pick<Transaction, 'date' | 'createdAt' | 'status' | 'workId' | 'categoryId' | 'schemeId'>[]): Map<string, number> {
  const map = new Map<string, number>();
  const sorted = [...txs]
    .filter((t) => t.status === 'active')
    .sort((a, b) => a.date.localeCompare(b.date) || (a.createdAt || '').localeCompare(b.createdAt || ''));
  for (const t of sorted) {
    const k = madKeyOf(t);
    if (!map.has(k)) map.set(k, map.size + 1);
  }
  return map;
}

/** मद → उसका L.F. नंबर (न मिले तो user ने ख़ुद भरा हुआ folio) */
export function folioFromMap(map: Map<string, number>, t: Pick<Transaction, 'ledgerFolio' | 'workId' | 'categoryId' | 'schemeId'>): string {
  const auto = map.get(madKeyOf(t));
  if (auto) return String(auto);
  return t.ledgerFolio || '';
}

export function buildLedger(
  opening: number,
  txs: Pick<Transaction, 'id' | 'type' | 'date' | 'reference' | 'party' | 'detail' | 'status' | 'amounts' | 'ledgerFolio' | 'medium' | 'createdAt' | 'workId' | 'categoryId' | 'schemeId' | 'pageId'>[],
  fundId?: string,
  /** v14 / L1-3 — pageId → "पन्ना नं. · तारीख़" (ledger का CB पृष्ठ कॉलम) */
  pageOf?: (pageId: string | null) => string
): LedgerRow[] {
  const folioMap = buildFolioMap(txs);
  const rows: LedgerRow[] = [
    { date: '', ref: '', folio: '', party: 'श्री पोते राशि', detail: 'प्रारंभिक शेष', debit: 0, credit: 0, running: opening },
  ];
  let running = opening;
  for (const t of txs.filter((x) => x.status === 'active').sort((a, b) => a.date.localeCompare(b.date))) {
    // transfer = signed per-fund amount (cash −X / bank +X); all-funds view = net 0 → skip
    const amt = fundId ? Number(t.amounts[fundId]) || 0 : sumAmounts(t.amounts);
    if (!amt) continue;
    const signed = t.type === 'expense' ? -amt : amt; // income +, expense −, transfer ± (signed input)
    running += signed;
    /* v10 #5 — विवरण में माध्यम भी दिखे: नकद या बैंक (yojana se alag) */
    const mediumTag = t.medium === 'bank' ? ' · बैंक' : t.medium === 'cash' ? ' · नकद' : '';
    rows.push({
      date: t.date,
      ref: t.reference || '—',
      folio: folioFromMap(folioMap, t),
      party: t.party,
      detail: `${t.detail}${t.detail ? mediumTag : t.medium ? `·${mediumTag}` : ''}`,
      debit: signed < 0 ? Math.abs(signed) : 0,
      credit: signed > 0 ? signed : 0,
      running,
      txnId: t.id,
      pageRef: pageOf ? pageOf(t.pageId ?? null) : '',
    });
  }
  return rows;
}

/**
 * v13 #11 — **बिल की राशि को CC/MB सामग्री के मदों में अनुपातिक बाँटना**
 *   हर मद का हिस्सा = (स्वीकृत मात्रा × दर) ÷ कुल स्वीकृत सामग्री राशि
 *   इस बिल में मात्रा = (बिल राशि × हिस्सा) ÷ दर
 * **रोक (cap):** सारे बिलों में बँटी कुल मात्रा कभी स्वीकृत मात्रा से अधिक नहीं होगी —
 * जहाँ सीमा पूरी हो गई वहाँ `capped: true` और मात्रा अवशिष्ट पर रुक जाती है।
 */
export function allocateBillItems(a: {
  /** इस बिल में बाँटने की राशि */
  amount: number;
  /** CC/MB की स्वीकृत सामग्री पंक्तियाँ */
  sanctioned: { itemName: string; qty: number; rate: number }[];
  /** पहले वाले बिलों में बँट चुकी मात्रा (मद-नाम → मात्रा) */
  alreadyUsed: Record<string, number>;
  /** दर न मिले तो यह (BSR/निविदा दर) */
  rateOf: (itemName: string) => number;
}): { itemName: string; qty: number; rate: number; capped: boolean }[] {
  const rows = a.sanctioned.map((s) => ({
    name: s.itemName,
    sanctioned: Number(s.qty) || 0,
    rate: Number(s.rate) > 0 ? Number(s.rate) : a.rateOf(s.itemName),
  }));
  const totalValue = rows.reduce((s, r) => s + r.sanctioned * r.rate, 0);
  return rows.map((r) => {
    const remaining = Math.max(0, r.sanctioned - (a.alreadyUsed[r.name] || 0));
    const share = totalValue > 0 ? (r.sanctioned * r.rate) / totalValue : 0;
    const want = r.rate > 0 ? (a.amount * share) / r.rate : 0;
    const qty = Math.round(Math.min(want, remaining) * 1000) / 1000;
    return { itemName: r.name, qty, rate: r.rate, capped: want > remaining + 1e-9 };
  });
}

export function ledgerCsv(rows: LedgerRow[], h: FmtHeader) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  /* v14 / K-18 + L1-3 — क्र. सं. + CB पृष्ठ कॉलम जुड़े (final set: क्र · दिनांक · CB पृष्ठ · L.F. · परिचय · जमा · नाम · शेष) */
  out.push(['क्र.', 'दिनांक', 'चेक/DD/वाउचर न.', 'L.F.', 'CB पृष्ठ', 'किस से प्राप्त / किसको भुगतान', 'विवरण', 'जमा', 'नाम', 'शेष']);
  rows.forEach((r, i) => out.push([i, r.date, r.ref, r.folio || '', r.pageRef || '', r.party, r.detail, r.credit ? R(r.credit) : '', r.debit ? R(r.debit) : '', R(r.running)]));
  const dr = rows.reduce((s, r) => s + r.debit, 0);
  const cr = rows.reduce((s, r) => s + r.credit, 0);
  // v14 — योग row = 10 cells (क्र. + CB पृष्ठ के बाद header alignment)
  out.push(['योग', '', '', '', '', '', '', R(cr), R(dr), R(rows[rows.length - 1]?.running || 0)]);
  return csvJoin(out);
}

/* ═══════════ 6. CC — कार्य पूर्णता प्रमाण पत्र (cc demo, 7 pages) ═══════════ */

export const CC_INSTRUCTIONS =
  'मार्गदर्शिका: कार्य का मूल्यांकन ग्रामीण कार्य निर्देशिका 2010 के प्रावधानों अनुसार। ' +
  'अनुमत राशि = स्वीकृत राशि की सीमा में (वास्तविक व्यय, मूल्यांकन राशि) में से जो कम हो।';

export function ccBuild(input: {
  work: Work;
  mbLines: MbLine[];
  bills: Bill[];
  rolls: PakhwadaRoll[];
  txs: Pick<Transaction, 'type' | 'status' | 'workId' | 'amounts'>[];
  fsAmount: number;
  asAmount: number;
}) {
  const labourLines = input.mbLines.filter((m) => m.workId === input.work.id && m.kind !== 'material');
  const materialLines = input.mbLines.filter((m) => m.workId === input.work.id && m.kind === 'material');
  /* MB श्रम मद (सीधे MB लाइनों से) — पृष्ठ 1 में तभी इस्तेमाल होता है जब कोई MR दर्ज न हो */
  const mbLabour = labourLines.reduce((s, m) => s + m.qty * m.rate, 0);
  /* ═══ v13 #3 — निविदा दर में कटौती (Tender rate %): **सिर्फ़ सामग्री** के BSR दर पर लागू ═══
     v14 / K-9 — अब **signed %**: नकारात्मक = BSR से नीचे (निविदा में कटौती),
     धनात्मक = BSR से ऊपर।  निविदा दर = BSR दर × (1 − % / 100)
     →  सीमेंट ₹100 और कटौती 2% = ₹98 · ऊपर +2% = ₹102
     श्रमिक / कारीगर (labour & karigar) की दर पर कोई असर नहीं — वे सीधे BSR दर से। */
  const tenderPct = Math.max(-100, Math.min(100, Number(input.work.tenderRatePct) || 0));
  const tenderRateOf = (rate: number, kind: 'material' | 'labour' | 'artisan' = 'material') =>
    kind === 'material' && tenderPct !== 0 ? Math.round(rate * (1 - tenderPct / 100) * 100) / 100 : rate;
  const material = materialLines.reduce((s, m) => s + m.qty * tenderRateOf(m.rate, m.kind), 0);
  /* निविदा कटौती से पहले की (सीधी BSR) सामग्री राशि — फ़र्क़ दिखाने के लिए */
  const materialBsr = materialLines.reduce((s, m) => s + m.qty * m.rate, 0);
  /* ═══ v14 / L1-16 + L1-17 (QL1, QL9 — hamesha AUTO-derive) ═══
     पृष्ठ 1 की "अ. श्रम मद राशि" = **पृष्ठ 3 के सभी MR का योग**
     (MR na ho to MB श्रम लाइनें) · "ब. सामग्री मद राशि" = पृष्ठ 4 का material योग
     (निविदा % लगा कर, नहीं तो चुनी हुई BSR)। इन्हें कभी हाथ से नहीं बदला जाता। */
  const rollWage = input.rolls
    .filter((r) => r.workId === input.work.id)
    .reduce((s, r) => s + (r.mateCount * r.days * r.wageMate + r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled), 0);
  const labour = rollWage > 0 ? rollWage : mbLabour;
  const mulyaankan = labour + material;
  /* लेखे अनुसार राशि = श्रम + सामग्री (यही पृष्ठ 1 की "मूल्यांकन के अनुसार कुल राशि") */
  const lekhyaCap = mulyaankan;
  const paid = input.bills.filter((b) => b.workId === input.work.id).reduce((s, b) => s + b.amount, 0);
  const actualExpense = input.txs
    .filter((t) => t.status === 'active' && t.type === 'expense' && t.workId === input.work.id)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
  /* v14 / K-6 — MB की कुल मूल्यांकन राशि (MB screen से भरी) = CC की छत */
  const mbValuation = Math.max(0, Number(input.work.mbValuation) || 0);
  const mbCap = mbValuation > 0 ? mbValuation : Infinity;
  // अनुमत राशि = min(FS, AS, लेखे/मूल्यांकन, वास्तविक व्यय, MB मूल्यांकन) — कभी अधिक नहीं
  const allowable = Math.min(
    input.fsAmount > 0 ? input.fsAmount : Infinity,
    input.asAmount > 0 ? input.asAmount : Infinity,
    lekhyaCap > 0 ? lekhyaCap : Infinity,
    actualExpense > 0 ? actualExpense : Infinity,
    mbCap
  );
  const finite = Number.isFinite(allowable) ? allowable : 0;
  /* वास्तविक व्यय, लेखे अनुसार (श्रम+सामग्री) से निकल गया → पृष्ठ 1 पर लाल चेतावनी */
  const lekhyaOver = Math.max(0, Math.round((actualExpense - lekhyaCap) * 100) / 100);
  /* v14 / K-6 — CC राशि MB मूल्यांकन से अधिक → लाल चेतावनी + रोक */
  const mbOver = mbValuation > 0 ? Math.max(0, Math.round((mulyaankan - mbValuation) * 100) / 100) : 0;
  /* ═══ v12 #17 + #22 — स्वीकृत सामग्री राशि और आकस्मिक व्यय 2% सीमा ═══ */
  const priorMat = Number(input.work.materialPrior) || 0;
  const priorLab = Number(input.work.labourPrior) || 0;
  const sanctionedMaterial =
    priorMat > 0 ? priorMat : input.fsAmount > priorLab ? input.fsAmount - priorLab : 0;
  const contingency = Math.max(0, input.work.contingencyAmount || 0);
  /** अधिकतम आकस्मिक = MB सामग्री राशि का 2% */
  const contingencyCap = Math.round(material * 0.02 * 100) / 100;
  return {
    labour,
    /* v14 / K-2 + L1-16 — श्रम मद के दोनों आधार (कहाँ से आया, यह दिखाने के लिए) */
    mbLabour,
    rollWage,
    material,
    /* v13 #3 — कटौती से पहले की सीधी BSR सामग्री राशि + लगाई गई निविदा % (signed) */
    materialBsr,
    tenderPct,
    tenderRateOf,
    mulyaankan,
    /* v14 / L1-18 (QL1) — "लेखे अनुसार" राशि = श्रम + सामग्री; allowed इससे अधिक नहीं */
    lekhyaCap,
    lekhyaOver,
    /* v14 / K-6 — MB कुल मूल्यांकन + उससे CC का अधिक होना */
    mbValuation,
    mbOver,
    /* v12 #17 — MB की सामग्री राशि स्वीकृति से बाहर? */
    sanctionedMaterial,
    materialOver: sanctionedMaterial > 0 && material > sanctionedMaterial ? material - sanctionedMaterial : 0,
    /* v12 #22 — आकस्मिक व्यय ≤ 2% (सामग्री राशि के) */
    contingency,
    contingencyCap,
    contingencyOver: contingency > contingencyCap ? Math.round((contingency - contingencyCap) * 100) / 100 : 0,
    paid,
    actualExpense,
    allowable: finite,
    residualMaterial: Math.max(0, finite - paid),
    mandays: input.rolls.reduce(
      (acc, r) => ({
        mate: acc.mate + r.mateCount * r.days,
        skilled: acc.skilled + r.skilledCount * r.days,
        unskilled: acc.unskilled + r.unskilledCount * r.days,
        wage: acc.wage + (r.mateCount * r.days * r.wageMate + r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled),
      }),
      { mate: 0, skilled: 0, unskilled: 0, wage: 0 }
    ),
  };
}

export function ccCsv(
  c: ReturnType<typeof ccBuild>,
  h: FmtHeader,
  work: { name: string; sanctionRef: string; ward: string }
) {
  const out: (string | number)[][] = [];
  out.push(head(h));
  out.push([]);
  out.push(['कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ) — ' + work.name]);
  out.push([]);
  out.push(['पृष्ठ 1 — कार्य पूर्णता प्रमाण पत्र']);
  out.push(['1- कार्य का नाम', work.name]);
  out.push(['4- वास्तविक व्यय (लेखे अनुसार)', R(c.actualExpense)]);
  out.push(['5- माप पुस्तिका में मूल्यांकन राशि', R(c.mulyaankan)]);
  out.push(['8- कुल अनुमत राशि (min rules)', R(c.allowable)]);
  out.push(['भुगतान योग्य राशि / शेष', R(c.residualMaterial)]);
  out.push([]);
  out.push(['पृष्ठ 2 — उपयोगिता प्रमाण पत्र (UC)']);
  out.push(['कुल व्यय', R(c.actualExpense), 'अनुमत', R(c.allowable)]);
  out.push([]);
  out.push(['पृष्ठ 3 — श्रमिकों पर व्यय का विवरण (पाक्षिक मस्टरोल)']);
  out.push(['कारीगर (कुशल) मानव दिवस', c.mandays.skilled]);
  out.push(['श्रमिक (अकुशल) मानव दिवस', c.mandays.unskilled]);
  out.push(['कुल श्रम व्यय (mandays × wage rate)', R(c.mandays.wage)]);
  out.push(['MB श्रम मद योग', R(c.labour)]);
  out.push(['नोट', 'मानव दिवस = श्रमिक संख्या × दिन; व्यय = मानव दिवस × दर (निर्देशिका अनुसार)']);
  out.push([]);
  out.push(['पृष्ठ 4 — सामग्री पर व्यय का विवरण (MB अनुसार)']);
  out.push(['सामग्री योग', R(c.material)]);
  out.push([]);
  out.push(['पृष्ठ 5 — तकनीकी निरीक्षण रिपोर्ट']);
  out.push(['मूल्यांकन जांच', 'ग्रामीण कार्य निर्देशिका 2010 अनुसार']);
  out.push([]);
  out.push(['पृष्ठ 6 — पूर्ण कार्य का फोटो + हस्ताक्षर']);
  out.push(['पृष्ठ 7 — पहले व कार्य के दौरान फोटो']);
  out.push([]);
  out.push(['हस्ताक्षर — सरपंच', '', 'ग्राम विकास अधिकारी', '', 'कनिष्ठ अभियंता']);
  return csvJoin(out);
}

export { formatINR };
