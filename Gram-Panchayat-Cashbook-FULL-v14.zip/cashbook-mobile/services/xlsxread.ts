/**
 * xlsxread.ts — असली `.xlsx` file पढ़ो (जो Excel/Google Sheets में बनी हो)।
 *
 * Instruction #15: बैंक statement `.xlsx` अपलोड करो → app में statement + cashbook भर जाए।
 * Instruction #19: backup `.xlsx` restore करो।
 *
 * कोई XML library नहीं है → छोटा, केवल OOXML के लिए बना scanner (regex based)।
 */
import { unzip, bytesToText } from './zipread';
import type { SheetCell } from './xlsx';

export type ParsedSheet = { name: string; rows: SheetCell[][] };

/* ─────────────── tiny XML helpers ─────────────── */

function decodeEntities(s: string): string {
  return s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&amp;/g, '&');
}

function textOf(xml: string): string {
  let out = '';
  const re = /<t[^>]*>([\s\S]*?)<\/t>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) out += decodeEntities(m[1]);
  return out;
}

/** "BC12" → colIndex 54 (A=0) */
function colIndex(ref: string): number {
  const m = /^([A-Za-z]+)/.exec(ref);
  if (!m) return 0;
  let n = 0;
  for (const ch of m[1].toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

function attr(attrs: string, name: string): string | null {
  const m = new RegExp(`${name}\\s*=\\s*"([^"]*)"`).exec(attrs);
  return m ? m[1] : null;
}

/* ─────────────── XLSX → sheets ─────────────── */

function sharedStrings(map: Map<string, Uint8Array>): string[] {
  const raw = map.get('xl/sharedStrings.xml');
  if (!raw) return [];
  const xml = bytesToText(raw);
  const out: string[] = [];
  const re = /<si\b[^>]*>([\s\S]*?)<\/si>/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) out.push(textOf(m[1]));
  return out;
}

function sheetRows(xml: string, shared: string[]): SheetCell[][] {
  const rows: SheetCell[][] = [];
  const rowRe = /<row\b([^>]*)>([\s\S]*?)<\/row>|<row\b([^>]*)\/>/g;
  let rm: RegExpExecArray | null;
  while ((rm = rowRe.exec(xml))) {
    const inner = rm[2] || '';
    const rowNo = rm[1] || rm[3] || '';
    const rIdx = parseInt(/(\d+)/.exec(attr(rowNo, 'r') || '')?.[1] || '0', 10);
    const cells: SheetCell[] = [];
    const cellRe = /<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g;
    let cm: RegExpExecArray | null;
    while ((cm = cellRe.exec(inner))) {
      const cAttrs = cm[1];
      const cInner = cm[2] || '';
      const ref = attr(cAttrs, 'r') || '';
      const type = attr(cAttrs, 't') || '';
      const ci = ref ? colIndex(ref) : cells.length;
      let val: SheetCell = null;
      if (type === 'inlineStr') {
        val = textOf(cInner);
      } else {
        const vm = /<v>([\s\S]*?)<\/v>/.exec(cInner);
        const rawV = vm ? decodeEntities(vm[1]) : '';
        if (type === 's') {
          const idx = parseInt(rawV, 10);
          val = Number.isFinite(idx) ? (shared[idx] ?? '') : '';
        } else if (type === 'b') {
          val = rawV === '1' || rawV.toLowerCase() === 'true';
        } else if (type === 'str' || rawV === '') {
          val = rawV === '' ? null : rawV;
        } else {
          const n = Number(rawV);
          val = Number.isFinite(n) ? n : rawV;
        }
      }
      while (cells.length < ci) cells.push(null);
      cells[ci] = val;
    }
    const at = rIdx > 0 ? rIdx - 1 : rows.length;
    while (rows.length < at) rows.push([]);
    rows[at] = cells;
  }
  // ख़ाली trailing rows हटाओ
  while (rows.length && rows[rows.length - 1].every((c) => c === null || c === undefined || c === '')) {
    rows.pop();
  }
  return rows;
}

/** पूरी `.xlsx` file → सारी sheets (`{name, rows}`) */
export function parseXlsx(buf: Uint8Array): ParsedSheet[] {
  const entries = unzip(buf);
  const map = new Map<string, Uint8Array>();
  for (const e of entries) map.set(e.name.replace(/^\.\//, ''), e.data);

  const shared = sharedStrings(map);

  // workbook: sheet order + rId
  type Wb = { name: string; rid: string };
  const wbs: Wb[] = [];
  const wbRaw = map.get('xl/workbook.xml');
  if (wbRaw) {
    const xml = bytesToText(wbRaw);
    const re = /<sheet\b([^>]*)\/?>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(xml))) {
      const a = m[1];
      const name = attr(a, 'name') || `Sheet${wbs.length + 1}`;
      const rid = attr(a, 'r:id') || attr(a, 'id') || '';
      wbs.push({ name, rid });
    }
  }

  // rels: rId → target
  const relMap = new Map<string, string>();
  const relRaw = map.get('xl/_rels/workbook.xml.rels');
  if (relRaw) {
    const xml = bytesToText(relRaw);
    const re = /<Relationship\b([^>]*)\/?>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(xml))) {
      const a = m[1];
      const id = attr(a, 'Id');
      const target = attr(a, 'Target');
      if (id && target) relMap.set(id, target);
    }
  }

  const resolve = (target: string): string => {
    if (target.startsWith('/')) return target.slice(1);
    if (target.startsWith('xl/')) return target;
    return `xl/${target}`;
  };

  const sheets: ParsedSheet[] = [];
  if (wbs.length) {
    for (const s of wbs) {
      const path = s.rid ? resolve(relMap.get(s.rid) || '') : '';
      const raw = path ? map.get(path) : undefined;
      if (!raw) continue;
      sheets.push({ name: s.name, rows: sheetRows(bytesToText(raw), shared) });
    }
  }
  if (!sheets.length) {
    // fallback: जो भी worksheets मिलें
    for (const [name, raw] of map) {
      if (!/^xl\/worksheets\/sheet\d+\.xml$/.test(name)) continue;
      sheets.push({ name, rows: sheetRows(bytesToText(raw), shared) });
    }
  }
  if (!sheets.length) throw new Error('इस .xlsx में कोई sheet नहीं मिली');
  return sheets;
}

/** सिर्फ़ पहली sheet के rows (bank statement import जैसे सीधे काम के लिए) */
export function parseXlsxFirstSheet(buf: Uint8Array): SheetCell[][] {
  return parseXlsx(buf)[0].rows;
}
