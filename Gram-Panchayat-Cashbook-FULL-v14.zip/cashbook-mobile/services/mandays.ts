/**
 * mandays.ts — Man-days distribution engine (old master B §7, merged PART V.2 #8)
 * नियम: पूरा मान-दिन ही; राशि ≤ MB component; BSR −5..15% safe band;
 * pakhwada = 15 − रविवार − छुट्टियाँ; हर calc audit में।
 *
 * v14 / L1-5 — safe band अब **−5% से −15%** (purana −10…−20 hata diya).
 * v14 / L1-10 + QL4 — MR की अवधि **15 दिन**; कार्य दिवस = 15 − रविवार − छुट्टी
 *                      → **koi holiday nahi = 13 दिन**, ek holiday = 12 दिन.
 *
 * v10 #19 — **छुट्टी का विकल्प हटाया.** अब हर MR / पखवाड़े में तीन राष्ट्रीय
 * छुट्टियाँ अपने-आप लगती हैं: 26 जनवरी · 15 अगस्त · 02 अक्टूबर।
 * v10 #19/#24 — **पखवाड़े के मान-दिवस default 12, अधिकतम 13** (13 सिर्फ़
 * निकटतम-राशि वाली गणना में, जब 12 पर बहुत बड़ा अंतर बचे)।
 */
import type { BsrRate, HolidayEntry } from '@/types/models';
import { toIsoLocal } from './pageEngine';

/** v10 #19 — तीन निश्चित राष्ट्रीय छुट्टियाँ (MM-DD), हर MR में अपने-आप */
export const FIXED_HOLIDAYS: { mmdd: string; name: string }[] = [
  { mmdd: '01-26', name: 'गणतंत्र दिवस (26 जनवरी)' },
  { mmdd: '08-15', name: 'स्वतंत्रता दिवस (15 अगस्त)' },
  { mmdd: '10-02', name: 'गांधी जयंती (02 अक्टूबर)' },
];

/** v10 #19/#24 — पखवाड़े के मान-दिवस: default 12, अधिकतम 13 */
export const DEFAULT_PAKHWADA_DAYS = 12;
export const MAX_PAKHWADA_DAYS = 13;

export function pakhwadaWorkingDays(
  fromDate: string,
  toDate: string,
  holidays: HolidayEntry[]
): { sundays: number; holidays: number; total: number; working: number } {
  const from = new Date(fromDate + 'T00:00:00');
  const to = new Date(toDate + 'T00:00:00');
  let total = 0;
  let sundays = 0;
  const holidaySet = new Set(holidays.map((h) => h.date));
  const fixed = new Set(FIXED_HOLIDAYS.map((h) => h.mmdd));
  let holidayCount = 0;
  const d = new Date(from);
  while (d <= to) {
    total++;
    const dow = d.getDay();
    // bug fix: toISOString (UTC) IST me previous din deta tha → holidays kabhi match nahi hote the
    const iso = toIsoLocal(d);
    const mmdd = iso.slice(5);
    if (dow === 0) sundays++;
    else if (holidaySet.has(iso) || fixed.has(mmdd)) holidayCount++;
    d.setDate(d.getDate() + 1);
  }
  return { total, sundays, holidays: holidayCount, working: total - sundays - holidayCount };
}

/**
 * BSR **−5% … −15%** safe band (v14 / L1-5 — purana band −10…−20 tha).
 * Recommended rate range from BSR. rate ≤ BSR ka hard cap wahi rehta hai.
 */
export function bsrBand(bsr: number) {
  return { min: Math.round(bsr * 0.85), max: Math.round(bsr * 0.95), bsr };
}

/** Rate validation: BSR se zyada kabhi nahi; BSR ke kareeb = warning (recoverable risk). */
export function rateCheck(rate: number, bsr: number | null): { ok: boolean; warn: string | null } {
  if (bsr == null) return { ok: true, warn: null };
  if (rate > bsr) return { ok: false, warn: `दर ₹${rate} BSR (₹${bsr}) से अधिक — अनुमति नहीं` };
  if (rate > bsrBand(bsr).max) return { ok: true, warn: `दर BSR−5% से ऊपर है — ऑडिट में recoverable बन सकती है (safe band ₹${bsrBand(bsr).min}–₹${bsrBand(bsr).max})` };
  return { ok: true, warn: null };
}

export type MandayCombo = {
  role: 'karigar' | 'labour' | 'mate';
  workers: number;
  days: number;
  rate: number;
  amount: number;
  remaining: number;
};

/** Amount ≤ MB component; पूरा मान-दिन; jitna kareeb utna behtar. Combos suggest karta hai. */
export function suggestCombos(
  targetAmount: number,
  rate: number,
  maxWorkers: number,
  maxDays: number,
  role: MandayCombo['role'] = 'labour'
): MandayCombo[] {
  const combos: MandayCombo[] = [];
  if (!(rate > 0) || !(targetAmount > 0)) return combos;
  for (let w = 1; w <= maxWorkers; w++) {
    for (let d = 1; d <= maxDays; d++) {
      const amount = w * d * rate;
      if (amount <= targetAmount + 0.001 && w * d >= Math.floor(targetAmount / rate) - 2) {
        combos.push({ role, workers: w, days: d, rate, amount, remaining: Math.round((targetAmount - amount) * 100) / 100 });
      }
    }
  }
  combos.sort((a, b) => a.remaining - b.remaining);
  return combos.slice(0, 8);
}

export function findBsr(bsrRates: BsrRate[], year: string, itemName: string): BsrRate | null {
  const q = itemName.trim().toLowerCase();
  const exact = bsrRates.find((b) => b.year === year && b.itemName.trim().toLowerCase() === q);
  if (exact) return exact;
  return bsrRates.find((b) => b.itemName.trim().toLowerCase() === q) || null;
}

/**
 * instruction #26 — default BSR दर: कारीगर ₹600, श्रमिक ₹260.
 * BSR master me entry na ho tabhi ye lagti hai (isliye manday हमेशा बनते हैं).
 */
export const DEFAULT_ROLE_RATE: Record<string, number> = { karigar: 600, labour: 260, mate: 400 };

/**
 * instruction #30 (bug) — role 'labour' tha par BSR item ka naam 'श्रमिक' है,
 * इसीलिए दर कभी मिलती नहीं थी और manday calculate नहीं होते थे.
 */
const ROLE_BSR_NAMES: Record<string, string[]> = {
  labour: ['श्रमिक', 'labour', 'लेबर', 'मजदूर'],
  karigar: ['कारीगर', 'karigar', 'कुशल'],
  mate: ['मेट', 'mate'],
};

/**
 * v13 #1 — **सिर्फ़ चुने हुए वर्ष की BSR.** पहले `findBsr` दूसरे किसी भी वर्ष की
 * दर return कर देता था, इसीलिए dropdown में 2027-28 चुनने पर भी 2026-27 की दर से
 * ही मान-दिवस बनते थे। अब वर्ष strictly लागू; उस वर्ष में दर न हो तो Worker
 * master (उसी वर्ष) → default (कारीगर ₹600 / श्रमिक ₹260)।
 */
function yearBsr(bsrRates: BsrRate[], year: string, itemName: string): BsrRate | null {
  const q = itemName.trim().toLowerCase();
  return bsrRates.find((b) => b.year === year && b.itemName.trim().toLowerCase() === q) || null;
}

/** Role reference rate (सिर्फ़ चुना हुआ वर्ष): BSR → Worker master (उसी वर्ष) → default */
export function referenceRate(
  bsrRates: BsrRate[],
  workerRates: { role: string; year: string; dailyRate: number }[],
  year: string,
  role: string
): { rate: number | null; source: 'BSR' | 'Worker' | 'Default' | null } {
  for (const name of ROLE_BSR_NAMES[role] || [role]) {
    const b = yearBsr(bsrRates, year, name);
    /* v13 #2 — दर 0 भी एक वैध मान है (0 = इस वर्ष यह दर लागू नहीं);
       0 होने पर Worker/Default पर चले जाओ ताकि गलत वर्ष की दर कभी न आए। */
    if (b && b.rate > 0) return { rate: b.rate, source: 'BSR' };
  }
  const w = workerRates.find((x) => x.year === year && x.role === role && x.dailyRate > 0);
  if (w) return { rate: w.dailyRate, source: 'Worker' };
  const def = DEFAULT_ROLE_RATE[role];
  if (def) return { rate: def, source: 'Default' };
  return { rate: null, source: null };
}

export { formatINR } from './pageEngine';
