# Gram Panchayat Cashbook — PROJECT MASTER (consolidated)

> Consolidated from `PROJECT_MASTER.md` + `PROJECT_MASTER old.md` + user's 15 latest instructions (2026-09). Supersedes both.
>
> **Document purpose:** अब यही एक authoritative requirements + design file है। Sections 0–20 = baseline (`PROJECT_MASTER.md`) का 1:1 mapping (same order/naming)। Section A = user के नवीनतम 15 निर्देश। Section B = पुरानी `.md` से वे instructions जो current spec cover नहीं करता (restore/obsolete verdict सहित)। Section C = old vs new contradictions + decision। Section D = v6 implementation status।
>
> **Sources read:** `PROJECT_MASTER.md` (749 lines), `PROJECT_MASTER old.md` (1926 lines), `F:\Android app\cashbook\` directory listing (no other `.md` exists there — only xlsx/pdf/html/zip), `extracted\cashbook-mobile\app\index.tsx`, `services\*`, `types\models.ts`, `context\AppStore.tsx`.
>
> **Status:** Requirements FINAL for Phase 1; 15 latest instructions folded in (2026-09).
> **Last updated:** 25-09-2026 (this consolidated file created).

---

## 0. Scope, platforms, hard rules   (from baseline)

- **Product:** Hindi-first Android digital cashbook for a Gram Panchayat (Expo / React Native, `com.grampanchayat.cashbook`), **offline-first**, single-device, **Admin-only** (D6).
- **अनिवार्य rules (never violate):**
  1. एक ही `.md` = authoritative spec (अब यही file)।
  2. हर screen के corner पर screen number badge (`S-01` … `S-n`); **App Settings हमेशा अंतिम screen number** (B32 restores bottom-right muted + toggle detail).
  3. FY 1 April → 31 March; **FY isolation** — पुराने FY की transaction rows कभी नए FY में नहीं दिखेंगी; सिर्फ़ closing balances carry (D17).
  4. **SAF `Documents/Cashbook/...` storage mandatory** (D13); backup कभी `Android/data` में नहीं (instruction #14 / B16).
  5. **PDF/Excel share = plain white background** (D14); printed documents **हमेशा हिंदी**, UI English/Hinglish (V.2#13).
  6. Summary lines (श्री पोते राशि, आय योग, पूर्व पोते, व्यय योग, बचत पोते, महायोग) **कभी manually editable नहीं** (C.5 / 19.11).
  7. हर report/page पर compulsory: `Export Excel | Export PDF | Share Excel | Share PDF | Print` (Part F) — instruction #6/#12 के साथ।
  8. Devanagari PDF: Noto Sans Devanagari (+Condensed for grid), **Mangal banned**, `OFL.txt` required, shaping-capable renderer only (V.2#1 / B10).
  9. **Money:** cashbook me paise-precision (2 decimal) store/calculate; display जगह rupee round (Part M, old §12.7).
  10. Demo/sample files = **visual source of truth** for formats (Part U): user की upload की हुई Excel/PDF जैसा ही बनेगा।

---

## 1. Product vision  (baseline PART A)

```text
Digital Cashbook + Side-by-side Income|Expense pages + Configurable N-line pages (default 25)
+ Dynamic fund/scheme columns + Scheme-required multi-column amounts + Category/Sub/Sub-sub taxonomy
+ Work / MB / Bills / CC (Phase 1) + Bank statement → tag → auto entry (Phase 1)
+ Auto ledgers & reports + Annual & till-date गोशवारा + PDF + Excel export/share (compulsory)
+ Grid + form data entry + Backdated correction + audit trail + SAF Documents/Cashbook storage
+ Backup / restore / phone transfer + Period lock + FY closing + Admin-only (multi-role later)
```

---

## 2. Financial year  (baseline PART B)

- FY window 1 Apr → 31 Mar; हर FY का data isolated (pages/statements/attachments under FY id).
- **Carry-forward only balances:** previous FY closing (fund-wise नकद + bank / scheme) → new FY opening **श्री पोते**; previous FY transaction rows never appear.
- New scheme in new year: opening may be manual; Page 1 श्री पोते row shows **Carry-forward vs Manual** indicator (screen + print).
- 31 March: annual गोशवारा → year-close checklist → backup → lock → archive read-only; locked-FY unauthorized edit blocked, corrections only via correction entries + audit.
- Old spec extras still valid: पुराने year archive/read-only; year lock से पहले validation + backup (old §2 — covered).

---

## 3. Cashbook page engine  (baseline PART C)

**Visual source of truth:** user-provided Excel cashbook PDF `DOC-20260622-WA0002` (GP काबजा, पं.समि. साबला, डूंगरपुर, FY 2026-27). Screen **and** PDF/Excel export must match that grid — not a vertical list (C.2 rejects list UI).

- **Page frame (C.1):** `कार्यालय ग्राम पंचायत` + Panchayat name; `पंचायत समिति` + block; `जिला` + district; `वित्तीय वर्ष` + label; `पृष्ठ संख्या` automatic top-right. Landscape preferred for print/PDF; light register tint on screen, **plain white on share** (D14). *No date-range under header; date only on श्री पोते line → B24.*
- **Horizontal split (C.2):** exactly two equal halves — प्राप्ति (left) | भुगतान (right), thick vertical rule, full Excel-like grid lines.
- **Columns (C.3):** Left = दिनांक · चेक/DD/इन्वॉइस नं. व दिनांक · किस से प्राप्त किया · विवरण · L.F. · रकम(नकद + बैंक: SFC, FFC, OWN FUND/INT, MP/MLA/TAD, Other/Security/DD, Total). Right = दिनांक · वाउचर नं. व दिनांक · भुगतान किसको किया (चेक न./मस्टर रोल न.) · किस कार्य पेटे · L.F. · परिसंपत्ति रजिस्टर पृष्ठ सं. · रकम (same fund set). Fund heads dynamic (D5) — default 11 columns; add/rename/archive से बढ़/घट.
- **Row map (C.4):** opening row on प्राप्ति side = **श्री पोते राशि** (भुगतान side blank); middle = blank/txn lines; last 3 rows always present, never edited: **आय योग | व्यय योग**, **पूर्व पोते | बचत पोते**, **महायोग | महायोग**. Wording lock: bottom-left = **पूर्व पोते** (not second श्री पोते).
- **Lines (C.4.1 / D1–D3):** default L = **25** (settings से बदल सकते हैं), `txn lines = L − 4`; new page auto when full **+ manual Add Page** (D9); empty days skip + optional empty-day page (D10).
- **Formulas (C.5):** per fund `f` — आय योग = txn sum; पूर्व पोते = श्री पोते; महायोग_L = आय योग + पूर्व पोते; व्यय योग = txn sum; बचत पोते = महायोग_L − व्यय योग; महायोग_R = व्यय योग + बचत पोते; **both महायोग equal (validation)**.
- **Carry-forward (C.6):** next page/next active date श्री पोते = previous page बचत पोते (per fund). FY change: closing balances only.
- **Mobile UI (C.7):** side-by-side grid (not list); horizontal + vertical scroll; tap cell/`+ Entry` → form; long-press → edit/cancel; badge S-07. *Thin layout + zoom → instruction #10/#15 (Section A).*
- **Export (C.8):** PDF reproduces grid (white, embedded Devanagari); Excel sheet “Cashbook Print” with same headers as C.3.

---

## 4. Income & expense entry  (baseline PART D)

- **Income fields (D.1):** date, invoice no/date, किससे प्राप्त, details, L.F., multi-fund amounts, auto total, **scheme required**, category path, note, attachment. Source list editable: Govt, व्यक्ति, Bank, संस्था, Firm/Vendor, अन्य (+ custom description when अन्य → **B3**).
- **Expense fields (D.2):** date, voucher no/date, party/vendor, **Work या Other**, work name / other category path, L.F., multi-fund amounts, auto total, scheme required, note, attachment, payment mode Cash/Bank. Party master = select/add/search + vendor-wise reports. Work = name required, master select/add, optional code/ward/sanction ref. Other = category tree (Stationery, Printing, भत्ता, बिजली, सफाई, ईंधन, यात्रा, मरम्मत, डाक, बैठक, मोबाइल/इंटरनेट, अन्य, …).
- **Work | Other chooser, in-dropdown “नया work add”, category add/edit/delete यहीं से → instruction #7; work form scheme + AS/TS/FS + dates + MB status → instruction #8; vendor dropdown + in-place add vendor → instruction #5; minimal entry fields + one scheme per entry → instruction #9 (Section A).**
- **Repeat entry (D.3):** “पिछली entry से copy” template (monthly बिजली/सफाई) — implemented.
- **Cancel (D.4):** reason required; print red strikethrough; excluded from totals; stays in audit.
- Defaults: **scheme = SFC**; without scheme save blocked; same-day total expense ≤ that day income-side महायोग; per-scheme negative = FY toggle (default OFF) (D4/D8, old 19.6).

---

## 5. Category / subcategory / sub-subcategory  (baseline PART E)

- Max 3 levels: Category → Subcategory → Sub-sub-category; separate/namespaced trees for Income & Expense (+ Work classification as needed).
- CRUD in Cashbook Settings (S-xx Category tree manager); node in use → **archive, not hard-delete** (old rows keep history).
- Every txn should carry deepest applicable path; incomplete path flaggable in Monthly Check.
- Used for: गोशवारा grouping, ledgers, reports, “same path” txn discovery.

---

## 6. Auto ledgers & reports  (baseline PART F)

- From **first saved txn** of an FY, ledger/report views exist (may show one row). **No “generate report” step.** Every add/edit/cancel/category change → aggregates refresh. Empty state = why + steps.
- Compulsory share row: `Export Excel | Export PDF | Share Excel | Share PDF | Print`.
- Report catalogue (23): page-wise, date-wise, daily/weekly/monthly/range, full FY, income, expense, work-wise, other-category, vendor-wise, fund/scheme-wise, L.F.-wise, category-wise, monthly dashboard, गोशवारा (till-date + annual), backdated, edited/corrected, cancelled, audit trail, validation/incomplete, reconciliation, attachments, pending verification, search results.
- **Contextual reports** on every details screen + drill-down back to source (both directions).
- Excel = editable workbook (multiple sheets, filters, freeze, Hindi headings, formulas) — *default 12-sheet set → B9*. PDF = configured line layout, landscape options, embedded Devanagari, white background, optional watermark/signatures — *full option set → B10*.
- Extra ledgers from old spec: **Material item-wise ledger (Stock Register)**, **labour ledger**, **scheme detail screen**, **fee ledgers (count + amount + list)** → B28.

---

## 7. Bank statement  (baseline PART G, Phase 1)

- Bank account master; upload PDF (password unlock) → AI/OCR → **editable grid** (user corrects before post); tag: scheme, work/category, vendor, लेखा शीर्ष, टिप्पणी (instruction #13); grouping rules (multi-line one instrument), **D−1 date rule**, instrument number; post → structured cashbook entries; month locked for re-upload when entries exist **and** verified; **no bank→cash withdrawal**; optional **Cash → Bank deposit** entry type; files under SAF FY folder.
- Field layout = user's uploaded Excel (दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष) → instruction #13 (Section A).
- Full engine rules (credit placement, 10–15-day grouping window, labour consolidation, account auto-detect/IFSC, duplicate-month warning, register print, UTR reconciliation) → **B25/B26** (restored).

---

## 8. Works, MB, Man-days, Bills, CC  (baseline PART H, Phase 1)

- Ongoing works list with **scheme-wise grouping/filter tabs**; add old work with prior material/labour spend + optional bill-wise history; work payments list → bills → material lines.
- **MB:** मद-वार material + कारीगर + labour; **total valuation**; **material vs labour grouping + कारीगर toggle (default labour)** → instruction #3 (Section A).
- **Man-days / master roll:** named workers and group rows (5 labour × 12 days); pakhwada = 15d − Sundays − holidays (Holiday master), manual override; **full man-days only**; amount ≤ MB component; closer-better rule; app auto-suggests combos (trial-and-error); calc audit trail (rate, man-days, BSR year) → **B37**; rate ≤ BSR with −10…−20% safe band guidance → **B36** (sanction-year default still open = C2).
- **Manday sanction inside sanction** (desired wage rate + man-days auto-calc) → instruction #4 (Section A).
- **Bill register** date-wise: bill date + cashbook payment date + page ref.
- **CC — 7 pages:** (1) Completion certificate (AS/TS/FS, MB refs, valuations, allowable = min rules) (2) UC (3) Labour by pakhwada (4) Material as per MB (5) Technical verification (6) Completion photo + signatures (7) Before & during photos. Output **exactly in user's uploaded Excel format** + share PDF/Excel → instruction #6 (Section A).
- **Live status residual:** after MB = CC allowable − payments (material/labour separate); before MB from FS; special toggle when MB labour > FS labour.
- Masters: BSR (year-wise rates, old years read-only, prefilled items: सीमेंट, रेत, गिट्टी 40/20/12 मिमी, पत्थर, ईंट…), Workers/roles (year-wise), Items (whole/decimal flags, last-bill, basic), Holidays (pakhwada).
- Pending decisions from old spec: material-first payment enforcement (C3), last-bill item list (C4), qty whole/decimal (C5), excess-payment live status → **B38**.

---

## 9. गोशवारा  (baseline PART I)

- **Till date** from FY Home; **annual 31 March** classified income (left) | expense (right) — **always two-sided** like user's uploaded Excel → instruction #11 (Section A).
- Bottom: आय योग, प्रारंभिक बैंक/नकद; व्यय योग, अंतिम बैंक/नकद; महायोग equality check (mismatch → warning/close block).
- Tap head → ledger of that head for the year (implemented).
- Optional monthly reminder (e.g. 5th) to share PDF; **one-tap WhatsApp share to पं.समि./BDO** → **B34**.

---

## 10. Dashboard & Monthly check  (baseline PART J)

- **FY Home:** FY, opening, income, expense, current balance, pages, pending verification, missing attachments, unbalanced/incomplete flags. Quick actions: Add Income/Expense, Cashbook, Reports, Backup, Bank, Works (+ Current Page / Search / Export / Reconciliation → **B11**). Tiles include Material Ledger & Schemes → **B28**.
- **Monthly check:** lists **all** transactions of the period (not only warnings); missing scheme / category path highlighted + filterable; tap row → edit/correct/cancel/fill; also unverified pages, untagged bank lines, missing bill attachments, pending statements.

---

## 11. App flow, settings, security  (baseline PART K)

```text
S-01 Login (Admin PIN + optional biometric)
  → S-02 Panchayat selection + [App Settings]
       → S-05 Financial Year (status + chooser) + [FY / Cashbook Settings]
            → S-06 FY Home → Cashbook | Bank | Works | गोशवारा | Ledgers/Reports |
                Monthly check | Backup | प्रपत्र/Formats | Masters | Closing | …
```

- **App Settings (last screen):** theme colour (**instruction #2**), logo, UI language (English/Hinglish), screen-number badge on/off, change PIN, biometric toggle/re-enrol, Panchayat add/edit/correction/delete (destructive **and edit** = PIN re-confirm), global backup defaults.
- **FY / Cashbook Settings:** FY CRUD (add/close = PIN confirm, C11), scheme/fund CRUD **for this FY** (red delete = this FY only), opening balance editor visible, line count L, blank gap 1|2, allow-scheme-negative ON/OFF, appearance colours, category-tree links, empty-day help text.
- **Auth:** Admin only; PIN to establish; biometric optional; future roles reserved in model only.
- **Navigation:** hardware/in-app back → parent in stack (no exit to Android Home until root confirm); no silent dead clicks — empty states with why + steps; badges renumber when screens added, App Settings always last.
- *Storage-permission screen (S-03) + restore-detected screen (S-04) → **B16/B17** (restored into screen index §15).*

---

## 12. Storage, backup, audit  (baseline PART L, Phase 1)

```text
Documents/Cashbook/<PanchayatName_or_Id>/<FY_Label>/
  database / exports / bank_statements / attachments / backups /
```

- **Backup/restore:** auto-save after txns; manual backup; versioned list; restore; backup before FY lock & before destructive schema/column changes; phone-transfer wizard (backup zip + 4-digit restore code); optional cloud later.
- **Instruction #14** adds: proper file-storage folder chosen by user, app provides the permission (grant once → files persist), files survive uninstall, **never `Android/data`** — code: `services/backupFolder.ts` (SAF folder picker).
- Retention: last 15 daily + 1 permanent monthly snapshot, operation-prior safe backups never auto-deleted; human-readable JSON export (V.2#3). *Zip + manifest + naming + checksum/migrate-restore flow → **B14/B15**.*
- **Audit log:** user, time, entity id, action, field, old/new, reason. Prefer Cancelled/Archived over hard delete. *Edit-reason picklist + correction-entry fields → **B6/B7**.*
- **Attachments:** receipt/bill/voucher/sanction/MB photo/PDF linked to txn; included in backup policy (photo attachment per txn = pending C7).

---

## 13. Validation  (baseline PART M)

Invalid dates; non-numeric amounts; negative-amount prevention per policy; scheme required; category incompleteness warning (Monthly Check); at least one fund amount > 0; Work name if Work / other path if Other; duplicate invoice/voucher warning; expense vs day महायोग; optional scheme minus; महायोग mismatch / unbalanced page warnings; backdated impact confirmation.
*Recovered additions: configurable missing-attachment warning + missing invoice/voucher report (**B12**).*

---

## 14. Data entities  (baseline PART N)

`FinancialYear, Panchayat, Page, PageOpening (per fund), Transaction, TransactionAmount, FundColumn/Scheme, CategoryNode, IncomeSource, Work, Vendor, Attachment, BankAccount, BankStatement, BankLine, MeasurementBook, ManDayEntry, PakhWadaRoll, Bill, BillLine, CompletionCertificate, AuditLog, PeriodLock, User (admin), BackupRecord, AppSettings, FySettings, ExportHistory`.
*Code model (`types/models.ts`) additionally has `Vendor`, work sanction/MB fields, karigar toggle, bank tagging fields — see Section D.*

---

## 15. Screen index  (baseline PART O + restored screens)

| # | Screen | Notes |
|---|--------|--------|
| S-01 | Login | PIN + optional biometric + first-run logo chooser (login button always visible → instruction #1) |
| S-02 | Panchayat selection | + App Settings entry |
| **S-03** | **Storage Permission** | **restored (B16)** — first launch, compulsory `Documents/Cashbook` |
| **S-04** | **Restore Detected** | **restored (B17)** — old backups list → restore + migrate |
| S-05 | Financial Year page | + FY/Cashbook Settings |
| S-06 | FY Home | Dashboard + module tiles |
| S-07 | Cashbook page view | N-line dual grid, thin layout + zoom (#10/#15) |
| S-08 | Add/Edit Income | multi-column + scheme + category; minimal fields (#9) |
| S-09 | Add/Edit Expense | Work/Other (#7), vendor dropdown (#5), scheme + category |
| S-10 | Entry detail / cancel / correct | |
| **S-12** | **Page Verification** | **restored (B13)** — “जाँचा-परखा” stamp + user + date |
| S-11+ | Page list / range share | PDF/Excel white |
| S-13–S-16 | Bank accounts / upload / tag / post | Phase 1; fields = uploaded Excel (#13) |
| S-17–S-26 | Works / MB / Man-days / Bills / CC | incl. **manday sanction-in-sanction** + BSR page (#4) |
| S-27 | गोशवारा | till-date + annual, two-sided (#11) |
| S-28–S-34 | Ledgers & Reports Hub | incl. **Material Ledger (B28)**, **Scheme detail (B28)**, **Fee/Patta ledgers** |
| S-35 | Fund / column settings | full column-manager feature set → **B4** |
| S-36–S-41 | BSR, Workers, Vendors, Items, Holidays, Users | |
| S-42 | Backup & restore | SAF user-chosen folder (#14) |
| S-43 | Global search | |
| S-44 | Export centre | |
| S-45 | FY Closing wizard | |
| S-46 | New phone transfer | zip + 4-digit code |
| S-xx | Category tree manager | Income & expense |
| S-xx | Monthly check (full txn list) | |
| S-**Last** | **App Settings** | theme colour (#2), PIN/biometric, logo, panchayat CRUD |

*(Numbers renumber when screens are added; App Settings always last.)*

---

## 16. Build order & acceptance gate  (baseline PART P + Q)

**Build order:** 1) PIN+biometric+settings security → 2) SAF bootstrap + FY-scoped DB → 3) Panchayat/FY settings hierarchy → 4) Fund columns + page engine (L=25) + openings → 5) Income/expense save (multi-column, scheme required, category) → 6) strict FY filter regression → 7) carry-forward balances only (CF/Manual badge) → 8) auto ledgers/reports pipeline → 9) monthly check → 10) PDF/Excel page export (white) → 11) backup/restore SAF → 12) bank pipeline → 13) Works → MB → Bills → CC → 14) गोशवारा + FY closing → 15) empty-day insert, +2 pages, navigation/empty-state polish.

**Acceptance (Phase 1 gate):** baseline checklist (25-line page, scheme mandatory, summary non-editable, FY isolation, 3-level category, auto reports, monthly check, biometric optional, SAF tree, bank fixture path, MB→bill→CC path, Excel+PDF export, back nav, day-expense guard, auto+manual page) **plus restored checks (B19):** new fund column updates the whole book; archived column keeps data; audit shows old/new values; locked period blocks unauthorized edit.

---

## 17. Deferred / out of scope  (baseline PART R + old §13/§18.6)

- Multi-role Operator/Checker/Approver/Viewer UI; fixed Play-style signing keystore; TDS/GST; multi-device realtime sync; demo/sample training mode (**rejected**).
- **Backlog register (restored from old §13, B30):** bank reconciliation, advance tracking, pending-bills/liabilities register, निधि उपयोग प्रमाण-पत्र, budget vs actual, Hindi number-to-words, voice entry (Hindi), Devanagari numerals toggle, page e-sign/verification stamp, year-comparison report, asset/dead-stock register, onboarding help screens, large-font/dark mode, reminder notifications, multi-Panchayat mode (keep `PanchayatId` in model).

---

## 18. Demo-format locks & round decisions  (baseline PART U)

| # | Topic | FINAL |
|---|--------|--------|
| D21 | Page add | Manual **+ Page**: append **or insert between** pages; insert renumbers; delete re-flows txns; auto page-1 per FY |
| D22 | Formats Centre | FY Home tile **प्रपत्र / Formats Centre** — गोशवारा, Ledger, प्रपत्र-1, प्रपत्र-4, Bank grid, CC — all live, share/export from every card |
| D23 | गोशवारा format | audit demo sheet-1: मद-wise आय\|व्यय, आय/व्यय योग, प्रारंभिक/अंतिम शेष नकद (+bank), महायोग, हस्ताक्षर block |
| D24 | प्रपत्र-1 | audit demo sheet-2: FS ref/राशि (लाख), पूर्व व्यय, आलोच्य वर्ष व्यय, कुल व्यय, स्थिति, मूल्यांकन, MB ref, श्रम/सामग्री split |
| D25 | प्रपत्र-4 | audit demo sheet-3: सामग्री-वार मात्रा/दर/कीमत/योग |
| D26 | Ledger format | ledger.pdf (GP खाता बही): श्री पोते opening → जमा/नाम rows → running शेष; fund-wise or all-funds |
| D27 | CC | cc demo xlsx: 7-page set; **अनुमत = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)**; भुगतान योग्य शेष = अनुमत − payments |
| D28 | Mandays | **पाक्षिक मस्टरोल**: (मेट/कुशल/अकुशल × दिन) × दर = श्रम व्यय; rolls aggregate on CC page-3 |
| D29 | Monthly check | Edit every field + cancel with confirm; month filter (YYYY-MM); cancelled list |
| D30 | Backup | Full JSON backup share/save + restore-by-paste; SAF file-write on device build (#14 extends this) |
| D31 | Data model | `CashbookPage`, `PakhWadaRoll`, `Transaction.pageId`; AsyncStorage key versioned |

Demo mapping: `audit formet demo.xlsx` → गोशवारा/प्रपत्र-1/प्रपत्र-4; `bank statement demo.xlsx` → bank grid; `cc talora chaina mojek.xlsx` → CC 7 pages + mandays; `ledger.pdf` → खाता बही.

---

## 19. Provenance & decision log  (baseline PART S / V / W / VI — pointer)

- **PART S** (contradiction resolution) and **PART W/VI** (C1–C12 user decisions) are re-stated in **Section C** below with old-vs-new verdicts — that is now the single conflict table.
- **PART V merge map** (old doc → current doc, `[ALREADY-COVERED]` / `[CONFLICT]` markers) is superseded by **Section B** (which re-mines the old file from scratch and flags anything still missing).
- Resolved decisions kept as-is: C1 page structure (25 lines), C9 white print, C6 L.F. column (added), C10 logo chooser (added) + default user NOT seeded, C11 FY PIN confirm (added). Open/backlog: **C2** (BSR sanction-year default), **C3** (material-first enforcement), **C4** (last-bill list), **C5** (qty decimals), **C7** (txn photo attachment), **C8** (gap-2), **C12** (patta fields).

---

## 20. CI / build notes  (baseline PART T)

- Expo Android CI: extract → `expo prebuild` → `assembleRelease`; embed **release** JS bundle (debug APK without Metro = “Unable to load script”); strip monorepo `catalog:`/`workspace:` pins; `babel.config.js` with `babel-preset-expo` + `reanimated/plugin`; `newArchEnabled: false` for first stable sideloads; package `com.grampanchayat.cashbook`.
- Sideload signing: per-run debug keystore → update may require uninstall until **fixed keystore** (D15 “Later”).
- Stability trade-offs: biometric native module may be omitted (PIN stays); PDF OCR/SAF wired progressively.
- Always-regression: switching FY must never show previous FY rows.
- *Old CI learnings (JVM17, wrapper, one workflow, logs downloadable) → **B20**.*

---
---

## A. यूज़र के 15 निर्देश (latest, 2026-09)

> हर instruction testable spec wording में; status tag = Section D (v6 code) के आधार पर।

**A1. Login screen layout** — *"login button ab screen par dikh nahi raha; ise neeche/visible jagah par le jao, layout thik karo."*
→ Acceptance: login/set-PIN screen (S-01) पर button हमेशा viewport में दिखे — logo chooser खुले या keyboard आए तब भी; fixed-height layout नहीं, scrollable/keyboard-avoiding container; button field list के ठीक नीचे। **[implemented]**

**A2. Theme colour in App Settings** — *"Main App Settings me 'theme color' ka option add karo."*
→ Acceptance: App Settings (last screen) में theme colour picker (6 themes: हरा/नीला/टील/मैरून/बैंगनी/केसरिया); चुनते ही पूरी app पर colour लागू, selection persist; **printed documents का Hindi format वैसा ही** (theme सिर्फ़ UI)। **[implemented]**

**A3. MB entry — material/labour separation** — *"MB entry page confusing hai — material (सामग्री) aur labour (श्रम) ka alag-alag grouping dikhao; ek toggle do ki कारीगर labour me jaye ya material me (default = labour). Dono ka subtotal alag, valuation line me jodho."*
→ Acceptance: MB screen दो साफ़ sections — **सामग्री** (मद-वार qty × rate) और **श्रम** (कारीगर + लेबर); कारीगर-amount के लिए toggle (labour | material), **default = labour**; हर पक्ष का subtotal अलग दिखे; **Total valuation = material subtotal + labour subtotal** (कारीगर toggle के हिसाब से)। **[implemented]**

**A4. Manday sanction inside sanction + BSR page** — *"work-sanction ke andar ek alag 'manday sanction/sanction inside sanction' kholo: usme labour/karigar amount daalte hi desired wage rate aur man-days apne aap calculate hon (per .md ke hisaab se). Agar us saal BSR rates add nahi hain to BSR page khole — usme pehle se items listed hon (cement, रेत, गिट्टी 40mm/20mm/12mm, पत्थर, ईंट आदि), sirf us year ki rates bharni hon, items add/edit/delete karne ka option. System 2–3 aise combos auto-calculate kare jo desired amount ke karib hon (trial & error), user unme se choose kare."*
→ Acceptance: (a) work detail ke andar अलग **मन-डे स्वीकृति** sub-flow (sanction-in-sanction), केवल labour/karigar amount डालते ही desired wage rate + man-days auto-compute (pakhwada working days, full man-days, amount ≤ MB component, rate ≤ BSR); (b) agar उस year की BSR नहीं → वहीं से **BSR page**: default items पहले से listed (सीमेंट, रेत, गिट्टी 40/20/12 मिमी, पत्थर, ईंट…), सिर्फ़ rates भरनी हों, item add/edit/delete option; (c) app **2–3 सबसे करीब combos** auto-calculate करे (workers × days × rate, trial-and-error), user उनमें से चुने। **[implemented — combo shortlist sorted by closeness; confirm UI shows only 2–3]**

**A5. Vendor dropdown in Bills** — *"Bills me vendor dropdown hon; agar koi vendor nahi hai to wahi par 'add vendor' ka option."*
→ Acceptance: Bill create form में vendor = dropdown (master से); dropdown/list में ही **“नया vendor add”** option, add करते ही वही select हो जाए। **[implemented]**

**A6. CC = exact Excel format + PDF/Excel share** — *"CC ke 7 pages bilkul waise hi Excel format me jaise user ki upload ki hui Excel file hai (format unchanged); share/export me PDF aur Excel — dono ka option dikhe."*
→ Acceptance: CC के सातों पृष्ठ (पूर्णता प्रमाण पत्र, UC, श्रम मस्टर रोल, सामग्री, तकनीकी जाँच, पूर्णता फोटो, पूर्व/दौरान फोटो) **exactly** `cc talora chaina mojek.xlsx` वाले layout में (format unchanged); share row में PDF और Excel दोनों। **[implemented]**

**A7. Cashbook expense-side Work | Other** — *"Cashbook expense-side entry me do option: Work | Other. Work = added works ki dropdown (na ho to dropdown ke andar hi 'naya work add' option); Other = category/sub-category hierarchy jisme add/edit/delete ho."*
→ Acceptance: expense form में साफ़ दो options **कार्य | अन्य**; कार्य = works dropdown + dropdown ke andar hi “नया कार्य” (पूरा form); अन्य = category → sub-category tree, हर level add/rename/delete वहीं से। **[implemented]**

**A8. Work add form fields** — *"Work add karte waqt scheme poochho (expense entry ke dauran wo auto-select hoti rahe), plus A.S. number/date, T.S. number/date, F.S. number/date, work start date, work complete date, MB status (Complete/Pending); agar MB Complete to MB details: Total valuation, labour amount, material amount, page number, MB number (per .md)."*
→ Acceptance: नया work form में — **scheme** (योजना), AS/TS/FS क्रमांक व दिनांक (तीनों), कार्य प्रारंभ तिथि, कार्य पूर्ण तिथि, **MB स्थिति = Complete | Pending**; MB Complete होने पर अतिरिक्त — कुल मूल्यांकन, श्रम राशि, सामग्री राशि, MB पृष्ठ संख्या, MB संख्या; expense entry में work चुनते ही उसकी **scheme auto-select** रहे। **[implemented]**

**A9. Minimal cashbook entry fields** — *"Cashbook entry me sirf ye poochho: date, किससे प्राप्त, amount, scheme, category — ek entry me ek hi scheme, scheme baar-baar mat poochho."*
→ Acceptance: entry form केवल — दिनांक, किससे प्राप्त/भुगतान किसको, राशि (fund amount), योजना, श्रेणी; **एक entry में एक ही scheme**; scheme default (पिछली/work से) रहे तो दोबारा न पूछा जाए; बाक़ी विवरण optional/advanced में। **[implemented]**

**A10. Thin cashbook + own-fund default** — *"Cashbook page ko horizontal me patla karo taki kam se kam ek side phone par fit ho (upload ki Excel layout ke hisaab se); cash sirf transaction medium hai, scheme nahi — cash transactions default me 'own fund' (apna kosh), doosri schemes dropdown se."*
→ Acceptance: ग्रिड चौड़ाई ऐसी कि **कम से कम एक side phone width में fit** हो (uploaded Excel column order/headings वैसे ही, format unchanged), बाक़ी scroll/zoom से; **नकद = माध्यम, योजना नहीं** — cash वाली entry default **Own Fund (अपना कोष)**, दूसरी योजनाएँ dropdown से। **[implemented]**

**A11. गोशवारा & ledger two-sided original format** — *"गोशवारा aur ledger hamesha do-sided (two-side) ho, bilkul waise hi jaise upload ki Excel/PDF — original-type Excel format."*
→ Acceptance: गोशवारा = बायाँ आय मद | दायाँ व्यय मद (दोनों पक्ष); ledger = खाता बही वाला original type (जमा/नाम + running शेष), uploaded `ledger.pdf` / audit demo जैसा; output Excel में वही layout। **[implemented]**

**A12. सभी प्रपत्र — original look + Excel-type + share both** — *"Sabhi प्रपत्र phone par original dikhte hue Excel-type format me hon; share me Excel aur PDF dono ka option ho."*
→ Acceptance: Formats Centre के सभी documents (गोशवारा, ledger, प्रपत्र-1, प्रपत्र-4, bank grid, CC, cashbook page) phone पर original (uploaded sample) जैसे दिखें, Excel-type table format में export हों, और **हर card/share पर Excel + PDF दोनों** option। **[implemented]**

**A13. Bank statement fields = uploaded Excel** — *"Bank statement ke fields bilkul waise hon jaise upload ki Excel (दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष + tagging योजना/कार्य/vendor/लेखा शीर्ष/टिप्पणी)."*
→ Acceptance: statement grid columns exactly — दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष; हर line पर tagging: योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी। **[implemented]**

**A14. Backup/restore in proper folder with app-granted permission** — *"Backup/restore thik se karein — ek proper file storage folder me save hon, iske liye app khud storage-permission dene ka option de (permission grant karke files bani rahein); file uninstall par bhi bani rahe (Android/data wale folder me mat likho)."*
→ Acceptance: एक बार folder picker (SAF) से अपना backup folder चुनो → permission persist; वहीं `Cashbook-Backup-<panchayat>-<timestamp>.json` बने, list/restore/delete वहीं से; folder public (uninstall-safe), **`Android/data` कभी नहीं**; permission revoke हो तो app दोबारा चुनने को कहे। **[implemented — `services/backupFolder.ts` + BackupScreen]**

**A15. Return to same page + zoom** — *"Kisi page ko chun kar entry me jane aur wapas aane par usi page par pahunchna chahiye (first page par na chala jaye); pinch-to-zoom ya +/- zoom controls ho taki dono sides ek saath dekhi ja saken."*
→ Acceptance: cashbook page → entry → back पर **वही page number + वही zoom level**; zoom = pinch **या** `+ / −` controls (+ % indicator, reset), ताकि एक साथ दोनों sides दिखें। **[partially implemented — page+zoom persist + `− / 100% / +` controls present; pinch gesture not found in code]**

---

## B. पुरानी .md से जो लौटाना/जोड़ना है

> Mining rule: `PROJECT_MASTER old.md` का हर section current `PROJECT_MASTER.md` से टकराया गया। जो fully covered है वह यहाँ नहीं है (वे आधे-अधूरे covered भी नीचे हैं)। Each item: instruction → कहाँ मिला → **RESTORE** / **OBSOLETE** (+ क्यों)। Legend: `old.md` = `PROJECT_MASTER old.md`, `cur.md` = `PROJECT_MASTER.md`.

| # | Instruction (old spec) | Where it appeared | Verdict | Why it matters / why obsolete |
|---|---|---|---|---|
| B1 | “Reports में केवल active transaction dates या सभी calendar days दिखाने का option होगा।” | old.md Part A §4, line 134 | **RESTORE** | D10 covers optional empty-day *pages*; the report-side display toggle (active dates only vs all days) is a separate report option — अभी कहीं नहीं है |
| B2 | “Actual transaction date और entry-created date अलग-अलग store होंगी” (+ last-updated, user id) | old.md Part A §4 lines 135–136, §10.1 lines 365–370 | **RESTORE** | Audit/backdated correctness: cur.md L.3 logs only generic fields; per-txn `createdAt/updatedAt/backdated` fields explicit नहीं हैं |
| B3 | Income “अन्य” चुनने पर custom description field खुलेगी | old.md §5.2 line 185 | **RESTORE** | cur.md D.1 में “Other/अन्य” है पर free-text detail खुलने का rule नहीं — नई categories बिना CRUD के भी entry लिखवाने का रास्ता |
| B4 | Fund column manager: add/rename/**Hindi-English label edit**/**stable code**/reorder/enable-disable/archive/**show-hide in print**/**show-hide in reports**/opening balance | old.md §8.1 lines 293–306 | **RESTORE** | cur.md D5/K.3 सिर्फ़ CRUD कहता है; print/report visibility और stable code (exports सुधरें) अभी unspecified |
| B5 | Column change का automatic propagation checklist: existing/new pages, headings, line totals, आय/व्यय योग, श्री/बचत पोते, महायोग, carry-forward, dashboard, reports, Excel, PDF + historical column **archive, never direct delete** | old.md §8.2 lines 308–325 | **RESTORE** | यही regression test है (D5 का acceptance); cur.md में propagation का explicit checklist नहीं |
| B6 | Edit reason picklist: गलत amount / date / category / party / invoice-voucher / fund head / अन्य | old.md §10.2 lines 382–392 | **RESTORE** | cur.md M में edit/cancel हैं पर standard reason dropdown नहीं — audit में reasons comparable नहीं होंगे |
| B7 | Locked-period correction entry fields: original reference, old value, correct value, difference, reason, approval status | old.md §10.3 lines 394–403 | **RESTORE** | cur.md PART B/L.3 सिर्फ़ “correction/adjustment entries + audit” कहता है; fields specify नहीं |
| B8 | Excel-like grid extras: cell tap→edit, duplicate row, sort/filter, search, **freeze header**, column resize/reorder, dropdown validation, dependent dropdowns, auto-save/draft, Excel **import** | old.md §13 lines 517–537 | **PARTIAL RESTORE** | cur.md V.2#2 में form-default + grid optional और copy/paste+undo/redo backlog है; **freeze/duplicate/sort-filter/search/column-resize** restore (grid optional feature); “Excel import” = OBSOLETE (no import path decided; exports only) |
| B9 | Excel workbook default **12 sheets** (Cashbook Print, All Transactions, Income/Expense Summary, Work-wise, Other Category, Vendor, Fund, Monthly, Annual गोशवारा, Validation/Errors, Audit Trail) + raw-data sheet + formulas/filters/freeze/Hindi headings | old.md §14 lines 541–558 | **RESTORE** | cur.md F सिर्फ़ “multiple sheets” कहता है; यह concrete export acceptance list है |
| B10 | PDF export options: A4 **and Legal/A3** landscape, compact/split layout, header/footer, **page numbering**, signature fields, **Draft/Verified/Final watermark**, **password-protected PDF optional**; share targets: **WhatsApp, Email, device storage, print, open in Excel/Google Sheets** | old.md §15 lines 562–591 | **RESTORE** | cur.md F में landscape/watermark/signature संकेत हैं; A3/Legal, page numbering, password PDF, share targets explicit नहीं (WhatsApp = पं.समि./BDO को भेजने का मुख्य रास्ता) |
| B11 | Dashboard quick actions: Current Page, Reports, **Export, Search, Reconciliation** (plus baseline list) | old.md §16 lines 634–643 | **RESTORE** | cur.md J.1 की quick-action list छोटी है; Search/Export/Reconciliation shortcuts FY Home पर चाहिए थे |
| B12 | “Missing attachment warning **configurable**”, “Missing invoice/voucher report”, “Incomplete transaction report” | old.md §17 lines 656–661 | **RESTORE** | cur.md M में duplicate-invoice और incomplete-txn (report 19) हैं; **configurable attachment warning** और **missing invoice/voucher report** नहीं |
| B13 | Page verification stamp: S-12 “जाँचा-परखा” + user + date; admin-only column settings; admin-only locked-period correction | old.md §18 lines 676–686; Part C S-12 line 1477 | **PARTIAL RESTORE** | Page verification RESTORE (FY closing checklist “pages verified” बिना verification screen के खोखला; S-12 index से गायब); admin-only column/correction = already implied by D6 → OK; “export/attachment permissions” separate = **OBSOLETE** (Admin-only, single user — granular permission matrix की ज़रूरत नहीं) |
| B14 | Backup **zip** = DB (WAL checkpoint) + attachments + `manifest.json` (app version, schema version, date, checksum); naming `GP_<Name>_YYYY-MM-DD_vX.Y.zip` | old.md §4.2 lines 1084–1093 | **RESTORE** | cur.md D30/V.2#3 सिर्फ़ JSON backup कहता है; attachments/DB लेने के लिए zip+manifest ज़रूरी; naming = पुरानी files पहचानने में |
| B15 | Restore flow: fresh install पर old backups auto-detect → “पुराना डेटा मिला — Restore करें?” → list (date, size, app version) → checksum verify → **schema migrate करके** restore (sirf copy पर्याप्त नहीं) | old.md §4.3 lines 1095–1101 | **RESTORE** | सीधा instruction #14 का companion; cur.md में restore सिर्फ़ “restore” शब्द है, UX+migrate+integrity unspecified |
| B16 | First launch: `Documents/Cashbook` permission **COMPULSORY** screen (S-03) — बिना आगे नहीं; revoke हो तो सबसे पहले re-grant screen; **`Android/data` में backup कभी नहीं** (uninstall पर delete) | old.md §3 lines 1060–1068; Part C S-03 line 1461 | **RESTORE** | cur.md में S-03 screen index से गायब; instruction #14 को पूरा करने के लिए यही flow है |
| B17 | Screen S-04 “Restore Detected” (first launch / Settings से) — old backups list → select → restore | old.md Part C line 1462 | **RESTORE** | B16 का जोड़ू; Settings से भी खुलना चाहिए |
| B18 | Modular rules: **versioned migrations (no drop/rename, archived flag)**, backup before update, **rollback on failed update**, untrusted code download नहीं, feature manifest/registry, signed modules | old.md §21 lines 750–762 | **PARTIAL RESTORE** | migrations + backup-before-update = RESTORE (V.2#5 में है, यहाँ दोहराया acceptance में); **feature registry/plugin manifest/rollback** = **OBSOLETE** — app अब single Expo bundle है, dynamic feature modules नहीं (old Kotlin/Compose plan) |
| B19 | Acceptance extras: नया fund column जोड़ने पर **पूरी book** update; historical column archive पर data सुरक्षित; audit trail **old/new values** दिखाए; locked period unauthorized edit रोके; Hindi font में कोई black box नहीं | old.md §26 lines 923–943 | **RESTORE** | cur.md Q में ये 4 checks नहीं हैं (font check है) — gate में जोड़ने हैं (already listed in §16 here) |
| B20 | CI learnings: extracted files + official Gradle wrapper > zip; JVM17 fix source में permanent; एक समय में एक active workflow; build logs/APK downloadable | old.md §23 lines 789–878 | **PARTIAL OBSOLETE** | Kotlin/Gradle starter pipeline हट चुका है (अब Expo prebuild, PART T) — JVM/wrapper/zip-extract **OBSOLETE (history)**; **“one active workflow + downloadable logs”** = keep as working rule (T.1) |
| B21 | 2-page demo PDF record + reusable build script (12+12, 30-line, sample totals) | old.md §1.3 lines 998–1003, §24 lines 882–894 | **OBSOLETE** | superseded by real export pipeline (`services/exportDoc.ts`) — numbers/layout अब demo से नहीं, live data से बनते हैं |
| B22 | श्री पोते row की टिप्पणी में source: “विगत वर्ष का बचत शेष” (page 1) / “पूर्व पृष्ठ का बचत पोते” (बाद के pages); पहला साल = admin एक बार fund-wise manual opening | old.md §2.1 lines 1012–1016 | **RESTORE** | cur.md C.6 carry + CF/Manual badge कहता है, पर **print/screen पर यह source text** unspecified — ऑडिट में opening का source यही बताता है |
| B23 | Cashbook appearance settings: default हल्का हरा page tint; **transaction text blue (ball-pen)**; श्री पोते **light red**; top श्री पोते + bottom-3 **bold, size +1**; footer colour configurable; हर option के साथ **detailed on-screen help** | old.md §19.4.3 lines 1806–1818 | **RESTORE** | cur.md C.1 सिर्फ़ “light register tint” कहता है; ink-colour rules रजिस्टर-जैसा look देते हैं और instruction #2 (theme) के साथ जाते हैं |
| B24 | Cashbook header: “सिर्फ़ GP का नाम + वि.व. — **नीचे कोई date range नहीं**”; तिथि **सिर्फ़ श्री पोते की line** के सामने | old.md §16.2 lines 1602–1603 | **RESTORE** | header की composition तो PDF-lock (C.1) जीतती है (§C6), पर **“no date-range band”** और **date-on-श्री-पोते-only** rule अभी भी valid हैं — दोनों files में यह refinement गायब है |
| B25 | Bank account master: bank + खाता संख्या + **IFSC**; statement की a/c से account auto-identify, नया मिले तो एक बार master में; **duplicate-month warning** (period range से); full statement का **register/full-format print**; reconciliation = cheque/UTR reference | old.md §11.1 lines 1262–1265 | **RESTORE** | cur.md G सिर्फ़ “Bank account master” कहता है — auto-detect, duplicate warning, UTR reconciliation, full print unspecified हैं |
| B26 | Bank auto-entry engine full rules: credit = credit date पर (month-end mode optional); **10–15 day grouping window → एक दिन/एक page**, बड़ा range → 2 pages (हर group पर अलग balance condition); **labour consolidation suggestion** (same-same debits → एक entry); work dropdown for कार्य payments; AS/FS/TS किसी भी समय; review screen एक-tap accept | old.md §11.2 lines 1268–1298 | **RESTORE** | cur.md G में सिर्फ़ “grouping rules + D−1” (संक्षेप); V.2#11 में detail है पर **coded = D−1 + balance only** — बाक़ी rules spec में explicit रहने चाहिए |
| B27 | Privacy note (Round 4, **final — इस पर आगे चर्चा नहीं**): bank/estimate data cloud AI को जा सकता है — GP का data वैसे भी RTI/public-domain में; भविष्य में offline OCR optional | old.md §11.1 line 1266, §18.5 lines 1696–1697 | **RESTORE (as recorded decision)** | cur.md से गायब; दो online exceptions (AI estimate, bank OCR) का legal/privacy आधार यही है — re-litigate न हो, इसलिए दर्ज करना ज़रूरी |
| B28 | FY Home tiles/ledgers: **Material Ledger (Stock Register)** — वस्तु-wise कुल + full ledger; **Schemes tile** → scheme detail (opening, income, expenditure, payment vouchers); **Labour ledger** (man-days, rates); fee ledgers count + full list | old.md §15.2 lines 1421–1422, §12 lines 1306–1346 | **RESTORE** | cur.md F की report list में ये generic reports हैं पर **distinct screens/tiles** (S-28/S-30/S-31/S-32) गायब हैं; stock register तो audit में मुख्य register है |
| B29 | पट्टा income entry extra fields: पट्टा क्रमांक (auto-suggest), पट्टाधारक नाम, जारी दिनांक — पट्टा ledger में दिखें | old.md §12.6 lines 1341–1346 | **RESTORE (pending C12)** | cur.md PART VI में यह open backlog है; ऑडिट का सीधा सवाल “साल में कितने पट्टे” — इसलिए रखना है |
| B30 | Future features (18 items: bank reconciliation, advance register, liabilities register, निधि उपयोग प्रमाण-पत्र, budget vs actual, Hindi number-to-words, voice entry, templates, Devanagari numerals, e-sign stamp, year comparison, asset register, onboarding help, large-font/dark mode, reminders, multi-Panchayat/PanchayatId, TDS/GST, multi-device sync) | old.md §13 lines 1357–1378 | **RESTORE (as backlog register)** | cur.md PART R में सिर्फ़ 5 चीज़ें हैं; बाक़ी 13 (जिनमें से templates/reminder कुछ हद तक बन चुके हैं) भूल जाएँगी — इसलिए §17 में restore |
| B31 | Launch/panchayat page: Sample-3 dropdown minimal style, deep-green gradient header, **time-based English greeting**, “**100% ऑफ़लाइन · डेटा सुरक्षित**” note | old.md §15.1 lines 1402–1407 | **PARTIAL RESTORE** | Greeting = already backlog (V.2#17) — keep; **offline-note text + dropdown minimal style** = RESTORE (trust signal, instruction-adjacent); M3 light-green theme = superseded by #2 theme picker |
| B32 | Screen badge: **bottom-right corner**, muted/light colour, hide/show toggle in Settings (default visible) | old.md §15.3 lines 1426–1431 | **RESTORE (detail)** | cur.md K.2 में on/off है, position/muted styling unspecified — design lock के लिए |
| B33 | Distinct screens dropped from condensed index: S-03 permission, S-04 restore-detected, S-12 page verification, **S-23 Master Roll**, **S-28 Material Ledger**, **S-30 Scheme ledger**, **S-32 Patta/Fee ledgers** | old.md Part C lines 1461–1545 | **RESTORE** | cur.md O में ranges (S-17–S-26, S-28–S-34) ने इन्हें absorb कर लिया — implementation भूल न जाए, इसलिए §15 में वापस नामित |
| B34 | गोशवारा: हर महीने की **5 तारीख़ reminder notification** + **one-tap WhatsApp PDF share** (पं.समि./BDO को) | old.md §17.1(9) lines 1665, S-27 line 1513 | **PARTIAL RESTORE** | cur.md I में “optional monthly reminder” है; **WhatsApp one-tap share** गायब है — वही तो असली काम है |
| B35 | Cash/bank practice: नकद शुल्क का **मिश्रित उपयोग** (कुछ daily खर्च, कुछ बैंक जमा); **हर नकद राशि बैंक में जमा करना ज़रूरी नहीं** — जमा आंशिक और optional | old.md §17.1(2) lines 1656–1658 | **RESTORE** | cur.md G में “no bank→cash + cash→bank deposit type” है, पर **partial/optional deposit** का rule नहीं — instruction #10 (cash = माध्यम, own fund) के साथ यही GP practice है |
| B36 | Rate rules: **HARD RULE rate ≤ BSR**; safe band BSR से 10–20% कम (कारण: cross-FY काम में ऊँची BSR → **audit में recoverable**); **स्वीकृति वर्ष की BSR default**; ऊँची चुनने पर तुरंत warning; **CC में हमेशा दिखे किस वर्ष की BSR से गणना** | old.md §7.2 lines 1139–1148 | **RESTORE** | cur.md H में सिर्फ़ “rate band guidance” (D-spirit); sanction-year default = open **C2** — audit-rationale और “BSR year on CC” दोनों spec में explicitly रहने चाहिए |
| B37 | हर man-days calculation **audit trail** में जाए (rate, man-days, BSR year) — certificate के पीछे का गणित दोबारा दिखे | old.md §7.3(5) line 1156 | **RESTORE** | V.2#8 में “partial” — calc audit log के बिना CC का गणित verify नहीं होता |
| B38 | Bill module rules: **material-first payment** (labour/MR payment warning या strict block, configurable); **last-bill items** (पानी/टेंकर/मशीनरी/वाइब्रेटर/मिक्सर/डिस्प्ले बोर्ड/पॉलिश) सिर्फ़ last bill में; **qty flags** (cement/ईंट = whole, loose = decimal); **basic items front-load suggestion**; **material bills योग = CC material validation**; payment-time **live spend status + excess-payment warning** | old.md §8 lines 1178–1216 | **RESTORE (pending C3/C4/C5)** | cur.md PART VI में ये open backlog हैं (masters बने हुए हैं) — audit के ये exactly वो rules हैं जो अक्सर टूटते हैं; इसलिए Section B में visible रखना ज़रूरी |
| B39 | CC/UC **format = actual Rajasthan Panchayati Raj sample** जब user दे — layout उसी के अनुसार | old.md §10 line 1248 | **RESTORE (as rule)** | demo xlsx अब lock है (D27), पर “user का actual sample = final format” का नियम भविष्य के प्रपत्रों (रसीद/पर्ची भी) पर लागू होना चाहिए |
| B40 | AI Estimate Reader: cloud OCR, **mandatory operator review step**, offline-policy exception #1, needs 2–3 sample estimate PDFs | old.md §9 lines 1219–1228 | **RESTORE (as deferred module)** | V.2#10 में है पर “deferred” के साथ duplicate न हो, इसलिए यहाँ register में दर्ज — requirement (review अनिवार्य) कभी हल्की न पड़े |
| B41 | Main-page/S-02 GP dropdown minimal style + “प्रवेश करें” button; **Panchayat selection हर बार दिखे**; FY page पर सिर्फ़ FY status + chooser | old.md §14 rows 8–11 lines 1393–1396, §15.1 | **RESTORE (confirm)** | cur.md K.1 flow में implicit है; “हर बार” और FY page की सादगी explicitly confirm कर लेना चाहिए (बदलाव = decision required) |
| B42 | Report rule: हर report में compulsory Excel/PDF export + share + print (22 reports) | old.md §12 lines 478–513 | *already covered* | cur.md F (23 reports + compulsory share row) — **no action** (listed only for completeness of the mining pass) |
| B43 | 30-line structure, श्री पोते twice (line 1 + 29), 26/27 split, green print hybrid, default user “Harish Patidar”, 47-screen fixed numbering, Kotlin/Room starter, demo-PDF pipeline | old.md §3/§2.2, §16.1, §18.2, §23–25, §27 | **OBSOLETE** | superseded by PDF-sample lock (25 lines, C1), user decisions C9/C10, Expo/AsyncStorage stack, live export pipeline — see Section C |

**Count: 43 mined items — 34 RESTORE (some partial), 9 OBSOLETE / already-covered.**

---

## C. विरोधाभास (contradictions) old vs new

| # | Old spec said | New spec says | Decision | Why |
|---|---|---|---|---|
| C-1 | हर पृष्ठ **30 lines**; income 26 txn + expense 27 txn (26/27 split) | **25 lines**, txn = L − 4 (21) | **NEW wins** | User decision C1 (24-09): real Excel/PDF sample (`DOC-20260622-WA0002`) का grid = source of truth, 30-line mode नहीं |
| C-2 | श्री पोते **दो बार** (line 1 + line 29, symmetry) | श्री पोते **सिर्फ़ top**; bottom-left = **पूर्व पोते** | **NEW wins** | PDF wording lock (C.4/C.9) — sample page पर bottom label “पूर्व पोते” है; repeat = double-count risk |
| C-3 | Page background हल्का हरा (#e9f4e9) + **hybrid print option** (रंगीन/सफ़ेद) | Screen: light register tint; **share/PDF = white only** (D14) | **NEW wins (C9)** | User decision: white-only print (ink cost + official copies); screen tint रहेगा (B23 appearance rules) |
| C-4 | Header = “सिर्फ़ GP नाम + वि.व.”, नीचे कोई date range नहीं | Header = GP + पं.समिति + जिला + वि.व. + पृष्ठ संख्या (C.1) | **NEW wins for composition; OLD rule kept (B24)** | C.1 = actual sample PDF lock; **date-range band नहीं** वाला refinement अभी भी लागू |
| C-5 | Line-count setting default **30** (19.2.3) | Default **25** (D1) | **NEW wins** | Same PDF lock as C-1; setting still allows L change |
| C-6 | Default fund = Cash column (§8) + separately entry scheme required | Cash = **माध्यम, योजना नहीं**; cash txn default **Own Fund**; दूसरी schemes dropdown (#10) | **NEW wins (reinforced)** | Instruction #10 (2026-09) explicit; own-fund column already in sample PDF |
| C-7 | **Sanction-year BSR default** + higher-year warning + CC shows BSR year (§7.2) | cur.md: सिर्फ़ “rate band −10…−20% guidance”; sanction-year default **not implemented** | **OLD wins as intent → OPEN (C2)** | Audit-rationale (recoverable risk) unchanged; pending user go-ahead in PART VI backlog |
| C-8 | Material-first payment **enforcement** (warning/strict block configurable) | cur.md silent | **OLD restored → OPEN (C3)** | Payment sequence = audit finding; user decision pending |
| C-9 | Last-bill items fixed list; whole/decimal qty flags | cur.md silent (masters hold flags) | **OLD restored → OPEN (C4/C5)** | Data model ready; UI rules pending user confirmation |
| C-10 | L.F. column दोनों forms में | cur.md entry form में L.F. नहीं (PDF C.3 में column है) | **OLD wins → DONE (C6, implemented)** | Ledger↔entry cross-verify के लिए L.F. ज़रूरी (user decision VI) |
| C-11 | Har transaction attachment (receipt/bill photo + PDF) | note-only; attachments backlog (C7) | **OPEN (C7)** | old rule restore on user confirmation; expo-image-picker present |
| C-12 | Blank-line gap Option A/B (default 1) | D1: gap 1|2 in settings | **NEW (same content)** | No real conflict — setting exists; default = 1 (C8 minor) |
| C-13 | First-run **8-logo chooser** + default user “Harish Patidar — Operator” | Logo fixed in app.json; admin generic | **SPLIT:** logo chooser **OLD restored (C10, implemented)**; default user **NEW wins** | User ने logo chooser चुना, default user seed नहीं चुना (PART VI) |
| C-14 | Password re-confirm on panchayat **and FY** edit/delete | panchayat destructive/edit only | **OLD wins → DONE (C11, implemented)** | FY add/close पर भी PIN confirm (user decision VI) |
| C-15 | पट्टा extra fields (क्रमांक/पट्टाधारक/जारी दिनांक) | not present | **OPEN (C12)** | Restore as backlog |
| C-16 | Screen index **exactly 47** (S-01…S-47), App Settings S-47 | Condensed index, renumber freely; App Settings **always last** | **NEW wins (process)** | Same intent; numbers now fluid — Section 15 restores missing *names* (B33) even if numbers shift |
| C-17 | Multi-role (Operator/Checker/Approver/Viewer) lists | **Admin only** (D6/19.1) | **NEW wins (agreed)** | old doc itself marks multi-role deferred (Round 5) — not a real conflict |
| C-18 | PDF: HTML→Chromium/Android-native shaping pipeline (ReportLab banned) | Expo `expo-print` + embedded Devanagari | **No conflict — requirement restated** | Binding rule = **shaping-capable renderer + Noto, Mangal banned**; expo-print (Chromium print pipeline) satisfies it — keep B10 font rules as the acceptance test |
| C-19 | Backup = zip + manifest + retention; restore = migrate + checksum | Backup = JSON share/save + retention (D30/V.2#3); restore unspecified | **NEW wins for what's built; OLD restored as target (B14/B15)** | JSON keeps “readable in 5 years”; zip/migrate flow needed for full-fidelity restore (#14) |
| C-20 | Demo/sample training mode | **Rejected** | **Agreed — OUT (both)** | old §17.2 rejected, cur.md PART R keeps it out |

---

## D. Implementation status (v6)

> Evidence: `extracted\cashbook-mobile\app\index.tsx` (3,925 lines; 27 screens + Pin/Cancel modals), `services/` (`backupFolder, exportDoc, formats, mandays, pageEngine`), `types/models.ts`, `context/AppStore.tsx`. All 15 instructions carry code markers (`/* instruction #N */`).

**Screens present (Stage union):** login, panchayat, appSettings, fy, fySettings, home, cashbook, entry, funds, categories, monthly, goswara, reports, ledgers, backup, bank, works, workDetail, mb, manday, bills, cc, formats, masters, closing. **Not present as dedicated screens:** S-03 storage-permission gate, S-04 restore-detected, page-verification, material-ledger/stock-register tile, scheme-detail screen (see B16/B17/B13/B28).

| # | Instruction | Status | Evidence |
|---|---|---|---|
| 1 | Login button visible / layout fixed | **Implemented** | `LoginScreen` — `KeyboardAvoidingView` + `ScrollView flexGrow` (comment: “fixed-height screen → login button niche chala jata tha”) |
| 2 | Theme colour in App Settings | **Implemented** | `AppSettingsScreen` “Theme colour (6 रंग)”, `app.themeId`, `applyThemeAndStyles` |
| 3 | MB material/labour grouping + कारीगर toggle (default labour) | **Implemented** | `MbScreen` (two parts + subtotals), `models.ts` `karigarIn: 'labour' \| 'material'` default labour |
| 4 | Manday sanction-in-sanction + prefilled BSR page + 2–3 closest combos | **Implemented (verify combo count)** | `MandayScreen` + BSR page (items pre-seeded: सीमेंट/रेत/गिट्टी 40-20-12/पत्थर/ईंट…), `AppStore` rate-missing → BSR open, `services/mandays.ts suggestCombos()` sorted by closeness, **returns top 8** — UI must show only 2–3 |
| 5 | Bills vendor dropdown + add-in-place | **Implemented** | `BillsScreen` — `vendors`, `addVendor`, dropdown + “यहीं से add” |
| 6 | CC 7 pages in uploaded Excel format + PDF/Excel share | **Implemented** | `CcScreen`, `services/formats.ts` CC section (पृष्ठ 1…7), `exportDoc.ts` (expo-print PDF + .xls) |
| 7 | Expense Work \| Other, in-dropdown new work, category CRUD | **Implemented** | `EntryScreen` “खर्च का प्रकार”, in-list “नया कार्य”, `CategoriesScreen`/category level list add-rename-delete |
| 8 | Work form: scheme, AS/TS/FS, dates, MB status + MB details | **Implemented** | `WorkForm` “Instruction #8 — योजना, AS/TS/FS …, शुरू/पूर्ण तिथि, MB स्थिति”, `models.ts` sanction/MB block; scheme auto-select on work pick in entry |
| 9 | Minimal entry fields, one scheme per entry, no repeat asking | **Implemented** | `EntryScreen` “instruction #9 — सिर्फ़ date, किससे प्राप्त, राशि, योजना, श्रेणी”; one-scheme save |
| 10 | Thin cashbook (one side fits) + cash = medium, default own fund | **Implemented** | `CashbookScreen` narrowed columns + scale (instruction #10), hint “नकद … default Own Fund” |
| 11 | गोशवारा + ledger two-side, original Excel/PDF type | **Implemented** | `formats.ts buildGoswara` (मद-wise आय\|व्यय), ledger = खाता बही rows (श्री पोते → जमा/नाम → running शेष) |
| 12 | सभी प्रपत्र original look + Excel-type + Excel & PDF share | **Implemented** | `FormatsScreen` + `formats.ts` (गोशवारा/प्रपत्र-1/प्रपत्र-4/ledger/bank/CC) + `exportDoc.shareFormat` (PDF \| Excel dialog) |
| 13 | Bank statement fields = uploaded Excel + 5-way tagging | **Implemented** | `BankScreen` “instruction #13”, `models.ts` `BankLine` + `vendorId/categoryId/note` tagging |
| 14 | Backup/restore in user folder, app-granted permission, uninstall-safe, no `Android/data` | **Implemented (device test pending)** | `services/backupFolder.ts` — SAF `Directory.pickDirectoryAsync`, permission persisted, list/read/delete in that folder; `BackupScreen` |
| 15 | Return to same page + zoom (pinch or ±) | **Partially implemented** | `cashbookUI = { page, zoom }` persists across entry→back; `− / reset / +%` controls present; **no pinch-gesture handler found** — pinch still pending |

**Not covered by the 15 but built in v6 (from `services/` + screens):** page engine (L, txn = L−4, carry-forward), FY closing wizard, formats centre, masters (BSR/Item/Holiday/Worker/Vendor), monthly check, FY settings with PIN confirm, 8-logo first-run chooser.

**Known gaps to track (mostly Section B):** S-03/S-04 permission+restore screens, page verification stamp, material ledger/scheme-detail tiles, zip+manifest backup & migrate-restore flow, PDF option set (page numbers/A3/watermark), Excel 12-sheet workbook, edit-reason picklist, correction-entry fields, sanction-year BSR default (C2), material-first/last-bill/qty rules (C3–C5), txn attachments (C7), patta fields (C12), pinch zoom, WhatsApp one-tap गोशवारा share.

---

**End of consolidated master document.** Implementation and GitHub issues should quote section ids (e.g. `C.2`, `A4`, `B15`, `C-7`, `D-4`).

---

## E. v8 implementation round (26-09-2026) — user ki 30-point correction list

> Deliverables: `Gram-Panchayat-Cashbook-FULL-v8.zip` (repo root par, 30 files, `node_modules` nahi,
> forward-slash paths, full project — configs + package-lock shamil) + `.github/workflows/build-apk.yml`
> (workflow name **v8**).
>
> Chalane ka tarika: **Actions → Build APK (Gram Panchayat Cashbook v8) → Run workflow**
> (ya `git tag v8 && git push origin v8`).

| # | Correction | Status | Kahan laga |
|---|---|---|---|
| 1 | Biometric हटाओ | done | LoginScreen — button + description + `setBiometricEnabled` hataya |
| 2 | Logo options हटाओ + folder ka `cashbook logo.jpg` | done | `LOGO_CHOICES` gayab; `assets/images/cashbook-logo.png` (1024×1024) login + App Settings dono me |
| 3 | FY home → Opening balance click → scheme-wise + edit (PIN/fingerprint) | done | `SchemeDrillModal` + `PinModal` + `updateFundOpening` |
| 4 / 8 | Income / Expense / Balance click → real-time scheme-wise | done | `Stat` pressable, FYScreen aur HomeScreen dono par |
| 5 | Entry click → scheme-wise count + amount | done | drill `txns` |
| 6 | Colour swatch picker (code input नहीं) | done | `ColorSwatchField` + `COLOR_SWATCHES` — FY Settings ke 4 colour fields |
| 7 | Cash कोई योजना नहीं — अपना कोष 2 columns (नगद + बैंक) | done | cashbook `amtCols = schemeCols + ownCols + कुल`; header row-1 योजना / अपना कोष / कुल |
| 9 | Expense से `परि. रजि. पृ.` column हटाओ; 9b footer uniform font colour | done | `rightCols` से `asset` हटाया; footer rows में `kindColor` |
| 10 | Entry click → edit; FY setting back-date edit on/off (off = read-only) | done | `FySettings.allowBackDateEdit` (default on) |
| 11 | Blank lines entry के समय (FY gap setting हटाओ) | done | `blankLineGap` 1..4 → 0..3 blank lines; EntryScreen chips |
| 12 | Pre-selected L1/L2/L3 श्रेणी नहीं — सिर्फ़ add/delete | done | flat leaf-category `SelectField` |
| 13 | DD/MM/YYYY | done | `fmtDate()` (pageEngine) सभी FY/date cells में |
| 14 | Expense का `कार्य` एक category की तरह | done | `categoryId = workCatId`, subcategories null |
| 15 | Month dropdown (manual नहीं); 15b हर महीने का month-end page अपने-आप | done | MonthlyScreen `SelectField`; `syncMonthlyPages()` |
| 16 | गोशवारा / ledger दो-पक्षीय (cashbook जैसा) | done | गोशवारा आय/व्यय panels; ledger जमा/नाम panels + चलता शेष |
| 17 | असली `.xlsx` share | done | `services/xlsx.ts` (हाथ से बना OOXML/ZIP writer, नया dependency नहीं) |
| 18 | Ledger में work/bill/vendor/AS-FS-TS संख्या+तिथि + ZP/PS प्रथम किस्त रसीद | done | LedgersScreen enriched rows + `ZP / PS प्रथम किस्त — रसीद` card |
| 19 | कार्य में funding-agency dropdown (add/edit/delete) | done | `FundingAgency` master + WorkAddForm `SelectField` + manager modal |
| 20 | Audit engine `audit formet demo.xlsx` की 6 sheets | done | Formats → **Audit workbook**: full गोशवारा · गोशवारा · प्रपत्र-1 · सामग्री ऑडिट · श्रम ऑडिट · पट्टा ऑडिट (`shareWorkbook`) |
| 21 | PDF default A4 + orientation option | done | `docHtml` का एक ही सही `@page` rule + `chooseOrientationThenShare` |
| 22 | Bank statement Excel-जैसा page | done | column letters A–E, WITHDRAWAL(DR) / DEPOSIT(CR), चलता शेष + list toggle |
| 23 | अलग Work / MB / Bill / CC tiles + work detail drill-down | done | 4 home tiles; `WorkPicker`; WorkDetailScreen (AS/TS/FS + तिथि, स्वीकृति, शुरू/पूर्ण, बिल, कुल भुगतान) |
| 24 | MB click → कार्य विवरण पहले से भरा + MB details (कुल/श्रम/कारीगर valuation, item-wise मात्रा + BSR दर, karigar toggle) | done | MbScreen auto work card + BSR hint + valuation split |
| 24b | Bills → works → payment entries → entry क्लिक → विवरण | done | `WorkPicker` + card tap → बिल विवरण modal (तिथि, vendor, MB सामग्री पंक्तियाँ) |
| 25 | CC click → Excel-जैसी sheets, Excel + PDF share | done | `askAndShare` (PDF A4 orientation / असली `.xlsx`) |
| 26 | MB सिर्फ़ valuation; mandays CC labour से; defaults कारीगर 600 / श्रमिक 260; trial-error solver (60000 → 20 × 235 × 255 = 59925); MR composition wizard (10+2 / 15+1 / +5) पाक्षिक split | done | `DEFAULT_ROLE_RATE`, चौड़ा workers sweep, `minPeople` hint, MR wizard (size / कारीगर / count → स्वतः note) → `MandayCalc.muster` |
| 27 | Backup custom storage path + install के बाद permission | done | SAF `Directory.pickDirectoryAsync`, persist permission, `expo-file-system` plugin |
| 28 | FY closing → file/database/zip share (text नहीं); format centre → पूरा A4 page | done | `shareRawFile` / `shareZipBundle` (json + गोशवारा.html + खाता बही.html + README); Formats → "पूरा Formats Centre A4" |
| 29 | Worker की list नहीं — सिर्फ़ counting + mandays | done | Masters → `मान-दिवस` tab (aggregate), Workers roster हटाया |
| 30 | BSR: mandays calculate नहीं होते, page बार-बार खुलता, boxes खाली | done | default दर 600/260 fallback; auto-`setBsrOpen(true)` effect हटाया; modal inputs का background अलग (`Field bg` + सफ़ेद दर box) |

**Verification:** `tsc --noEmit` EXIT=0 · `expo export --platform android` EXIT=0 (4.8 MB `.hbc` bundle).

---

## Section F — v9 (19-point correction list)

> **Zip:** `Gram-Panchayat-Cashbook-FULL-v9.zip` (repo root, forward-slash paths,
> full project — configs + package-lock shamil, `node_modules/.git/.expo/android/ios/dist/.idea/.vs/out/.cache` nahi)
> + `.github/workflows/build-apk.yml` (workflow name **v9**).
>
> Chalane ka tarika: **Actions → Build APK (Gram Panchayat Cashbook v9) → Run workflow**
> (ya `git tag v9 && git push origin v9`).

| # | Correction | Status | Kahan laga |
|---|---|---|---|
| 1 | Launcher icon aapka jpg (1024 full-bleed) | done | `assets/images/cashbook-icon.png` (icon + favicon), `cashbook-icon-foreground.png` (#123b2c canvas + logo 634px) → `app.json` `icon` + `adaptiveIcon.foregroundImage` + `splash.image`; `version` 1.0.2 / `versionCode` 3 (CI me `expo prebuild` icon regenerate karta hai) |
| 2 | FY main + FY home tiles = 2-tile grid (6 tiles) | done | `Stat` (tile style outermost, `width:47.5%` flexGrow/Shrink 0), `statLabel/statValue/statHint/statPressed`; FYScreen + HomeScreen me 6th टाइल **रद्द (cancelled)** |
| 3 | Cashbook: month-end page sirf month ki last date ke baad; baaki waqt current date ka page; back-date sirf usi entry tap par; nayi entry par date ke baad "is date ka page / agla possible page" (suggestion = agla); ek page ki saari dates ek hi hon; zabardasti alag date = us date ka naya page | done | `types/models.ts` `CashbookPage.date?`; `pageEngine.monthLastDay()`; `AppStore.withPageDates` (migration), `dateLabel/pageDate/insertDatePage`, date-based `assignPageFor`, `syncMonthlyPages` (sirf month-end < aaj; **future ke auto month-end pages bhi delete** — un par entry nahi honi chahiye), `pageOptionsForDate/ensurePageForDate/pageDateOf`, `addTransaction({... pageId})`; hydrate chain `stripSchemeCats(migratePages(withPageDates(withOpeningsSnapshot(seedBsrItems(mergeRaw(p))))))`; EntryScreen date-blur `askPageForDate` (सुझाव: अगला पन्ना / {date} का नया पन्ना / बाद में); CashbookScreen `ensurePageForDate(todayInFy())` + `gotoTodayFy` effect + header `· {date}` |
| 4 | Cashbook share → PDF/Excel + page-range select | done | CashbookScreen share → page-range modal → `askAndShare(title, body, true)` |
| 5 | Categories se SFC/FFC hatana | done | `seedCategories` se `inc-sfc/inc-ffc` gayab; `stripSchemeCats()` hydrate + `importBackupJson` chain me |
| 6 | "Amounts by fund" = ek hi राशि column | done | MonthlyScreen edit modal me ek hi `editAmount` |
| 7 | Category path se SFC/FFC hatana | done | `stripSchemeCats()` + edit path me `aliveCat()` (purane category id clear) |
| 8 | Phone back button entry-edit par kaam kare | done | MonthlyScreen edit Modal `onRequestClose` + local `BackHandler` listener; PinModal/CancelModal `onRequestClose` |
| 9 | गोशवारा share/table = Excel-type layout | done | GoswaraScreen `tblBox/tblHead/tblHeadCell/tblRow/tblCell/tblTot`; button "Share — PDF / Excel" |
| 10 | Manday count rework — **'मेट' hataya**; श्रेणी/कारीगर ki alag-alag राशि; real-time निकटतम; dono me se ek-ek chuno → total (labour + karigar); MR detail (23 श्रमिक / 7 कारीगर → 3 × 10-10 MR); per-MR karigar split, baaki sab श्रमिक; MR ek-ek karke bharein; wahi detail work ke CC Excel format me | done | `MandayScreen` pura naya: `mandayOptions()` (days fix, rate −5/−10/−15/−20/−10%/−20% → sabse kam bache **3 options**, useMemo par real-time), `desiredLab` + `desiredKar` do alag fields, ek-ek option pick → **कुल योग** card; MR composition (size chips + apni size, count = auto ya custom, har MR me **कारीगर / श्रमिक dono custom inputs** — "pehle कारीगर, baaki श्रमिक"); save → 1 `MandayCalc` + N `PakhwadaRoll` (`rollNo MR-1…`, `mateCount:0`, `skilledCount`=कारीगर, `unskilledCount`=श्रमिक, `sourceId`) → **CC पृष्ठ 3 (Excel) me wahi detail**; `deleteMandayCalc` apne rolls bhi delete |
| 11 | AS/TS/FS + dates add karne par **MB entry** me mention hona chahiye | done | MbScreen "कार्य विवरण (auto) — स्वीकृति व MB" card ab alag-alag label lines: योजना/स्वीकृति सं./एजेंसी, **A.S. (प्रशासनिक) — क्रमांक + दिनांक**, **T.S. (तकनीकी)**, **F.S. (वित्तीय)**, FS राशि + MB मूल्यांकन, शुरू→पूर्ण + MB नं./पृष्ठ |
| 12 | MB detail se **'मेट'** hatana; सामग्री qty & rate column patle | done | MbScreen role buttons sirf **श्रमिक / कारीगर**; qty-rate fields `Field grow` (row me poori chaurai); HTML tables me `cols(...)` colgroup → CC पृष्ठ 4 (6 col: 6/30/12/10/19/23) aur प्रपत्र-4 (7 col: 6/26/11/9/14/17/17) — मात्रा/दर/मूल्यांकन ab patle nahi |
| 13 | Labour side par श्रेणी/कारीगर ko **item nahi puchna**; सामग्री items = **BSR dropdown + usi dropdown me "नया item"** | done | MbScreen: `part==='labour'` par Item field gayab, naam apne-aap श्रमिक/कारीगर, दर `referenceRate()` se auto; `part==='material'` par `SelectField` = BSR(active FY) + ItemMaster ki poori list + aakhir me **➕ नया item…** (usi dropdown me) → 'new' chunne par free-text naam; BSR select karte hi दर auto |
| 14 | MR composition: MR labour/karigar count custom, phir per-MR karigar/labour split bhi custom | done | MR size chips (5/10/15/20) + **apni numeric size**; MR count chips (1–6) ya **स्वतः** (ceil(लोग/size), up to 60); har MR ka card `MR i/n — X कारीगर + Y श्रमिक = Z/size` with 2 numeric inputs; validation (कुल कारीगर/श्रमिक match + per-MR ≤ size) |
| 15 | Bank statement **Excel upload** (PDF nahi) → app parse karke statement + cashbook bhare, phir edit | done | BankScreen "⬇ Excel / CSV फ़ाइल से import" (`File.pickFileAsync`) → `.xlsx` = `parseXlsx` (har sheet ko koshish) / `.csv` = `parseCsv(bytesToText)`; header detect `DATE · NARRATION · Scheme · WITHDRAWAL (DR) · DEPOSIT (CR) · BALANCE · vendor · Particulars · Other` (+ txn date/val date, debit/credit, cheque/UTR); Excel serial + DD/MM/YYYY + YYYY-MM-DD date, ₹/,/(neg) amount, Scheme → fund match, duplicate skip; phir har row **edit modal** (`BankLineEditor` — दिनांक/विवरण/राशि/जमा-नाम/संदर्भ/योजना/कार्य/विक्रेता/शीर्ष/टिप्पणी) + **"सबको cashbook में Post करें"** bulk post; sheet row tap = edit |
| 16 | Backup folder "backup fail" — SAF `File.create` kaam nahi karta → `directory.createFile` | done | `services/backupFolder.ts` `saveBackup(string\|Uint8Array)` → `Directory.createFile(name, mime)` (purana same-name delete); `listBackups` `.json/.csv/.xlsx/.zip`; `readBackupBytes` |
| 17 | Full JSON backup share as `.json`/`.zip` **file** | done | `BackupScreen.shareBackupFile` (`shareRawFile`/`shareZipBundle`), `encode()` json/csv/xlsx/zip |
| 18 | "Share FY CSV" share kare — har jagah format match | done | ReportsScreen `shareFyCsv()` → `shareRawFile` (module-level), `Share` import hataya |
| 19 | Restore **excel / csv / json** accept kare | done | `services/zipread.ts` (hand-written DEFLATE inflater + ZIP reader), `xlsxread.ts` (OOXML regex parser), `backupCodec.ts` (`backupToCsv/Xlsx/Zip`, `parseCsv`, `csvToXlsx`, `parseBackupText/Bytes`); paste-restore bhi `parseBackupText` se |

**Verification:** `tsc --noEmit` EXIT=0 · `expo export --platform android` EXIT=0 (4.9 MB `.hbc` bundle).


---

## Section G — v10 (30-point correction list)

> **Zip:** `Gram-Panchayat-Cashbook-FULL-v10.zip` (repo root, forward-slash entry paths,
> prefix `cashbook-mobile/`, poora project — configs + `package-lock.json` shamil;
> `node_modules` `.git` `.expo` `android` `ios` `dist` `.idea` `.vs` `out` `.cache` bahar)
>
> **Workflow:** `.github/workflows/build-apk.yml` →
> `name: Build APK (Gram Panchayat Cashbook v10)` + `ZIP=./Gram-Panchayat-Cashbook-FULL-v10.zip`
>
> **Run:** GitHub → Actions → **"Build APK (Gram Panchayat Cashbook v10)"** → **Run workflow**

### G.1 — App banane ke liye zaroori details (kisi bhi tool se banane ke liye)

Ye steps kisi bhi machine par chalao — output same aayega:

1. **Zip extract** karo (forward-slash entries, `cashbook-mobile/` prefix) → `extracted/cashbook-mobile/`
2. **Node 20+** (local par Node 24 bhi chalta hai), phir:
   `cd extracted/cashbook-mobile && npm ci --no-audit --no-fund`
3. **Typecheck (fail-fast):** `npm run typecheck` (= `tsc -p tsconfig.json --noEmit`) → exit 0 chahiye
4. **Native project banao:** `npx expo prebuild --platform android --no-install`
   (`-y` mat likhna — SDK 57 me aisa flag nahi hai)
5. **APK:** `cd android && ./gradlew assembleRelease --no-daemon --stacktrace`
6. **Output:** `android/app/build/outputs/apk/release/*.apk`

Bundle sanity check (optional):
`npx expo export --platform android --output-dir <any-folder>` → exit 0.

**Nayi dependency (v10):** `expo-local-authentication@~57.0.3` — `package.json` +
`package-lock.json` dono updated hain, isliye `npm ci` se hi install ho jaata hai aur
`expo prebuild` + Gradle autolinking use kar leta hai. Koi config-plugin entry zaroori nahi.
Android par koi extra permission declare karni padti nahi (BiometricPrompt).

** zaroori environment/rule (same as v9):**
- App **offline-first** hai — koi server/API nahi. Poora data device par AsyncStorage me.
- हर पंचायत का **अलग database** (`panchayatId` scoping) — naya panchayat = fresh seed.
- Share hamesha **asli file** ho (PDF/Excel/CSV/JSON/ZIP), kabhi text message nahi.
- Devanagari text UTF-8 me hi likho — `Set-Content` se `?` ban jaate hain (node / UTF-8 writer use karo).

### G.2 — 30-point list (status)

| # | Requirement | Status | Implementation |
|---|---|---|---|
| 1 | Naya panchayat banate hi **doosre panchayat ka data bilkul na dikhe** — har panchayat ka alag database | done | `types/models.ts` — 18 record types me `panchayatId?`; `AppStore` me `SCOPED_KEYS` + `scopeData(raw)` (view) + `runScoped(action)` (action scoped chalta hai, baaki panchayat ki rows wapas merge, nayi rows `prev.activePanchayatId` stamp) + `setData` wrapper; `addPanchayat` naye DB ko **fresh `uid()` ids** ke sath seed karta hai (funds/categories `catIdMap` remap, fundingAgencies, bankAccounts fallback `ba1`, bsrRates, itemMasters, workerRates, `openingBalance: 0`) aur transactions/works/mbLines/bills/bankLines/pages/workers/vendors/holidays/mandayCalcs **khaali**; `deletePanchayat` `setDataRaw` se seedha purges (`panchayatId===id` ya `panchayatId==null && cur===id`) |
| 2 | FY tile popup ka **niche wala box dikhta nahi** tha | done | Modal-overflow root fix: `useModalBodyMax(pct, reserve)` → `Math.max(150, Math.round((height-44)*pct) - reserve)`; `modalCard` ka `maxHeight` % ab clip karta hai kyunki andar ka ScrollView pixel-exact hai. Har lambe modal par lagaya: `SelectField`, `SchemeDrillModal`, `EntryScreen`, `BankLineEditor`, `WorkAddForm`, `BsrYearSheet`, `BillsScreen`, `WorksScreen`, `WorkDetailScreen`, `CcScreen`, `CategoriesScreen` |
| 3 | Cashbook me **aaya/kharch ki lines parallel** (line 15 ↔ line 15) | done | Dual grid — dono paksh ek hi row-grid par |
| 4 | आय श्रेणी popup layout | done | Same `useModalBodyMax` + tree/list layout |
| 5 | Scheme chunne ke baad **cash ya bank** poochho | done | `Transaction.medium?: 'cash'`+'`bank`'+`null`; EntryScreen me scheme SelectField ke turant baad "लेन-देन का माध्यम" segmented buttons; `medium` save payload me; `buildLedger` Pick me `medium` + detail tag ` · नकद` / ` · बैंक` |
| 6 | Cashbook me **apna fund pehle**, phir **2 column (cash, bank)** | done | Own-fund row पहली; do amount columns |
| 7 | Cashbook ki **दूसरी bottom लाइन (पूर्व/बचत पोते) lal + bold** | done | Inline `{ color: C.expense, fontWeight: '900' }` |
| 8 | Fund head se **cash hatana** | done | `SchemeDrillModal` rows, `MonthlyScreen` scheme chips, bank-line scheme tags, `FundsScreen` sab me `fund !== 'cash'` filter; `openEdit` me legacy `'cash'` fallback; `EntryScreen` ki `schemeFunds` pehle se filtered |
| 9 | **Category screen tree** jaisa presentation — har branch par add/edit/delete | done | `CategoriesScreen` me recursive `renderNode` (L1→L2→L3), expand/collapse chevron, har node par `+` / `✎` / `🗑`, add-child / rename / archive modals; `archiveCategory` ab **poori subtree** ko archive karta hai (5-pass descendant collection) |
| 10 | Monthly check dropdown popup ka niche box | done | `useModalBodyMax` (item 2 wala fix) |
| 11 | गोशवारा Excel-jaisi **footer lines dono taraf** | done | `goswaraHtml` footer bands left + right |
| 12 | Ledger **Excel-jaisa table har format** me; ZP/PS ka **"प्रथम किस्त" hatana**; ledger **per work** | done | `tblBox/tblHead/tblRow/tblCell/tblTot` sab ledger/CC tables me; `ledgerHtml`/`buildLedger` me koi "प्रथम किस्त" nahi; ledger work choose karke |
| 13 | Ledger home par **dropdowns (scheme / work / month)** | done | `LedgersScreen` ke teen filters |
| 14 | Share ki Excel/PDF file ke naam me **format ka naam + date** | done | `stampedName(title)` = `safeName(title) + ' - YYYY-MM-DD'`, `sharePdf`/`shareExcel`/`shareWorkbook` me |
| 15 | Format Center me **dropdown + share se pehle layout preview** | done | `fmtKey`/`fmtList` + `SelectField`, orientation/filename box, "पूर्व-दृश्य" → `previewDoc` (expo-print), "Share — PDF / Excel" → `askAndShare` |
| 16 | Bank statement par **karya (work) chunne ka popup** | done | `WorkPicker` modal |
| 17 | Sirf ankon wali fields par **numeric keyboard** (dates bhi) | done | Har numeric `Field` par `keyboardType="numeric"` (audit: 0 missing); **dates** ab `dateDigit(setter)` se — sirf अंक type karo, `-` apne-aap (`YYYY-MM-DD`); purane `DD-MM-YYYY` text ko chhunta nahi |
| 18 | Masters ki input fields **bahut patli** thi; **alag man-days calculation page** (bina koi kaam jode) | done | `Field` ko `minHeight:46` + `grow` + `bg: C.input` (BSR Unit/Rate, Item name); **Home tile "मान-दिवस गणना (स्वतंत्र)"** → `go('manday','')` → `MandayScreen` standalone mode (`workId=''`): header alag, MB-component limit 0, **sirf हिसाब save** (koi Muster Roll nahi banta), alert me bhi yahi bataya jata hai |
| 19 | **Holiday ka option hatana**; 26 Jan / 15 Aug / 02 Oct har MR me default chhuttiyan; pakhwada default **12 man-days** | done | `FIXED_HOLIDAYS` + `pakhwadaWorkingDays` (Sunday + teen fixed; Sunday jeet jata hai); `DEFAULT_PAKHWADA_DAYS=12`; `MastersScreen` ka **Holiday tab puri tarah hataya** (uski jagah hamesha-dikhne wala "छुट्टियाँ (निश्चित — कोई विकल्प नहीं)" card); Home tile label `Masters (BSR/Items/मान-दिवस)` |
| 20 | **Work add hone ke baad edit** ka option | done | `WorkAddForm` me `edit`/`onDone` props (sare field prefilled) + `updateWork`; `WorkDetailScreen` par "✎ कार्य सुधारें" modal |
| 21 | MB entry ke liye **सामग्री और श्रम alag-alag pages**; सामग्री page par karigar → material ya labour; **default = karigar in labour amount** | done | `MbScreen` me do bade tabs: **सामग्री (Material) · N** / **श्रम (Labour) · N**; ek hi waqt sirf us page ka form + us page ka group card (doosre ka sirf yog). सामग्री page par naya chooser **"यह किस पक्ष में गिनें?"** → `सामग्री` / `कारीगर → श्रम राशि`; `isKarigarName()` (कारीगर/मिस्त्री/श्रमिक/मजदूर/labour/karigar…) match hote hi **default labour**, `kind:'artisan'` + `karigarIn:'labour'`. श्रम page par purana karigar-toggle **hataya** |
| 22 | Nearest-amount ka **vistaar se hisaab** (e.g. "19 labour × 12 days + 1 labour × 2 days @ ₹260/day → ₹59,800 near ₹60,000") | done | `MandayOpt` me `full`/`rem`; `mandayOptions(desired, rate, days)` ab `floor(desired/rate)` man-days ko `full × days + 1 × rem` me baant-ta hai; `dayChoices = [12,13]` jab `days===12`; `optDetail(o, desired, who)` → `"19 श्रमिक × 12 दिन + 1 श्रमिक × 2 दिन @ ₹260/दिन → ₹59,800 · चाहिए ₹60,000 · अंतर ₹200"`; **`optList(..., desired)`** call sites par `parseFloat(desiredLab/Kar)` pass hota hai |
| 23 | Karigar ke liye **wahi detail** | done | `optKar` wale `optList` par bhi `desiredKar`; per-MR line dono hisso ki dikhati hai |
| 24 | Labour/karigar **13 man-days se zyada nahi**; default 12; 13 sirf tab jab 12 se bada fark bache | done | `MAX_PAKHWADA_DAYS=13`; days field ab `onChangeText={onDays}` (clamp 1..13); `rollDays = max(selLab.days, selKar.days) \|\| D` → MR/period/saving sab usi se; **`saveCalc` me do guards** (`D>13` aur `rollDays>13` par rok); option lists me 13 sirf nearest-amount candidate ke roop me |
| 25 | Bills par **vendor chunne ka popup** | done | Vendor chooser modal (`WorkPicker` jaisa) |
| 26 | Bills → **works ki list + "Other Expenses"**; cashbook ke vouchers apne-automatically apne work ke niche; voucher tap → detail + edit/correct/delete | done | `OTHER_WORK_ID='other-expenses'` sentinel + `WorkPicker.includeOther`; `BillsScreen` ka voucher section → detail modal → "✎ सुधारें" (`setEditTxnId` → EntryScreen) aur "🗑 रद्द करें" (`CancelModal`); `Shell` `setEditTxnId` pass karta hai |
| 27 | CC → **wahi works list**; work ka CC data print/Excel layout me; wahin se edit/correct | done | पृष्ठ 1 / 3 / 4 sab `tblBox` Excel tables; `ccBody()` nikala — `share` aur naya `preview` dono use karte hain; "✎ कार्य सुधारें" → `WorkAddForm edit={w}` |
| 28 | Works screen: **upar list → detail; bottom-right `+` FAB** se add form | done | `WorksScreen` FAB + modal; `Empty` steps update |
| 29 | Layout audit — **koi box doosre ko cover na kare**; font/bg colour same nahi hone chahiye | done | Header title ab `minWidth:0/flexShrink:1` (lamba title action/badge ko cover nahi karta); action/badge ko `flexShrink:0` wrapper; `Field` ka bg `C.card`→`C.input` (modal ke andar invisible box tha); sabhi chip selected par **white text on `C.primary`**; table header `#1d2b23` on `#e8f2ec` (contrast); CC पृष्ठ 3 + Excel/CSV se **"मेट" कॉलम hataya** (header + rows + totals + note), naam कारीगर/श्रमिक; lambe modal sab `useModalBodyMax` par |
| 30 | Web research → sujhav poocho → confusion confirm → **feedback ke baad implement** | done | Research: eGramSwaraj / Meri Panchayat (geo-tag, audit trail, offline), GIGW + Bharat fintech/rural UX (offline-first, vernacular, duplicate prevention, trust/lock). User ne chuna: **(A) App Lock, (B) Auto-backup reminder, (C) Duplicate entry warning** — teeno implement |

### G.3 — v10 me nayi 3 cheezein (user ke feedback ke baad)

**(A) App Lock — PIN + अंगुली/चेहरा + auto-relock**
- `types/models.ts` `AppSettings` me naya: `lastBackupAt?`, `autoLockSec?` (`biometricEnabled` pehle se tha, ab use hota hai).
- `app/index.tsx` module-level helpers `bioAvailable()` (`hasHardwareAsync && isEnrolledAsync`) aur `bioAuth()` (`LocalAuthentication.authenticateAsync`) — dono try/catch, kisi bhi error par `false` (app kabhi nahi atakta).
- **LoginScreen:** agar sensor hai to "अंगुली / चेहरा से खोलें" (chalu) ya "अंगुली से खोलना चालू करें" (bund) button; success → seedha app. PIN field hamesha maujood (fallback).
- **AppSettingsScreen → Security (App lock):** अंगुली ON/OFF toggle + "ऐप background जाने पर कितनी देर बाद lock" chips: `तुरंत / 30 सेकंड / 2 मिनट / 10 मिनट` (default **30 सेकंड** — chhote app-switch par adhura form na ude).
- **Shell** me `AppState` listener: `background`/`inactive` → timer, `active` → timer cancel; timer fire hone par `stackRef = ['login']` + `setStage('login')`.

**(B) Auto-backup reminder**
- `BackupScreen` — `saveBackup()` aur `shareBackupFile()` safal hote hi `updateApp({ lastBackupAt: now })`.
- `HomeScreen` — `lastBackupAt` missing ho ya **≥ 2 din** purana ho to sabse upar hamesha **काम का card**: "⬇ बैकअप लेने का समय हो गया" + aakhri backup ki tareekh + tap → `go('backup')`.

**(C) Duplicate entry warning**
- `EntryScreen.save` — do check: (a) wahi `reference` (purana wala), aur **(b) naya**: wahi `date` + wahi `type` + `|amount − n| < 0.5` + (party khali na ho to wahi party, case-insensitive). Dono me se koi mila to confirm dialog: "संभावित दोहरी entry" + kaaran + wahi entry ki details + "वापस / हाँ, सहेजें".

**Verification:** `tsc -p tsconfig.json --noEmit` EXIT=0 · `expo export --platform android` EXIT=0 (4.9 MB `.hbc` bundle).
**Zip:** `Gram-Panchayat-Cashbook-FULL-v10.zip` — approx **2.11 MB**, **44 entries** (34 files + 10 dir entries), sab forward-slash, sab `cashbook-mobile/` prefix, `node_modules` bahar.

---

## H. v11 — 27 अंक (यूज़र की सूची) — सब पूरे

> Scope: bug-fix + UX + Format Centre/CC की असली original जैसी छपाई + BSR multi-year + reminders/greeting.
> दोनों `PROJECT_MASTER_NEW.md` (repo root और `cashbook-mobile/`) एक ही साथ अपडेट रखे जाते हैं।

### H.1 — पूरे 27 अंक

| # | अंक | क्या बदला | कहाँ |
|---|---|---|---|
| 1 | FY-home tile popup के नीचे के बॉक्स दिखें | सब `useModalBodyMax` reserves बढ़ाए (default 190→250), modal chrome से कम न हो | `app/index.tsx` |
| 2 | Cashbook खुले तो **आज के दिन** के पेज पर + पेज date-wise क्रम में | `cashbookUI` में `gotoDate` add; `fyPages` को `pageSortKey` + `pageNo` से sort | `context/AppStore.tsx`, `app/index.tsx` |
| 3 | Entry submit के बाद उसी तारीख़ के पेज पर जाए + "आज की तारीख़ पर जाएँ" + ऊपर खुले पेज की तारीख़ | EntryScreen `back()` से पहले `cashbookUI.gotoDate`; CashbookScreen में `आज` बटन + टॉप पर खुले पेज की तारीख़ | `app/index.tsx` |
| 4 | SFC/FFC चुनते ही माध्यम **बैंक** auto | `effSchemeId === 'sfc' \| 'ffc'` → `setMedium('bank')` | EntryScreen |
| 5 | आय श्रेणी popup के नीचे के बॉक्स दिखें | item 1 के साथ ही reserve बढ़े | EntryScreen |
| 6 | "इनमें से कोई नहीं" श्रेणी = सामान्य अदायगी; month-check में category error न आए | sentinel `GENERAL_CAT_ID` / `GENERAL_CAT_LABEL` export; `isPathIncomplete` = false, `categoryPathLabel` = लेबल; `catOptions` में आख़िरी option + quick chip "सामान्य अदायगी" | `services/pageEngine.ts`, EntryScreen, `services/formats.ts` |
| 7 | तारीख़ चुनने को **कैलेंडर महीना popup** | `DateField` component — महीना/साल selector + दिनों का grid | `app/index.tsx` |
| 8 | व्यय में "को भुगतान" = सिर्फ़ **vendor dropdown** + inline नया vendor | vendor `SelectField` + `vendorAddOpen` modal (`addVendor`); `party.trim()` अनिवार्य | EntryScreen |
| 9 | Voucher flow: शेष → राशि → भुगतान प्रकार (कार्य/अन्य) → कार्य dropdown → योजना auto → माध्यम (कार्य पर बैंक) → विवरण; योजना दोबारा न पूछे | पूरा ऑर्डर बदला; कार्य चुनने पर scheme कार्ड read-only; ऊपर balance card (नगद/बैंक/कुल) | EntryScreen |
| 10 | श्रेणी-वृक्ष आसान + **long-press मेनू** | row `onLongPress` + ⋮ `folder` IconBtn → `menuFor` modal (जोड़ें/नाम बदलें/खोलें-बंद/हटाएँ) + "सब खोलें/सब बंद" | CategoriesScreen |
| 11 | Cashbook share crash (`<b>` टैग) | RN में `<b>` नहीं चलता — `<Text fontWeight='900'>` (HTML export strings अपरिवर्तित) | CashbookScreen |
| 12 | लेजर dropdowns (स्कीम/कार्य/श्रेणी) + **गोशवारा → लेजर cross-link** | `GoswaraRow.key` (`cat:`/`work:`/`scheme:`), `buildGoswara(..., workNames, schemeNames)`; row Pressable → `ledgerJump` → `go('ledgers')`; LedgersScreen में `catId` + `pathOf` + श्रेणी SelectField | `services/formats.ts`, LedgersScreen |
| 13 | Format Centre export असली जैसे + CC में फोटो space, फोटो उसी पेज पर, नीचे हस्ताक्षर | `photoBox` 300px; **Format Centre में CC entry + "पूरा प्रपत्र केंद्र" में CC पेज**; हर पेज `.ccpage` wrapper | `services/exportHtml.ts`, FormatsScreen |
| 14 | हर जगह कैलेंडर से तारीख़ | सारे date inputs → `DateField` (14 जगह) | `app/index.tsx` |
| 15 | Labour का nearest-value floor bug (2900/6100) | `mandayOptions` अब `totalMd >= 1` ही माँगता है; empty-state में न्यूनतम राशि quote | `services/mandays.ts` |
| 16 | MR-wise समानांतर karigar/labour विभाजन + combo विकल्प + कार्य खोलने पर show/edit/delete | `capOf(i,n,sz,tw)` (आख़िरी MR = शेष), `dist(total)` क्षमता-आधारित + largest-remainder, overflow rebalancing; **WorkDetailScreen में "मन-डे स्वीकृतियाँ (MR)" कार्ड** — ✎ (MandayScreen) व 🗑 (confirm) | `services/mandays.ts`, WorkDetailScreen |
| 17 | CC photo पेज पर सरपंच/जीवीए के साथ **सचिव** हस्ताक्षर + तालिका पन्ने के नीचे तक | `signTable` में "हस्ताक्षर — ग्राम सचिव"; `.ccpage` flex + `table.sign:last-child { margin-top: auto }` → बची जगह में फोटो, हस्ताक्षर सबसे नीचे | `services/exportDoc.ts`, `services/exportHtml.ts` |
| 18 | Masters → BSR add/edit/delete | पूरा CRUD: वर्ष chips, खोज़, कार्ड list, ✎ popup (Item/Unit/Rate), 🗑 confirm, उसी वर्ष में जोड़ें (दोहरा नाम → अपडेट) | MastersScreen |
| 19 | **कई वर्षों की BSR** अलग-अलग add/edit/correct/delete | `bsrYearList(fys, rates)` + `YearField` chips + "+ नया वर्ष जोड़ें" modal; `BsrRate.year` आधार | `app/index.tsx` |
| 20 | बिल व मन-डे बनाते समय **BSR वर्ष dropdown** + वहीं से items संपादित | `YearField` + `BsrYearSheet` (year, add/update/delete) — **MandayScreen, MbScreen, BillsScreen** तीनों में | `app/index.tsx` |
| 21 | कार्य जोड़ते समय स्वीकृति राशि का **श्रम हिस्सा + सामग्री हिस्सा** | दो फ़ील्ड + live योग कार्ड; FS ख़ाली हो तो योग = स्वीकृति; `Work.labourPrior`/`materialPrior` save; WorkDetail में दिखता है | WorkAddForm, WorkDetailScreen |
| 22 | भुगतान की vendor list में उस कार्य के **MR नंबर व राशि** ही | vendor options में `rollsForWork` MR जोड़े (`ROLL — श्रम भुगतान ₹…`); चुनने पर `party` + amount auto-fill | EntryScreen |
| 23 | प्रपत्र-1 टॉप: scheme-wise balance ✎ हटाएँ + **पंचायत का पूरा नाम + पेज विवरण** | Prapt1 header बदला | Prapt1 / Formats |
| 24 | **रिमाइंडर — 9 व 18 तारीख़ + custom interval + चालू/बंद** | `AppSettings.reminderEnabled/reminderDays/reminderIntervalDays/reminderLastSeen`; helper `reminderDue()`; Home पर ⏰ कार्ड (एक दिन में एक बार); AppSettings में 1–31 तारीख़ chips + अंतराल chips (3/7/15/30 दिन) + अपना अंतराल (1–90) | `types/models.ts`, AppSettingsScreen, HomeScreen |
| 25 | **अभिवादन — ऐप खोलते ही + login पर** | `greetOf()` (सुबह/दोपहर/शाम/रात); पहली बार पूरा welcome modal (एक ही बार, `greetingShown`), उसके बाद होम की पतली कार्ड; Login पर भी greet + पंचायत नाम | `app/index.tsx` |
| 26 | स्थिरता / डेटा-loss फ़ीचर सुझाए | नीचे H.3 देखें | — |
| 27 | प्रोजेक्ट फ़ाइलें अपडेट | यह Section H — दोनों `PROJECT_MASTER_NEW.md` में (root + `cashbook-mobile/`) | यह फ़ाइल |

### H.2 — फ़ाइल नक्शा (v11)

- `types/models.ts` — `AppSettings` में `reminderEnabled`, `reminderDays`, `reminderIntervalDays`, `reminderLastSeen`, `greetingShown`
- `services/pageEngine.ts` — `GENERAL_CAT_ID`, `GENERAL_CAT_LABEL`
- `services/formats.ts` — `GoswaraRow.key`, `buildGoswara(..., workNames?, schemeNames?)`
- `services/exportDoc.ts` — `.ccpage`, `.ccpage > table.sign:last-child { margin-top: auto }`
- `services/exportHtml.ts` — CC `.ccpage` wrapper, photo box 300px, 4-हस्ताक्षर तालिका (सरपंच / ग्राम सचिव / जीवीए / JTA)
- `services/mandays.ts` — `mandayOptions` 1-manday floor, `capOf`, proportional `dist`
- `context/AppStore.tsx` — `fyPages` sort
- `app/index.tsx` — `DateField`, `YearField`, `bsrYearList`, `greetOf`, `reminderDue`, गोशवारा→लेजर link, और Entry / Categories / Ledgers / Manday / Mb / Bills / Masters / WorkAdd / WorkDetail / Cc / Formats / Home / AppSettings / Login सभी screens

### H.3 — (26) स्थिरता व डेटा-loss के सुझाव — अगले राउंड के लिए

**अभी जो बचाव पहले से हैं:** auto-backup reminder (2 दिन) · manual backup (json + zip) · duplicate-entry warning · back-date edit lock · App Lock (PIN + अंगुली) · cancelled entries audit में · FY-समापन पर safe backup (zip)।

**सुझाए गए (अमल में लाने योग्य):**

1. **Silent auto-backup** — ऐप खोलते ही Documents dir में एक नया json (दिन में एक बार), 7 दिन rotate; क्रैश/रिसेट के बाद 1-tap restore।
2. **Crash reporter** — `ErrorBoundary` + स्क्रीन-नाम/स्टैक log file में; अगली बार खोलने पर "पिछली बार समस्या हुई थी — बैकअप लें?" बैनर।
3. **Write-ahead undo** — entry save से **पहले** एक undo-snapshot; 30 दिन तक "पिछली एंट्री पूर्ववत् करें"।
4. **Sanity-check पेज** — शून्य/नकारात्मक scheme, अधूरी श्रेणी, अनटैग्ड बैंक-लाइन गिनकर "सुधारें" लिस्ट (Home पर flags पहले से हैं; अलग पेज बनाएँ)।
5. **Storage दबाव** — db size (MB) + entry count दिखाएँ; 15 MB से ऊपर बैकअप के लिए कहे।
6. **डिवाइस बदलने पर transfer** — पूरा db लाने/ले जाने का 1-step QR/zip flow (backup-restore को सरल)।
7. **Destructive actions दो-चरण** — पंचायत/FY delete पर typed confirmation।
8. **Session log (audit)** — entry कब बनी / सुधारी / रद्द हुई (मौजूदा `cancelledReason` को आगे बढ़ाएँ)।
9. **Reminder + backup एक साथ** — 9 व 18 को अनुस्मारक के साथ ही "बैकअप भी ले लें" वाला एक कॉर्ड।
10. **Slow-start guard** — भविष्य के db migration के लिए पहली स्क्रीन पर migrate + backup status, फिर Home।

### H.4 — Verification

- `tsc -p tsconfig.json --noEmit` → **EXIT=0**
- `expo export --platform android` → **EXIT=0** (5 MB `.hbc` bundle, 1793 modules)
- Zip: `Gram-Panchayat-Cashbook-FULL-v11.zip` — forward-slash entries, `cashbook-mobile/` prefix, `node_modules` / `.git` / `.expo` / `android` / `ios` / `dist` / `.idea` / `.vs` / `out` / `.cache` बाहर
- Workflow: `.github/workflows/build-apk.yml` → **Build APK (Gram Panchayat Cashbook v11)**, `ZIP=` → v11

---

## SECTION I - v12 (32-point round) - WORK DONE + SPEC

> Ye section kisi bhi tool ko de kar app **waise ka waisa** dobara bana sakte hain.
> Har point ke saath exact file / function / property bataayi gayi hai. Har naya
> behaviour code me hi likha gaya hai - spec aur code kabhi alag nahi hote.

### I.0 - Baseline

- Typecheck `tsc -p tsconfig.json --noEmit` - **EXIT=0**
- `expo export --platform android` - **EXIT=0** (5.2 MB `.hbc`, 1905 modules)
- Workflow name **Build APK (Gram Panchayat Cashbook v12)**; zip auto-glob
  `Gram-Panchayat-Cashbook-FULL-*.zip` (sabse bada version = latest).

### I.1 - Naye shared primitives (ye teeno har popup me apply hain)

**`ModalBody({ title, hint, onClose, closeLabel?, backdropClose?, children })`** - `app/index.tsx`

- Andar `ScrollView` (`maxHeight = useModalBodyMax(0.9, 140)`, content
  `flexGrow: 0`) - **content kabhi bottom box ko bahar na dhake**.
- Neeche **hamesha dikhne wala Back button**:
  `closeLabel` na do to `t(lang, "back", "वापस जाएँ (Back)")`.
- `backdropClose={false}` tab rakho jab form bhara hua ho (galat tap par band na ho).
- **Rule:** har overlay/popup parent par lautne wala Back button rakhe (v12 #6).
  Saare purane cancel labels `बंद करें` / `रद्द` / `रहने दें` / `Cancel` ko
  `वापस जाएँ (Back)` kar diya gaya (sirf CancelModal ka danger `रद्द करें` bacha).

**`IconBtn`** - v12 #29/#32: pehle white icon + white 15% bg = safed card par
**dikhta hi nahi** tha. Ab `backgroundColor: C.primarySoft`, `borderColor: C.primary`,
`borderWidth: 1`, `color: C.primary`. Isse Categories ke `+` / `✎` / `🗑` / `↗` hamesha
dikhne lage.

**`Field` / `DateField` ka `grow` prop** - v12 #32: `<View style={styles.row}>` ke andar
`grow` nahi tha to input bahut patla (kareeb invisible) reh jaata tha. Sabhi aisi rows
me `grow` add kiya:

| jagah | rows |
|---|---|
| Categories: nayi shrni ka naam | 1 |
| WorkAddForm: A.S. / T.S. / F.S. kramank+tarikh | 3 |
| WorkAddForm: kaary avadhi (shuru/purna tarikh) | 1 |
| WorkAddForm: MB sankhya / pustak page | 1 |
| WorkAddForm: shram rashi / samagri rashi | 1 |
| BsrYearSheet: naya mad / ikaai | 1 |
| CcScreen: FS rashi / AS-TS rashi | 2 |

- `Field` ka `grow` = `flex: 1, minWidth: 0` (sirf chaudai me - lambai me nahi).
- `SelectField` ka dropdown popup ab `ModalBody` me hai (v12 #10): title = label,
  har option `styles.field` row ki tarah, `+ नया ...` button, phir Back (v12 #6).

### I.2 - v12 #1 / #7 - naam badla

- Cashbook ka Hindi naam **"रोकड़ बही"** hai (naming, tile, greeting, sab jagah).
- `नकद पंजी` poori codebase me se hata diya gaya (verify: grep = 0 match).

### I.3 - v12 #2 / #3 / #21 - greeting

- `greetOf(d, userName?, lang = "hinglish")` - `app/index.tsx`
  - Login aur Home **kabhi panchayat ka naam nahi dikhate** (sirf naam + samay).
  - `userName` App Settings -> "aapka naam" se aata hai; khaali ho to sirf abhivadan.
  - `lang` ke liye `english` branch: `Good morning / Hello / Good evening / Good night`.
- Reminder ka naam **"reminder"** hai - `अनुस्मारक` kahin nahi (grep = 0 match).

### I.4 - v12 #4 - FY data mitaana (PIN ke saath)

- `FYSettingsScreen` ka block: **"erase this financial year data"**.
- `purgeFinancialYearEntries()` - `context/AppStore.tsx` (saare entries + audit trail
  tak, usi FY se) - `PinModal` ke baad chalta hai.
- Flow: button -> PinModal -> `setPending(fn)` -> PIN sahi -> `runPending()`.

### I.5 - v12 #5 - cashbook page ka data mitaana

- Cashbook page ke `+ Page` menu me **Alert.alert ki jagah `ModalBody`** hai
  (Android Alert max 3 button dikhata hai - isliye menu ModalBody me hai).
- `pageTxnIds()` - us page ki saari entries; PIN ke baad `purgeTransactions(ids)` ->
  wo entries audit trail se bhi gayab. 2-step confirm: (1) page delete, (2) page erase.

### I.6 - v12 #8 - share me page selection

- Checkbox chips: "sabhi pages kram me" **+ manual range**: `1-2, 3, 5-`.
- `parseManual(str)`, `selectedIdxs()`, `shareXlsBody()` - inhi se PDF aur Excel dono
  bante hain. Comma = alag-alag, dash = range, khaali end = us tak.

### I.7 - v12 #9 - page navigator par sirf EK tarikh

- Header ka eyebrow date hata diya (do tarikh dikhti thi).
- Navigator me sirf `curPage.label - i/n` bacha.

### I.8 - v12 #11 - monthly check: cancel page -> delete permanently

- `MonthlyScreen` ke cancelled tab me har entry par **"delete permanently"**;
  `cancelTransaction` ki jagah `purgeTransactions` (audit trail se bhi gayab).
- Screen par hint: "ye entry cashbook aur dono jagah se hat jaayegi".

### I.9 - v12 #13 - CC manual edit + MB ka pehla control BSR varsh

- CC screen: `✎ कार्य सुधारें` -> `WorkAddForm` (A.S./T.S./F.S. kramank-tarikh, kaary
  avadhi, MB varn, dono hisse). Ye **completed / MB-complete karyon ke liye bhi**
  chalu rehta hai - koi gate nahi, sirf meta note add kiya.
- MbScreen, **सामग्री page par sabse pehle BSR varsh**:
  `पहले वर्ष चुनें - फिर मद` -> `YearField` (BSR varsh) -> `BSR items संपादित करें` ->
  phir hint -> `नई पंक्ति - सामग्री`. Varsh chune bina mad/dar choose karna bekar tha,
  isliye varsh hi pehla step.

### I.10 - v12 #14 - CC ke 7 PDF pages ka layout (`services/exportHtml.ts`)

- **`.ccpage` CSS** - `services/exportDoc.ts` (DOC_CSS):
  - `.ccpage { display:flex; flex-direction:column; min-height:254mm; }`
  - `.ccpage > table.sign:last-child { margin-top:auto; }` -> panna neeche baith jaata hai
  - **naya:** `.ccpage.p2/p3/p4/p5 > table.sign:last-child { margin-top:10px; }`
    -> panna 2,3,4,5 par **hastakshar table upar khisak jaata hai** (saamagri ke theek
    neeche, neeche khadda nahi banta)
  - **naya:** `.ccpage.p2 > table:first-of-type th { height:26px }` + `td { height:32px }`
    -> **panna 2 ke columns thode unche**
  - **naya:** `.photocol { display:flex; flex-direction:column; gap:6px; min-height:520px; }`
  - **naya:** `.warn { background:#fdecea; color:#b3261e; font-weight:700 }`
- Wrapper ab **page number class** deta hai:
  `` `<div class="ccpage p${i+1}">${p}</div>` `` (p1..p7).
- **Panna 7 = do unche columns**: ek `<th>कार्य से पूर्व (Before work)</th>`, doosra
  `<th>कार्यकाल (During work)</th>`; dono `<td>` me `.photocol` = 2-2 photo boxes
  (240px) + `दिनांक / स्थान` line. Hastakshar table neeche (margin-top:auto).
- **Bug fix:** `photoBox()` HTML deta hai par `cellS()` use escape kar deta tha -
  photo box **dikhta hi nahi** tha. Ab raw `<td>${photoBox(...)}</td>` (panna 6 aur 7).

### I.11 - v12 #15 - bill me "cross-check with cashbook" toggle

- `Bill.crossCheck?: boolean | null` - `types/models.ts`
  - `null` = kabhi chuna nahi, `false` = explicitly nahi, `true` = haan.
- UI: chips (haan/nahi). Note page par `crossCheck === true` dikhata hai.
- **Agar true + bill ka FY = current FY** to `addTransaction` se khud ek kharcha
  entry ban jaati hai (expense, `workId` ke saath).
- **Purana FY** = na koi page, na koi cross-tally (sirf flag).
- `false`/`null` = koi asar nahi.

### I.12 - v12 #16 - works list ko FY se filter

- `WorksScreen` me `fyIdOfWork(w)`: `fsDate` valid ho to **us FY me** jo date aati hai,
  warna `w.fyId`.
- `SelectField` - `सभी वित्तीय वर्ष` + har FY. Har row par `fsDate` bhi dikhta hai.
- Khali hone par filter-aware Empty state.
- **Note:** Mb/Bills/CC/WorkPicker ke andar `w.fyId === activeFy.id` wale chaar jagah
  jaan-boojh kar nahi badle - wahan pickers toot jaate.

### I.13 - v12 #17 + #22 - saankit saamagri + 2% contingency

**`ccBuild()` - `services/formats.ts`** me nayi fields:

```
sanctionedMaterial = materialPrior > 0 ? materialPrior
                   : fsAmount > labourPrior ? fsAmount - labourPrior : 0
materialOver       = sanctionedMaterial > 0 && material > sanctionedMaterial
                     ? material - sanctionedMaterial : 0
contingency        = max(0, work.contingencyAmount || 0)
contingencyCap     = round(material * 0.02, 2)      // MB samagri rashi ka 2%
contingencyOver    = contingency > contingencyCap ? (contingency - cap) : 0
```

- `Work.contingencyAmount?: number` - `types/models.ts` (v12 #22).

**On screen (CcScreen):**
- `स्वीकृत सामग्री राशि (F.S.)` + `MB में सामग्री` + `अंतर`.
- `c.materialOver > 0` -> **laal chetavani**: `⚠ ... {amount} adhik hai - swikriti me
  sanshodhan karein ya map pustak sudharein`.
- Naya card **`आकस्मिक व्यय (Contingency)`**: Field + `अनुमति {cap} (saamagri {material}
  ke 2%) - दर्ज {x}`; `contingencyOver > 0` -> laal chetavani; `✓ आकस्मिक व्यय सहेजें`
  -> `updateWork(workId, { contingencyAmount })`.

**PDF (panna 4 / तुलना तालिका):** `स्वीकृत सामग्री राशि (F.S.)`, `सामग्री मद - अंतर`,
`आकस्मिक व्यय दर्ज`, `अनुमत अधिकतम आकस्मिक (2% सामग्री)` + `.warn` red rows.

### I.14 - v12 #18 + #19 - Home ki tiles

- **"Add Income / Expense" tile hata diya.** Ab cashbook page ke neeche floating `+`
  hai (works page jaisa) - `onNewEntry` -> `setEditTxnId(null)`.
- Saare tiles ab ek `Settings` tile ke andar (v12 #19), aurar woh bhi group:
  `Masters (BSR/Items/man-days) - Formats Centre - FY closing wizard - Backup/Export -
  Reports hub - Categories (3 levels) - Fund heads`.

### I.15 - v12 #20 - cashbook share Excel = cashbook page jaisa

- `pageXlsHtml(...)` - dual grid (12+12 columns, do side by side) wahi format jo
  screen par dikhta hai.
- `askAndShare(title, body, landscape, excelBody?)` - ab **4th argument** le sakta
  hai: PDF ke liye A4 `pageBlockHtml`, Excel ke liye `pageXlsHtml`.
- Cashbook share me dono pass hote hain.

### I.16 - v12 #23 - MB sirf MB-complete karyon se

- `WorkPicker` ka naya prop **`onlyMb`**: sirf `mbStatus === "complete"` dikhata hai;
  MB no. / page / valuation sub me; apna hint + apna Empty text.
- MbScreen ka work picker `onlyMb` pass karta hai.
- MbScreen par naya card **`माप पुस्तिका (MB) - विवरण`**: `✎ MB सुधारें` ->
  `go("workDetail", workId)`; `🗑 MB हटाएँ` -> har `deleteMbLine` + `updateWork`
  (mbStatus -> pending, mb fields saaf).

### I.17 - v12 #24 - work delete (cascade)

- **`deleteWorkCascade(id)`** - `context/AppStore.tsx` (type bhi store me):
  - work + mbLines + bills + mandayCalcs **hatata hai**;
  - linked `transactions` se sirf `workId` aur `expenseKind` **clear** karta hai -
    `party`/`vendor`/`amount`/`date` **bache rehte hain** (cashbook vouchers zinda);
  - `updatedAt` refresh.
- `WorkDetailScreen` ka section **`कार्य मिटाएँ (Delete work)`** + danger `Btn`,
  Alert me cascade counts, phir `back()`.
- Entry monthly check par wapas dikhne lagti hai.

### I.18 - v12 #25 - daily backup

- `AppSettings`: `autoBackup?: boolean`, `backupHour?: number`, `backupLastRun?: string`.
- **Folder select hote hi** (`BackupScreen.chooseFolder`): `autoBackup: true`,
  `backupHour` default **2 (raat 2 baje)**; Alert me likha ki daily backup chalu ho gaya
  aur samay kahan se badlein.
- **Backup screen** par naya card **"रोज़ाना बैकअप (Daily auto backup)"**: chalu/band
  button + `SelectField` **24 ghante (00:00-23:00)** = wahi "samay/interval".
  Select par `backupLastRun: undefined` (taaki aaj ka backup turant ho sake).
- **Auto-run** - `Shell` ka effect: app khulte/waapas aate par, agar
  `autoBackup === true` AND `now >= today {backupHour}:00` AND
  `backupLastRun < scheduled` -> `getBackupDirUri()` se folder check ->
  `saveBackup("Cashbook-AutoBackup-YYYY-MM-DD.json", exportBackupJson())` ->
  `lastBackupAt` + `backupLastRun` update. Folder na ho to chup-chaap skip.

### I.19 - v12 #26 - bank statement me chalta hesh

- `bankStatementCsv()` me naya column **`चलता शेष (Running Balance)`** (har row ka
  `running`), aur **योग row 8 cells** (pehle 7 thi - columns shift ho rahe the).
- `BankScreen` ke upar naya card **`चलता शेष (Running balance)`** - credit / debit /
  current balance teeno totals.
- Sheet, list meta aur `bankStatementHtml` pehle se running balance rakhte the.

### I.20 - v12 #27 - bhaasha chunav

- `AppSettings.lang?: "hinglish" | "english" | "hindi"` - **default `"hinglish"`**.
- `export type Lang`, `LANGS`, `EN`, `HI` dictionaries, `useLang()`, `t(lang, key, fallback)`
  - `app/index.tsx`.
- **Daayra:** bhaasha sirf **app ka interface** badalti hai - menu, tile, button,
  abhivadan. Aadhikarik prapatr (रोकड़ बही, गोशवारा, प्रपत्र-1/2/4, खाता बही,
  बैंक विवरण, CC ke 7 panne) **hamesha Hinglish/Hindi me hi** rehte hain -
  record jyon ke tyon chhapein.
- **Koi key chhoot jaye to fallback (maujooda Hinglish text) hi dikhta hai** -
  toota hua label kabhi nahi.
- Apply kiya gaya: `LoginScreen` (title/sub/buttons/bio), `HomeScreen` ke 11 tiles +
  Settings tile + Settings modal ki entries + greeting popup, `ModalBody` ka Back,
  `greetOf` (English greeting branch).
- Chuni jagah: **Home -> व्यवस्था (Settings) -> chips `Hinglish (default) / English /
  हिन्दी`** (sabse upar) **+ App Settings -> `App language` SelectField** (chhota 3-line
  note ke saath ki prapatr Hinglish me hi rahenge).

### I.21 - v12 #28 - Home par chal-ta shesh graph

- `BalanceGraph` component - `react-native-svg` (`Svg`, `Polyline`, `Circle`, `SvgLine`).
- `runPoints` memo: 01 Apr (FY shuru) -> aaj, har FY page ka `currentBalance`.
- Market-style: upar max/min dotted lines, `tap` se us din ki date + amount,
  `col = v >= pehla.v ? C.income : C.expense`.

### I.22 - v12 #29 - Categories ke buttons hamesha dikh dein

- Har category row par hamesha: `+` (agar level < 3), `✎ नाम बदलें`, `🗑 हटाएँ`,
  `↗ pura menu` - sab `IconBtn` (ab primarySoft/primary styling, upar I.1).
- Long-press bhi wahi menu kholta hai.

### I.23 - v12 #30 - khaali jagah tap = NAYI entry

- `CashbookScreen` ka `onNewEntry` prop -> `setEditTxnId(null)`.
- `EntryScreen` unmount par `onClearEdit()` chalata hai (purana edit id bacha nahi).
- Khaali cashbook area tap -> nayi entry; edit icon -> wahi entry dobara.

### I.24 - v12 #31 - header me poora panchayat naam

- `कार्यालय ग्राम पंचायत - {panchayat}` / `पंचायत समिति - {block}` wala header
  (jisme naam, samiti aur zila teeno aate hain).

### I.25 - v12 #32 - data-fill popups ka bottom box

- Har popup -> `ModalBody` (scroll + hamesha Back) - I.1.
- Har `styles.row` ki field rows me `grow` - I.1 ki table dekhein.
- `IconBtn` ka naya contrast - I.1.
- `SelectField` dropdown = `ModalBody` (backdropClose wahi, koi extra tint nahi).
- Date picker = `ModalBody` (title = field label), andar sirf `आज (आज की तिथि)` -
  Back `ModalBody` deta hai (duplicate Back hataya).
- BSR edit sheet (`BsrYearSheet`) = `useModalBodyMax(0.92, 300)` scroll + Back.

### I.26 - Verification (v12)

- `tsc -p tsconfig.json --noEmit` - **EXIT=0** (multiple re-runs)
- `expo export --platform android` - **EXIT=0** (5.2 MB `.hbc`, 1905 modules)
- Zip: `Gram-Panchayat-Cashbook-FULL-v12.zip` - forward-slash entries,
  `cashbook-mobile/` prefix, `node_modules` / `.git` / `.expo` / `android` / `ios` /
  `dist` / `.idea` / `.vs` / `out` / `.cache` excluded
- Workflow: `.github/workflows/build-apk.yml` - **Build APK (Gram Panchayat Cashbook v12)**,
  `ZIP=` auto-glob (sabse bada version chunta hai).

### I.27 - v12 shuru kaise karein

1. GitHub -> Actions -> **Build APK (Gram Panchayat Cashbook v12)** -> Run workflow
2. Artifact `GramPanchayatCashbook-APK` se APK download karein.
3. Naya round = sirf nayi zip root par, workflow waise ka waisa.


## SECTION J - v13 (20-point round) - WORK DONE + SPEC

Date: 04-10-2026.  Zip: `Gram-Panchayat-Cashbook-FULL-v13.zip`  Workflow: **Build APK (Gram Panchayat Cashbook v13)**.
Typecheck `tsc --noEmit` EXIT=0 · `expo export --platform android` EXIT=0 (1905 modules, 5.3 MB .hbc).

### J.1  Point-by-point (all 20 DONE)

| # | Point | What was implemented | Where |
|---|-------|----------------------|-------|
| 1 | Manday BSR year ignored | `yearBsr(bsrRates, year, item)` strict-year helper; `referenceRate` = BSR(same year, >0) → Worker(same year) → Default. kisi bhi dusre saal ki dar kabhi na milti hai. | services/mandays.ts |
| 2 | BSR rate 0 → purani dar wapas | save ab `rate >= 0` allow karta hai (0 valid); `referenceRate` me `yearBsr` ke baad hi 0 check — 0 = chunav 0, purana rate na. | index.tsx BSR save + BsrYearSheet.saveAll |
| 3 | CC material = tender rate % | `Work.tenderRatePct` (0-100). CC पृष्ठ 4 me field + save. **निविदा दर = BSR दर × (1 − %/100)** — सीमेंट ₹100, −2% → ₹98. **श्रमिक/कारीगर दर पर कोई असर नहीं** (सीधे BSR). `ccBuild` returns `tenderPct`, `tenderRateOf()`, `materialBsr`. Export HTML (CC पृष्ठ 4) bhi wahi rate dikhata hai + "बचत" row. | services/formats.ts, exportHtml.ts, CcScreen |
| 4 | S-22 man-days 3 → 6 options | `mandayOptions: return out.slice(0, 6)`. | index.tsx |
| 5 | Man-days approvals = edit/correct/delete | Har स्वीकृति row पर ✎ व 🗑. Edit modal: मुस्तर/श्रमिक-कारीगर या workers-days-rate, BSR वर्ष, राशि फिर गिनें, सेव = amount recomputed + muster.mrs sync + workerRolls sync + `updateMandayCalc`. | MandayScreen |
| 6 | Man-days page = BSR वर्ष चुनाव | Approvals list से ठीक ऊपर `YearField "BSR वर्ष (नई स्वीकृति के लिए)"` + chips (सब वर्ष / per-year). सारी वही वर्ष की स्वीकृतियाँ filter. | MandayScreen |
| 7 | BSR edit area के नीचे के बॉक्स दिखते नहीं थे | "नया मद/इकाई" row = `C.muted` card, 1.5 px `C.primary` border, Fields `bg={C.card}`; list rows = `C.muted` bg + 1.5 border → screen पर साफ़ दिखते हैं. | BsrYearSheet |
| 8 | सारे badges सिर्फ़ numeric + हर पेज unique | S-01, S-46…S-56 नए; जो आपने बोले (S-06, S-13, S-22) वो वैसे ही रहे. Settings page = **S-57**. | all screens |
| 9 | Cashbook share Excel में सिर्फ़ format | `parseManual` 0-based + `manualLabel` + `txnsOfPageIdx` → pageBlockHtml/pageXlsHtml दोनों सही entries छापते हैं. | index.tsx |
| 10 | L.F. = per-मद auto folio + दो-तरफ़ा लिंक | `buildFolioMap`: पूरे FY में date/createdAt क्रम से **पहली बार दिखने वाला मद = L.F. 1**, अगला नया मद = 2 … (`madKeyOf` = work:/cat:/scheme:/other). कैशबुक L.F. cell पर tap → उसी मद का खाता बही (ledger) खुलता है; ledger की किसी पंक्ति पर tap → उसी entry का कैशबुक पन्ना खुलता है. Export/Excel तीनों जगह वही संख्या. | formats.ts (`madKeyOf` `buildFolioMap` `folioFromMap`, `LedgerRow.txnId`), index.tsx (CashbookScreen, LedgersScreen, `cashbookUI.openPage`) |
| 11 | बिल का प्रकार + अनुपातिक सामग्री वितरण (सीमा के भीतर) | नया बिल: **आरंभिक / मध्यकालीन / अंतिम** chips (`Bill.billType`). `allocateBillItems()`: हर मद का हिस्सा = (स्वीकृत मात्रा × दर) ÷ कुल स्वीकृत सामग्री राशि → इस बिल की मात्रा = (राशि × हिस्सा) ÷ दर (दर = BSR − निविदा %). **रोक:** सारे बिलों की कुल मात्रा कभी CC/MB स्वीकृत मात्रा से अधिक नहीं — जहाँ सीमा पूरी वहाँ मात्रा अवशिष्ट पर रुकती है (लाल चेतावनी). मैन्युअल per-item edit + save पर फिर से cap check. `Bill.items[]` में सब दर्ज. | formats.ts, BillsScreen |
| 12 | बैंक S-13 = चलता शेष (last column) | हर list card पर दाईं ओर **चलता शेष** box (`balanceOf`); sheet view में column letters तक `A…F`. | BankScreen |
| 13 | गोशवारा = मद पर tap → उस मद की ledger | आय व व्यय दोनों पंक्तियाँ `Pressable` + `›` इशारा; `jumpTxnLedger` work/cat/fund निकालकर `go('ledgers')`. | GoswaraScreen |
| 14a | S-06 Settings tile = अपना पन्ना (Stage) | नया Stage **`settings`** + `SettingsScreen` (badge S-57). Modal हटाया. कोई item चुनो → Back → **वापस Settings पेज** (stack में `settings`), S-06 home पर नहीं. | index.tsx |
| 14b | Formats Centre = हर format का अपना पृष्ठ | dropdown की जगह **नंबर-वाली cards** (f-01, f-02…). Card दबाने पर उसी format का अलग पृष्ठ: प्रिंट लेआउट (system preview), Share PDF/Excel, और **मैन्युअल HTML संपादन** (जो यहाँ बदलो वही प्रिंट/शेयर में जाता है; "मूल (auto) पर वापस" बटन से reset). | FormatsScreen |
| 15 | सारे share/export formats क्रमांक `f-01, f-02…` | `fmtList2` हर format को `f-01`, `f-02`… देता है; badge + फ़ाइल का नाम दोनों में. | FormatsScreen |
| 16 | MB पूर्ण → सामग्री खपत जोड़ें → BSR दर से योग = MB मूल्यांकन | सामग्री पक्ष हर पंक्ति ✎ (Qty = खपत, Rate) से सुधरती है. नया card **"MB मूल्यांकन सहेजें"**: सामग्री + श्रम भरकर `mbValuation / mbMaterialAmount / mbLabourAmount` में दर्ज (CC पृष्ठ 4 से मिलान). | MbScreen |
| 17 | MB tile = कार्य-सूची → चुनो → MB, उसी पेज से सुधार/हटाव | Home MB tile अब `go('mb','')` (पिछला कार्य auto नहीं खुलता) → WorkPicker. चुने हुए कार्य की हर MB पंक्ति पर ✎ (modal: नाम/Qty/Rate/कौन-सा पक्ष) व 🗑 — बार-बार. | HomeScreen, MbScreen |
| 18 | बिल tile = कार्य-सूची → चुनो → बिल, उसी पेज से सुधार/हटाव | Home tile `go('bills','')`. हर बिल card पर ✎ (vendor, राशि, तिथियाँ, page ref, note, प्रकार, सामग्री वितरण) व 🗑 — बार-बार. | HomeScreen, BillsScreen |
| 19 | CC tile = कार्य-सूची → चुनो → CC, उसी पेज से सुधार/हटाव | Home tile `go('cc','')`. CC पेज पर: ✎ कार्य सुधारें + **MB पंक्तियाँ सुधारें** + **बिल सुधारें/हटाएँ** (सीधे उसी कार्य के) + **🗑 कार्य हटाएँ** (cascade: MB/बिल/मान-दिवस/entries). | HomeScreen, CcScreen |
| 20 | MB/बिल/CC तीनों tile पहले कार्य-सूची दिखाएँ | Home tile press → `go(stage, '')` → WorkPicker → चुना कार्य उसी की details → उसी पेज से सुधार/हटाव. | HomeScreen |

### J.2  New / changed data model (types/models.ts)

- `Work.tenderRatePct?: number` — निविदा दर में कटौती % (**सिर्फ़ सामग्री** पर, श्रम/कारीगर पर नहीं).
- `Bill.billType?: 'starting' | 'during' | 'final'`
- `Bill.items?: { itemName: string; qty: number; rate: number; kind? }[]` — इस बिल में बँटी सामग्री.
- `LedgerRow.txnId?: string` (formats.ts) — ledger row → cashbook page cross-link.
- Store: `updateMandayCalc`, `updateWorkerRoll`, `updateBill`, `updateMbLine` (पहले से `updateWork`, `deleteWorkCascade`, `deleteMbLine`, `deleteBill`).

### J.3  New / changed functions

- `services/formats.ts`: `madKeyOf`, `buildFolioMap`, `folioFromMap`, `allocateBillItems`, `buildLedger` (+ id/createdAt/workId/... + txnId + folioFromMap), `ccBuild` (+ `tenderPct` `tenderRateOf` `materialBsr`).
- `services/mandays.ts`: `yearBsr`.
- `app/index.tsx`: `SettingsScreen`, `cashbookUI.openPage`, `folioOf` / `openLedgerOf` / `jumpToCashbook`, `lineRows` (MbScreen), `sanctionedRows` / `usedOf` / `rateOf` (BillsScreen), `fmtList2` + format detail view.

### J.4  Screen index delta (v12 → v13)

- **New Stage:** `settings` (S-57) — भाषा + Masters / Formats / FY समापन / Backup / Reports / Categories / Fund heads. Back = उसी पेज पर.
- Home (S-06): "व्यवस्था (Settings)" अब खुद एक पन्ना (modal नहीं); MB / बिल / CC tiles कार्य-सूची से शुरू.
- Formats Centre (S-56): f-01… list → per-format detail page (प्रिंट + मैन्युअल edit + share).
- New badges: S-46…S-57 (numeric only, unique).


---

## SECTION K - v14 (19-point round) - SPEC ONLY (CODE PENDING)

Date: 06-10-2026.  **Status = SPEC ONLY — app abhi nahi banaaya.**
User ka nirdesh: *"abhi app nhi banana hai.. sirf project ki .md file ko update kro..
puri .md file ko padhkar ek .txt file banakr do, jisme sabhi screen ke rules/defaults
alag-alag list out hon."*
Isliye is round me: (a) neeche 19 अंक spec ke roop me lock hue, (b) code me **koi
badlav nahi**, (c) zip + workflow abhi bhi **v13** par hain
(`Gram-Panchayat-Cashbook-FULL-v13.zip` + **Build APK (Gram Panchayat Cashbook v13)**),
(d) rules index file = `CASHBOOK-RULES-INDEX.txt` (repo root + cashbook-mobile dono jagah).
Implementation tab hogi jab user "v14 banao" bole → us round me zip `...-v14.zip` +
workflow name/comment **v14** + `tsc --noEmit` + `expo export --platform android` + Section K.4 ka
deliverables checklist.

### K.1  19 अंक (user ki list, as-is) + acceptance spec + kahan lagega

> **STATUS (v14 build, 07-10-2026): 18/19 DONE** — sab except **K-11** (bank PDF →
> Excel) jo **DEFERRED** hai: koi PDF text-extraction lib nahi hai, OCR allowed nahi.
> Neeche ka `Status` column isi round ke pehle ki "PENDING" mark hai — ab kaam ho chuka.

| # | Point (user ki bhasha) | Acceptance spec (jab code bane) | Kahan | Status |
|---|---|---|---|---|
| 1 | "app ka new logo update kro" | `assets/images/cashbook-logo.png` (1024×1024 PNG) replace → login header + App Settings dono jagah turant badal jaaye; file ≤512 KB, square, white/transparent bg. SOURCE FILE **already folder me hai**: `F:\Android app\cashbook\cashbook logo 1.jpg` (06-10-2026, 30,116 B) — usse 1024x1024 PNG banana hai. | `assets/images/cashbook-logo.png` (badalna hai), LoginScreen, SettingsScreen | PENDING (asset ready) |
| 2 | "S-19 page par मन-डे स्वीकृति add karne par bhi wo amount CC me add nahi ho raha — fix karo" | मन-डे स्वीकृति की राशि MB के श्रम पक्ष में जुड़े और CC पृष्ठ 1 की **"मूल्यांकन के अनुसार — अ. श्रम मद राशि"** (और जहाँ लागू हो पृष्ठ 3 की श्रमिक-पंक्तियों) में अपने आप आए. आज यह गायब है. | MandayScreen → `mbLabourAmount` → `ccBuild` → CcScreen | PENDING (bug) |
| 3 | "CC पृष्ठ 3 श्रमिक विवरण — MR बनाने के बाद CC में आना चाहिए; स्वीकृति page पर अलग से option कि कारीगर सामग्री में गिना जाए या labour part में; बहुत confusion — simplify karo" | (a) Muster/MR बनते ही वे श्रमिक CC पृष्ठ 3 में दिखें (नाम, दिन, दर, राशि); (b) **सिर्फ़ एक जगह** (मन-डे स्वीकृति page) एक साफ़ दो-चुनाव वाला control: कारीगर → **सामग्री** या **श्रम**; (c) MB और स्वीकृति — दोनों pages पर वही control वही दिखें (आज alag-alag hai — isi se confusion). Default फिर भी **श्रम** (A3). | MandayScreen, MbScreen, `ccBuild` | PENDING |
| 4 | "CC me MB विवरण एक बार भर दिया तो वही रहना चाहिए; kabhi-kabhi automatic erase ho ja raha hai; khud edit karne par hi nayi value aaye" | कोई भी auto-recalc / recalc-on-navigation पहले से भरे हुए मान (CC MB-विवरण, पृष्ठ 1/3/4 के मूल्यांकन-कक्ष) को **मिटाए नहीं**. नई तभी जब user ✎ दबाकर खुद भरे और सेव करे. पहली बार भरने पर value store + "भरा हुआ" flag. | CcScreen, `ccBuild` (formats.ts), MbScreen | PENDING (bug) |
| 5 | "MB page ko 2 भाग/alag-alag page banao — ek labour (breakdown: कारीगर amount kitna + labour kitna), doosra material (material breakdown)" | MB = दो full pages: **पृष्ठ-L श्रम** → कुल श्रम मूल्यांकन + breakup = कारीगर राशि + श्रमिक-राशि + मन-दिवस तालिका; **पृष्ठ-M सामग्री** → कुल सामग्री मूल्यांकन + breakup मदवार (मात्रा × दर) + खपत. दोनों pages के ऊपर तीनों आँकड़े: कुल / श्रम / सामग्री. (v10 #21 से MB में दो tabs हैं — अब tabs = दो असली pages + breakup.) | MbScreen (`mbValuation`, `mbLabourAmount`, `mbMaterialAmount`) | PENDING |
| 6 | "CC ka amount kabhi MB ke total valuation se adhik nahi ho sakta — counting me kahin ho bhi jaye to warning aa jani chahiye" | **नया hard rule:** save/share/export से पहले check — CC की कुल राशि ≤ MB मूल्यांकन. ज़्यादा हो तो **लाल warning** + save/share रोक (सिर्फ़ चेतावनी ही नहीं, block). साथ में कौन-सी पंक्ति सीमा तोड़ रही है वह भी. | `ccBuild`, CcScreen, exportHtml `ccPagesHtml` | PENDING (new rule) |
| 7 | "CC ke sabhi page alag-alag banao; jis page par jo format hai uska pura same Excel jaisa layout + data (realtime) app me hi dikhe; page 1 (CC), page 3 (labour), page 4 (material) hi editable; baaki read-only" | CC = एक-समय-में-एक-पृष्ठ UI (p1…p7 selector). हर पृष्ठ पर **वही layout जो PDF/Excel में जाता है** (`ccPagesHtml`), रियल-टाइम data के साथ. Editable सिर्फ़ **पृष्ठ 1, 3, 4**; पृष्ठ 2, 5, 6, 7 = read-only (बस देखो/शेयर). | CcScreen + `exportHtml.ccPagesHtml` | PENDING |
| 8 | "Page 1 edit me ye sab entry enable rahenge: कार्य का नाम, योजना का नाम, प्रशासनिक/तकनीकी/वित्तीय स्वीकृति क्रमांक + इनकी तिथियाँ, स्वीकृत राशि, कार्य शुरू तिथि, कार्य पूर्ण तिथि, मूल्यांकन के अनुसार अ. श्रम मद राशि / ब. सामग्री मद राशि, मूल्यांकन कुल राशि, माप पुस्तिका संख्या, माप पुस्तिका पृष्ठ संख्या, सृजित परिसंपत्ति दिनांक, विकास पंजिका रजिस्टर क्रम संख्या" | पृष्ठ 1 का एडिट-मोड ऊपर दी गई **पूरी field-सूची** खोले. Model: `Work.sanctionRef`, नए `adminSanctionRef/adminSanctionDate`, `techSanctionRef/techSanctionDate`, `finSanctionRef/finSanctionDate`, `mbNo`, `mbPageNo`, `assetCreatedDate`, `lfRegisterNo` (जो न हो वह add). सेव सीधे `updateWork` पर + CC पृष्ठ 1 पर realtime. | CcScreen p1 edit, `types/models.ts` | PENDING |
| 9 | "Page 9 [sic] me sirf items selection aur unki quantity editable; rate BSR se automatic; baaki calculation realtime; option ho ki Rates BSR ke according rakhni hain ya tender rate ke anusar above/below" | संदर्भ से यह **CC पृष्ठ 4 (सामग्री)** लगता है — confirm ज़रूरी (Q1). Spec: मद-चुनाव + मात्रा editable, **दर BSR से auto**, सब calculate realtime. ऊपर एक चुनाव: **दर = BSR** या **दर = BSR ± निविदा %**. **बदलाव:** v13 #3 में `tenderRatePct` 0–100 सिर्फ़ *कटौती* (नीचे) है — अब **signed % (−/+) ताकि दर ऊपर भी जा सके**. | CcScreen p4, `Work.tenderRatePct` → `tenderRateAdjPct`, `ccBuild.tenderRateOf` | PENDING |
| 10 | "dark, light aur system default theme ka option add karo" | S-01 App Settings में 3-चुनाव: **Light / Dark / System (default)**; System = OS `useColorScheme` follow करे, बदलते ही app बदले. 6 रंग-थीम (A2) **अलग** रहें → दो independent axis: *hue* × *mode*. सारे screens + modals + exported (PDF/Excel) पर लागू; **छपाई हमेशा सफ़ेद background** (baseline rule 5 — dark mode PDF लागू नहीं). | SettingsScreen, `constants/colors.ts`, `hooks/useColors.ts` | PENDING |
| 11 | "bank ke PDF statement se excel me automatic entries add karne ka option — OCR nahi, sirf text PDF offline read karni hai" | नई capability: **text-based PDF को offline पढ़ो** (कोई OCR नहीं, कोई internet नहीं). चुनो → date / narration / credit / debit / balance निकालो → **editable review table** → Post → bank rows (D−1 rule वैसा ही). Image/scan PDF → साफ़ message "text PDF नहीं है". आज `package.json` में **कोई PDF lib नहीं**; line 5621 पर यह पहले से *Part U / device build* के रूप में deferred है. | BankScreen, नया `services/pdfImport.ts`, package.json (पहली PDF dependency) | PENDING (new capability) |
| 12 | "greeting me 'शुभ हरिष रात्रि' ki jagah 'शुभ रात्रि हरिष' aana chahiye" | **Root cause मिला** — `greetOf` (`app/index.tsx:291-300`), लाइन 299: `g.split(' ')[0] + ', ' + who + ' ' + g.split(' ')[1]`. 'शुभ रात्रि 🌙' पर बनता है **"शुभ, हरिष रात्रि 🌙"** (और 'शुभ संध्या 🌇' पर "शुभ, हरिष संध्या 🌇"); 'सुप्रभात 🌞'/'नमस्कार 🙏' सही बनते हैं. Fix: पूरा greeting पहले, नाम बाद में → **"शुभ रात्रि, हरिष 🌙"** (see Q2). Login + Home + Settings-preview तीनों जगह. | `greetOf` | PENDING (bug) |
| 13 | "S-06 running balance graph me sabhi scheme ke balance ka bhi graph; kisi din minus ho to utni line alag color se" | `BalanceGraph` (`index.tsx:1751`) आज **एक ही series** (कुल शेष) दिखाता है. नया: उसी चार्ट में कुल-शेष + **हर scheme की अपनी line** (legend/tap से चुनो); जहाँ किसी scheme का शेष **< 0**, उस सेगमेंट को अलग (लाल) रंग + ज़ीरो लाइन. Tap पर उस दिन की सबकी शेष. | `BalanceGraph`, HomeScreen (S-06) | PENDING |
| 14 | "app me jaisa cashbook data ban raha hai, waisa hi ditto same data exported excel aur pdf me dikhe" | **Export-parity rule:** हर share/export (cashbook S-50, गोशवारा, खाता बही, CC, MB, बिल, बैंक, प्रपत्र, reports, audit) में वही क्रम, वही शीर्षक, वही संख्याएँ, वही सारांश-पंक्तियाँ जो screen पर; सारांश **manually editable नहीं** (baseline rule 5); preview = share = file. | `exportHtml.ts`, `exportDoc.ts` | PENDING (audit + fixes) |
| 15 | "date selection me month scroll karna mushkil — pehle year, phir month, phir date" | `DateField` 3-step: **(1) साल** → **(2) महीना** (12-बटन grid) → **(3) दिन**. Back से पिछला step; "आज" shortcut बना रहे. अभी month-calendar + `‹ ›` से खिसकाना पड़ता है (v11 #7). | `DateField` (`index.tsx:448`) | PENDING (UX) |
| 16 | "expense entry me voucher ki date dali ho to usi date ka page create karne ya us date ke 5-7 din PEHLE agar koi page already bana ho to us page par entry karne ka option — abhi sirf current date" | व्यय में date-blur पर विकल्प: **(a)** voucher date का page (नया/मौजूदा) — default, **(b)** उस date से **5–7 दिन पहले** का *मौजूदा* page (उसी पर entry). आज `askPageForDate` (`index.tsx:3220`) सिर्फ़ "सुझाव: अगला पन्ना" / "<date> का नया पन्ना" / "बाद में" देता है. **तकनीकी note:** Android `Alert.alert` में 3 से ज़्यादा बटन नहीं दिखते → यह विकल्प list/sheet UI में आना चाहिए. | EntryScreen, `pageOptionsForDate` (AppStore) | PENDING |
| 17 | "income entry me bhi wahi — usi date ka page ya us date ke 5-7 BAAD agar page already bana ho to us page par entry" | आय के लिए सममित विकल्प: voucher date का page, या उस date के **5–7 दिन बाद** का मौजूदा page. बाकी (default, prompts, तकनीकी note) #16 जैसा ही. | EntryScreen | PENDING |
| 18 | "kisi bhi scheme/kaam/mad/expenses/income — sab ki खाता बही 2 side (income + expenditure); folder ki excel jaisa EK table me hi dono side — sr, particulars, amount column" | हर ledger (scheme / कार्य / मद / श्रेणी / महीना) **एक ही table**: **स्र. क्रमांक · परिचय (particulars) · जमा (आय) · नाम (व्यय) · शेष**. आज `LedgersScreen` का table 6 column देता है — दिनांक \| L.F. \| किस से प्राप्त/किसको भुगतान \| जमा \| नाम \| शेष; **स्र. क्रमांक अभी नहीं है** → वही जोड़ना है. PDF/Excel export में भी यही एक layout. | LedgersScreen, `buildLedger` (formats.ts), `ledgerHtml` | PENDING |
| 19 | "entry par click karne par default tab EXPENSE khulna chahiye, na ki income" | **Root cause:** `index.tsx:3213` → `useState(... editTxn ? (editTxn.type==='expense'?'expense':'income') : 'income')`. बदलकर **`'expense'`** — सिर्फ़ नई entry में; सुधार (edit) में मौजूदा type अपने आप बनी रहे. | EntryScreen (S-08/S-09) | PENDING (bug) |

### K.2  Ye points purane locked rules ko chhute hain (decision chahiye)

| # | Purana rule (kahan) | Naya point | Kya badlega |
|---|---|---|---|
| a | **A3** — MB में कारीगर toggle (labour \| material), default = labour; **v10 #21** — MB दो tabs | K1-3 | Toggle अब **मन-डे स्वीकृति page** पर भी और वही दोनों जगह दिखे → एक ही source of truth. Default वही **श्रम**. |
| b | **v13 #16** — "MB मूल्यांकन सहेजें" auto-write | K1-4 | Auto-write अब **lock**: भरी हुई value कभी अपने आप मिटेगी नहीं; सिर्फ़ ✎ + सेव. |
| c | **v13 #3** — `tenderRatePct` 0–100, *सिर्फ़ कटौती*, सामग्री पर | K1-9 | **Signed % (−/+)** — दर ऊपर भी जा सकती है. नाम बदलकर `tenderRateAdjPct` (migration ज़रूरी). |
| d | **v12 #14** — CC 7 pages का layout; **v13 #14b** — हर format का अपना पेज | K1-7, K1-8 | CC भी **per-page detail view** बनेगा (formats centre जैसा), editable = p1/p3/p4. |
| e | **v10 #13** — ledger columns | K1-18 | आगे **स्र. क्रमांक** column; सारे ledgers एक ही layout. |
| f | **A2** — 6 colour themes (theme colour picker) | K1-10 | hue × mode दो independent axis. |
| g | **v9 #3** — `askPageForDate` prompt | K1-16, K1-17 | विकल्प बढ़ेंगे (5–7 दिन पीछे/आगे); 3-बटन Alert limit की वजह से sheet UI. |
| h | — (पहले कहीं नहीं) | K1-6 | CC ≤ MB = **नया hard validation** (save/share रुकेगा). |
| i | **Part U** (deferred) — OCR/PDF import | K1-11 | अब सिर्फ़ *text* PDF, बिना OCR → वही deferred item वापस आया, scope सीमित. |
| j | **v13 #3** — निविदा % सिर्फ़ सामग्री पर, श्रम/कारीगर पर नहीं | K1-9 | यह बना रहे? (confirm — Q5) |

### K.3  Open questions (coding se pehle confirm)

- **Q1** — K1-9 me aapne *"page 9"* likha. CC में सिर्फ़ 7 pages हैं → क्या मतलब **पृष्ठ 4 (सामग्री)** है? (items + BSR rate + tender = material page)
- **Q2** — K1-12 greeting का अंतिम रूप: **"शुभ रात्रि, हरिष 🌙"** ठीक है, या बिना comma **"शुभ रात्रि हरिष 🌙"**, या emoji बिलकुल नहीं?
- **Q3** — K1-16/17 का window "5–7 दिन" = बीच का कोई भी (5,6,7) या कोई एक फ़िक्स्ड?
- **Q4** — K1-6 की सीमा **MB मूल्यांकन** (mbValuation = श्रम + सामग्री) ही है ना? या सिर्फ़ किसी एक पक्ष से compare?
- **Q5** — K1-3 का "कारीगर = सामग्री/श्रम" चुनाव **सिर्फ़ मन-डे स्वीकृति page** पर, या MB page पर भी दिखे?
- **Q6** — K1-1 ka asset folder me mil chuka hai: `cashbook logo 1.jpg` (06-10-2026). Confirm: **isi** file ko `assets/images/cashbook-logo.png` (1024×1024) bana kar lagaaun? Koi aur file aani hai to bhej do.
- **Q7** — K1-2: CC में जो "add नहीं हो रहा" — वह **पृष्ठ 1 की "अ. श्रम मद राशि"** है या **पृष्ठ 3 की श्रमिक-पंक्तियाँ**? (K1-3 पृष्ठ 3 अलग से माँग रहा है, इसलिए पृष्ठ 1 लगता है — confirm)
- **Q8** — K1-11 में PDF से पहले **स्कीम/कॉलम mapping** दिखाएँ (date, narration, dr, cr, bal चुनो) या automatic मान लो?

### K.4  Jab implementation shuru ho — is round ka deliverable checklist

1. Code edits (K.1 ke 19 अंक + K.2 ke decisions) — `app/index.tsx`, `services/*`, `types/models.ts`, `constants/colors.ts`, नया `services/pdfImport.ts`.
2. `tsc -p tsconfig.json --noEmit` → **EXIT=0**.
3. `expo export --platform android` → EXIT=0, `.hbc` size note karo.
4. Zip `Gram-Panchayat-Cashbook-FULL-v14.zip` (repo root; `cashbook-mobile/` prefix, forward slashes, no `node_modules`, full project).
5. `.github/workflows/build-apk.yml` → name + comment **"Build APK (Gram Panchayat Cashbook v14)"**.
6. Logo file (K1-1) replace.
7. दोनों `PROJECT_MASTER_NEW.md` sync + `CASHBOOK-RULES-INDEX.txt` refresh.
8. Hinglish summary + run steps: **Actions → Build APK (Gram Panchayat Cashbook v14) → Run workflow**.

**Status of Section K: 0/19 implemented (as instructed).**


---

## SECTION L - v15 (18-point round) - IMPLEMENTED IN v14 (with Section K)

Date: 07-10-2026.  **Status = SPEC LOCKED + CODE DONE (v14 build, ek hi zip me).**
User ka nirdesh (point 18 ke aakhir me): *"project files update kro.."*
Isliye sirf yeh file + `CASHBOOK-RULES-INDEX.txt` update kiye gaye.

**Version naming (dono pending rounds ek saath):**
- **Section K = v14** (19 अंक) — **18/19 DONE** (K-11 deferred).
- **Section L = v15** (18 अंक + L1-19 = 19) — **19/19 DONE**.
- **Decision (07-10-2026): dono ek saath ek build me** → ek hi zip =
  `Gram-Panchayat-Cashbook-FULL-v14.zip`, workflow **v14**, dono sections done.

### L.1  18 अंक (user ki list, as-is) + acceptance spec + kahan lagega

> **STATUS (v14 build, 07-10-2026): 19/19 DONE** (18 + L1-19) — dono sections ek
> hi build me: zip `Gram-Panchayat-Cashbook-FULL-v14.zip`, workflow **v14**.

| # | Point (user ki bhasha) | Acceptance spec (jab code bane) | Kahan | Status |
|---|---|---|---|---|
| 1 | "Login button hamesha viewport me — scroll / keyboard-avoiding layout" | Login/set-PIN screen **scrollable + `KeyboardAvoidingView`**, button field-list ke theek neeche; logo-chooser khule ya keyboard aaye tab bhi button viewport me. **Abhi bhi v11/A1 wala rule hai — sirf verify + keyboard case pakka karna hai** (`KeyboardAvoidingView` sirf LoginScreen me hai, index.tsx:987). | LoginScreen | RE-ASSERT (verify) |
| 2 | "Cashbook pages me Pinch-to-zoom abhi code me nahi — add kro" | Cashbook grid par **2-उंगली pinch** se zoom (0.5–1.8), ± controls + % indicator + `cashbookUI.zoom` persist sab chalte rahein; pinch ke saath pan/scroll bhi kaam kare. `react-native-gesture-handler@~2.32` + `react-native-reanimated@4.5.1` **package.json me pehle se hain**. Aaj sirf `− / 100% / +` hai (index.tsx:2992 ka comment: "pinch nahi to ± se"). | CashbookScreen (S-07) | PENDING |
| 3 | "Har ledger me sabhi entries ke saamne **CB page column** — us entry ka cashbook page reference; click par wo page khule" | Ledger table me naya **column "CB पृष्ठ"** (page number + date) har row par, tap → `cashbookUI.openPage` se usi entry ka cashbook page. v13 #10 me sirf **row-tap** tha — ab **visible column** chahiye; screen + PDF + Excel teeno me. K-18 (`स्र. क्रमांक`) ke saath final column-set: **स्र · दिनांक · CB पृष्ठ · L.F. · परिचय · जमा · नाम · शेष**. | LedgersScreen, `buildLedger`, `ledgerHtml` | PENDING |
| 4 | "Expense entry me agar kisi **MR ka payment ho gaya** hai to wo **vendor list se hat jaayega**" | Entry (S-09) ki "किसको भुगतान" list me **अदाये जा चुके MR न दिखें**. Aaj txn me सिर्फ़ `party` string save hoti hai (`MR-1 — श्रम भुगतान ₹…`, index.tsx:3623) — **rollId link nahi**, isliye model me `Transaction.rollId?` chahiye (ya equivalent), warna paid/pending pata hi nahi chalta. | `types/models.ts`, EntryScreen `vendorOptions` (index.tsx:3320) | PENDING |
| 5 | "Man days me safe band **−10…−20%** ki jagah **−5% se −15%** kro" | BSR rate band guidance = **−5% … −15%** (rate ≤ BSR ka cap wahi rehta hai). MandayScreen ki hint text + `services/mandays.ts` dono. | `mandays.ts` (B36 band), MandayScreen | PENDING (rule change) |
| 6 | "App me **redo/undo** ka option — poocha jaaye ki is particular page ka hi undo/redo karna hai ya **pure app ka**" | Har undo/redo tap par scope-prompt: **(a) सिर्फ़ इस पन्ने का** / **(b) पूरे app का** + preview ki kya lautega/waapas aayega. Do alag stacks (page-scope = us cashbook page ki entries/pages; app-scope = sab). Snapshot / operation-log based; har undo/redo audit trail me record. | naya `undoStack`/ `redoStack` (AppStore), CashbookScreen menu + Home/Settings | PENDING (new capability) |
| 7 | "App me **global search** option — **realtime** search data show ho" | Naya page: type karte hi live results — entries (party / voucher / राशि / तारीख़), कार्य, MB, बिल, vendor, श्रेणी, मद, MR, बैंक लाइन, प्रपत्र. Case-insensitive, Hindi + English, minimum 2 अक्षर. Result tap → seedha us screen/record par. | naya `searchAll()` + `GlobalSearchScreen`, naya Stage `search` | PENDING (S-43 reserved tha) |
| 8 | "MR payment ke baad wo MR ki details **MR register list** me show hon — **naya page**" | Naya **MR Register**: हर MR की पंक्ति — MR नं., कार्य, अवधि (from→to), कार्य दिवस, कारीगर/श्रमिक संख्या, दर, कुल राशि, **भुगतान स्थिति (हाँ/नहीं) + भुगतान तिथि + CB पृष्ठ**. Row tap → detail + us entry par जाएँ. Home tile + Work detail dono se. | naya `MrRegisterScreen`, naya Stage | PENDING (badge → L.3 Q7) |
| 9 | "कार्य पेते **bill pay** karne ke baad wo **Bill register list** me show hon — **naya page**" | Naya **Bill Register**: बिल तिथि, कार्य, विक्रेता, राशि, प्रकार (आरंभिक/मध्यकालीन/अंतिम), **भुगतान तिथि, cashbook पन्ना + तिथि (page ref), भुगतान स्थिति**. Row tap → बिल detail / cashbook page. | naya `BillRegisterScreen`, naya Stage | PENDING (§8 ka pending implementation) |
| 10 | "MR Duration me **15 din** dikhana chahiye (1 tareekh se 15) — par un 15 me normally **12 din (2 ravivar + ek extra) working day** hote hain" | MR की **अवधि = 15 दिन** window (1–15 / 16–31) screen par saaf; uske saath **कार्य दिवस = 15 − रविवार − window me padi निश्चित छुट्टी** (aam taur par **12**). Dono alag-alag dikhें: "अवधि **15** दिन · कार्य दिवस **12**". Man-days = मज़दूर × कार्य दिवस (default 12 wahi rehta hai); `MAX_PAKHWADA_DAYS` band wahi. | `pakhwadaWorkingDays`, MandayScreen, MR wizard | PENDING (display + window) |
| 11 | "Pure app me kahi bhi **keyboard se type karte time text/page hide nahi** hona chahiye" | Cross-cutting UX rule: har input par keyboard-avoiding + **focused input scroll-into-view**; modal ka ScrollView keyboard ke upar khicha rahe; kisi bhi field/label/button ke upar keyboard na baithe. **Aaj `KeyboardAvoidingView` sirf LoginScreen me hai** (index.tsx:987) — poori app ka audit chahiye. | saare screens + modals | PENDING (UX, cross-cutting) |
| 12 | "**One-tap complete backup** ka option add kro" | **Sirf ek tap** → pura backup (DB + attachments + exports) ek hi file me, SAF folder me save + confirmation (naam, size, jagah) + `lastBackupAt` update. **Aaj format-chooser aata hai** (`fmtChoice`, 4 options — index.tsx:10360) — one-tap me chooser nahi; share alag button. | BackupScreen (S-42), `saveBackup` | PENDING |
| 13 | "**Audit format ka layout phone me bhi visible** — same Excel format app me dikhna chahiye; abhi PDF/Excel me hi dikhta hai" | Formats Centre → Audit workbook: **har sheet ka on-screen Excel-type table** (`tblBox/tblHead/tblRow`), wahi 6 sheets — full गोशवारा · गोशवारा · प्रपत्र-1 · सामग्री ऑडिट · श्रम ऑडिट · पट्टा ऑडिट. Share buttons alag rahein. **Aaj `auditSheets()` sirf HTML banata hai** → `shareWorkbook` / `askAndShare` (index.tsx:9665, 9920). | FormatsScreen (S-56), `auditSheets()` | PENDING |
| 14 | "Audit format me jahan data required hai aur wo cashbook/गोशवारा se nahi mil raha to **uss column me kya bhara jaave** pucha jaave" | Har audit-sheet cell ke liye jo auto-derive nahi hota, wahan **prompt**: column ka naam + sawaal + input → value FY-scoped store (override) → agli baar prefill. Prompt sirf missing fields par, "skip" ka vikalp bhi. | FormatsScreen audit overrides + AppStore | PENDING |
| 15 | "CC me har page ka app me bhi **alag page** banega" | **= K1-7 ka dobara confirmation** (CC p1…p7 alag-alag, Excel-jaisa realtime layout, editable sirf p1/p3/p4). Is round me yahi same rule dobara lock. | CcScreen | PENDING (dup of K-7) |
| 16 | "CC ke first page par likhe anusar **श्रम wali value = पृष्ठ 3 me sabhi MR ki amount ka total** hoti hai" | **Derivation rule:** CC पृष्ठ 1 की **"मूल्यांकन के अनुसार — अ. श्रम मद राशि"** = **Σ (पृष्ठ 3 के सभी MR/MandayCalc राशियाँ)**. Auto-derive; manual edit सिर्फ़ explicit override (K-4 lock) से. **Yahi K-2 (man-day sanction ka amount CC me nahi aa raha) ka root fix hai.** | `ccBuild` (formats.ts), CcScreen p1 | PENDING (derivation) |
| 17 | "CC ke first page par likhe anusar **सामग्री की value = पृष्ठ 4 me material ki total value** hoti hai" | **Derivation rule:** CC पृष्ठ 1 की **"ब. सामग्री मद राशि"** = **Σ (पृष्ठ 4 की material rows: मात्रा × दर)**, दर = BSR ± निविदा % (K-9). `मूल्यांकन के अनुसार कुल राशि` = अ. + ब. | `ccBuild`, CcScreen p1 | PENDING (derivation) |
| 18 | "**CC allowed expenditure hamesha 'लेखे अनुसार' amount se kam/barabar — adhik nahi**" | **Hard cap:** `allowed ≤ लेखे अनुसार amount` — कभी अधिक नहीं (save/share/export par laal warning + block). `अनुमत` = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय) **aur upar wali seema**. K-6 (CC ≤ MB मूल्यांकन) se **mil kar** lagti hai — teeno cap ek saath. [??] "लेखे अनुसार" = kaun-si rashi? (Q1) | `ccBuild`, CcScreen | PENDING (new rule) |

### L.2  Ye points purane locked rules ko chhute hain (decision chahiye)

| # | Purana rule (kahan) | Naya point | Kya badlega |
|---|---|---|---|
| a | **B36** — BSR safe band **−10…−20%** (MD-03) | L1-5 | Band = **−5% … −15%**. rate ≤ BSR cap wahi. |
| b | **G-19** (v10 #19) — Holiday tab hataya, sirf 3 fixed + Sunday; `DEFAULT_PAKHWADA_DAYS=12`; `MAX_PAKHWADA_DAYS=13` | L1-10 | **अवधि 15 दिन** ka display + **कार्य दिवस 12** alag-alag; "ek extra" = window me padi fixed holiday (confirm Q4). man-days per worker wahi 12. |
| c | **v11 #22** — MR vendor list me `party` **string** se (rollId nahi) | L1-4, L1-8 | `Transaction.rollId?` model change; bina iske paid/pending/paid-date pata nahi chalega. |
| d | **v13 #10** — ledger row-tap → cashbook page | L1-3 | Ab **alag visible column "CB पृष्ठ"** chahiye (export me bhi). |
| e | **K-18** — ledger me `स्र. क्रमांक` | L1-3 | Dono columns ek saath add honge → final set L1-3 me. |
| f | **v13 #16** (MB valuation card) + **K-4** (CC value lock) | L1-16, L1-17 | p1 ki dono values **derive** hoti hain — derived vs locked ka rule decide karo: derive tab bhi sirf tab jab user ne explicitly save na kiya ho. |
| g | **D27** — `अनुमत = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)`; **K-6** — CC ≤ MB | L1-18 | Teesri cap: `allowed ≤ लेखे अनुसार amount`. Teen caps stack. |
| h | **E-20** (v8 #20) — Audit workbook = share-only (6 sheets) | L1-13, L1-14 | Ab on-screen view + missing-data prompts. |
| i | **G-30B** (v10 #30B) — manual backup + auto-reminder | L1-12 | One-tap complete backup (chooser ke bina). |
| j | **A1 / L-01** — login button viewport me | L1-1 | Re-assert + keyboard case. |
| k | **A15** — zoom = ± controls ("pinch not found") | L1-2 | Pinch ab mandatory. |
| l | **B34** (BACKLOG) — WhatsApp one-tap share | L1-8, L1-9 | Naye register pages — scope alag, par "one-tap" wahi spirit. |
| m | **G-03 / C-16** — App Settings hamesha **aakhri** screen number | L1-7, L1-8, L1-9 | 3 naye screens (search, MR Register, Bill Register) → S-57 last nahi rahega. Ya naye screens ko **khali numbers** (S-43 reserved) do, ya **App Settings ko S-60** karo. → Q7 |

### L.3  Open questions (coding se pehle confirm)

- **Q1 (L1-18)** — *"लेखे अनुसार amount"* ka matlab: **(a)** CC पृष्ठ 1 की "मूल्यांकन के अनुसार कुल राशि", **(b)** "स्वीकृत राशि", **(c)** FS राशि, या **(d)** वास्तविक (अभी तक का) व्यय? Kaun-si?
- **Q2 (L1-4)** — MR **पूरा** अदाया हो तभी list se hatana, ya किसी भी हिस्से के भुगतान पर? Hatane ke baad wo MR Register me "भुगतान हो गया" dikhega?
- **Q3 (L1-6)** — Undo/redo ki **depth** kya hogi? "Pure app" me kya-kya aayega (entry, page add/delete, work/MB/bill delete)? **Permanent delete (purge, I-8) undo me wapas aayega ya nahi?**
- **Q4 (L1-10)** — "15 me se **ek extra** chhutti" = कौन-सी? (a) वही window me padi **निश्चित छुट्टी** (26 Jan/15 Aug/02 Oct), (b) **13वाँ दिन** hamesha chhutti, या (c) manually chun sakte hain? Working days hamesha `15 − Sunday − fixed` ho ya override?
- **Q5 (L1-12)** — One-tap backup = **(a)** SAF folder me save, **(b)** seedha share (WhatsApp/email), **(c)** dono ek saath? File format fixed (zip) ya pichhli baar wali JSON?
- **Q6 (L1-14)** — Audit ka missing-data prompt: **ek baar** (us FY ke liye) ya **har baar** jab format khole? Value FY-scoped store hogi?
- **Q7 (badges)** — 3 naye screens ke liye number: **(a)** `search = S-43` (reserved), `MR Register = S-58`, `Bill Register = S-59` aur **App Settings = S-60** (last rule), ya **(b)** aap jo chahein numbers?
- **Q8 (L1-7)** — Global search me kya-kya shamil: sirf entries, या works/MB/bill/vendor/श्रेणी/MR/bank/प्रपत्र भी? Default tab kaun-sa?
- **Q9 (L1-16/17)** — CC p1 ki श्रम/सामग्री values **hamesha derive** rahein, या derive + "लॉक" button (taaki K-4 jaisa ek baar bhara rahe)?

### L.4  Jab implementation shuru ho — is round ka deliverable checklist

1. Decide karo: **ek build (K + L dono, zip v14)** ya **do build (v14 phir v15)**.
2. Code edits (L.1 ke 18 अंक + L.2 ke decisions + L.3 ke jawab).
   Files: `app/index.tsx`, `services/*` (`mandays.ts`, `formats.ts`, `exportHtml.ts`),
   `types/models.ts` (`Transaction.rollId?`), `context/AppStore.tsx` (undo/redo,
   audit overrides, register queries), `package.json` (koi nayi dep nahi —
   gesture-handler already hai), naye screens (`GlobalSearchScreen`,
   `MrRegisterScreen`, `BillRegisterScreen`).
3. `tsc -p tsconfig.json --noEmit` → **EXIT=0**.
4. `expo export --platform android` → EXIT=0, `.hbc` size note.
5. Zip `Gram-Panchayat-Cashbook-FULL-vN.zip` (repo root; `cashbook-mobile/` prefix,
   forward slashes, no `node_modules`, poora project).
6. `.github/workflows/build-apk.yml` → name + comment **"Build APK (Gram Panchayat Cashbook vN)"**.
7. Dono `PROJECT_MASTER_NEW.md` sync + `CASHBOOK-RULES-INDEX.txt` refresh
   (PART 28 me Section L ke rules mark karna hai).
8. Badge audit: har page unique number + **App Settings sabse aakhir**.
9. Hinglish summary + run steps: **Actions → Build APK (Gram Panchayat Cashbook vN) → Run workflow**.

**Status of Section L: 0/19 implemented (as instructed).**
**Total done in build v14: Section K (v14) 18/19 + Section L (v15) 19/19 = 37/38.**
(K-11 = DEFERRED — PDF text-import ke liye koi lib nahi.)


---

### L.5  User ke jawab (07-10-2026) + NAYA FEATURE — SECTION L UPDATE

> Ye Section L.1–L.4 ka **update** hai. **Code abhi nahi bana — build abhi bhi v13.**
> Is round ke points ab **19** ho gaye (18 + L1-19).

**A. Jawab mil gaye — ye spec ab FINAL**

- **QL1 → "लेखे अनुसार" = do rashiyan** (yaani **L1-16 + L1-17 confirm**):
  - **श्रम राशि** = CC **पृष्ठ 3** me sabhi MR (MandayCalc) amount ka **कुल योग**.
  - **सामग्री राशि** = CC **पृष्ठ 4** ka **कुल material amount** —
    **निविदा (tender) rate applied hai to utna % below**, warna **chune hue BSR** anusar.
  - → **L1-18 (allowed expenditure)** = **श्रम राशि + सामग्री राशि**
    (= CC पृष्ठ 1 ka "मूल्यांकन के अनुसार कुल राशि").
    **`allowed ≤ यह कुल` — kabhi adhik nahi** (save/share/export par laal warning + block).
    Ye **D27** (`min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)`) aur **K-6** (`CC ≤ MB`) ke
    **saath** lagti hai — teeno cap stack me.

- **QL3 → Undo/Redo ka scope FINAL:**
  - **Permanent delete (purge) wapas kabhi nahi aayega.**
  - **Pure app ka undo/redo abhi nahi** — sirf **khule hue cashbook page** par.
  - → L1-6 ki **"is page ka / pure app ka" wali scope-prompt hata di gayi**
    (scope fixed = current cashbook page). Chaho to ek chhota confirm dialog
    rakh sakte hain — "is page ki latest entry lautaaen?" (**QL3b, optional**).

- **QL4 → MR ke working days (L1-10):**
  - `कार्य दिवस = 15 − रविवार − (usi window me padi निश्चित छुट्टी)`.
  - **Koi holiday nahi hai → 13 दिन** (15 − 2 रविवार).
  - Ek holiday aaya → **12 दिन**.
  - Screen par do alag line: **"अवधि 15 दिन · कार्य दिवस 13 (ya 12)"**;
    man-days = मज़दूर × कार्य दिवस.

- **QL5 → One-tap complete backup = SAF folder me SAVE.**
  - Ek tap → pura backup file **chosen SAF folder** me save + confirmation
    (naam / size / jagah) + `lastBackupAt` update.
  - Share wala button **alag** rehta hai (purane waise hi).

- **QL7 → Badge numbers FINAL:**
  `Global search = S-43` · `MR Register = S-58` · `Bill Register = S-59` ·
  **`App Settings = S-60`** → G-03 / C-16 ("App Settings hamesha aakhri number") intact.

**B. NAYA FEATURE — L1-19 : Badge → Feedback window (user, 07-10-2026)**

- Har page ka **unique badge (S-xx) ab Pressable** hai → click par **Feedback window** khule.
- Window me: page ka reference **auto** (badge + screen ka naam/stage + FY + panchayat),
  phir textarea — *"is page se related koi sudhaar suggest karna ho to likho"*
  + optional category (bug / naya feature / layout / anya) + **Submit** + रद्द.
- **Submit → SAF backup folder me `Feedback.txt`** — file na ho to **banao**,
  warna **append** (purana data kabhi mat mitao). UTF-8 + Devanagari.
- Har entry ka format:
  ```text
  ---- 2026-10-07 14:35 | S-26 | CC (7 pages) | FY 2026-27 | GP <name> | v14 ----
  [bug] yahan likha hua feedback...
  ```
  (timestamp · badge · screen/stage · FY · panchayat · app version · category · text)
- **Purpose (user ka words):** *"jab bhi app ka next development/improvement
  hona ho tab ye text file hi copy kar ke yahan paste kar sake."*
- Backup folder abhi chosen na ho to pehle SAF folder picker
  (`services/backupFolder.ts`) → phir save; success par chhota confirmation.
- **[??] QL5b (optional):** window me "पिछले feedback" ki read-only list bhi
  dikhayen (file padh kar) ya sirf submit?

**C. Abhi bhi khule hue — QL2, QL6, QL8, QL9** (user ne poochha hai ki
   inme kya-kya batana hai) → unhe **Section L.3 ka naam lekar** alag se
   poocha gaya hai. Inke jawab aate hi Section L **complete** ho jaayegi.

**Status of Section L after L.6: spec LOCKED · 0/19 implemented (build = v13).**


---

### L.6  Jawab — round 2 (07-10-2026)  —  SECTION L AB **LOCKED**

> QL2, QL6, QL8, QL9 ke jawab mil gaye → **Section L ke saare open
> questions band.** Spec ab **LOCKED** — coding kabhi bhi shuru ho
> sakti hai. **Code abhi nahi bana — build = v13.**

**QL2 → MR paid + vendor-list filter (L1-4) ki FINAL spec:**

- **Jis kaam (work) ki entry me MR ka भुगतान cashbook me darj hua,
  usi kaam ki vendor list se sirf wahi MR hatna chahiye.**
  - Example: kaam **W** me 3 MR hain → kisi **EK** MR ka भुगतान-entry
    ban gaya → wo MR **W** ki list se gayab, baaki **2** dikhte rahein.
- **Scope sirf usi kaam ka:** doosre kaam ka भुगतान karte waqt list me
  **doosre kaam ka MR bilkul nahi dikhega**
  (yeh rule code me pehle se hai —
  `rollsForWork = workerRolls.filter((r) => r.workId === workId)`,
  index.tsx:3320 — isi ko hi keep rakhna hai).
- **Auto-hide:** MR khud-ba-khid hat jaaye — koi alag toggle nahi.
- **Cancel/reverse par wapas:** भुगतान-entry रद्द/उलट hone par wo MR
  **dobara list me aa jaayega** (sirf **active, non-cancelled**
  भुगतान-entries hi count hogi).
- **Technical:** `Transaction.rollId?` (+ entry ka `cancelled` /`
  reversal` flag) → `paidRollIds(work)` = us work ki cancelled na ho
  भुगतान-entries se → `vendorOptions.filter((o) => !paidRollIds.has(o.key))`.
  **Bina `rollId` ke yeh possible nahi** (aaj sirf `party` string banti
  hai, index.tsx:3623).

**QL6 → Audit missing-data prompt (L1-14):**

- **Sirf EK baar poochho** + value **FY-wise save** (per-FY override).
- Pehli baar sirf **missing** fields; agli baar prefill (edit ka vikalp).
- FY badli → nayi FY ke liye dobara poochna (values FY-scoped hain).

**QL8 → Global search (L1-7):**

- **Sab kuch:** entries (party / voucher / राशि / तारीख़), कार्य, MB,
  बिल, vendor, श्रेणी, मद, MR, बैंक लाइन, प्रपत्र — **realtime**
  (min 2 अक्षर, case-insensitive, Hindi + English).
- **Result tap → seedha us record par**
  (entry → cashbook page / entry edit · कार्य → work detail ·
   बिल → bill detail · vendor → masters · MR → MR Register ...).
- **Order:** entries pehle, phir कार्य / बिल / vendor / baaki.
- Badge **S-43** (QL7 se confirm).

**QL9 → CC पृष्ठ 1 की श्रम/सामग्री राशि (L1-16 / L1-17):**

- **Hamesha AUTO-derive** — manual edit / override **bilkul nahi**.
- User sirf **पृष्ठ 3** (MR) aur **पृष्ठ 4** (सामग्री) badle →
  **पृष्ठ 1 apne-aap** बन jaata hai.
- **`allowed = श्रम राशि + सामग्री राशि`** (L1-18) — kabhi adhik nahi.

**Optional — default ke saath (alag chahiye to bol dena):**

- **QL3b** — undo tap par chhota confirm dialog: **nahi**
  (seedha undo + chhota toast "lauta diya · Redo karo").
- **QL5b** — feedback window me "पिछले feedback" ki list: **nahi**
  (sirf submit; aap file padh kar yahan paste kar loge).

**Section L STATUS: spec = LOCKED (19/19 + saare Q band) · implementation = 19/19 DONE.**
**Total done in build v14: Section K (v14) 18/19 + Section L (v15) 19/19 = 37/38**
 (K-11 = DEFERRED: bank PDF → Excel, koi PDF text-lib nahi, OCR allowed nahi).
