# Gram Panchayat Cashbook — Android Source

Offline-first Expo Android app for a Hindi-first gram panchayat cashbook.

## Included in this MVP

- Secure first-launch 4-digit PIN setup and local unlock
- Panchayat selection flow
- Financial year status page for FY 2026–27
- FY home dashboard with opening, income, expense and current balance
- 30-line cashbook page with the final 26/27 transaction split
- Red `श्री पोते` opening balance line and carry-forward calculation
- Income and expense entry forms
- Dynamic fund heads with fund-wise opening balances
- Paise-accurate stored amounts and formatted Indian currency display
- Backdated entries are sorted chronologically and page totals recalculate
- Entry cancellation keeps the record available in local audit history
- Local AsyncStorage persistence
- Screen-number badges (`S-01`, `S-02`, `S-05`, `S-06`, `S-07`, `S-35`)
- Custom cashbook app icon

## Run

1. Install dependencies with `pnpm install`.
2. Run `pnpm --filter @workspace/cashbook-mobile run dev`.
3. Open the Expo preview or scan the QR code with Expo Go.

This source is designed for the Replit Expo workflow and can be opened in Android Studio or continued with the normal Expo Android build process.

## Architecture

- `app/index.tsx` — complete MVP navigation and mobile UI
- `context/CashbookContext.tsx` — offline data model, persistence and totals
- `constants/colors.ts` — semantic product palette
- `components/ScreenBadge.tsx` — screen index marker

The next modules can be added without changing the cashbook calculation model: Bank Statement, Works, BSR, Measurement Book, Bills, Completion Certificate, Ledgers, Reports, FY Closing and Transfer Wizard.