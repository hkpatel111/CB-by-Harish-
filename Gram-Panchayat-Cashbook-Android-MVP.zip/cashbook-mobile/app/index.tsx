import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useMemo, useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import colors from '@/constants/colors';
import { CashbookProvider, formatINR, TransactionType, useCashbook } from '@/context/CashbookContext';
import { ScreenBadge } from '@/components/ScreenBadge';
import { useColors } from '@/hooks/useColors';

const C = colors.light;

type Stage = 'login' | 'panchayat' | 'fy' | 'home' | 'cashbook';

type EntryDraft = {
  type: TransactionType;
  date: string;
  reference: string;
  party: string;
  detail: string;
  note: string;
  amounts: Record<string, string>;
};

const emptyDraft = (type: TransactionType, fundIds: string[]): EntryDraft => ({
  type,
  date: new Date().toISOString().slice(0, 10),
  reference: '',
  party: '',
  detail: '',
  note: '',
  amounts: Object.fromEntries(fundIds.map((id) => [id, ''])),
});

function IconButton({ name, onPress, tint = C.primary }: { name: keyof typeof Feather.glyphMap; onPress: () => void; tint?: string }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}><Feather name={name} size={19} color={tint} /></Pressable>;
}

function Button({ label, onPress, variant = 'primary', icon, disabled = false }: { label: string; onPress: () => void; variant?: 'primary' | 'soft' | 'outline' | 'danger'; icon?: keyof typeof Feather.glyphMap; disabled?: boolean }) {
  const background = variant === 'primary' ? C.primary : variant === 'danger' ? C.expenseSoft : variant === 'soft' ? C.primarySoft : 'transparent';
  const foreground = variant === 'primary' ? C.primaryForeground : variant === 'danger' ? C.expense : C.primary;
  return <Pressable disabled={disabled} onPress={() => { Haptics.selectionAsync(); onPress(); }} style={({ pressed }) => [styles.button, { backgroundColor: background, borderColor: variant === 'outline' ? C.border : background, opacity: disabled ? 0.45 : pressed ? 0.82 : 1 }]}>{icon ? <Feather name={icon} size={17} color={foreground} /> : null}<Text style={[styles.buttonText, { color: foreground }]}>{label}</Text></Pressable>;
}

function Header({ eyebrow, title, onBack, action }: { eyebrow?: string; title: string; onBack?: () => void; action?: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  return <View style={[styles.header, { paddingTop: Platform.OS === 'web' ? 67 : insets.top + 8 }]}><View style={styles.headerRow}>{onBack ? <IconButton name="arrow-left" onPress={onBack} /> : <View style={styles.mark}><Feather name="book-open" size={18} color={C.primaryForeground} /></View>}<View style={styles.headerCopy}>{eyebrow ? <Text style={styles.headerEyebrow}>{eyebrow}</Text> : null}<Text style={styles.headerTitle}>{title}</Text></View><View>{action ?? <ScreenBadge label="S-01" />}</View></View></View>;
}

function Field({ label, value, onChangeText, placeholder, keyboardType = 'default', multiline = false }: { label: string; value: string; onChangeText: (value: string) => void; placeholder?: string; keyboardType?: 'default' | 'numeric'; multiline?: boolean }) {
  return <View style={styles.fieldWrap}><Text style={styles.fieldLabel}>{label}</Text><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor={C.mutedForeground} keyboardType={keyboardType} multiline={multiline} style={[styles.field, multiline && styles.multiline]} /></View>;
}

function LoginScreen({ onContinue }: { onContinue: () => void }) {
  const { pin, setPin, setupComplete } = useCashbook();
  const [entry, setEntry] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const firstTime = !setupComplete || !pin;
  const submit = async () => {
    if (entry.length !== 4) return setError('Enter a 4-digit PIN.');
    if (firstTime && entry !== confirm) return setError('PINs do not match.');
    if (!firstTime && entry !== pin) return setError('Incorrect PIN. Try again.');
    await setPin(entry);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    onContinue();
  };
  return <View style={styles.darkPage}><StatusBar style="light" /><View style={styles.loginOrbOne} /><View style={styles.loginOrbTwo} /><View style={styles.loginContent}><View style={styles.loginTop}><View style={styles.logoBox}><Feather name="book-open" size={28} color={C.accent} /></View><View><Text style={styles.brandKicker}>CASHBOOK</Text><Text style={styles.brandTitle}>Panchayat Ledger</Text></View></View><View style={styles.loginMiddle}><Text style={styles.loginGreeting}>{firstTime ? 'Set up your secure PIN' : 'Welcome back'}</Text><Text style={styles.loginDescription}>{firstTime ? 'Your records stay on this device, ready for every working day.' : 'Sign in to continue to your financial year.'}</Text><View style={styles.userCard}><View style={styles.avatar}><Text style={styles.avatarText}>HP</Text></View><View style={{ flex: 1 }}><Text style={styles.userName}>Harish Patidar</Text><Text style={styles.userRole}>Operator · ग्राम पंचायत माल</Text></View><Feather name="shield" size={18} color={C.accent} /></View><View style={styles.pinRow}>{[0, 1, 2, 3].map((index) => <View key={index} style={[styles.pinDot, entry.length > index && styles.pinDotActive]} />)}</View><TextInput autoFocus value={entry} onChangeText={(value) => { setError(''); setEntry(value.replace(/[^0-9]/g, '').slice(0, 4)); }} keyboardType="numeric" secureTextEntry style={styles.pinInput} placeholder="4-digit PIN" placeholderTextColor="rgba(255,255,255,0.38)" /><Text style={styles.pinHint}>{firstTime ? 'Create a PIN you will remember' : 'Enter your 4-digit PIN'}</Text>{firstTime ? <TextInput value={confirm} onChangeText={(value) => setConfirm(value.replace(/[^0-9]/g, '').slice(0, 4))} keyboardType="numeric" secureTextEntry style={[styles.pinInput, { marginTop: 12 }]} placeholder="Confirm PIN" placeholderTextColor="rgba(255,255,255,0.38)" /> : null}{error ? <Text style={styles.errorText}>{error}</Text> : null}<Pressable testID="login-continue" onPress={submit} style={({ pressed }) => [styles.loginButton, pressed && { opacity: 0.86 }]}><Text style={styles.loginButtonText}>{firstTime ? 'Create secure PIN' : 'Unlock cashbook'}</Text><Feather name="arrow-right" size={18} color={C.darkForest} /></Pressable></View><View style={styles.offlinePill}><View style={styles.onlineDot} /><Text style={styles.offlineText}>100% offline · data stays safe</Text></View></View><ScreenBadge label="S-01" /></View>;
}

function PanchayatScreen({ onContinue, onBack }: { onContinue: () => void; onBack: () => void }) {
  const { panchayat } = useCashbook();
  return <View style={styles.page}><StatusBar style="dark" /><Header eyebrow="GOOD MORNING" title="Choose your workplace" onBack={onBack} action={<ScreenBadge label="S-02" />} /><ScrollView contentContainerStyle={styles.scrollContent}><View style={styles.welcomeBlock}><Text style={styles.welcomeTitle}>Namaste, Harish</Text><Text style={styles.welcomeBody}>Select a gram panchayat to open its records.</Text></View><View style={styles.selectCard}><View style={styles.selectIcon}><Feather name="map-pin" size={21} color={C.primary} /></View><View style={{ flex: 1 }}><Text style={styles.fieldLabel}>GRAM PANCHAYAT</Text><Text style={styles.selectValue}>{panchayat}</Text><Text style={styles.selectMeta}>पं.समि. साबला · जिला डूंगरपुर</Text></View><Feather name="chevron-down" size={20} color={C.mutedForeground} /></View><View style={styles.infoBanner}><Feather name="lock" size={17} color={C.primary} /><Text style={styles.infoBannerText}>Your cashbook is stored locally on this device.</Text></View><Button label="Enter panchayat" icon="arrow-right" onPress={onContinue} /><View style={styles.hintBox}><Feather name="info" size={16} color={C.warning} /><Text style={styles.hintText}>You can switch panchayat later from App Settings.</Text></View></ScrollView><View style={styles.bottomBadge}><ScreenBadge label="S-02" /></View></View>;
}

function FYScreen({ onContinue, onBack }: { onContinue: () => void; onBack: () => void }) {
  const { financialYear, totalOpening, totalIncome, totalExpense, currentBalance, activeFunds } = useCashbook();
  return <View style={styles.page}><StatusBar style="dark" /><Header eyebrow="ग्राम पंचायत माल" title="Financial year" onBack={onBack} action={<ScreenBadge label="S-05" />} /><ScrollView contentContainerStyle={styles.scrollContent}><View style={styles.fyHero}><View><Text style={styles.fyLabel}>CURRENT RECORD</Text><Text style={styles.fyValue}>FY {financialYear}</Text><Text style={styles.fyDates}>01 Apr 2026 — 31 Mar 2027</Text></View><View style={styles.fyIcon}><Feather name="calendar" size={22} color={C.primary} /></View></View><Text style={styles.sectionTitle}>At a glance</Text><View style={styles.statsGrid}><Stat label="Opening" value={formatINR(totalOpening)} icon="download" /><Stat label="Total income" value={formatINR(totalIncome)} icon="trending-up" tone="income" /><Stat label="Total expense" value={formatINR(totalExpense)} icon="trending-down" tone="expense" /><Stat label="Current balance" value={formatINR(currentBalance)} icon="briefcase" tone="accent" /></View><Text style={styles.sectionTitle}>Fund-wise opening balance</Text><View style={styles.fundList}>{activeFunds.map((fund) => <View style={styles.fundRow} key={fund.id}><View style={[styles.fundDot, { backgroundColor: C.primary }]} /><Text style={styles.fundName}>{fund.name}</Text><Text style={styles.fundAmount}>{formatINR(fund.openingBalance)}</Text></View>)}</View><Button label="Open financial year" icon="arrow-right" onPress={onContinue} /></ScrollView><View style={styles.bottomBadge}><ScreenBadge label="S-05" /></View></View>;
}

function Stat({ label, value, icon, tone = 'default' }: { label: string; value: string; icon: keyof typeof Feather.glyphMap; tone?: 'default' | 'income' | 'expense' | 'accent' }) {
  const tint = tone === 'income' ? C.income : tone === 'expense' ? C.expense : tone === 'accent' ? C.accent : C.primary;
  return <View style={styles.statCard}><View style={[styles.statIcon, { backgroundColor: tint + '18' }]}><Feather name={icon} size={17} color={tint} /></View><Text style={styles.statLabel}>{label}</Text><Text style={styles.statValue}>{value}</Text></View>;
}

function HomeScreen({ onCashbook, onBack, onFunds }: { onCashbook: () => void; onBack: () => void; onFunds: () => void }) {
  const { financialYear, totalIncome, totalExpense, currentBalance, transactions } = useCashbook();
  const pending = transactions.filter((item) => item.status === 'active' && !item.note).length;
  return <View style={styles.page}><StatusBar style="dark" /><Header eyebrow="FY 2026–27" title="Good morning, Harish" onBack={onBack} action={<ScreenBadge label="S-06" />} /><ScrollView contentContainerStyle={styles.scrollContent}><View style={styles.homeHero}><View style={styles.heroCopy}><Text style={styles.heroKicker}>FINANCIAL YEAR HOME</Text><Text style={styles.heroBalance}>{formatINR(currentBalance)}</Text><Text style={styles.heroCaption}>Current available balance</Text></View><View style={styles.heroBadge}><Feather name="shield" size={20} color={C.accent} /><Text style={styles.heroBadgeText}>Offline safe</Text></View></View><View style={styles.quickActions}><QuickAction icon="plus-circle" label="Add income" tint={C.income} onPress={() => onCashbook()} /><QuickAction icon="minus-circle" label="Add expense" tint={C.expense} onPress={() => onCashbook()} /><QuickAction icon="book-open" label="Cashbook" tint={C.primary} onPress={onCashbook} /><QuickAction icon="sliders" label="Fund heads" tint={C.accent} onPress={onFunds} /></View><View style={styles.sectionHeader}><Text style={styles.sectionTitle}>This financial year</Text><Text style={styles.sectionLink}>{financialYear}</Text></View><View style={styles.homeStats}><View><Text style={styles.homeStatLabel}>Total income</Text><Text style={[styles.homeStatValue, { color: C.income }]}>{formatINR(totalIncome)}</Text></View><View style={styles.dividerVertical} /><View><Text style={styles.homeStatLabel}>Total expense</Text><Text style={[styles.homeStatValue, { color: C.expense }]}>{formatINR(totalExpense)}</Text></View></View><View style={styles.checkCard}><View style={styles.checkTop}><View style={styles.checkIcon}><Feather name="check-circle" size={19} color={C.primary} /></View><View style={{ flex: 1 }}><Text style={styles.checkTitle}>Monthly check</Text><Text style={styles.checkBody}>{pending ? pending + ' entries need a note' : 'Everything is ready for review'}</Text></View><Feather name="chevron-right" size={18} color={C.mutedForeground} /></View><View style={styles.progressTrack}><View style={[styles.progressFill, { width: pending ? '70%' : '100%' }]} /></View></View><Text style={styles.sectionTitle}>Your workspace</Text><HomeRow icon="file-text" title="Goshwara till date" subtitle="Classified annual summary" /><HomeRow icon="layers" title="Reports & ledgers" subtitle="Cash, funds and audit trail" /><HomeRow icon="database" title="Backup & restore" subtitle="Protect your records" /></ScrollView><View style={styles.bottomBadge}><ScreenBadge label="S-06" /></View></View>;
}

function QuickAction({ icon, label, tint, onPress }: { icon: keyof typeof Feather.glyphMap; label: string; tint: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.quickAction, pressed && styles.pressed]}><View style={[styles.quickIcon, { backgroundColor: tint + '18' }]}><Feather name={icon} size={21} color={tint} /></View><Text style={styles.quickLabel}>{label}</Text></Pressable>;
}

function HomeRow({ icon, title, subtitle }: { icon: keyof typeof Feather.glyphMap; title: string; subtitle: string }) {
  return <View style={styles.homeRow}><View style={styles.homeRowIcon}><Feather name={icon} size={18} color={C.primary} /></View><View style={{ flex: 1 }}><Text style={styles.homeRowTitle}>{title}</Text><Text style={styles.homeRowSub}>{subtitle}</Text></View><Feather name="chevron-right" size={18} color={C.mutedForeground} /></View>;
}

function CashbookScreen({ onBack, onFunds }: { onBack: () => void; onFunds: () => void }) {
  const { panchayat, financialYear, activeFunds, transactions, totalOpening, addTransaction, cancelTransaction } = useCashbook();
  const [entryType, setEntryType] = useState<TransactionType | null>(null);
  const [draft, setDraft] = useState<EntryDraft>(() => emptyDraft('income', activeFunds.map((fund) => fund.id)));
  const [selectedPage, setSelectedPage] = useState(1);
  const [showAll, setShowAll] = useState(false);
  const [error, setError] = useState('');
  const activeTransactions = useMemo(() => transactions.filter((item) => item.status === 'active').sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt)), [transactions]);
  const incomes = activeTransactions.filter((item) => item.type === 'income');
  const expenses = activeTransactions.filter((item) => item.type === 'expense');
  const incomePages = Math.max(1, Math.ceil(incomes.length / 26));
  const expensePages = Math.max(1, Math.ceil(expenses.length / 27));
  const totalPages = Math.max(incomePages, expensePages);
  const pageIncome = incomes.slice((selectedPage - 1) * 26, selectedPage * 26);
  const pageExpense = expenses.slice((selectedPage - 1) * 27, selectedPage * 27);
  const priorIncome = incomes.slice(0, (selectedPage - 1) * 26);
  const priorExpense = expenses.slice(0, (selectedPage - 1) * 27);
  const opening = selectedPage === 1 ? totalOpening : totalOpening + priorIncome.reduce((sum, item) => sum + Object.values(item.amounts).reduce((a, b) => a + b, 0), 0) - priorExpense.reduce((sum, item) => sum + Object.values(item.amounts).reduce((a, b) => a + b, 0), 0);
  const pageIncomeTotal = pageIncome.reduce((sum, item) => sum + Object.values(item.amounts).reduce((a, b) => a + b, 0), 0);
  const pageExpenseTotal = pageExpense.reduce((sum, item) => sum + Object.values(item.amounts).reduce((a, b) => a + b, 0), 0);
  const mahayog = opening + pageIncomeTotal;
  const bachat = mahayog - pageExpenseTotal;
  const startEntry = (type: TransactionType) => { setError(''); setDraft(emptyDraft(type, activeFunds.map((fund) => fund.id))); setEntryType(type); };
  const saveEntry = async () => {
    const amountTotal = Object.values(draft.amounts).reduce((sum, value) => sum + (Number(value) || 0), 0);
    if (!draft.date || !draft.party.trim() || !draft.detail.trim() || amountTotal <= 0) return setError('Date, party/source, detail and at least one amount are required.');
    await addTransaction({ type: draft.type, date: draft.date, reference: draft.reference.trim(), party: draft.party.trim(), detail: draft.detail.trim(), note: draft.note.trim(), amounts: Object.fromEntries(Object.entries(draft.amounts).map(([id, value]) => [id, Number(value) || 0])) });
    setEntryType(null);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };
  return <View style={styles.page}><StatusBar style="dark" /><Header eyebrow={panchayat} title="Cashbook" onBack={onBack} action={<View style={styles.headerActions}><IconButton name="sliders" onPress={onFunds} /><ScreenBadge label="S-07" /></View>} /><View style={styles.cashbookToolbar}><View><Text style={styles.cashbookYear}>FY {financialYear}</Text><Text style={styles.cashbookSub}>Page {selectedPage} of {totalPages} · 30-line register</Text></View><View style={styles.pageStepper}><Pressable disabled={selectedPage <= 1} onPress={() => setSelectedPage((page) => Math.max(1, page - 1))} style={styles.stepperButton}><Feather name="chevron-left" size={16} color={selectedPage <= 1 ? C.border : C.primary} /></Pressable><Text style={styles.pageNumber}>{selectedPage}</Text><Pressable disabled={selectedPage >= totalPages} onPress={() => setSelectedPage((page) => Math.min(totalPages, page + 1))} style={styles.stepperButton}><Feather name="chevron-right" size={16} color={selectedPage >= totalPages ? C.border : C.primary} /></Pressable></View></View><ScrollView contentContainerStyle={styles.cashbookScroll}><View style={styles.paper}><View style={styles.paperHeader}><Text style={styles.paperTitle}>{panchayat}</Text><Text style={styles.paperFY}>वि.व. {financialYear}</Text></View><View style={styles.paperColumns}><View style={styles.paperSide}><View style={styles.sideHeading}><Text style={styles.sideTitle}>प्राप्ति</Text><Text style={styles.sideEnglish}>INCOME</Text></View><View style={styles.openingLine}><Text style={styles.openingLabel}>श्री पोते</Text><Text style={styles.openingAmount}>{formatINR(opening)}</Text></View>{pageIncome.map((item, index) => <LedgerLine key={item.id} number={index + 2} item={item} onCancel={() => cancelTransaction(item.id)} />)}{Array.from({ length: Math.max(0, 26 - pageIncome.length) }).map((_, index) => <EmptyLine key={'income-empty-' + index} number={pageIncome.length + index + 2} />)}<SummaryLine label="आय योग" value={pageIncomeTotal} /><View style={styles.paperLine}><Text style={styles.paperLineLabel}>श्री पोते</Text><Text style={styles.paperLineValue}>{formatINR(opening)}</Text></View><SummaryLine label="महायोग" value={mahayog} strong /></View><View style={styles.paperSide}><View style={[styles.sideHeading, { backgroundColor: C.expenseSoft }]}><Text style={[styles.sideTitle, { color: C.expense }]}>व्यय</Text><Text style={styles.sideEnglish}>EXPENSE</Text></View>{pageExpense.map((item, index) => <LedgerLine key={item.id} number={index + 1} item={item} onCancel={() => cancelTransaction(item.id)} expense />)}{Array.from({ length: Math.max(0, 27 - pageExpense.length) }).map((_, index) => <EmptyLine key={'expense-empty-' + index} number={pageExpense.length + index + 1} />)}<SummaryLine label="व्यय योग" value={pageExpenseTotal} expense /><View style={styles.paperLine}><Text style={styles.paperLineLabel}>बचत पोते</Text><Text style={styles.paperLineValue}>{formatINR(bachat)}</Text></View><SummaryLine label="महायोग" value={mahayog} expense strong /></View></View></View><View style={styles.formActions}><Button label="Add income" icon="plus" onPress={() => startEntry('income')} /><Button label="Add expense" icon="minus" variant="soft" onPress={() => startEntry('expense')} /></View>{activeTransactions.length ? <Pressable onPress={() => setShowAll((value) => !value)} style={styles.recentToggle}><Text style={styles.recentToggleText}>{showAll ? 'Hide all transactions' : 'View all transactions'}</Text><Feather name={showAll ? 'chevron-up' : 'chevron-down'} size={16} color={C.primary} /></Pressable> : null}{showAll ? <View style={styles.allTransactions}>{activeTransactions.map((item) => <View key={item.id} style={styles.transactionListRow}><View style={[styles.transactionBadge, { backgroundColor: item.type === 'income' ? C.incomeSoft : C.expenseSoft }]}><Feather name={item.type === 'income' ? 'arrow-down-left' : 'arrow-up-right'} size={15} color={item.type === 'income' ? C.income : C.expense} /></View><View style={{ flex: 1 }}><Text style={styles.transactionTitle}>{item.detail}</Text><Text style={styles.transactionMeta}>{item.date} · {item.party}</Text></View><Text style={[styles.transactionAmount, { color: item.type === 'income' ? C.income : C.expense }]}>{item.type === 'income' ? '+' : '-'}{formatINR(Object.values(item.amounts).reduce((a, b) => a + b, 0), true)}</Text></View>)}</View> : null}</ScrollView><View style={styles.bottomBadge}><ScreenBadge label="S-07" /></View><Modal visible={entryType !== null} animationType="slide" transparent onRequestClose={() => setEntryType(null)}><KeyboardAvoidingView style={styles.modalOverlay} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><View style={styles.entrySheet}><View style={styles.sheetHeader}><View><Text style={styles.sheetEyebrow}>{entryType === 'income' ? 'NEW RECEIPT' : 'NEW PAYMENT'}</Text><Text style={styles.sheetTitle}>{entryType === 'income' ? 'Add income' : 'Add expense'}</Text></View><IconButton name="x" onPress={() => setEntryType(null)} /></View><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.sheetScroll}><View style={styles.typeSwitch}><Pressable onPress={() => setDraft((value) => ({ ...value, type: 'income' }))} style={[styles.typeOption, draft.type === 'income' && styles.typeSelectedIncome]}><Text style={[styles.typeText, draft.type === 'income' && { color: C.income }]}>Income</Text></Pressable><Pressable onPress={() => setDraft((value) => ({ ...value, type: 'expense' }))} style={[styles.typeOption, draft.type === 'expense' && styles.typeSelectedExpense]}><Text style={[styles.typeText, draft.type === 'expense' && { color: C.expense }]}>Expense</Text></Pressable></View><Field label="Transaction date" value={draft.date} onChangeText={(value) => setDraft((current) => ({ ...current, date: value }))} placeholder="YYYY-MM-DD" /><Field label={draft.type === 'income' ? 'Received from' : 'Paid to'} value={draft.party} onChangeText={(value) => setDraft((current) => ({ ...current, party: value }))} placeholder={draft.type === 'income' ? 'Source / person / institution' : 'Vendor / party name'} /><Field label="Details" value={draft.detail} onChangeText={(value) => setDraft((current) => ({ ...current, detail: value }))} placeholder={draft.type === 'income' ? 'SFC, fee, grant...' : 'Work name or category'} /><Field label={draft.type === 'income' ? 'Receipt number / date' : 'Voucher number / date'} value={draft.reference} onChangeText={(value) => setDraft((current) => ({ ...current, reference: value }))} placeholder="Optional reference" /><Text style={styles.fieldLabel}>FUND AMOUNTS</Text><View style={styles.amountGrid}>{activeFunds.map((fund) => <View key={fund.id} style={styles.amountCell}><Text style={styles.amountLabel}>{fund.shortName}</Text><TextInput value={draft.amounts[fund.id] ?? ''} onChangeText={(value) => setDraft((current) => ({ ...current, amounts: { ...current.amounts, [fund.id]: value.replace(/[^0-9.]/g, '') } }))} keyboardType="numeric" placeholder="0.00" placeholderTextColor={C.mutedForeground} style={styles.amountInput} /></View>)}</View><Field label="Additional note" value={draft.note} onChangeText={(value) => setDraft((current) => ({ ...current, note: value }))} placeholder="Attachment or audit note" multiline />{error ? <Text style={styles.formError}>{error}</Text> : null}<Button label="Save entry" icon="check" onPress={saveEntry} /></ScrollView></View></KeyboardAvoidingView></Modal></View>;
}

function LedgerLine({ number, item, onCancel, expense = false }: { number: number; item: import('@/context/CashbookContext').Transaction; onCancel: () => void; expense?: boolean }) {
  const [expanded, setExpanded] = useState(false);
  const total = Object.values(item.amounts).reduce((sum, value) => sum + value, 0);
  return <Pressable onPress={() => setExpanded((value) => !value)} style={styles.ledgerLine}><View style={styles.lineNumber}><Text style={styles.lineNumberText}>{number}</Text></View><View style={{ flex: 1 }}><Text numberOfLines={1} style={styles.lineTitle}>{item.detail}</Text><Text numberOfLines={1} style={styles.lineSub}>{item.date.slice(5)} · {item.party}</Text>{expanded ? <View style={styles.lineDetail}><Text style={styles.lineDetailText}>{item.reference || 'No reference'}{item.note ? ' · ' + item.note : ''}</Text><Pressable onPress={onCancel}><Text style={styles.cancelText}>Cancel entry</Text></Pressable></View> : null}</View><Text style={[styles.lineAmount, { color: expense ? C.expense : C.income }]}>{formatINR(total)}</Text></Pressable>;
}

function EmptyLine({ number }: { number: number }) { return <View style={styles.emptyLine}><View style={styles.lineNumber}><Text style={styles.lineNumberText}>{number}</Text></View><View style={styles.emptyLineFill} /></View>; }
function SummaryLine({ label, value, expense = false, strong = false }: { label: string; value: number; expense?: boolean; strong?: boolean }) { return <View style={[styles.summaryLine, strong && styles.summaryStrong]}><Text style={[styles.summaryLabel, strong && styles.summaryStrongText]}>{label}</Text><Text style={[styles.summaryValue, { color: expense ? C.expense : C.income }, strong && styles.summaryStrongText]}>{formatINR(value)}</Text></View>; }

function FundsScreen({ onBack }: { onBack: () => void }) {
  const { activeFunds, addFund, updateOpeningBalance } = useCashbook();
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [editing, setEditing] = useState<string | null>(null);
  const saveFund = async () => { if (!name.trim()) return; await addFund(name, Number(amount) || 0); setName(''); setAmount(''); };
  return <View style={styles.page}><StatusBar style="dark" /><Header eyebrow="ADMIN SETTINGS" title="Fund heads" onBack={onBack} action={<ScreenBadge label="S-35" />} /><ScrollView contentContainerStyle={styles.scrollContent}><View style={styles.settingsIntro}><View style={styles.settingsIcon}><Feather name="sliders" size={22} color={C.primary} /></View><View style={{ flex: 1 }}><Text style={styles.settingsTitle}>Dynamic fund columns</Text><Text style={styles.settingsBody}>Changes flow through pages, totals, reports and carry-forward balances.</Text></View></View><Text style={styles.sectionTitle}>Active fund heads</Text>{activeFunds.map((fund) => <View key={fund.id} style={styles.fundSettingRow}><View style={styles.fundSettingDot}><Feather name="layers" size={16} color={C.primary} /></View><View style={{ flex: 1 }}><Text style={styles.fundName}>{fund.name}</Text><Text style={styles.fundMeta}>Opening balance · {formatINR(fund.openingBalance)}</Text></View><Pressable onPress={() => setEditing(editing === fund.id ? null : fund.id)}><Text style={styles.editLink}>{editing === fund.id ? 'Done' : 'Edit'}</Text></Pressable>{editing === fund.id ? <View style={styles.inlineEdit}><TextInput keyboardType="numeric" value={String(fund.openingBalance)} onChangeText={(value) => updateOpeningBalance(fund.id, Number(value) || 0)} style={styles.inlineInput} /></View> : null}</View>)}<Text style={[styles.sectionTitle, { marginTop: 24 }]}>Add fund head</Text><Field label="Fund name" value={name} onChangeText={setName} placeholder="e.g. 15th Finance" /><Field label="Opening balance" value={amount} onChangeText={setAmount} placeholder="0.00" keyboardType="numeric" /><Button label="Add fund column" icon="plus" onPress={saveFund} disabled={!name.trim()} /><View style={styles.infoBanner}><Feather name="info" size={17} color={C.primary} /><Text style={styles.infoBannerText}>Historical fund heads should be archived instead of deleted.</Text></View></ScrollView><View style={styles.bottomBadge}><ScreenBadge label="S-35" /></View></View>;
}

function AppContent() {
  const [stage, setStage] = useState<Stage>('login');
  const [returnStage, setReturnStage] = useState<Stage>('home');
  const [fundsOpen, setFundsOpen] = useState(false);
  const { hydrated } = useCashbook();
  if (!hydrated) return <View style={styles.loading}><Feather name="loader" size={24} color={C.primary} /><Text style={styles.loadingText}>Loading secure cashbook…</Text></View>;
  if (fundsOpen) return <FundsScreen onBack={() => setFundsOpen(false)} />;
  if (stage === 'login') return <LoginScreen onContinue={() => setStage('panchayat')} />;
  if (stage === 'panchayat') return <PanchayatScreen onContinue={() => setStage('fy')} onBack={() => setStage('login')} />;
  if (stage === 'fy') return <FYScreen onContinue={() => setStage('home')} onBack={() => setStage('panchayat')} />;
  if (stage === 'cashbook') return <CashbookScreen onBack={() => setStage(returnStage)} onFunds={() => { setReturnStage('cashbook'); setFundsOpen(true); }} />;
  return <HomeScreen onCashbook={() => { setReturnStage('home'); setStage('cashbook'); }} onBack={() => setStage('fy')} onFunds={() => { setReturnStage('home'); setFundsOpen(true); }} />;
}

export default function Index() { return <CashbookProvider><AppContent /></CashbookProvider>; }

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  darkPage: { flex: 1, backgroundColor: C.darkForest, overflow: 'hidden' },
  loginContent: { flex: 1, paddingHorizontal: 24, paddingBottom: 20, justifyContent: 'space-between' },
  loginOrbOne: { position: 'absolute', width: 320, height: 320, borderRadius: 160, backgroundColor: '#1d6147', top: -150, right: -120, opacity: 0.42 },
  loginOrbTwo: { position: 'absolute', width: 280, height: 280, borderRadius: 140, backgroundColor: '#244f3d', bottom: -160, left: -140, opacity: 0.65 },
  loginTop: { paddingTop: 68, flexDirection: 'row', alignItems: 'center', gap: 13 },
  logoBox: { width: 54, height: 54, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)' },
  brandKicker: { color: C.accent, letterSpacing: 3, fontSize: 11, fontWeight: '700' },
  brandTitle: { color: '#ffffff', fontSize: 16, marginTop: 3, fontWeight: '600' },
  loginMiddle: { paddingBottom: 12 },
  loginGreeting: { color: '#ffffff', fontSize: 29, fontWeight: '700', letterSpacing: -0.6 },
  loginDescription: { color: 'rgba(255,255,255,0.68)', fontSize: 14, lineHeight: 21, marginTop: 9, marginBottom: 22, maxWidth: 290 },
  userCard: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 13, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.08)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.11)' },
  avatar: { width: 38, height: 38, borderRadius: 13, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: C.darkForest, fontWeight: '800', fontSize: 13 },
  userName: { color: '#ffffff', fontWeight: '600', fontSize: 14 },
  userRole: { color: 'rgba(255,255,255,0.56)', fontSize: 11, marginTop: 3 },
  pinRow: { flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 24 },
  pinDot: { width: 10, height: 10, borderRadius: 5, borderWidth: 1, borderColor: 'rgba(255,255,255,0.4)' },
  pinDotActive: { backgroundColor: C.accent, borderColor: C.accent },
  pinInput: { color: '#ffffff', textAlign: 'center', fontSize: 19, letterSpacing: 6, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.2)', paddingVertical: 11, marginTop: 13 },
  pinHint: { color: 'rgba(255,255,255,0.45)', textAlign: 'center', fontSize: 11, marginTop: 9 },
  errorText: { color: '#ffc9bb', textAlign: 'center', fontSize: 12, marginTop: 10 },
  loginButton: { height: 54, borderRadius: 17, backgroundColor: C.accent, marginTop: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  loginButtonText: { color: C.darkForest, fontWeight: '800', fontSize: 14 },
  offlinePill: { alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 12, paddingVertical: 8, backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 18 },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#76c993' },
  offlineText: { color: 'rgba(255,255,255,0.58)', fontSize: 11 },
  header: { backgroundColor: C.background, paddingHorizontal: 20, paddingBottom: 14 },
  headerRow: { minHeight: 50, flexDirection: 'row', alignItems: 'center', gap: 12 },
  mark: { width: 38, height: 38, borderRadius: 13, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' },
  headerCopy: { flex: 1 },
  headerEyebrow: { color: C.primary, fontSize: 10, letterSpacing: 1.6, fontWeight: '800', marginBottom: 4 },
  headerTitle: { color: C.foreground, fontSize: 21, fontWeight: '800', letterSpacing: -0.4 },
  iconButton: { width: 38, height: 38, borderRadius: 13, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  pressed: { opacity: 0.72 },
  scrollContent: { padding: 20, paddingBottom: Platform.OS === 'web' ? 34 : 28 },
  welcomeBlock: { paddingTop: 11, paddingBottom: 24 },
  welcomeTitle: { fontSize: 28, fontWeight: '800', letterSpacing: -0.7, color: C.foreground },
  welcomeBody: { color: C.mutedForeground, fontSize: 14, marginTop: 7 },
  selectCard: { backgroundColor: C.card, borderRadius: 18, borderWidth: 1, borderColor: C.border, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 12, shadowColor: C.darkForest, shadowOpacity: 0.04, shadowRadius: 14, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  selectIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  fieldLabel: { color: C.mutedForeground, fontSize: 10, letterSpacing: 1.2, fontWeight: '800', marginBottom: 8 },
  selectValue: { color: C.foreground, fontSize: 16, fontWeight: '700' },
  selectMeta: { color: C.mutedForeground, fontSize: 11, marginTop: 4 },
  infoBanner: { flexDirection: 'row', gap: 10, alignItems: 'center', padding: 13, backgroundColor: C.primarySoft, borderRadius: 14, marginVertical: 16 },
  infoBannerText: { color: C.secondaryForeground, fontSize: 12, flex: 1, lineHeight: 18 },
  hintBox: { flexDirection: 'row', gap: 8, alignItems: 'center', paddingTop: 18, justifyContent: 'center' },
  hintText: { color: C.mutedForeground, fontSize: 11 },
  button: { minHeight: 50, paddingHorizontal: 17, borderRadius: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  buttonText: { fontSize: 13, fontWeight: '800' },
  bottomBadge: { position: 'absolute', bottom: Platform.OS === 'web' ? 34 : 17, right: 19 },
  fyHero: { backgroundColor: C.primarySoft, borderRadius: 21, padding: 19, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, marginBottom: 23 },
  fyLabel: { color: C.primary, fontSize: 10, letterSpacing: 1.3, fontWeight: '800' },
  fyValue: { color: C.primary, fontSize: 29, fontWeight: '800', marginTop: 6 },
  fyDates: { color: C.secondaryForeground, fontSize: 12, marginTop: 4 },
  fyIcon: { width: 50, height: 50, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.55)', alignItems: 'center', justifyContent: 'center' },
  sectionTitle: { color: C.foreground, fontSize: 15, fontWeight: '800', marginBottom: 12 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 24 },
  statCard: { backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: C.border, width: '48%', padding: 13 },
  statIcon: { width: 29, height: 29, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  statLabel: { color: C.mutedForeground, fontSize: 11 },
  statValue: { color: C.foreground, fontSize: 17, fontWeight: '800', marginTop: 4 },
  fundList: { backgroundColor: C.card, borderRadius: 17, borderWidth: 1, borderColor: C.border, paddingHorizontal: 14, marginBottom: 20 },
  fundRow: { minHeight: 48, flexDirection: 'row', alignItems: 'center', borderBottomWidth: 1, borderBottomColor: C.input },
  fundDot: { width: 8, height: 8, borderRadius: 4, marginRight: 10 },
  fundName: { flex: 1, color: C.foreground, fontSize: 13, fontWeight: '600' },
  fundAmount: { color: C.foreground, fontSize: 13, fontWeight: '700' },
  homeHero: { backgroundColor: C.darkForest, borderRadius: 22, padding: 19, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: 8, marginBottom: 14, overflow: 'hidden' },
  heroCopy: { flex: 1 },
  heroKicker: { color: 'rgba(255,255,255,0.58)', fontSize: 9, letterSpacing: 1.5, fontWeight: '800' },
  heroBalance: { color: '#ffffff', fontSize: 31, letterSpacing: -0.8, fontWeight: '800', marginTop: 9 },
  heroCaption: { color: 'rgba(255,255,255,0.62)', fontSize: 12, marginTop: 4 },
  heroBadge: { alignItems: 'center', gap: 4 },
  heroBadgeText: { color: C.accent, fontSize: 10, fontWeight: '700' },
  quickActions: { backgroundColor: C.card, borderRadius: 18, borderWidth: 1, borderColor: C.border, padding: 12, flexDirection: 'row', justifyContent: 'space-between', marginBottom: 24 },
  quickAction: { alignItems: 'center', width: '24%', gap: 7 },
  quickIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  quickLabel: { color: C.foreground, fontSize: 10, fontWeight: '600', textAlign: 'center' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionLink: { color: C.primary, fontSize: 12, fontWeight: '700', marginBottom: 12 },
  homeStats: { backgroundColor: C.card, borderRadius: 18, borderWidth: 1, borderColor: C.border, padding: 16, flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  homeStatLabel: { color: C.mutedForeground, fontSize: 11, marginBottom: 6 },
  homeStatValue: { fontSize: 19, fontWeight: '800' },
  dividerVertical: { width: 1, height: 38, backgroundColor: C.border, marginHorizontal: 20 },
  checkCard: { backgroundColor: C.card, borderRadius: 18, borderWidth: 1, borderColor: C.border, padding: 15, marginBottom: 24 },
  checkTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  checkIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  checkTitle: { color: C.foreground, fontSize: 13, fontWeight: '800' },
  checkBody: { color: C.mutedForeground, fontSize: 11, marginTop: 4 },
  progressTrack: { height: 5, backgroundColor: C.input, borderRadius: 3, marginTop: 14, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: C.primary, borderRadius: 3 },
  homeRow: { backgroundColor: C.card, borderRadius: 16, borderWidth: 1, borderColor: C.border, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 9 },
  homeRowIcon: { width: 35, height: 35, borderRadius: 11, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  homeRowTitle: { color: C.foreground, fontSize: 13, fontWeight: '700' },
  homeRowSub: { color: C.mutedForeground, fontSize: 11, marginTop: 3 },
  cashbookToolbar: { paddingHorizontal: 20, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cashbookYear: { color: C.foreground, fontSize: 14, fontWeight: '800' },
  cashbookSub: { color: C.mutedForeground, fontSize: 11, marginTop: 3 },
  pageStepper: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  stepperButton: { width: 28, height: 28, borderRadius: 9, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  pageNumber: { color: C.primary, fontSize: 12, fontWeight: '800' },
  cashbookScroll: { paddingHorizontal: 12, paddingBottom: 34 },
  paper: { backgroundColor: C.paperGreen, borderRadius: 12, borderWidth: 1, borderColor: C.paperLine, overflow: 'hidden' },
  paperHeader: { paddingVertical: 12, paddingHorizontal: 12, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: C.paperLine },
  paperTitle: { color: C.darkForest, fontWeight: '800', fontSize: 14 },
  paperFY: { color: C.secondaryForeground, fontSize: 10, marginTop: 3 },
  paperColumns: { flexDirection: 'row' },
  paperSide: { flex: 1, borderRightWidth: 1, borderRightColor: C.paperLine },
  sideHeading: { backgroundColor: C.incomeSoft, paddingVertical: 8, paddingHorizontal: 8, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sideTitle: { color: C.income, fontSize: 13, fontWeight: '800' },
  sideEnglish: { color: C.mutedForeground, fontSize: 8, letterSpacing: 0.8, fontWeight: '700' },
  openingLine: { minHeight: 42, paddingHorizontal: 7, borderBottomWidth: 1, borderBottomColor: C.paperLine, backgroundColor: '#fce8e5', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  openingLabel: { color: C.redInk, fontSize: 10, fontWeight: '800' },
  openingAmount: { color: C.redInk, fontSize: 10, fontWeight: '800' },
  ledgerLine: { minHeight: 40, paddingHorizontal: 5, borderBottomWidth: 1, borderBottomColor: C.paperLine, flexDirection: 'row', alignItems: 'center', gap: 4 },
  lineNumber: { width: 18, alignItems: 'center' },
  lineNumberText: { color: C.mutedForeground, fontSize: 8 },
  lineTitle: { color: C.foreground, fontSize: 9, fontWeight: '700' },
  lineSub: { color: C.mutedForeground, fontSize: 8, marginTop: 2 },
  lineAmount: { fontSize: 9, fontWeight: '800', paddingLeft: 2 },
  lineDetail: { paddingTop: 4, paddingBottom: 4 },
  lineDetailText: { color: C.mutedForeground, fontSize: 8 },
  cancelText: { color: C.expense, fontSize: 9, fontWeight: '700', marginTop: 4 },
  emptyLine: { minHeight: 40, paddingHorizontal: 5, borderBottomWidth: 1, borderBottomColor: C.paperLine, flexDirection: 'row', alignItems: 'center' },
  emptyLineFill: { flex: 1, borderBottomWidth: 1, borderBottomColor: 'rgba(201,223,202,0.55)', marginRight: 4 },
  paperLine: { minHeight: 42, paddingHorizontal: 7, borderBottomWidth: 1, borderBottomColor: C.paperLine, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  paperLineLabel: { color: C.secondaryForeground, fontSize: 10, fontWeight: '700' },
  paperLineValue: { color: C.foreground, fontSize: 10, fontWeight: '800' },
  summaryLine: { minHeight: 42, paddingHorizontal: 7, borderBottomWidth: 1, borderBottomColor: C.paperLine, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  summaryStrong: { backgroundColor: C.primarySoft, borderBottomWidth: 0 },
  summaryLabel: { color: C.secondaryForeground, fontSize: 10, fontWeight: '800' },
  summaryValue: { fontSize: 10, fontWeight: '800' },
  summaryStrongText: { color: C.primary },
  formActions: { flexDirection: 'row', gap: 10, marginTop: 14 },
  recentToggle: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 17 },
  recentToggleText: { color: C.primary, fontSize: 12, fontWeight: '800' },
  allTransactions: { backgroundColor: C.card, borderRadius: 17, borderWidth: 1, borderColor: C.border, padding: 12 },
  transactionListRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: C.input },
  transactionBadge: { width: 31, height: 31, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  transactionTitle: { color: C.foreground, fontSize: 12, fontWeight: '700' },
  transactionMeta: { color: C.mutedForeground, fontSize: 10, marginTop: 3 },
  transactionAmount: { fontSize: 11, fontWeight: '800' },
  modalOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(11,32,24,0.48)' },
  entrySheet: { backgroundColor: C.background, borderTopLeftRadius: 26, borderTopRightRadius: 26, maxHeight: '93%', paddingTop: 19 },
  sheetHeader: { paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 15 },
  sheetEyebrow: { color: C.primary, fontSize: 10, letterSpacing: 1.5, fontWeight: '800' },
  sheetTitle: { color: C.foreground, fontSize: 23, fontWeight: '800', marginTop: 4 },
  sheetScroll: { paddingHorizontal: 20, paddingBottom: 30 },
  typeSwitch: { flexDirection: 'row', backgroundColor: C.muted, borderRadius: 13, padding: 4, marginBottom: 17 },
  typeOption: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
  typeSelectedIncome: { backgroundColor: C.incomeSoft },
  typeSelectedExpense: { backgroundColor: C.expenseSoft },
  typeText: { color: C.mutedForeground, fontSize: 12, fontWeight: '800' },
  fieldWrap: { marginBottom: 14 },
  field: { borderWidth: 1, borderColor: C.border, borderRadius: 13, backgroundColor: C.card, color: C.foreground, fontSize: 14, paddingHorizontal: 13, paddingVertical: 12 },
  multiline: { minHeight: 75, textAlignVertical: 'top' },
  amountGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 15 },
  amountCell: { width: '31.5%' },
  amountLabel: { color: C.mutedForeground, fontSize: 10, fontWeight: '700', marginBottom: 5 },
  amountInput: { borderWidth: 1, borderColor: C.border, borderRadius: 11, backgroundColor: C.card, color: C.foreground, fontSize: 13, paddingHorizontal: 9, paddingVertical: 10 },
  formError: { color: C.expense, fontSize: 12, marginTop: -4, marginBottom: 12, lineHeight: 18 },
  settingsIntro: { flexDirection: 'row', gap: 12, backgroundColor: C.primarySoft, borderRadius: 18, padding: 15, marginTop: 7, marginBottom: 24 },
  settingsIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.68)', alignItems: 'center', justifyContent: 'center' },
  settingsTitle: { color: C.primary, fontSize: 14, fontWeight: '800' },
  settingsBody: { color: C.secondaryForeground, fontSize: 11, lineHeight: 17, marginTop: 5 },
  fundSettingRow: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 16, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 9, flexWrap: 'wrap' },
  fundSettingDot: { width: 33, height: 33, borderRadius: 11, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  fundMeta: { color: C.mutedForeground, fontSize: 10, marginTop: 4 },
  editLink: { color: C.primary, fontSize: 11, fontWeight: '800' },
  inlineEdit: { width: '100%', marginTop: 2 },
  inlineInput: { borderWidth: 1, borderColor: C.border, borderRadius: 11, backgroundColor: C.background, padding: 10, color: C.foreground },
  loading: { flex: 1, backgroundColor: C.background, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingText: { color: C.mutedForeground, fontSize: 13 },
});
