import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

export type Fund = {
  id: string;
  name: string;
  shortName: string;
  openingBalance: number;
  enabled: boolean;
};

export type TransactionType = 'income' | 'expense';
export type Transaction = {
  id: string;
  type: TransactionType;
  date: string;
  reference: string;
  party: string;
  detail: string;
  amounts: Record<string, number>;
  note: string;
  status: 'active' | 'cancelled';
  createdAt: string;
};

type CashbookData = {
  panchayat: string;
  financialYear: string;
  funds: Fund[];
  transactions: Transaction[];
  pin: string | null;
  setupComplete: boolean;
};

type CashbookContextValue = CashbookData & {
  hydrated: boolean;
  activeFunds: Fund[];
  totalOpening: number;
  totalIncome: number;
  totalExpense: number;
  currentBalance: number;
  setPin: (pin: string) => Promise<void>;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt' | 'status'>) => Promise<void>;
  cancelTransaction: (id: string) => Promise<void>;
  addFund: (name: string, openingBalance: number) => Promise<void>;
  updateOpeningBalance: (fundId: string, openingBalance: number) => Promise<void>;
};

const STORAGE_KEY = 'gram-panchayat-cashbook-v1';

const seedFunds: Fund[] = [
  { id: 'cash', name: 'Cash', shortName: 'Cash', openingBalance: 0, enabled: true },
  { id: 'sfc', name: 'SFC', shortName: 'SFC', openingBalance: 0, enabled: true },
  { id: 'ffc', name: 'FFC', shortName: 'FFC', openingBalance: 0, enabled: true },
  { id: 'own', name: 'Own Fund / Interest', shortName: 'Own Fund', openingBalance: 0, enabled: true },
  { id: 'mp', name: 'MP / MLA / TAD', shortName: 'MP / MLA', openingBalance: 0, enabled: true },
];

const defaultData: CashbookData = {
  panchayat: 'ग्राम पंचायत माल',
  financialYear: '2026–27',
  funds: seedFunds,
  transactions: [],
  pin: null,
  setupComplete: false,
};

const CashbookContext = createContext<CashbookContextValue | null>(null);

function amountOf(transactions: Transaction[], type: TransactionType, funds: Fund[]) {
  return transactions
    .filter((item) => item.status === 'active' && item.type === type)
    .reduce((sum, item) => sum + funds.reduce((fundSum, fund) => fundSum + (item.amounts[fund.id] ?? 0), 0), 0);
}

export function formatINR(value: number, paise = false) {
  const rounded = paise ? value.toFixed(2) : Math.round(value).toString();
  const [whole, decimal] = rounded.split('.');
  const formatted = Number(whole).toLocaleString('en-IN');
  return paise && decimal ? '₹' + formatted + '.' + decimal : '₹' + formatted;
}

export function CashbookProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<CashbookData>(defaultData);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (raw) setData({ ...defaultData, ...JSON.parse(raw) });
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (hydrated) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch(() => undefined);
  }, [data, hydrated]);

  const value = useMemo<CashbookContextValue>(() => {
    const activeFunds = data.funds.filter((fund) => fund.enabled);
    const totalOpening = activeFunds.reduce((sum, fund) => sum + fund.openingBalance, 0);
    const totalIncome = amountOf(data.transactions, 'income', activeFunds);
    const totalExpense = amountOf(data.transactions, 'expense', activeFunds);
    return {
      ...data,
      hydrated,
      activeFunds,
      totalOpening,
      totalIncome,
      totalExpense,
      currentBalance: totalOpening + totalIncome - totalExpense,
      setPin: async (pin) => setData((previous) => ({ ...previous, pin, setupComplete: true })),
      addTransaction: async (transaction) => {
        setData((previous) => ({
          ...previous,
          transactions: [...previous.transactions, { ...transaction, id: Date.now().toString() + Math.random().toString(36).slice(2, 8), createdAt: new Date().toISOString(), status: 'active' }],
        }));
      },
      cancelTransaction: async (id) => {
        setData((previous) => ({ ...previous, transactions: previous.transactions.map((item) => item.id === id ? { ...item, status: 'cancelled' } : item) }));
      },
      addFund: async (name, openingBalance) => {
        const normalized = name.trim();
        if (!normalized) return;
        setData((previous) => ({
          ...previous,
          funds: [...previous.funds, { id: Date.now().toString(), name: normalized, shortName: normalized.slice(0, 12), openingBalance, enabled: true }],
        }));
      },
      updateOpeningBalance: async (fundId, openingBalance) => {
        setData((previous) => ({ ...previous, funds: previous.funds.map((fund) => fund.id === fundId ? { ...fund, openingBalance } : fund) }));
      },
    };
  }, [data, hydrated]);

  return <CashbookContext.Provider value={value}>{children}</CashbookContext.Provider>;
}

export function useCashbook() {
  const context = useContext(CashbookContext);
  if (!context) throw new Error('useCashbook must be used inside CashbookProvider');
  return context;
}
