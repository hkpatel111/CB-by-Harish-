package com.gpcashbook.app

import com.gpcashbook.app.engine.CashbookEngine
import com.gpcashbook.app.engine.CashbookEngine.FundAmount
import com.gpcashbook.app.engine.CashbookEngine.Line
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CashbookEngineTest {

    private val cashFund = 1L
    private val sfcFund = 2L
    private val funds = listOf(cashFund, sfcFund)

    @Test
    fun `page line limits are 26 income and 27 expense`() {
        assertEquals(26, CashbookEngine.MAX_INCOME_TRANSACTION_LINES)
        assertEquals(27, CashbookEngine.MAX_EXPENSE_TRANSACTION_LINES)
        assertTrue(CashbookEngine.canAddLine(CashbookEngine.Side.INCOME, 25))
        assertFalse(CashbookEngine.canAddLine(CashbookEngine.Side.INCOME, 26))
        assertTrue(CashbookEngine.canAddLine(CashbookEngine.Side.EXPENSE, 26))
        assertFalse(CashbookEngine.canAddLine(CashbookEngine.Side.EXPENSE, 27))
    }

    @Test
    fun `page 1 demo numbers from PROJECT_MASTER Section 1_3 reconcile`() {
        // Demo PDF figures: आय योग 1,64,050; व्यय योग 66,000; श्री पोते 45,500;
        // बचत पोते 1,43,550; दोनों महायोग 2,09,550
        val opening = mapOf(cashFund to 45_500_00L)
        val income = listOf(Line(1, listOf(FundAmount(cashFund, 164_050_00L))))
        val expense = listOf(Line(2, listOf(FundAmount(cashFund, 66_000_00L))))

        val totals = CashbookEngine.computePageTotals(listOf(cashFund), opening, income, expense)

        assertEquals(164_050_00L, totals.aayYogPerFund[cashFund])
        assertEquals(66_000_00L, totals.vyayYogPerFund[cashFund])
        assertEquals(209_550_00L, totals.mahayogIncomePerFund[cashFund])
        assertEquals(143_550_00L, totals.bachatPotePerFund[cashFund])
        assertEquals(209_550_00L, totals.mahayogExpensePerFund[cashFund])
        assertTrue(totals.isBalanced())
    }

    @Test
    fun `carry-forward - page 2 opening equals page 1 closing`() {
        val opening = mapOf(cashFund to 0L)
        val income = listOf(Line(1, listOf(FundAmount(cashFund, 100_00L))))
        val expense = emptyList<Line>()

        val page1 = CashbookEngine.computePageTotals(listOf(cashFund), opening, income, expense)
        val page2Opening = CashbookEngine.nextPageOpeningShriPote(page1)

        assertEquals(page1.bachatPotePerFund, page2Opening)
    }

    @Test
    fun `both mahayog always equal even with multiple funds`() {
        val opening = mapOf(cashFund to 1_000_00L, sfcFund to 500_00L)
        val income = listOf(
            Line(1, listOf(FundAmount(cashFund, 200_00L))),
            Line(2, listOf(FundAmount(sfcFund, 300_00L)))
        )
        val expense = listOf(
            Line(3, listOf(FundAmount(cashFund, 150_00L)))
        )

        val totals = CashbookEngine.computePageTotals(funds, opening, income, expense)
        assertTrue(totals.isBalanced())
    }

    @Test
    fun `display rounding rounds to nearest rupee without touching stored paise`() {
        assertEquals(100L, CashbookEngine.displayRupees(99_60L))
        assertEquals(99L, CashbookEngine.displayRupees(99_40L))
        assertEquals("143550.00", CashbookEngine.paiseToRupeesDecimalString(143_550_00L))
    }
}
