package com.gpcashbook.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gpcashbook.app.data.AppDatabase
import com.gpcashbook.app.repository.CashbookRepository
import com.gpcashbook.app.ui.CashbookApp
import com.gpcashbook.app.viewmodel.CashbookViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = AppDatabase.getInstance(applicationContext)
        val repository = CashbookRepository(db)
        val factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return CashbookViewModel(repository) as T
            }
        }

        setContent {
            val viewModel: CashbookViewModel = viewModel(factory = factory)
            CashbookApp(viewModel)
        }
    }
}
