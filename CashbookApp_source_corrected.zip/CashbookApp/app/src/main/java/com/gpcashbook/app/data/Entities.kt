package com.gpcashbook.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Core Room entities for the MVP slice.
 * Scope: App-flow (S-01..S-06) + Cashbook core (S-07..S-10) per PROJECT_MASTER.md
 * Section 25 (Recommended implementation order) and Section 18.7 (Round 4 build status).
 *
 * Money fields are stored as Long paise (integer) to avoid floating point rounding
 * problems — see PROJECT_MASTER.md Section 12.7 (Rounding rules): cashbook keeps
 * full 2-decimal precision; only *display* rounds to nearest rupee elsewhere.
 */

enum class Role { ADMIN, OPERATOR, CHECKER, APPROVER, VIEWER }

enum class TransactionType { INCOME, EXPENSE }

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val pinHash: String,
    val role: Role
)

@Entity(tableName = "financial_years")
data class FinancialYearEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,           // e.g. "2026-27"
    val startDateEpochDay: Long, // 1 April
    val endDateEpochDay: Long,   // 31 March
    val isLocked: Boolean = false
)

/**
 * Dynamic fund column — see PROJECT_MASTER.md Section 8. Never hard-coded.
 * openingBalancePaise is the FY-level default opening used for page 1 when no
 * previous year exists (Section 2.1).
 */
@Entity(tableName = "fund_columns")
data class FundColumnEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,          // stable code, e.g. "CASH", "SFC", "FFC", "OWN", "MPMLA"
    val labelHindi: String,
    val labelEnglish: String,
    val displayOrder: Int,
    val isEnabled: Boolean = true,
    val openingBalancePaise: Long = 0
)

/**
 * One printed cashbook page for a given Financial Year.
 * Income side max 26 transaction lines, Expense side max 27 transaction lines
 * (PROJECT_MASTER.md Section 2.2, Round 4 final line-structure).
 *
 * Per-fund श्री पोते (opening) is stored in [PageOpeningEntity], not as a single total.
 */
@Entity(
    tableName = "pages",
    indices = [Index(value = ["financialYearId", "pageNumber"], unique = true)]
)
data class PageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val financialYearId: Long,
    val pageNumber: Int
)

/**
 * Per-fund opening balance (श्री पोते) for a page.
 * Page 1: from FundColumn.openingBalancePaise (or previous FY closing).
 * Page N+1: previous page's बचत पोते (Section 4.1 carry-forward).
 */
@Entity(
    tableName = "page_openings",
    primaryKeys = ["pageId", "fundColumnId"],
    foreignKeys = [
        ForeignKey(
            entity = PageEntity::class,
            parentColumns = ["id"],
            childColumns = ["pageId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("pageId"), Index("fundColumnId")]
)
data class PageOpeningEntity(
    val pageId: Long,
    val fundColumnId: Long,
    val amountPaise: Long
)

@Entity(
    tableName = "transactions",
    indices = [
        Index("pageId"),
        Index("financialYearId"),
        Index(value = ["pageId", "type"])
    ]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val financialYearId: Long,
    val pageId: Long,
    val type: TransactionType,
    val transactionDateEpochDay: Long,
    val entryCreatedAtEpochMillis: Long,
    val lastUpdatedAtEpochMillis: Long,
    val docNumber: String? = null,     // invoice/voucher number
    val partyOrSource: String,         // "किससे प्राप्त किया" / "किसको भुगतान किया"
    val details: String? = null,
    val ledgerFolio: String? = null,
    val note: String? = null,
    val isCancelled: Boolean = false,
    val cancelReason: String? = null,
    val createdByUserId: Long
)

/**
 * Amount of a transaction against one dynamic fund column.
 * A transaction can span multiple fund columns (rare) but usually one.
 */
@Entity(
    tableName = "transaction_amounts",
    indices = [Index("transactionId"), Index("fundColumnId")]
)
data class TransactionAmountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: Long,
    val fundColumnId: Long,
    val amountPaise: Long
)

@Entity(tableName = "audit_log")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entityName: String,
    val entityId: Long,
    val action: String,       // ADD / EDIT / CANCEL / ARCHIVE / LOCK ...
    val fieldChanged: String? = null,
    val oldValue: String? = null,
    val newValue: String? = null,
    val reason: String? = null,
    val userId: Long,
    val atEpochMillis: Long
)
