package com.gpcashbook.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Default "हरा" theme — PROJECT_MASTER.md Section 15.1 / 16.1 (6 themes planned; green is default/MVP).
val GreenPrimary = Color(0xFF2E7D32)
val GreenPageTint = Color(0xFFE9F4E9) // Section 2.3 — हल्का हरा page background
val ShriPoteRed = Color(0xFFC62828)   // Section 2.1 — श्री पोते red text

private val LightColors = lightColorScheme(
    primary = GreenPrimary,
    secondary = GreenPrimary,
    background = Color.White,
    surface = GreenPageTint
)

private val DarkColors = darkColorScheme(
    primary = GreenPrimary,
    secondary = GreenPrimary
)

@Composable
fun CashbookTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
