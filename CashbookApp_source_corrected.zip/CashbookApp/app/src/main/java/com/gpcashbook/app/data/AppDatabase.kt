package com.gpcashbook.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class Converters {
    @TypeConverter
    fun fromRole(role: Role): String = role.name

    @TypeConverter
    fun toRole(value: String): Role = Role.valueOf(value)

    @TypeConverter
    fun fromTxType(type: TransactionType): String = type.name

    @TypeConverter
    fun toTxType(value: String): TransactionType = TransactionType.valueOf(value)
}

@Database(
    entities = [
        UserEntity::class,
        FinancialYearEntity::class,
        FundColumnEntity::class,
        PageEntity::class,
        PageOpeningEntity::class,
        TransactionEntity::class,
        TransactionAmountEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun financialYearDao(): FinancialYearDao
    abstract fun fundColumnDao(): FundColumnDao
    abstract fun pageDao(): PageDao
    abstract fun pageOpeningDao(): PageOpeningDao
    abstract fun transactionDao(): TransactionDao
    abstract fun transactionAmountDao(): TransactionAmountDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        /**
         * NOTE: per PROJECT_MASTER.md Section 3, the real DB file must live under the
         * user-chosen `Documents/Cashbook` SAF location (not app-private storage) so it
         * survives uninstall/backup. This MVP still uses default app-private storage —
         * wiring SAF-backed storage is a follow-up task (Section 4 of the doc).
         */
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cashbook.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
