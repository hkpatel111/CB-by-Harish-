package com.gpcashbook.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gpcashbook.app.engine.CashbookEngine
import com.gpcashbook.app.viewmodel.CashbookViewModel
import java.time.LocalDate

private object Routes {
    const val LOGIN = "S01_login"                 // S-01
    const val PANCHAYAT = "S02_panchayat"          // S-02
    const val FY_PAGE = "S05_fy_page"              // S-05 (S-03/S-04 first-launch stubs skipped in this MVP)
    const val FY_HOME = "S06_fy_home"              // S-06
    const val CASHBOOK = "S07_cashbook"            // S-07
    const val ADD_INCOME = "S08_add_income"        // S-08
    const val ADD_EXPENSE = "S09_add_expense"      // S-09
}

@Composable
fun CashbookApp(viewModel: CashbookViewModel) {
    val navController = rememberNavController()
    CashbookTheme {
        NavHost(navController = navController, startDestination = Routes.LOGIN) {
            composable(Routes.LOGIN) { LoginScreen(navController) }
            composable(Routes.PANCHAYAT) { PanchayatSelectionScreen(navController) }
            composable(Routes.FY_PAGE) { FinancialYearScreen(navController, viewModel) }
            composable(Routes.FY_HOME) { FyHomeScreen(navController) }
            composable(Routes.CASHBOOK) { CashbookPageScreen(navController, viewModel) }
            composable(Routes.ADD_INCOME) { AddIncomeScreen(navController, viewModel) }
            composable(Routes.ADD_EXPENSE) { AddExpenseScreen(navController, viewModel) }
        }
    }
}

/** S-01 — Login Screen. PIN/role check is stubbed for the MVP; UI flow only. */
@Composable
fun LoginScreen(nav: NavController) {
    var name by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    ScreenScaffold(title = "Login — S-01") {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("User name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("PIN") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = { nav.navigate(Routes.PANCHAYAT) }, modifier = Modifier.fillMaxWidth()) { Text("Login") }
    }
}

/** S-02 — Panchayat Selection. Multi-Panchayat mode is deferred (Section 13 item 18), single GP stub here. */
@Composable
fun PanchayatSelectionScreen(nav: NavController) {
    ScreenScaffold(title = "Panchayat Selection — S-02") {
        Text("Good Morning! 🙏", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        Text("ग्राम पंचायत माल (पं.समि. साबला, जिला डूंगरपुर)")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { nav.navigate(Routes.FY_PAGE) }, modifier = Modifier.fillMaxWidth()) { Text("प्रवेश करें") }
    }
}

/** S-05 — Financial Year Page: starts a FY if none exists yet, then shows status. */
@Composable
fun FinancialYearScreen(nav: NavController, vm: CashbookViewModel) {
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit) {
        if (state.financialYearId == null) {
            vm.startFinancialYear("2026-27", LocalDate.of(2026, 4, 1), LocalDate.of(2027, 3, 31))
        }
    }
    ScreenScaffold(title = "Financial Year — S-05") {
        Text("वित्तीय वर्ष: 2026-27")
        Spacer(Modifier.height(8.dp))
        Text("वर्तमान शेष सहित पूरी status यहाँ दिखेगी (fund-wise) — MVP में सरल placeholder.")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { nav.navigate(Routes.FY_HOME) }, modifier = Modifier.fillMaxWidth()) { Text("Proceed →") }
    }
}

/** S-06 — FY Home: entry point to all modules. Only Cashbook is wired in this MVP. */
@Composable
fun FyHomeScreen(nav: NavController) {
    ScreenScaffold(title = "FY Home — S-06") {
        val items = listOf(
            "Cashbook" to Routes.CASHBOOK,
            "Bank Statement (आगे जोड़ा जाएगा)" to null,
            "Ongoing कार्य (आगे जोड़ा जाएगा)" to null,
            "गोशवारा till date (आगे जोड़ा जाएगा)" to null,
            "Material Ledger (आगे जोड़ा जाएगा)" to null,
            "Schemes (आगे जोड़ा जाएगा)" to null,
            "Reports (आगे जोड़ा जाएगा)" to null
        )
        items.forEach { (label, route) ->
            Button(
                onClick = { route?.let { nav.navigate(it) } },
                enabled = route != null,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) { Text(label) }
        }
    }
}

/** S-07 — Cashbook Page View: 30-line page, 26 income + 27 expense (Section 2.2, Round 4 final). */
@Composable
fun CashbookPageScreen(nav: NavController, vm: CashbookViewModel) {
    val state by vm.state.collectAsState()
    ScreenScaffold(title = "Cashbook — S-07 (पृष्ठ ${state.currentPage?.pageNumber ?: 1})", tint = GreenPageTint) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Button(onClick = { nav.navigate(Routes.ADD_INCOME) }) { Text("+ आय") }
            Button(onClick = { nav.navigate(Routes.ADD_EXPENSE) }) { Text("+ व्यय") }
        }
        Spacer(Modifier.height(12.dp))
        Text("श्री पोते (opening)", color = ShriPoteRed, fontWeight = FontWeight.Bold)

        val totals = state.totals
        if (totals == null) {
            Text("अभी कोई entry नहीं — + आय / + व्यय से शुरू करें।")
        } else {
            state.activeFunds.forEach { fund ->
                val row = "${fund.labelHindi}: " +
                    "श्री पोते ₹${CashbookEngine.paiseToRupeesDecimalString(totals.shriPoteOpeningPerFund[fund.id] ?: 0)} · " +
                    "आय योग ₹${CashbookEngine.paiseToRupeesDecimalString(totals.aayYogPerFund[fund.id] ?: 0)} · " +
                    "व्यय योग ₹${CashbookEngine.paiseToRupeesDecimalString(totals.vyayYogPerFund[fund.id] ?: 0)} · " +
                    "बचत पोते ₹${CashbookEngine.paiseToRupeesDecimalString(totals.bachatPotePerFund[fund.id] ?: 0)} · " +
                    "महायोग ₹${CashbookEngine.paiseToRupeesDecimalString(totals.mahayogIncomePerFund[fund.id] ?: 0)}"
                Text(row, modifier = Modifier.padding(vertical = 4.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(if (totals.isBalanced()) "✔ दोनों महायोग बराबर" else "⚠ महायोग मेल नहीं खाता — जाँचें")
        }
    }
}

/** S-08 — Add Income form (MVP: single fund column per entry). */
@Composable
fun AddIncomeScreen(nav: NavController, vm: CashbookViewModel) {
    val state by vm.state.collectAsState()
    var source by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var selectedFundId by remember { mutableStateOf(state.activeFunds.firstOrNull()?.id) }

    ScreenScaffold(title = "Add Income — S-08") {
        OutlinedTextField(value = source, onValueChange = { source = it }, label = { Text("किससे प्राप्त किया") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = details, onValueChange = { details = it }, label = { Text("Details / note") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        FundColumnPicker(state.activeFunds, selectedFundId) { selectedFundId = it }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("राशि (₹)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                selectedFundId?.let { vm.addIncome(source, details.ifBlank { null }, it, amount) }
                nav.popBackStack()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save") }
    }
}

/** S-09 — Add Expense form (MVP: single fund column per entry). */
@Composable
fun AddExpenseScreen(nav: NavController, vm: CashbookViewModel) {
    val state by vm.state.collectAsState()
    var party by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var selectedFundId by remember { mutableStateOf(state.activeFunds.firstOrNull()?.id) }

    ScreenScaffold(title = "Add Expense — S-09") {
        OutlinedTextField(value = party, onValueChange = { party = it }, label = { Text("किसको भुगतान किया") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = details, onValueChange = { details = it }, label = { Text("Work / Other detail") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        FundColumnPicker(state.activeFunds, selectedFundId) { selectedFundId = it }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("राशि (₹)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                selectedFundId?.let { vm.addExpense(party, details.ifBlank { null }, it, amount) }
                nav.popBackStack()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save") }
    }
}

@Composable
private fun FundColumnPicker(
    funds: List<com.gpcashbook.app.data.FundColumnEntity>,
    selectedId: Long?,
    onSelect: (Long) -> Unit
) {
    Column {
        Text("Fund column", style = MaterialTheme.typography.labelMedium)
        LazyColumn(modifier = Modifier.heightIn(max = 160.dp)) {
            items(funds) { fund ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                    RadioButton(selected = fund.id == selectedId, onClick = { onSelect(fund.id) })
                    Text(fund.labelHindi)
                }
            }
        }
    }
}

@Composable
private fun ScreenScaffold(
    title: String,
    tint: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = tint) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(16.dp))
            content()
        }
    }
}
