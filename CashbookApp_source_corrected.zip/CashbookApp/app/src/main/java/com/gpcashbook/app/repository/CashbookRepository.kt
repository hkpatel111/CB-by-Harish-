package com.gpcashbook.app.repository

import com.gpcashbook.app.data.*
import com.gpcashbook.app.engine.CashbookEngine
import com.gpcashbook.app.engine.CashbookEngine.FundAmount
import com.gpcashbook.app.engine.CashbookEngine.Line
import kotlinx.coroutines.flow.first
import java.time.LocalDate

class CashbookRepository(private val db: AppDatabase) {

    /** Default fund columns per PROJECT_MASTER.md Section 8 (editable later from S-35). */
    suspend fun seedDefaultFundColumnsIfEmpty() {
        if (db.fundColumnDao().getActive().isNotEmpty()) return
        val defaults = listOf(
            FundColumnEntity(code = "CASH", labelHindi = "नकद", labelEnglish = "Cash", displayOrder = 1),
            FundColumnEntity(code = "SFC", labelHindi = "SFC", labelEnglish = "SFC", displayOrder = 2),
            FundColumnEntity(code = "FFC", labelHindi = "FFC", labelEnglish = "FFC", displayOrder = 3),
            FundColumnEntity(code = "OWN", labelHindi = "स्वयं निधि/ब्याज", labelEnglish = "Own Fund/Interest", displayOrder = 4),
            FundColumnEntity(code = "MPMLA", labelHindi = "MP/MLA/TAD", labelEnglish = "MP/MLA/TAD", displayOrder = 5)
        )
        db.fundColumnDao().insertAll(defaults)
    }

    /** Seed default operator user (S-01 default: Harish Patidar — Operator) if none exist. */
    suspend fun seedDefaultUserIfEmpty() {
        if (db.userDao().count() > 0) return
        db.userDao().insert(
            UserEntity(
                name = "Harish Patidar",
                pinHash = "0000", // MVP stub — real hashing later
                role = Role.OPERATOR
            )
        )
    }

    suspend fun activeFundColumns(): List<FundColumnEntity> = db.fundColumnDao().getActive()

    suspend fun createFinancialYear(label: String, start: LocalDate, end: LocalDate): Long =
        db.financialYearDao().insert(
            FinancialYearEntity(
                label = label,
                startDateEpochDay = start.toEpochDay(),
                endDateEpochDay = end.toEpochDay()
            )
        )

    /**
     * Returns the page a new transaction of [side] should land on for [fyId],
     * creating a fresh page if the current last page is full for that side.
     * Section 4 (page auto-creation) + Section 2.2 (26/27 line limits).
     *
     * Carry-forward: next page's per-fund श्री पोते = previous page's बचत पोते
     * (PROJECT_MASTER.md Section 4.1). Page 1 openings come from FundColumn.openingBalancePaise
     * (Section 2.1).
     */
    private suspend fun pageForNewLine(fyId: Long, side: CashbookEngine.Side): PageEntity {
        val last = db.pageDao().getLastPage(fyId)
        if (last == null) {
            // First page: श्री पोते = fund-column opening balances (admin-set or previous FY)
            val funds = activeFundColumns()
            val openings = funds.associate { it.id to it.openingBalancePaise }
            return createNewPage(fyId, pageNumber = 1, openingsPerFund = openings)
        }
        val txType = if (side == CashbookEngine.Side.INCOME) TransactionType.INCOME else TransactionType.EXPENSE
        val count = db.transactionDao().countLinesForPage(last.id, txType)
        if (CashbookEngine.canAddLine(side, count)) return last

        // Full — compute previous page totals correctly (with its real openings) then carry forward
        val previousTotals = getPageTotals(last)
        val nextOpenings = CashbookEngine.nextPageOpeningShriPote(previousTotals)
        return createNewPage(fyId, pageNumber = last.pageNumber + 1, openingsPerFund = nextOpenings)
    }

    private suspend fun createNewPage(
        fyId: Long,
        pageNumber: Int,
        openingsPerFund: Map<Long, Long>
    ): PageEntity {
        val entity = PageEntity(financialYearId = fyId, pageNumber = pageNumber)
        val id = db.pageDao().insert(entity)
        val page = entity.copy(id = id)
        val openingRows = openingsPerFund.map { (fundId, amount) ->
            PageOpeningEntity(pageId = id, fundColumnId = fundId, amountPaise = amount)
        }
        if (openingRows.isNotEmpty()) {
            db.pageOpeningDao().insertAll(openingRows)
        }
        return page
    }

    private suspend fun loadLines(pageId: Long, type: TransactionType): List<Line> {
        val txs = db.transactionDao().getLinesForPage(pageId, type)
        if (txs.isEmpty()) return emptyList()
        val amounts = db.transactionAmountDao().getForTransactions(txs.map { it.id })
        val byTx = amounts.groupBy { it.transactionId }
        return txs.map { tx ->
            Line(tx.id, (byTx[tx.id] ?: emptyList()).map { FundAmount(it.fundColumnId, it.amountPaise) })
        }
    }

    private suspend fun loadOpenings(pageId: Long): Map<Long, Long> {
        return db.pageOpeningDao().getForPage(pageId).associate { it.fundColumnId to it.amountPaise }
    }

    /**
     * Add a transaction line (income or expense). Auto-assigns the page per the
     * 26/27 line rule, stores per-fund amounts, and logs to the audit trail.
     */
    suspend fun addTransaction(
        fyId: Long,
        type: TransactionType,
        transactionDate: LocalDate,
        partyOrSource: String,
        details: String?,
        amounts: List<FundAmount>,
        userId: Long
    ): Long {
        val side = if (type == TransactionType.INCOME) CashbookEngine.Side.INCOME else CashbookEngine.Side.EXPENSE
        val page = pageForNewLine(fyId, side)
        val now = System.currentTimeMillis()

        val tx = TransactionEntity(
            financialYearId = fyId,
            pageId = page.id,
            type = type,
            transactionDateEpochDay = transactionDate.toEpochDay(),
            entryCreatedAtEpochMillis = now,
            lastUpdatedAtEpochMillis = now,
            partyOrSource = partyOrSource,
            details = details,
            createdByUserId = userId
        )
        val txId = db.transactionDao().insert(tx)
        db.transactionAmountDao().insertAll(
            amounts.map { TransactionAmountEntity(transactionId = txId, fundColumnId = it.fundColumnId, amountPaise = it.amountPaise) }
        )
        db.auditLogDao().insert(
            AuditLogEntity(
                entityName = "transaction",
                entityId = txId,
                action = "ADD",
                userId = userId,
                atEpochMillis = now
            )
        )
        return txId
    }

    /** Load a page's full computed totals for display (S-07 Cashbook Page View). */
    suspend fun getPageTotals(page: PageEntity): CashbookEngine.PageTotals {
        val activeFunds = activeFundColumns().map { it.id }
        val incomeLines = loadLines(page.id, TransactionType.INCOME)
        val expenseLines = loadLines(page.id, TransactionType.EXPENSE)
        val opening = loadOpenings(page.id)
        return CashbookEngine.computePageTotals(activeFunds, opening, incomeLines, expenseLines)
    }

    suspend fun getLastPage(fyId: Long): PageEntity? = db.pageDao().getLastPage(fyId)
}
