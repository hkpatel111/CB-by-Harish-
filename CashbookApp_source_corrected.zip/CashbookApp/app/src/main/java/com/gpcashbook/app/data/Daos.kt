package com.gpcashbook.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FinancialYearDao {
    @Insert
    suspend fun insert(fy: FinancialYearEntity): Long

    @Query("SELECT * FROM financial_years ORDER BY startDateEpochDay DESC")
    fun observeAll(): Flow<List<FinancialYearEntity>>

    @Query("SELECT * FROM financial_years WHERE id = :id")
    suspend fun getById(id: Long): FinancialYearEntity?
}

@Dao
interface FundColumnDao {
    @Insert
    suspend fun insertAll(columns: List<FundColumnEntity>)

    @Query("SELECT * FROM fund_columns WHERE isEnabled = 1 ORDER BY displayOrder ASC")
    fun observeActive(): Flow<List<FundColumnEntity>>

    @Query("SELECT * FROM fund_columns WHERE isEnabled = 1 ORDER BY displayOrder ASC")
    suspend fun getActive(): List<FundColumnEntity>
}

@Dao
interface PageDao {
    @Insert
    suspend fun insert(page: PageEntity): Long

    @Query("SELECT * FROM pages WHERE financialYearId = :fyId ORDER BY pageNumber DESC LIMIT 1")
    suspend fun getLastPage(fyId: Long): PageEntity?

    @Query("SELECT * FROM pages WHERE financialYearId = :fyId ORDER BY pageNumber ASC")
    fun observePages(fyId: Long): Flow<List<PageEntity>>

    @Query("SELECT * FROM pages WHERE id = :pageId")
    suspend fun getById(pageId: Long): PageEntity?
}

@Dao
interface PageOpeningDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(openings: List<PageOpeningEntity>)

    @Query("SELECT * FROM page_openings WHERE pageId = :pageId")
    suspend fun getForPage(pageId: Long): List<PageOpeningEntity>
}

@Dao
interface TransactionDao {
    @Insert
    suspend fun insert(tx: TransactionEntity): Long

    @Update
    suspend fun update(tx: TransactionEntity)

    @Query("SELECT * FROM transactions WHERE pageId = :pageId AND type = :type AND isCancelled = 0 ORDER BY transactionDateEpochDay ASC, id ASC")
    suspend fun getLinesForPage(pageId: Long, type: TransactionType): List<TransactionEntity>

    @Query("SELECT COUNT(*) FROM transactions WHERE pageId = :pageId AND type = :type AND isCancelled = 0")
    suspend fun countLinesForPage(pageId: Long, type: TransactionType): Int

    @Query("SELECT * FROM transactions WHERE pageId = :pageId ORDER BY transactionDateEpochDay ASC, id ASC")
    fun observePage(pageId: Long): Flow<List<TransactionEntity>>
}

@Dao
interface TransactionAmountDao {
    @Insert
    suspend fun insertAll(amounts: List<TransactionAmountEntity>)

    @Query("SELECT * FROM transaction_amounts WHERE transactionId = :txId")
    suspend fun getForTransaction(txId: Long): List<TransactionAmountEntity>

    @Query("SELECT * FROM transaction_amounts WHERE transactionId IN (:txIds)")
    suspend fun getForTransactions(txIds: List<Long>): List<TransactionAmountEntity>
}

@Dao
interface AuditLogDao {
    @Insert
    suspend fun insert(log: AuditLogEntity)
}

@Dao
interface UserDao {
    @Insert
    suspend fun insert(user: UserEntity): Long

    @Query("SELECT * FROM users WHERE name = :name LIMIT 1")
    suspend fun findByName(name: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users")
    suspend fun count(): Int
}
