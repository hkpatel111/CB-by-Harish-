package com.gpcashbook.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gpcashbook.app.data.FundColumnEntity
import com.gpcashbook.app.data.PageEntity
import com.gpcashbook.app.data.TransactionType
import com.gpcashbook.app.engine.CashbookEngine
import com.gpcashbook.app.engine.CashbookEngine.FundAmount
import com.gpcashbook.app.repository.CashbookRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

data class CashbookUiState(
    val financialYearId: Long? = null,
    val currentPage: PageEntity? = null,
    val activeFunds: List<FundColumnEntity> = emptyList(),
    val totals: CashbookEngine.PageTotals? = null,
    val isLoading: Boolean = true
)

class CashbookViewModel(private val repository: CashbookRepository) : ViewModel() {

    private val _state = MutableStateFlow(CashbookUiState())
    val state: StateFlow<CashbookUiState> = _state.asStateFlow()

    fun startFinancialYear(label: String, start: LocalDate, end: LocalDate) {
        viewModelScope.launch {
            repository.seedDefaultFundColumnsIfEmpty()
            repository.seedDefaultUserIfEmpty()
            val fyId = repository.createFinancialYear(label, start, end)
            _state.value = _state.value.copy(financialYearId = fyId, isLoading = false)
            refreshCurrentPage(fyId)
        }
    }

    private suspend fun refreshCurrentPage(fyId: Long) {
        val page = repository.getLastPage(fyId)
        val funds = repository.activeFundColumns()
        val totals = page?.let { repository.getPageTotals(it) }
        _state.value = _state.value.copy(currentPage = page, activeFunds = funds, totals = totals)
    }

    fun addIncome(partyOrSource: String, details: String?, fundColumnId: Long, amountRupees: String, userId: Long = 1L) {
        addTransaction(TransactionType.INCOME, partyOrSource, details, fundColumnId, amountRupees, userId)
    }

    fun addExpense(partyOrSource: String, details: String?, fundColumnId: Long, amountRupees: String, userId: Long = 1L) {
        addTransaction(TransactionType.EXPENSE, partyOrSource, details, fundColumnId, amountRupees, userId)
    }

    private fun addTransaction(
        type: TransactionType,
        partyOrSource: String,
        details: String?,
        fundColumnId: Long,
        amountRupees: String,
        userId: Long
    ) {
        val fyId = _state.value.financialYearId ?: return
        val amountPaise = rupeesStringToPaise(amountRupees)
        if (amountPaise <= 0L || partyOrSource.isBlank()) return

        viewModelScope.launch {
            repository.addTransaction(
                fyId = fyId,
                type = type,
                transactionDate = LocalDate.now(),
                partyOrSource = partyOrSource,
                details = details,
                amounts = listOf(FundAmount(fundColumnId, amountPaise)),
                userId = userId
            )
            refreshCurrentPage(fyId)
        }
    }

    private fun rupeesStringToPaise(input: String): Long {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return 0L
        val parts = trimmed.split(".")
        val rupees = parts.getOrNull(0)?.toLongOrNull() ?: return 0L
        val paise = parts.getOrNull(1)?.padEnd(2, '0')?.take(2)?.toLongOrNull() ?: 0L
        return rupees * 100 + paise
    }
}
