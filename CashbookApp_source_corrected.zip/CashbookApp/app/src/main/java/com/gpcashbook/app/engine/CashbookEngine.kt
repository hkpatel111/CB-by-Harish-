package com.gpcashbook.app.engine

/**
 * Pure, Room/Android-free calculation engine for the 30-line cashbook page.
 * Implements PROJECT_MASTER.md:
 *  - Section 2.2 (Round 4 FINAL line structure — 26 income / 27 expense lines)
 *  - Section 9 (formula rules, adapted for the 26/27 split)
 *  - Section 4.1 (carry-forward rule)
 *
 * All money in Long **paise** (2-decimal precision kept everywhere, per Section 12.7).
 * Nothing here talks to Room/Compose — keep it unit-testable.
 */
object CashbookEngine {

    const val MAX_INCOME_TRANSACTION_LINES = 26
    const val MAX_EXPENSE_TRANSACTION_LINES = 27

    enum class Side { INCOME, EXPENSE }

    /** True if one more transaction line of this [side] still fits on the page. */
    fun canAddLine(side: Side, currentLineCountOnPage: Int): Boolean = when (side) {
        Side.INCOME -> currentLineCountOnPage < MAX_INCOME_TRANSACTION_LINES
        Side.EXPENSE -> currentLineCountOnPage < MAX_EXPENSE_TRANSACTION_LINES
    }

    /** A single fund-column amount attached to a transaction line. */
    data class FundAmount(val fundColumnId: Long, val amountPaise: Long)

    data class Line(val transactionId: Long, val amounts: List<FundAmount>)

    /** Result of totalling one page, per active fund column id. */
    data class PageTotals(
        val shriPoteOpeningPerFund: Map<Long, Long>,   // line 1 (income side)
        val aayYogPerFund: Map<Long, Long>,            // income योग (26 lines)
        val vyayYogPerFund: Map<Long, Long>,           // व्यय योग (27 lines)
        val mahayogIncomePerFund: Map<Long, Long>,     // आय योग + श्री पोते
        val bachatPotePerFund: Map<Long, Long>,        // महायोग(आय) - व्यय योग -> next page opening
        val mahayogExpensePerFund: Map<Long, Long>     // व्यय योग + बचत पोते  (must equal mahayogIncome)
    ) {
        /** Section: दोनों महायोग हमेशा बराबर — validation locked. */
        fun isBalanced(): Boolean =
            mahayogIncomePerFund.keys.all { fund ->
                (mahayogIncomePerFund[fund] ?: 0L) == (mahayogExpensePerFund[fund] ?: 0L)
            }
    }

    private fun sumPerFund(lines: List<Line>): Map<Long, Long> {
        val result = mutableMapOf<Long, Long>()
        for (line in lines) {
            for (amt in line.amounts) {
                result[amt.fundColumnId] = (result[amt.fundColumnId] ?: 0L) + amt.amountPaise
            }
        }
        return result
    }

    /**
     * Compute a full page's totals.
     *
     * @param activeFundColumnIds all currently-enabled fund columns, so every result map
     *   has an entry even for funds with zero activity this page.
     * @param openingShriPote श्री पोते coming in from previous page (or FY opening balance
     *   on page 1) — per fund.
     * @param incomeLines up to [MAX_INCOME_TRANSACTION_LINES] transaction lines.
     * @param expenseLines up to [MAX_EXPENSE_TRANSACTION_LINES] transaction lines.
     */
    fun computePageTotals(
        activeFundColumnIds: List<Long>,
        openingShriPote: Map<Long, Long>,
        incomeLines: List<Line>,
        expenseLines: List<Line>
    ): PageTotals {
        require(incomeLines.size <= MAX_INCOME_TRANSACTION_LINES) {
            "Income side max $MAX_INCOME_TRANSACTION_LINES lines (Section 2.2)"
        }
        require(expenseLines.size <= MAX_EXPENSE_TRANSACTION_LINES) {
            "Expense side max $MAX_EXPENSE_TRANSACTION_LINES lines (Section 2.2)"
        }

        val zeroBase = activeFundColumnIds.associateWith { 0L }
        val shriPote = zeroBase + openingShriPote.filterKeys { it in activeFundColumnIds }
        val aayYog = zeroBase + sumPerFund(incomeLines)
        val vyayYog = zeroBase + sumPerFund(expenseLines)

        val mahayogIncome = activeFundColumnIds.associateWith { fund ->
            (aayYog[fund] ?: 0L) + (shriPote[fund] ?: 0L)
        }
        val bachatPote = activeFundColumnIds.associateWith { fund ->
            (mahayogIncome[fund] ?: 0L) - (vyayYog[fund] ?: 0L)
        }
        val mahayogExpense = activeFundColumnIds.associateWith { fund ->
            (vyayYog[fund] ?: 0L) + (bachatPote[fund] ?: 0L)
        }

        return PageTotals(
            shriPoteOpeningPerFund = shriPote,
            aayYogPerFund = aayYog,
            vyayYogPerFund = vyayYog,
            mahayogIncomePerFund = mahayogIncome,
            bachatPotePerFund = bachatPote,
            mahayogExpensePerFund = mahayogExpense
        )
    }

    /**
     * Section 4.1 carry-forward rule:
     * "अगली active transaction date की श्री पोते = पिछली active date/page की बचत पोते"
     * The बचत पोते of this page becomes the opening श्री पोते of the next page.
     */
    fun nextPageOpeningShriPote(previousPageTotals: PageTotals): Map<Long, Long> =
        previousPageTotals.bachatPotePerFund

    /** Round a paise value to nearest rupee for *display only* (Section 12.7). Storage stays in paise. */
    fun displayRupees(amountPaise: Long): Long {
        val rupees = amountPaise / 100
        val remainderPaise = amountPaise % 100
        return if (remainderPaise >= 50) rupees + 1 else rupees
    }

    fun paiseToRupeesDecimalString(amountPaise: Long): String {
        val negative = amountPaise < 0
        val abs = kotlin.math.abs(amountPaise)
        val rupees = abs / 100
        val paise = abs % 100
        val sign = if (negative) "-" else ""
        return "$sign$rupees.${paise.toString().padStart(2, '0')}"
    }
}
