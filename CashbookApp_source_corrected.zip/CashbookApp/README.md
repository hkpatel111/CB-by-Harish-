# GP Cashbook — Android Source (MVP slice)

यह source `PROJECT_MASTER.md` (Round 4, 19-09-2026 तक की सारी decisions) पर आधारित है।
पूरे 47 screens में से **इस MVP में सिर्फ़ App-flow + Cashbook का core हिस्सा actually काम करता है** —
document के अपने Section 25 (Recommended implementation order) और "Discussion order" के मुताबिक़
सबसे पहले यही बनना था.

## इस MVP में क्या काम करता है

- **S-01 Login** — UI मौजूद है, PIN/role check अभी stub है (real validation आगे जुड़ेगा). Default user seed: Harish Patidar — Operator.
- **S-02 Panchayat Selection** — UI stub (multi-Panchayat अभी deferred है, Section 13 item 18). Sample GP: ग्राम पंचायत माल.
- **S-05 Financial Year Page** — एक FY (2026-27) auto-start करता है.
- **S-06 FY Home** — सिर्फ़ "Cashbook" button काम करता है; बाक़ी options placeholder हैं.
- **S-07 Cashbook Page View** — असली काम की चीज़: दोनों तरफ़ की running totals live दिखती हैं,
  fund-column-wise (श्री पोते, आय योग, व्यय योग, बचत पोते, महायोग) — `CashbookEngine.kt` से.
  हल्का हरा page tint (Section 2.3) + श्री पोते red (Section 2.1).
- **S-08 Add Income / S-09 Add Expense** — काम करने वाले forms; entry save होते ही page की
  totals और (ज़रूरत पड़ने पर) अगला page अपने-आप बन जाते हैं.
- **Core engine (`engine/CashbookEngine.kt`)** — pure Kotlin, कोई Android dependency नहीं,
  पूरी तरह unit-tested (`src/test/.../CashbookEngineTest.kt`):
  - Line structure: income side **26** transaction lines, expense side **27** — दोनों तरफ़ 30-30
    (PROJECT_MASTER.md Section 2.2, Round 4 final).
  - Formulas: आय योग, व्यय योग, महायोग(आय)=आय योग+श्री पोते, बचत पोते=महायोग(आय)−व्यय योग,
    महायोग(व्यय)=व्यय योग+बचत पोते — और दोनों महायोग हमेशा बराबर होने का validation.
  - Carry-forward: एक page की बचत पोते अगले page की श्री पोते बनती है (Section 4.1) — **per-fund**.
  - Rounding: सारी राशि Long **paise** में store होती है (कोई floating-point rounding नहीं);
    `displayRupees()` सिर्फ़ *display* के लिए nearest रुपया round करता है (Section 12.7).
- **Room database** — core entities (FinancialYear, FundColumn, Page, **PageOpening** (per-fund श्री पोते),
  Transaction, TransactionAmount, User, AuditLog) — offline-first (Section 3).

## Corrections applied vs original ZIP (cross-check against PROJECT_MASTER.md)

1. **Per-fund श्री पोते / carry-forward (critical)**  
   Original ZIP stored only a single total `openingShriPotePaise` on `PageEntity` and passed empty/zero
   opening maps into `computePageTotals`. That broke multi-fund books and made page-2+ openings wrong.
   **Fixed:** new `PageOpeningEntity` (pageId + fundColumnId + amountPaise). Page 1 openings come from
   `FundColumn.openingBalancePaise` (Section 2.1). Page N+1 openings = previous page’s `bachatPotePerFund`
   via `CashbookEngine.nextPageOpeningShriPote` (Section 4.1). Repository now loads real openings.

2. **Default user seed** — Section 16.1 default “Harish Patidar — Operator” is seeded on first FY start
   so `createdByUserId` is valid.

3. **Manifest** — removed `@mipmap/ic_launcher` reference (resource was missing → build failure).

4. **Cleanup** — removed erroneous empty directory `{data,engine,repository,ui,viewmodel}`.

5. **exportSchema** set to false for MVP (no schema export folder required).

## जान-बूझकर अभी scope से बाहर (आगे इसी क्रम में जुड़ेगा)

document के Section 25 वाले order में:
1. S-03/S-04 (Storage permission + restore flow) और असली `Documents/Cashbook` SAF storage —
   अभी DB app-private storage में है, यह अगला ज़रूरी step है (Section 3/4).
2. Backdated entry + correction/cancel (S-10), locked period.
3. Works/MB/Man-days/Bills/Completion Certificate (S-17–S-26).
4. Bank Statement Reader + AI Estimate Reader (S-13–S-16, cloud modules).
5. गोशवारा, Ledgers, Reports Hub (S-27–S-34).
6. Masters/Settings, FY Closing wizard, Phone-transfer wizard, App Settings (S-35–S-47).
7. Devanagari-safe PDF export (Noto Sans Devanagari, HTML→PDF या Android-native rendering —
   ReportLab जैसी libraries से बचें, Section 1.2).
8. Multi-fund-column amount entry UI (engine already supports multiple amounts per line; forms still single-fund for MVP simplicity).
9. Authentication (PIN hashing/verify), Role permissions enforcement, Audit-trail viewer UI.

## Build कैसे करें

1. Android Studio (Koala या नया) में यह folder खोलें — पहली बार खुलने पर Gradle खुद wrapper jar
   download कर लेगा (इस environment में network नहीं था, इसलिए `gradle-wrapper.jar` शामिल नहीं है —
   सिर्फ़ `gradle-wrapper.properties` है; Android Studio अपने-आप ठीक कर देगा, या manually चलाएँ:
   `gradle wrapper --gradle-version 8.7`).
2. Sync Gradle → Run पर app किसी भी emulator/device (minSdk 26) पर चलेगी.
3. Unit tests: `./gradlew testDebugUnitTest` — `CashbookEngineTest` में line-limits, demo-PDF के
   numbers (Section 1.3 के 1,64,050 / 66,000 / 45,500 / 1,43,550 / 2,09,550) और carry-forward
   सब verify होते हैं.

## Devanagari font

अभी तक कोई `.ttf` bundle नहीं किया गया (binary asset, network चाहिए था). Production से पहले
`Noto Sans Devanagari` (UI) + Condensed variant (print grid) डालें
`app/src/main/res/font/` में — Section 1.1/1.2 का rule ज़रूर मानें: सिर्फ़ font embed करना
काफ़ी नहीं, PDF pipeline shaping-capable होना चाहिए (HTML→Chromium/WeasyPrint या Android-native
rendering — ReportLab नहीं).

## Signing keystore

Section 4.1 के मुताबिक़ keystore सबसे क़ीमती चीज़ है — इस project में कोई keystore शामिल नहीं;
पहली release बनाते वक़्त एक बनाएँ और अलग से सुरक्षित backup रखें.
