# Cashbook Project — Master Document (एकमात्र .md file)

**Document purpose:** पूरे project की **एक ही** authoritative requirements + design file। Original baseline, पूरी discussion/chat, Round decisions और FINAL locks — सब यहीं। अलग overlapping `.md` files नहीं बनेंगी; updates सिर्फ़ इसी file में।

**App UI:** हर screen के corner पर screen number (`S-01` … `S-n`) — discussion/correction number से। **App Settings हमेशा अंतिम screen number**।

**Status:** Requirements FINAL for Phase 1 implementation (20-09-2026 decisions locked).

**Last updated:** 24-09-2026 — PART V: old master (Round 0–5) merged; demo formats locked (गोशवारा/प्रपत्र-1/प्रपत्र-4/Bank/CC/Ledger); manual page add; CC mandays×wage engine

---

# PART 0 — FINAL DECISIONS LOG (20-09-2026)

ये locks पुराने टकरावों को resolve करते हैं। Implementation इन्हीं पर चले।

| # | Topic | FINAL |
|---|--------|--------|
| D1 | Default lines per page side | **25** (Cashbook Settings से बदल सकते हैं) |
| D2 | Line map | **PDF sample lock**: dual grid प्राप्ति\|भुगतान; top **श्री पोते राशि**; bottom **आय योग / पूर्व पोते / महायोग** \| **व्यय योग / बचत पोते / महायोग**; expense has no opening row (see Part C) |
| D3 | Transaction lines (default) | **21** = `totalLines - 4` |
| D4 | Amounts on a line | **Multi-column** (Cash, SFC, FFC, Own, MP/MLA/TAD, …) **and** scheme select **required** on save (default **SFC**) |
| D5 | Columns | Default **11** (incl. Total); fund/scheme add-edit-delete से columns बढ़/घट सकते हैं |
| D6 | Roles (now) | **Admin only** |
| D7 | Settings hierarchy | **Round 5** (Login → Panchayat+App Settings → FY+FY Settings → FY Home) |
| D8 | Balance guards | Same-day total expense ≤ income-side महायोग; per-scheme minus = FY toggle (default OFF) |
| D9 | New page | **Auto** when txn lines full **+ manual** Add Page |
| D10 | Empty days | Skip by default; **optional insert empty-day page** between two dates |
| D11 | Bank module | **Phase 1** |
| D12 | Works / MB / Bills / CC / BSR | **Phase 1** (full stack) |
| D13 | Storage | **SAF `Documents/Cashbook/...` mandatory Phase 1** |
| D14 | PDF/Excel share background | **Plain white** |
| D15 | Fixed signing keystore | **Later** (not in this doc yet) |
| D16 | Login biometric | **Phase 1**; optional after PIN; toggle/change in **App Settings** |
| D17 | FY isolation | **Only closing balances** carry to next FY opening — **not entries** |
| D18 | Category taxonomy | **Category → Subcategory → Sub-subcategory** CRUD in Cashbook Settings; archive if in use |
| D19 | Ledgers/reports | **Auto from first entry**; every entry updates all views — no separate “generate” step |
| D20 | Monthly check | **All transactions** of period; edit/complete scheme & category path in-place |

---

# PART A — Product vision

Hindi-first Android digital cashbook:

```text
Digital Cashbook
+ Side-by-side Income | Expense pages
+ Configurable N-line pages (default 25)
+ Dynamic fund/scheme columns
+ Scheme-required multi-column amounts
+ Category / sub / sub-sub taxonomy
+ Work / MB / Bills / CC (Phase 1)
+ Bank statement → tag → auto entry (Phase 1)
+ Auto ledgers & reports
+ Annual & till-date गोशवारा
+ PDF + Excel export/share (compulsory)
+ Grid + form data entry
+ Backdated correction + audit trail
+ SAF Documents/Cashbook storage
+ Backup / restore / phone transfer
+ Period lock + FY closing
+ Admin-only (multi-role later)
```

---

# PART B — Financial year

- FY window: **1 April → 31 March** (example: FY 2026–27 = 01-04-2026 … 31-03-2027).
- Each FY has **isolated** transactions, pages, statements, attachments under that FY id.
- **Carry-forward only balances:** previous FY **closing** (fund-wise नकद + bank / scheme) → new FY **opening श्री पोते**. **Previous FY transaction rows must never appear in current FY lists/pages.**
- New scheme in new year: opening may be manual; Page 1 श्री पोते shows indicator **Carry-forward** vs **Manual**.
- 31 March: annual गोशवारा; year-close checklist; backup; then lock → archive read-only.
- Unauthorized edit of locked FY blocked; corrections via correction/adjustment entries + audit.

---

# PART C — Cashbook page engine

> **Visual source of truth (21-09-2026):** User-provided Excel cashbook PDF  
> `DOC-20260622-WA0002` — कार्यालय ग्राम पंचायत **काबजा**, पं.समिति **साबला**, जिला **डूंगरपुर**, FY **2026-27**.  
> App screen **and** PDF/Excel export must match this grid — not a vertical transaction list.

## C.1 Page frame (header)

Every page (screen + print):

| Element | Content |
|---------|---------|
| Left/centre title | `कार्यालय ग्राम पंचायत` + **Panchayat name** |
| Block | `पंचायत समिति` + block name |
| District | `जिला` + district |
| FY | `वित्तीय वर्ष` + label (e.g. 2026-27) |
| Page no. | `पृष्ठ संख्या` — automatic, top-right |

- Orientation for print/PDF: **landscape** preferred (matches Excel sheet).
- Background: light register tint on screen; **plain white** on share/PDF (D14).

## C.2 Horizontal split (mandatory)

```text
+---------------------------+---------------------------+
|     प्राप्ति (Income)      |     भुगतान (Expense)      |
|     left half             |     right half            |
+---------------------------+---------------------------+
```

- **Exactly two equal halves** side-by-side (not stacked list).
- Thick vertical rule between halves.
- Full grid lines (Excel-like cells).

## C.3 Column structure (from real PDF)

### C.3.1 Left — प्राप्ति (Receipt / Income)

| # | Column | Notes |
|---|--------|--------|
| 1 | **दिनांक** | Transaction / श्री पोते date |
| 2 | **चेक, DD, इन्वॉइस नंबर व दिनांक** | Instrument / invoice ref |
| 3 | **किस से प्राप्त किया** | Payee/source name; also holds label **श्री पोते राशि** / summary labels |
| 4 | **विवरण** | Detail / narration |
| 5 | **L.F.** | Ledger folio |
| 6+ | **रकम** group → | |
| 6a | **नकद** | Cash amount |
| 6b–6g | **बैंक** sub-columns | **SFC**, **FFC**, **OWN FUND/INT**, **MP/MLA/TAD**, **Other/Security/DD**, **Total** |

Default bank fund heads match sample PDF; user may add/rename/archive via Fund settings (still dynamic).

### C.3.2 Right — भुगतान (Payment / Expense)

| # | Column | Notes |
|---|--------|--------|
| 1 | **दिनांक** | |
| 2 | **वाउचर नंबर व दिनांक** | |
| 3 | **भुगतान किसको किया गया** (चेक न. / मस्टर रोल न. भी लिखें) | Party / vendor |
| 4 | **किस कार्य पेटे भुगतान किया गया** | Work / purpose |
| 5 | **L.F.** | |
| 6 | **परिसंपत्ति रजिस्टर पृष्ठ संख्या** | Asset register page ref (sample PDF) |
| 7+ | **रकम** group → | |
| 7a | **नकद** | |
| 7b–7g | **बैंक** sub-columns | Same fund set as left: SFC, FFC, OWN FUND/INT, MP/MLA/TAD, Other/Security/DD, **Total** |

## C.4 Row / line map (aligned to sample pages)

Sample pages show:

1. **Opening row** on **प्राप्ति** side: date + label **`श्री पोते राशि`** + fund-wise amounts (नकद + each bank head + Total).  
   - **भुगतान** side on the same visual row: **blank** (no opening text on expense side).
2. **Middle rows:** empty grid lines and/or real transactions (income on left cells, expense on right cells). Many blank lines are normal (hand-register style).
3. **Last 3 rows** (shaded in sample) — **both sides, always present, never manually edited:**

| | प्राप्ति (Left) | भुगतान (Right) |
|--|-----------------|----------------|
| L−2 | **आय योग** — sum of income txn amounts in each amount column | **व्यय योग** — sum of expense txn amounts |
| L−1 | **पूर्व पोते** — same opening / brought-forward as श्री पोते राशि (sample wording) | **बचत पोते** — left महायोग − व्यय योग (per column) |
| L | **महायोग** = आय योग + पूर्व पोते | **महायोग** = व्यय योग + बचत पोते |

> **Wording lock from PDF:** bottom-left second line is **`पूर्व पोते`**, not a second label “श्री पोते”. Top opening label remains **`श्री पोते राशि`**.

### C.4.1 Default line capacity

- Default **~25 body rows** including opening + txns + 3 footer rows (settings may change total `L`).
- `transaction_lines ≈ L − 4` (1 opening/shri zone + 3 footer), same spirit as D1–D3.
- New page: auto when transaction zone full **or** manual Add Page (D9).
- Empty calendar days skipped; optional insert empty-day page (D10).

## C.5 Formulas (per amount column `f`)

```text
Line Total[f]  = amount in that column on the line
आय योग[f]     = sum of income transaction lines (exclude श्री पोते / footer)
पूर्व पोते[f]  = श्री पोते राशि[f] (page opening / carry)
महायोग_L[f]   = आय योग[f] + पूर्व पोते[f]

व्यय योग[f]   = sum of expense transaction lines
बचत पोते[f]   = महायोग_L[f] − व्यय योग[f]
महायोग_R[f]   = व्यय योग[f] + बचत पोते[f]
```

Both महायोग totals must match (sample pages show equal महायोग left/right).

**No manual edit** on: श्री पोते राशि, आय योग, पूर्व पोते, व्यय योग, बचत पोते, महायोग.

## C.6 Carry-forward

```text
Next page / next active date श्री पोते राशि[f] = previous page बचत पोते[f]
```

FY change: **only** closing balances → new FY openings; **not** prior FY transaction rows (D17).

## C.7 UI requirements (mobile)

- Must present **side-by-side प्राप्ति | भुगतान grid**, not a single vertical “Income txns / Expense txns” list.
- Horizontal + vertical scroll allowed so all columns remain usable on phone.
- Tap empty txn cell / “+ Entry” → form (scheme required, multi-column amounts).
- Long-press txn → edit/cancel.
- Screen badge S-07; page number in header like PDF `पृष्ठ संख्या`.

## C.8 Export

- PDF page export must reproduce this grid (white background, embedded Hindi font).
- Excel export: one sheet “Cashbook Print” with same column headers as C.3.

## C.9 Decision log updates (supersede older wording where conflicted)

| Earlier wording | PDF-locked wording |
|-----------------|-------------------|
| Bottom income line “श्री पोते” | **पूर्व पोते** |
| Simple 11 flat columns | **नकद + बैंक (SFC/FFC/OWN/MP/Other) + Total** each side |
| List UI acceptable | **Rejected** — dual-page grid only |
| Expense top “blank parallel” | Confirmed: no श्री पोते on भुगतान side |


# PART D — Income & expense entry details

## D.1 Income

**Fields:** transaction date, invoice no/date, किससे प्राप्त, details, ledger folio, multi-fund amounts, total auto, scheme (required), category path, note, attachment.

**Source list (editable):** Govt, व्यक्ति, Bank, संस्था, Firm/Vendor, अन्य.

**Detail / income taxonomy:** managed as Category tree (Part E) — includes SFC, FFC, MP/MLA/TAD, पट्टा शुल्क, विवाह/जन्म/मृत्यु प्रमाण शुल्क, Other, plus user-defined.

## D.2 Expense

**Fields:** transaction date, voucher no/date, party/vendor, Work **or** Other, work name or other category path, ledger, multi-fund amounts, total auto, scheme required, note, attachment, payment mode Cash/Bank when needed for reconciliation.

**Party master:** select / add / search; vendor-wise reports.

**Work:** name required; master select or add; optional code, location/ward, sanction reference.

**Other:** category tree (Stationery, Printing, भत्ता, बिजली, सफाई, ईंधन, यात्रा, मरम्मत, डाक, बैठक, मोबाइल/इंटरनेट, अन्य, …).

## D.3 Repeat entry

Copy previous entry as template (monthly बिजली/सफाई etc.).

## D.4 Cancel entry

Reason required; print strikethrough (red); excluded from totals; remains in audit.

---

# PART E — Category / subcategory / sub-subcategory

## E.1 Model

Three levels maximum:

```text
Category
 └── Subcategory
      └── Sub-subcategory
```

Separate trees (or namespaced) for **Income** and **Expense** (and Work classification as needed).

## E.2 Management

- **Cashbook Settings** (and/or Masters): add / edit / correction / delete.
- If any transaction references a node → **archive** (not hard-delete); archived nodes remain on old rows for history.
- Every transaction should allow assigning the deepest applicable path; incomplete path flaggable in Monthly Check.

## E.3 Use

- गोशवारा grouping/filter  
- Ledgers by category path  
- Reports sort/filter  
- Identify all txns sharing same path  

---

# PART F — Auto ledgers & reports

- From **first saved transaction** of an FY, ledger and report views are available for that FY (may show single row).
- **No separate “generate report” prerequisite.**
- On every add / edit / cancel / category change → aggregates refresh.
- Empty state only when filtered set is truly empty — message explains why and next steps (e.g. “Is FY selected?”, “No expense in this category yet”).

### Compulsory on every report/page share

```text
Export Excel | Export PDF | Share Excel | Share PDF | Print
```

### Report catalogue (minimum)

1. Page-wise cashbook  
2. Date-wise  
3. Daily / weekly / monthly / custom range  
4. Full FY  
5. Income  
6. Expense  
7. Work-wise expenditure  
8. Other-category (tree) expenditure  
9. Vendor/firm-wise  
10. Fund/scheme-wise  
11. Ledger-folio-wise  
12. Category / sub / sub-sub wise  
13. Monthly dashboard  
14. गोशवारा till-date & annual  
15. Backdated entries  
16. Edited / corrected  
17. Cancelled  
18. Audit trail  
19. Validation / incomplete (missing scheme or category path)  
20. Reconciliation  
21. Attachments  
22. Pending verification  
23. Search results  

**Contextual reports:** from Cashbook, Bank, Work, Bill, गोशवारा, etc., with drill-down back to source transaction.

Excel = editable workbook (multiple sheets, filters, freeze, Hindi headings, formulas where useful).  
PDF = configured line layout, landscape options, **embedded Devanagari font**, white background for share, optional watermark/signatures.

---

# PART G — Bank statement (Phase 1)

- Bank account master  
- Upload PDF (password unlock)  
- AI/OCR → editable grid (user corrects before post)  
- Tag: scheme, work/category, or ignore  
- Grouping rules (multi-line one instrument), **D−1** date rule as adopted in discussion, instrument number  
- Post → cashbook entries (not free-text only — structured)  
- Month locked for re-upload when entries exist **and** verified  
- **No bank→cash withdrawal entry type** (GP practice)  
- Optional entry type: **Cash → Bank deposit** (reduces cash, increases bank; not income/expense)  
- Files under SAF FY folder  

---

# PART H — Works, MB, Bills, CC (Phase 1)

Full stack from discussion (not name-only):

- Ongoing works list; scheme-wise grouping/filter  
- Add old work with prior material/labour spent + optional bill-wise history  
- Work payments list → bills → material lines  
- **MB:** मद-वार material + कारीगर + labour; total valuation  
- **Man-days / master roll:** named workers and **group** rows (e.g. 5 labour × 12 days)  
- **Bill register** date-wise; bill date + cashbook payment date + page ref  
- **CC — 7 pages:** (1) Completion certificate with AS/TS/FS, MB refs, valuations, allowable = min rules (2) UC (3) Labour by pakhwada (4) Material as per MB (5) Technical verification (6) Completion photo + signatures (7) Before & during photos  
- **Live status residual:** after MB, residual from **CC allowable − payments** (material/labour separate); before MB from FS  
- Special case toggle when MB labour &gt; FS labour (documented warning)  
- Masters: BSR (year-wise rates), Workers/roles, Items (whole/decimal flags), Holidays (pakhwada)  
- Rate band: operator chooses within BSR −10%…−20% style guidance (not single fixed %)

---

# PART I — गोशवारा

- **Till date** from FY Home  
- **Annual 31 March** classified income (left) / expense (right)  
- Bottom lines: आय योग, प्रारंभिक बैंक/नकद; व्यय योग, अंतिम बैंक/नकद; महायोग equality check  
- Tap head → ledger of that head for the year  
- Optional monthly reminder (e.g. 5th) to share PDF  

---

# PART J — Dashboard & Monthly check

## J.1 FY Home dashboard

Financial year, opening, income, expense, current balance, pages, pending verification, missing attachments, unbalanced/incomplete flags. Quick actions: Add Income/Expense, Cashbook, Reports, Backup, Bank, Works.

## J.2 Monthly check

- Lists **all transactions** in the selected month/period (not only warnings).  
- Incomplete: missing **scheme** and/or **category / sub / sub-sub** → highlight + filter.  
- Tap row → edit / correct / cancel / fill classification.  
- Also surface: unverified pages, untagged bank lines, missing bill attachments, pending statements.

---

# PART K — App flow, settings, security

## K.1 Flow

```text
S-01 Login (Admin PIN + optional biometric)
  → S-02 Panchayat selection  +  [App Settings]
       → S-05 Financial Year (status + chooser)  +  [FY / Cashbook Settings]
            → S-06 FY Home
                 → Cashbook | Bank | Works | गोशवारा | Ledgers/Reports | Monthly check | Backup | …
```

## K.2 App Settings (canonical last screen number)

- Theme (multi-colour), logo, UI language (English/Hinglish), screen-number badge on/off  
- **Security:** change PIN; enable/disable biometric; re-enrol biometric  
- Panchayat add / edit / correction / delete — **destructive & edit require PIN re-confirm**  
- Global backup defaults  

## K.3 FY / Cashbook Settings (from S-05)

- FY add / edit / delete (confirm policy)  
- Scheme/fund CRUD for **this FY**; opening balance editor **visible**; red delete = **this FY only**  
- Line count L; blank gap 1|2; allow scheme negative ON/OFF  
- Appearance colours  
- Link to **Category tree** editors (income & expense)  
- Optional: insert-empty-day tools help text  

## K.4 Auth

- **Admin only** for Phase 1  
- PIN required to establish account; **biometric optional** thereafter  
- PIN or biometric unlock; Settings can toggle/change either  
- Future roles (Operator, Checker, Approver, Viewer) reserved in model, not exposed now  

## K.5 Navigation UX

- Hardware Back and in-app back → **parent** in stack; do not exit to Android Home until root confirm  
- No silent dead clicks — empty states with **why + steps**  
- Screen badges S-01…S-n; **renumber freely when screens added**; App Settings always **last**

---

# PART L — Storage, backup, audit (Phase 1)

## L.1 SAF layout (mandatory)

```text
Documents/Cashbook/
  <PanchayatName_or_Id>/
    <FY_Label>/
      database /
      exports /
      bank_statements /
      attachments /
      backups /
```

App uses Storage Access Framework; user-visible folder structure preferred.

## L.2 Backup / restore

- Auto-save after transactions  
- Manual backup; versioned list; restore  
- Backup before FY lock and before destructive schema/column changes  
- **Phone transfer wizard:** backup zip + **4-digit restore code** guided flow  
- Optional cloud later; not required to block Phase 1 if local SAF works  

## L.3 Audit trail

Log: user, time, entity id, action, field, old/new, reason. Prefer Cancelled/Archived over hard delete.

## L.4 Attachments

Receipt/bill/voucher/sanction/MB photo/PDF linked to txn; included in backup policy.

---

# PART M — Validation (non-exhaustive)

- Invalid dates; non-numeric amounts; negative amount prevention where policy says  
- Scheme required; category incompleteness warning (Monthly Check)  
- At least one fund amount &gt; 0  
- Work name if Work; other path if Other  
- Duplicate invoice/voucher warning  
- Expense vs day महायोग; optional scheme minus  
- Mahayog mismatch / unbalanced page warnings  
- Backdated impact confirmation  

**Money:** cashbook stores **paise-precision (2 decimal)**; other displays may round to rupee per earlier rounding policy.

---

# PART N — Suggested data entities

FinancialYear, Panchayat, Page, PageOpening (per fund), Transaction, TransactionAmount, FundColumn/Scheme, CategoryNode (level, parent, kind income|expense), IncomeSource, Work, Vendor, Attachment, BankAccount, BankStatement, BankLine, MeasurementBook, ManDayEntry, Bill, BillLine, CompletionCertificate, AuditLog, PeriodLock, User (admin), BackupRecord, AppSettings, FySettings, ExportHistory.

---

# PART O — Screen index (baseline; renumber when expanded)

> Numbers will be **rewritten** when screens are added. App Settings remains **last**.

| # | Screen | Notes |
|---|--------|--------|
| S-01 | Login | PIN + biometric |
| S-02 | Panchayat selection | + entry to App Settings |
| S-05 | Financial Year page | + FY/Cashbook Settings |
| S-06 | FY Home | Dashboard + module tiles |
| S-07 | Cashbook page view | N-line Option A |
| S-08 | Add/Edit Income | Multi-column + scheme + category |
| S-09 | Add/Edit Expense | Work/Other + scheme + category |
| S-10 | Entry detail / cancel / correct | |
| S-11+ | Page list / range share | PDF/Excel white |
| S-13–S-16 | Bank accounts / upload / tag / post | Phase 1 |
| S-17–S-26 | Works / MB / Man-days / Bills / CC | Phase 1 |
| S-27 | गोशवारा | Till-date + annual |
| S-28–S-34 | Ledgers & Reports Hub | Auto-updated |
| S-35 | Fund / column settings | |
| S-36–S-41 | BSR, Workers, Vendors, Items, Holidays, Users | |
| S-42 | Backup & restore | SAF |
| S-43 | Global search | |
| S-44 | Export centre | |
| S-45 | FY Closing wizard | |
| S-46 | New phone transfer | |
| S-xx | Category tree manager | Income & expense |
| S-xx | Monthly check (full txn list) | |
| S-**Last** | **App Settings** | PIN/biometric, theme, panchayat CRUD |

*(Exact numeric assignment to be frozen in implementation sprint 1 after UI list freeze.)*

---

# PART P — Phase 1 build order (recommended)

1. Admin PIN + biometric + App Settings security toggles  
2. SAF folder bootstrap + FY-scoped DB  
3. Panchayat / FY settings hierarchy  
4. Fund columns + **page engine Option A (L=25)** + openings  
5. Income/expense save with multi-column amounts + **scheme required** + category path  
6. **Strict FY filter** (regression: old year entries never leak)  
7. Carry-forward balances only; indicators CF/Manual  
8. Auto ledgers/reports refresh pipeline  
9. Monthly check full list + incomplete classification  
10. PDF/Excel page export (white)  
11. Backup/restore SAF  
12. Bank statement pipeline  
13. Works → MB → Bills → CC  
14. गोशवारा + FY closing wizard  
15. Empty-day insert option; +2 pages; polish navigation/empty states  

---

# PART Q — Acceptance criteria (Phase 1 gate)

- [ ] Default 25-line page; 21 txn lines; Option A blank expense line 1  
- [ ] Multi-column amounts + scheme mandatory (default SFC)  
- [ ] Summary lines not user-editable; formulas correct; left/right महायोग coherent  
- [ ] Switching FY never shows previous FY transaction rows; only openings carried  
- [ ] Category 3-level CRUD; archive if in use; filter in गोशवारा/ledgers  
- [ ] First entry makes ledgers/reports meaningful; each entry updates them  
- [ ] Monthly check lists all period txns; can set scheme/category there  
- [ ] Biometric optional; PIN/biometric change in App Settings  
- [ ] SAF Documents/Cashbook tree used for DB exports/statements/backups  
- [ ] Bank upload→tag→post path works for at least one statement PDF fixture  
- [ ] One work can go MB → bill → CC allowable residual path  
- [ ] Excel + PDF export on cashbook page and one summary report  
- [ ] Back navigation stays inside app stack  
- [ ] Day expense ≤ day mahayog enforced; scheme-minus respects FY flag  
- [ ] Auto + manual new page; empty day skip; optional empty-day insert  

---

# PART R — Deferred (explicitly not blocking Phase 1 doc)

- Multi-role Operator/Checker/Approver/Viewer UI  
- Fixed Play-style signing keystore documentation  
- TDS/GST  
- Multi-device realtime sync  
- Demo/sample training mode (rejected earlier)  

---

# PART S — Contradiction resolution (reference)

| Conflict | Resolution |
|----------|------------|
| 25 vs 30 lines | Default **25**; setting changes L; txn = L−4 |
| श्री पोते top vs only bottom | Top **श्री पोते राशि**; bottom-left **पूर्व पोते** (PDF wording); expense no opening row |
| Single scheme vs multi-column | **Both**: columns hold amounts; scheme required on entry |
| Admin vs multi-role | Admin only now |
| Entries vs balances on new FY | **Balances only** |
| Report “generate” step | **None** — auto from data |
| Bank/Works scope | **In Phase 1** |

---

**End of master document.**  
Implementation and GitHub issues should quote Part/section ids (e.g. `C.2`, `D17`, `Q`).

---

# PART V — Old master merge ("PROJECT_MASTER old.md" → Round 0–5 record, merged 24-09-2026)

User ne पुराना combined master (Part A: original progress record, Part B: design decisions Sections 1–19, Part C: 47-screen index, Sections 16–19: prototype rounds) folder me rakha. Uska **novel content** neeche merge ho gaya; jo cheezein pehle se PROJECT_MASTER (Part C cashbook engine + PART U) me locked thin, unhe **[ALREADY-COVERED]** mark kiya. Jo cheezein **conflict** karti hain unke aage **[CONFLICT → C1…C12]** — decisions PART W me hain.

## V.1 Merge map (old doc → this doc)

| Old section | Status | Kahan |
|---|---|---|
| A §2 FY rules, §9 formulas, §10.2 edit reasons, §17 validations | **[ALREADY-COVERED]** | Part B/M/L/Q |
| A §3/§11 30-line, श्री पोते 2x | **[CONFLICT C1]** | PART W |
| A §4 empty-day skip, §10 backdated recalc | **[ALREADY-COVERED]** | D9/D10, M |
| A §5.1 source list, §5.2 income detail taxonomy | **[ALREADY-COVERED]** | Part D.1 |
| A §6 party/work master, §7 notes/attachments | **[ALREADY-COVERED]** | Part D.2, L.4 (attachments Phase 1 UI pending — backlog) |
| A §8 fund column master + auto-propagation | **[ALREADY-COVERED]** | D5, Part K.3 |
| A §12/§14 22 reports + 12-sheet Excel workbook | **[ALREADY-COVERED]** | Part F (superset) |
| A §15.1 + B §1 Devanagari PDF font rules (Noto, no Mangal, shaping-capable pipeline, OFL.txt) | **MERGED — novel** | V.2 (#1) |
| A §13 Excel-like grid UI (cell edit, copy/paste, undo/redo, freeze, column resize) | **MERGED — novel (mobile: form-first, grid optional)** | V.2 (#2) |
| A §18/B deferred multi-role, §19 audit trail spec (old/new/reason/approver) | **[ALREADY-COVERED]** (audit UI backlog) | Part R, L.3 |
| A §20 backup retention (15 daily + monthly permanent), JSON human-readable | **PARTIAL — novel retention rules** | V.2 (#3) |
| A §21 modular architecture, §22 entities, §25 build order, §26 acceptance | **[ALREADY-COVERED]** | Part N, P, Q |
| A §23 GitHub/CI learnings (extracted repo > zip, wrapper, JVM17) | **MERGED — notes** | V.2 (#4) |
| B §2.3 green page + hybrid print | **[ALREADY-COVERED]** | fySettings.pageBackground; print option pending |
| B §3 offline-first + SAF compulsory first-launch | **[ALREADY-COVERED]** | D13 (SAF device build pending — noted) |
| B §4 versioned migrations, operation-prior safe backup, keystore warning | **MERGED — novel** | V.2 (#5) |
| B §5 BSR master (year-wise, old read-only) | **MERGED — novel → CODE** | V.2 (#6) |
| B §6 MB labour split कारीगर/लेबर + worker masters | **MERGED — novel → CODE** | V.2 (#7) |
| B §7 man-days engine (pakhwada days, BSR−10..20% band, full man-days, amount ≤ MB component, auto-suggest, audit of calc) | **MERGED — novel → CODE (partial)** | V.2 (#8) |
| B §8 bill module (material-first payment, last-bill items, whole/decimal qty flags, basic-item front-load, material ledger reconciliation, live spend status) | **MERGED — novel (partial code)** | V.2 (#9) |
| B §9 AI Estimate Reader (cloud, mandatory review) | **MERGED — deferred module** | V.2 (#10) |
| B §10 CC min(FS, MB, app-math) rule | **[ALREADY-COVERED + CODE]** | D27 (app-math = mandays×rate now implemented) |
| B §11 bank reader: D−1 debit rule, balance-condition placement, 10–15d grouping window, credit-after rules, labour consolidation, month auto-detect, re-upload lock | **MERGED — novel → CODE (D−1 + balance guard)** | V.2 (#11) |
| B §12 ledgers (cash/scheme/material/labour/fee-count/patta extra fields) + audit drill-down | **MERGED — novel (fee-count ledgers + patta fields novel)** | V.2 (#12) |
| B §12.7 rounding: paise in cashbook, rupee display elsewhere | **[ALREADY-COVERED]** | Part M |
| B §15.1 launch page style, greeting, UI English / prints Hindi | **MERGED — UI English/Hinglish already set; greeting pending** | V.2 (#13) |
| Part C 47-screen index, contextual reports rule | **[ALREADY-COVERED supersets]** | Part O |
| §16 prototype rounds (logo chooser, 6 themes, S-07 header rules, works scheme-wise grouping, bank re-upload lock, गोशवारा मद-tap → ledger, CC 7-page detail) | **MERGED — novel where not in D21–D31** | V.2 (#14) |
| §17.1 FY closing wizard checklist, नकद→बैंक entry type, no bank→cash, repeat template, cancel reason, रसीद print (user format pending), reminders, phone-transfer wizard | **MERGED — novel where not covered** | V.2 (#15) |
| §17.2 **Demo mode REJECTED** | **[ALREADY-COVERED]** | Part R |
| §18.2 47 screens final, §18.3 rate band conditional FINAL, §18.4 rounding FINAL | **[ALREADY-COVERED]** | — |
| §18.8 per-fund page openings lesson | **[ALREADY-COVERED]** | D2/Part C (per-fund openings) |
| §19 Round 5 (admin-only, settings hierarchy, nav, 19.4 structure, 19.5 fund UX, 19.6 SFC default + day-guard, 19.7 empty states, 19.8 monthly deep-link, 19.9 no dead ends, 19.10 white share, 19.11 summary non-editable, +2 blank pages rule) | **[ALREADY-COVERED]** except +2 pages (→ CODE) | V.2 (#16) |
| §14 लंबित निर्णय open items | **[CONFLICT C9–C12]** | PART W |

## V.2 Novel specs now adopted (implementation notes)

1. **Devanagari PDF pipeline:** Noto Sans Devanagari (UI), Condensed for print grid, Noto Serif optional headings; **Mangal banned**; OFL.txt required; PDF must use shaping-capable renderer (Android native/Chromium) — ReportLab-style generators banned. Bundled `PROJECT_MASTER.md` travels with builds.
2. **Excel-like grid (mobile-tuned):** form view default; grid optional with cell tap→edit, duplicate row, sort/filter, search, freeze header. Copy/paste + undo/redo backlog me.
3. **Backup retention:** last 15 daily + 1 permanent monthly snapshot; auto daily on first open; operation-prior safe backup (FY lock, schema change) — **never auto-deleted**. JSON export human-readable (implemented).
4. **CI:** extracted project files + committed wrapper > zip upload; one active workflow; build failures log-downloadable.
5. **Update safety:** same signing key over-install; keystore external backup; additive-only migrations (no drop/rename; archived flag); backup before schema change.
6. **BSR master:** year-wise rates (2020-21+), unit, old years read-only; estimate/bill/CC rates from BSR; **[CONFLICT C2]** default FY for rate selection.
7. **MB labour split:** कारीगर (mistri) राशि + लेबर (mazdoor) राशि अलग; worker/role masters year-wise rates.
8. **Man-days engine:** pakhwada = 15d − Sundays − holidays (Holiday master) ≈ 12, manual override; **full man-days only**; amount ≤ MB component; closer-better rule; app auto-suggest combos (workers×days×rate), trial-and-error adjust; calc audit trail (rate, man-days, BSR year). Partial: pakhwada auto-day count + combos suggest backlog.
9. **Bill rules:** material-first payment (labour/MR payment blocked/warn until material bills complete — configurable strictness **[CONFLICT C3]**); last-bill items (पानी/टेंकर/मशीनरी/वाइब्रेटर/मिक्सर/डिस्प्ले बोर्ड/पॉलिश) only in final bill; qty flags (cement/brick = whole only; loose = decimal); basic items front-load suggestion; bill register date-wise with bill+payment+page ref; material bills sum = CC material validation.
10. **AI Estimate Reader:** optional cloud module, mandatory operator review, offline-policy exception #1. Deferred until sample estimate PDFs supplied.
11. **Bank auto-entry engine:** debit → D−1 date if day balance ≥ amount else statement date; credit → on open days / month-end mode; **10–15 day grouping window → one day/page**, else split; same-day labour debit consolidation suggestion; month auto-detect; verified-month re-upload lock. Partial code: D−1 + balance guard on post.
12. **Fee ledgers:** पट्टा/विवाह/जन्म/मृत्यु शुल्क — count + राशि + full list; patta entry extra fields (क्रमांक, पट्टाधारक, जारी दिनांक) — backlog in entry form.
13. **Language lock:** UI English/Hinglish; **printed documents हमेशा हिंदी**.
14. **Prototype round rules:** logo chooser (8 finance logos) on first run; **6 themes** (हरा/नीला/टील/मैरून/बैंगनी/केसरिया) — Code me theme setting added; works scheme-wise grouping + filter tabs; गोशवारा मद-tap → उस मद का ledger; bank month auto-detect + 🔒 re-upload lock.
15. **FY closing wizard:** checklist (pages verified, statements verified, missing attachments) → final गोशवारा → operation-prior safe backup → lock → auto opening; **नकद→बैंक जमा** entry type (cash−, bank+, not income/expense — Code me added); **no bank→cash ever**; repeat-template entry; cancel reason mandatory; रसीद/वाउचर print user-format pending; monthly 5th reminder; S-46 phone-transfer wizard (zip + 4-digit code).
16. **+2 blank pages** after last entry date auto-reserve (Round 5 19.4.2) — Code me Add Page flow ke saath.
17. **Launch page:** GP selection dropdown minimal style + time-based greeting (English) — backlog.

## V.3 Code status after merge (24-09-2026)

**Added to code this round:** BSR Master (year-wise, whole-unit flag), Item Master (whole/decimal + last-bill + basic flags), Holiday Master (year-wise), Worker Masters (कारीगर/लेबर year-wise rates), Man-days engine (pakhwada days, BSR−10..20% band check, full man-days, amount≤MB guard, calculator), Repeat-entry template button, **नकद→बैंक जमा** entry type (transfer, not income/expense), 6 themes + logo chooser, +2 pages auto-reserve, FY Closing wizard screen (checklist → गोशवारा → safe backup → lock → carry-forward), Bank post D−1 + balance guard, CC material-bills reconciliation warning, गोशवारा मद-tap → ledger drill-down.

---

# PART W — CONFLICTS from old master (decisions pending — user se poochha ja raha hai)

| # | Topic | Current FINAL (PROJECT_MASTER.md) | Old doc kahta hai | User decision chahiye |
|---|---|---|---|---|
| C1 | Line count + श्री पोते repeat | 25 lines (txn = L−4), श्री पोते **sirf top**, bottom-left **पूर्व पोते** (PDF sample lock) | 30 lines; income side श्री पोते **2 baar** (line 1 + line 29); txn 26\|27 split | C1 |
| C2 | BSR year for rate default | (naya feature) | sanction year BSR default; operator higher-year BSR chune to warning | C2 |
| C3 | Material-first payment enforcement | (naya rule) | material bills complete hone tak MR payment: warning ya strict block (configurable) | C3 |
| C4 | Last-bill items list | (naya rule) | fixed list (पानी/टेंकर/मशीनरी/वाइब्रेटर/मिक्सर/डिस्प्ले बोर्ड/पॉलिश) sirf last bill me; editable master | C4 |
| C5 | Qty decimals | (naya rule) | cement/ईंट = sirf poorn sankhya; loose (रेत/गिट्टी/लोहा) = decimal allowed | C5 |
| C6 | Ledger folio column | (abhi entry form me nahi) | income/expense dono me L.F. column | C6 |
| C7 | Attachment on every txn | (abhi note-only) | receipt/bill/voucher photo + PDF har txn se link | C7 |
| C8 | Blank-line gap | D1: L=25, gap 1 (settings me) | gap 1 ya 2 (Option A/B) — default 1 | C8 (gap 2 bhi?) |
| C9 | Print green vs white | D14: share/PDF **white** | hybrid: print me option (रंगीन/सफ़ेद), decision pending tha | C9 |
| C10 | Logo + default user | app.json icon fixed; admin generic | 8-logo chooser first-run; default user "Harish Patidar — Operator" | C10 |
| C11 | Password re-confirm scope | panchayat CRUD destructive par PIN confirm | + FY CRUD delete/edit par bhi password re-confirm | C11 |
| C12 | Patta fee extra fields | (abhi nahi) | पट्टा क्रमांक/पट्टाधारक/जारी दिनांक patta income entry me | C12 |

**PART W decisions PART VI (answers) me likhi jayengi.**

---

# PART VI — PART W conflict resolutions — USER DECISIONS FINAL (24-09-2026)

| # | Topic | USER ka FINAL decision | Code status |
|---|---|---|---|
| C1 | Page structure | **25 lines (PDF lock) final** — txn = L−4, श्री पोते sirf top, bottom-left पूर्व पोते; 30-line mode NAHI | Already implemented |
| C9 | Print background | **White only** — D14 bana rahega; green print option nahi | Already implemented |
| C6 | L.F. column | **Add** — income/expense form + edit dono me; ledger me L.F. dikhega taaki entry↔ledger cross-verify ho | ✅ Implemented (entry form, monthly-check edit, ledger CSV + LedgerRow.folio, CSV export column) |
| C10 | Logo chooser | **8-logo chooser first-run** + App Settings me change | ✅ Implemented (LoginScreen first-run chooser; AppSettingsScreen logo grid; AppSettings.logoId) |
| C10 | Default user | Harish Patidar seed **nahi** chuna user ne (sirf logo + FY-PIN select kiye) — admin generic rahega | — |
| C11 | FY PIN re-confirm | **Add** — FY add aur FY close/lock par PIN confirm | ✅ Implemented (FYSettingsScreen dono buttons PinModal ke through) |

**Remaining PART W items jo user ne select nahi kiye (scope se bahar rehte hain):** C2 (BSR year default — sanction-year default code me nahi, master hi bana), C3 (material-first enforcement), C4 (last-bill items list), C5 (qty decimals), C7 (photo attachment), C8 (gap-2 default), C12 (patta fields) — ye backlog me hain; jab user kahe tab implement honge. Masters screens (BSR/Item/Holiday/Worker) already bane hain jo C2/C4/C5 ka data-model ready rakhte hain.

---

# PART U — Demo-format locks & round-2 decisions (24-09-2026)

User-provided demo files are the **visual source of truth** for each format. Builders live in `services/formats.ts`; every view re-computes from transactions on each render — **no generate step** (D19 spirit).

| # | Topic | FINAL |
|---|--------|--------|
| D21 | Page add | Manual **+ Page** har page par: next page append **or** insert **between** pages (Excel-jaisa); insert renumbers pages; delete re-flows txns to unassigned; auto page-1 per FY | 
| D22 | Formats Centre | FY Home tile **प्रपत्र / Formats Centre** — गोशवारा, Ledger, प्रपत्र-1, प्रपत्र-4, Bank grid, CC — sab auto-update, share/export har card se |
| D23 | गोशवारा format | Audit demo sheet-1: मद-wise आय\|व्यय columns; आय योग, व्यय योग, प्रारम्भिक/अंतिम शेष **नगद**, (बैंक linked), महायोग, हस्ताक्षर block |
| D24 | प्रपत्र-1 | Audit demo sheet-2: FS ref/राशि (लाख), पूर्व व्यय, आलोच्य वर्ष व्यय, कुल व्यय, स्थिति पूर्ण/प्रगतिरत, मूल्यांकन, MB संदर्भ, श्रम/सामग्री split |
| D25 | प्रपत्र-4 | Audit demo sheet-3: सामग्री-वार मात्रा/दर/कीमत/योग (MB material lines se) |
| D26 | Ledger format | ledger.pdf (standard GP खाता बही): श्री पोते opening → जमा/नाम rows → running **शेष**; fund-wise ya all-funds |
| D27 | CC | cc demo xlsx: 7-page set; **अनुमत राशि = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)**; भुगतान योग्य शेष = अनुमत − payments |
| D28 | Mandays | **पाक्षिक मस्टरोल** entity: (मेट/कुशल/अकुशल संख्या × दिन) × दर = श्रम व्यय; rolls CC page-3 me aggregate |
| D29 | Monthly check | Har txn par **Edit** (date, party, detail, note, scheme, category, fund amounts) + cancel with confirm; month filter (YYYY-MM); cancelled list |
| D30 | Backup | **Full JSON backup share/save** (har app me file ban jati hai) + restore-by-paste (phone transfer); SAF file-write device build me |
| D31 | Data model | v4: `CashbookPage`, `PakhwadaRoll` added; `Transaction.pageId` added; AsyncStorage key `gpc-cashbook-v4` |

**Demo file mapping:** `audit formet demo.xlsx` → sheets 1/2/3 = गोशवारा/प्रपत्र-1/प्रपत्र-4; `bank statement demo.xlsx` → bank grid; `cc talora chaina mojek.xlsx` → CC 7 pages + mandays; `ledger.pdf` → खाता बही (scanned).

### Suggested next improvements (round-3 backlog)

1. **Real PDF output** (exceljs + expo-print) — grid exact demo jaisa, white background (D14), Devanagari embed.
2. **Attachments** (bill/receipt photo) on txn + CC pages 6-7 — expo-image-picker already present.
3. **Audit log UI** — abhi data model me nahi; L.3 ke liye AuditLog entity + view.
4. **Bank statement PDF import** — OCR/native module device build me; D−1 rule + grouping (Part G).
5. **Voucher/invoice no. + L.F. columns** entry form me (PDF sample C.3 columns abhi partial).
6. **FY closing wizard screen** (S-45) — checklist + backup-before-lock (L.2).
7. **Google Drive auto-sync** (optional, later) — backup JSON scheduled upload.

---

# PART T — Implementation / CI notes (21-09-2026)

Product requirements above remain FINAL. These notes record **build packaging** state only.

## T.1 Expo Android CI

- Source is Expo (React Native) app; GitHub Actions: extract ZIP → `expo prebuild` → `assembleRelease`.
- JS must be embedded via **release** bundle (`createBundleReleaseJsAndAssets`). Debug APK without Metro will show “Unable to load script”.
- Strip monorepo `catalog:` / `workspace:` and remove packages that fail Kotlin compile on SDK 57 if unused (`expo-document-picker`, `expo-file-system` with wrong pins).
- Require **`babel.config.js`** with `babel-preset-expo` + `react-native-reanimated/plugin`.
- Prefer **`newArchEnabled: false`** for first stable sideload APKs.
- Android `applicationId` / package: `com.grampanchayat.cashbook`.

## T.2 Sideload signing

- CI may sign with a **generated debug keystore** each run → update over previous install can require uninstall (data wipe) until a **fixed keystore** is used (D15 still Later).

## T.3 Current APK stability trade-offs

- **Biometric native module** may be omitted in a stability build; PIN login remains required (product still calls for biometric in D16 — re-enable when native module matches SDK).
- Full native PDF OCR / SAF folder UI may be wired progressively; data models and screens for Bank / Works / ledgers remain in Phase 1 scope (Parts G–L).

## T.4 Critical product regression to always test

- Switching FY must **not** show previous FY transaction rows (D17).
- Only closing balances → new FY openings.

## T.5 Real Excel PDF layout (21-09-2026)

- Sample file: user WhatsApp PDF `DOC-20260622-WA0002` (16 pages, GP Kabja).
- Part **C** rewritten so UI/PDF match that grid (प्राप्ति|भुगतान, नकद/बैंक heads, पूर्व पोते, page header).
- Implementation priority: replace list-style Cashbook screen with scrollable dual grid before further module polish.
