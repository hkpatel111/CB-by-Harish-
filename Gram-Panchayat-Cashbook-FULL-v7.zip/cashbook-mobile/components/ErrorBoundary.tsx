import React from 'react';
import { Text, View, ScrollView, StyleSheet } from 'react-native';

type S = { error?: Error };

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, S> {
  state: S = {};

  static getDerivedStateFromError(error: Error): S {
    return { error };
  }

  componentDidCatch(error: Error) {
    console.error('App ErrorBoundary', error);
  }

  render() {
    if (this.state.error) {
      return (
        <View style={styles.box}>
          <Text style={styles.title}>App error</Text>
          <ScrollView style={{ maxHeight: 320 }}>
            <Text style={styles.msg}>{this.state.error.message}</Text>
            <Text style={styles.msg}>{String(this.state.error.stack || '')}</Text>
          </ScrollView>
        </View>
      );
    }
    return this.props.children;
  }
}

const styles = StyleSheet.create({
  box: { flex: 1, backgroundColor: '#fff', padding: 24, justifyContent: 'center' },
  title: { fontSize: 20, fontWeight: '800', marginBottom: 12, color: '#a34e46' },
  msg: { fontSize: 12, color: '#333', marginBottom: 8 },
});
