/**
 * Gram Panchayat Cashbook — Phase 1 full UI
 * PROJECT_MASTER.md (20-09-2026 FINAL)
 */
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  Alert,
  BackHandler,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import colors, { applyTheme, THEMES } from '@/constants/colors';
import { formatINR, useStore, BSR_TEMPLATE } from '@/context/AppStore';
import { ScreenBadge } from '@/components/ScreenBadge';
import {
  categoryPathLabel,
  isValidIsoDate,
  isPathIncomplete,
  pageOpenings,
  schemeBalance,
  sumAmounts,
  toIsoLocal,
  transactionLineCount,
} from '@/services/pageEngine';
import { pakhwadaWorkingDays, rateCheck, referenceRate, suggestCombos } from '@/services/mandays';
import {
  clearBackupDir,
  deleteBackup,
  getBackupDirUri,
  listBackups,
  pickBackupDir,
  readBackup,
  saveBackup,
  type BackupEntry,
} from '@/services/backupFolder';
import {
  buildGoswara,
  buildLedger,
  buildPrapt1,
  buildPrapt4,
  ccBuild,
  CC_INSTRUCTIONS,
  type FmtHeader,
} from '@/services/formats';
/* instruction #6/#11/#12/#13 — share me PDF ya Excel (askAndShare) + Excel-type HTML formats */
import { askAndShare } from '@/services/exportDoc';
import {
  bankStatementHtml,
  ccPagesHtml,
  goswaraHtml,
  ledgerHtml,
  prapt1Html,
  prapt2Html,
  prapt4Html,
} from '@/services/exportHtml';
import type { MbLine, Transaction, Work } from '@/types/models';

const C = colors.light;

/** 8 finance logos (old doc §16.1) — Feather icons */
const LOGO_CHOICES: { id: string; icon: keyof typeof Feather.glyphMap; name: string }[] = [
  { id: 'book', icon: 'book-open', name: 'बही' },
  { id: 'rupee', icon: 'dollar-sign', name: '₹' },
  { id: 'coin', icon: 'circle', name: 'सिक्का' },
  { id: 'bank', icon: 'home', name: 'बैंक' },
  { id: 'bill', icon: 'file-text', name: 'बिल' },
  { id: 'chart', icon: 'bar-chart-2', name: 'चार्ट' },
  { id: 'wallet', icon: 'credit-card', name: 'पैसा' },
  { id: 'scroll', icon: 'layers', name: 'पंजिका' },
];

type Stage =
  | 'login'
  | 'panchayat'
  | 'appSettings'
  | 'fy'
  | 'fySettings'
  | 'home'
  | 'cashbook'
  | 'entry'
  | 'funds'
  | 'categories'
  | 'monthly'
  | 'goswara'
  | 'reports'
  | 'ledgers'
  | 'backup'
  | 'bank'
  | 'works'
  | 'workDetail'
  | 'mb'
  | 'manday'
  | 'bills'
  | 'cc'
  | 'formats'
  | 'masters'
  | 'closing';

function Btn({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'soft' | 'outline' | 'danger';
  icon?: keyof typeof Feather.glyphMap;
  disabled?: boolean;
}) {
  const bg =
    variant === 'primary' ? C.primary : variant === 'danger' ? C.expenseSoft : variant === 'soft' ? C.primarySoft : 'transparent';
  const fg = variant === 'primary' ? '#fff' : variant === 'danger' ? C.expense : C.primary;
  return (
    <Pressable
      disabled={disabled}
      onPress={() => {
        Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.btn,
        { backgroundColor: bg, borderColor: variant === 'outline' ? C.border : bg, opacity: disabled ? 0.4 : pressed ? 0.85 : 1 },
      ]}
    >
      {icon ? <Feather name={icon} size={16} color={fg} /> : null}
      <Text style={[styles.btnText, { color: fg }]}>{label}</Text>
    </Pressable>
  );
}

function IconBtn({ name, onPress }: { name: keyof typeof Feather.glyphMap; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.iconBtn}>
      <Feather name={name} size={18} color="#fff" />
    </Pressable>
  );
}

function Header({
  title,
  eyebrow,
  onBack,
  badge,
  action,
}: {
  title: string;
  eyebrow?: string;
  onBack?: () => void;
  badge?: string;
  action?: React.ReactNode;
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? 40 : insets.top) + 6 }]}>
      <View style={styles.headerRow}>
        {onBack ? <IconBtn name="arrow-left" onPress={onBack} /> : <View style={styles.mark}><Feather name="book-open" size={16} color="#fff" /></View>}
        <View style={{ flex: 1 }}>
          {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
          <Text style={styles.hTitle}>{title}</Text>
        </View>
        {action}
        {badge ? <ScreenBadge label={badge} /> : null}
      </View>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  keyboardType = 'default',
  secureTextEntry,
  multiline,
  placeholder,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  keyboardType?: 'default' | 'numeric';
  secureTextEntry?: boolean;
  multiline?: boolean;
  placeholder?: string;
}) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        multiline={multiline}
        placeholder={placeholder}
        placeholderTextColor={C.mutedForeground}
        style={[styles.field, multiline && { minHeight: 70, textAlignVertical: 'top' }]}
      />
    </View>
  );
}

/**
 * Dropdown select (instructions #5, #7, #9, #10): tap karo → modal me list;
 * addNewLabel/onAddNew ho to list me hi "नया जोड़ें" ka option (jaise vendor/work add).
 */
function SelectField({
  label,
  value,
  placeholder = 'चुनें',
  options,
  onSelect,
  addNewLabel,
  onAddNew,
  hint,
}: {
  label: string;
  value: string;
  placeholder?: string;
  options: { key: string; label: string; sub?: string }[];
  onSelect: (key: string) => void;
  addNewLabel?: string;
  onAddNew?: () => void;
  hint?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <Pressable
        onPress={() => setOpen(true)}
        style={[styles.field, { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }]}
      >
        <Text style={{ color: value ? C.foreground : C.mutedForeground, flex: 1, fontWeight: '700' }} numberOfLines={1}>
          {value || placeholder}
        </Text>
        <Feather name="chevron-down" size={16} color={C.mutedForeground} />
      </Pressable>
      {hint ? <Text style={styles.meta}>{hint}</Text> : null}
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.modalBg} onPress={() => setOpen(false)}>
          <Pressable style={[styles.modalCard, { maxHeight: '78%' }]} onPress={() => undefined}>
            <Text style={styles.modalTitle}>{label}</Text>
            {hint ? <Text style={styles.meta}>{hint}</Text> : null}
            <ScrollView style={{ maxHeight: 340 }} keyboardShouldPersistTaps="handled">
              {options.map((o) => (
                <Pressable
                  key={o.key}
                  onPress={() => {
                    setOpen(false);
                    onSelect(o.key);
                  }}
                  style={[styles.field, { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }]}
                >
                  <Text style={{ color: C.foreground, fontWeight: '700', flex: 1 }} numberOfLines={2}>
                    {o.label}
                  </Text>
                  {o.sub ? <Text style={{ color: C.mutedForeground, fontSize: 11 }}>{o.sub}</Text> : null}
                </Pressable>
              ))}
              {options.length === 0 ? <Text style={styles.meta}>कोई विकल्प नहीं — नीचे से जोड़ें</Text> : null}
            </ScrollView>
            {onAddNew ? (
              <Btn label={addNewLabel || '+ नया जोड़ें'} icon="plus" variant="soft" onPress={() => { setOpen(false); onAddNew(); }} />
            ) : null}
            <Btn label="बंद करें" variant="outline" onPress={() => setOpen(false)} />
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

function Empty({ title, why, steps }: { title: string; why: string; steps: string[] }) {
  return (
    <View style={styles.empty}>
      <Feather name="info" size={20} color={C.primary} />
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyWhy}>{why}</Text>
      {steps.map((s, i) => (
        <Text key={i} style={styles.emptyStep}>
          {i + 1}. {s}
        </Text>
      ))}
    </View>
  );
}

function PinModal({
  open,
  title,
  onCancel,
  onOk,
}: {
  open: boolean;
  title: string;
  onCancel: () => void;
  onOk: () => void;
}) {
  const { verifyPin } = useStore();
  const [pin, setPin] = useState('');
  // bug fix: cancel hone par pin field reset (warna purana PIN dikhta rehta tha)
  React.useEffect(() => {
    if (!open) setPin('');
  }, [open]);
  return (
    <Modal visible={open} transparent animationType="fade">
      <View style={styles.modalBg}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>{title}</Text>
          <Field label="Admin PIN" value={pin} onChangeText={setPin} secureTextEntry keyboardType="numeric" />
          <View style={styles.row}>
            <Btn label="Cancel" variant="outline" onPress={onCancel} />
            <Btn
              label="Confirm"
              onPress={() => {
                if (!verifyPin(pin)) {
                  Alert.alert('गलत PIN');
                  return;
                }
                setPin('');
                onOk();
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* D4: रद्द करने का कारण अनिवार्य — यहीं माँगा जाता है */
function CancelModal({
  txn,
  onCancel,
  onConfirm,
}: {
  txn: Transaction;
  onCancel: () => void;
  onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState('');
  return (
    <Modal visible transparent animationType="fade">
      <View style={styles.modalBg}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>शुद्धि — कारण आवश्यक</Text>
          <Text style={styles.meta}>
            {txn.date} · {txn.party} · {formatINR(sumAmounts(txn.amounts))}
          </Text>
          <Field label="रद्द करने का कारण *" value={reason} onChangeText={setReason} multiline />
          <Text style={styles.meta}>
            Entry audit में रहेगी, totals से बाहर होगी, print में लाल strike-through दिखेगा (D4)।
          </Text>
          <View style={styles.row}>
            <Btn label="वापस" variant="outline" onPress={onCancel} />
            <Btn label="रद्द करें" variant="danger" disabled={!reason.trim()} onPress={() => onConfirm(reason)} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* ——— LOGIN ——— */
function LoginScreen({ onDone }: { onDone: () => void }) {
  const { app, setPin, verifyPin, updateApp } = useStore();
  const [pin, setPinLocal] = useState('');
  const [confirm, setConfirm] = useState('');
  const [err, setErr] = useState('');
  const [showLogos, setShowLogos] = useState(!app.setupComplete);

  // First-run: 8 finance logo chooser (old doc §16.1) — saved via updateApp on submit
  const [logoId, setLogoId] = useState(app.logoId || 'book');

  const submit = async () => {
    if (!app.setupComplete || !app.pin) {
      if (pin.length < 4) return setErr('PIN ≥ 4');
      if (pin !== confirm) return setErr('PIN match नहीं');
      await updateApp({ logoId });
      await setPin(pin);
      onDone();
      return;
    }
    if (!verifyPin(pin)) return setErr('गलत PIN');
    onDone();
  };

  return (
    <View style={styles.dark}>
      <StatusBar style="light" />
      {/* bug fix: screen fixed-height thi (ScrollView nahi) — logo chooser ya keyboard
          khulte hi Login button niche chala jata tha / gayab ho jata tha. */}
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingBottom: 32, paddingHorizontal: 2 }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.loginPad}>
            <Text style={styles.brand}>ADMIN · PHASE 1</Text>
            <Text style={styles.loginHi}>{!app.pin ? 'PIN सेट करें' : 'Login'}</Text>
            <Text style={styles.loginSub}>PIN + optional biometric (Settings से toggle)</Text>
            <Field label="PIN" value={pin} onChangeText={setPinLocal} secureTextEntry keyboardType="numeric" />
            {!app.pin ? <Field label="Confirm PIN" value={confirm} onChangeText={setConfirm} secureTextEntry keyboardType="numeric" /> : null}
            {err ? <Text style={styles.err}>{err}</Text> : null}
            {showLogos ? (
              <View>
                <Text style={styles.loginSub}>ऐप का चिन्ह चुनें (बाद में App Settings से बदल सकते हैं)</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {LOGO_CHOICES.map((l) => (
                    <Pressable
                      key={l.id}
                      onPress={() => setLogoId(l.id)}
                      style={{
                        width: 60,
                        height: 60,
                        borderRadius: 14,
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderWidth: 2,
                        borderColor: logoId === l.id ? '#f0b429' : 'rgba(255,255,255,0.2)',
                        backgroundColor: logoId === l.id ? 'rgba(240,180,41,0.15)' : 'rgba(255,255,255,0.08)',
                      }}
                    >
                      <Feather name={l.icon} size={24} color={logoId === l.id ? '#f0b429' : '#fff'} />
                      <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 9, marginTop: 2 }}>{l.name}</Text>
                    </Pressable>
                  ))}
                </View>
                <Btn label="चिन्ह सहेज लिया — आगे बढ़ें ✓" variant="soft" onPress={() => setShowLogos(false)} />
              </View>
            ) : null}
            <View style={{ height: 8 }} />
            <Btn label={!app.pin ? 'Save & Continue' : 'Login with PIN'} icon="log-in" onPress={submit} />
            <ScreenBadge label="S-01" />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

function PanchayatScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { panchayats, activePanchayatId, setActivePanchayatId, activePanchayat } = useStore();
  return (
    <View style={styles.page}>
      <Header title="Panchayat" eyebrow="Select" onBack={onBack} badge="S-02" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>⚙ App Settings — PIN/biometric, पंचायत CRUD</Text>
        {panchayats.map((p) => (
          <Pressable key={p.id} onPress={() => setActivePanchayatId(p.id)} style={[styles.card, activePanchayatId === p.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <Text style={styles.meta}>{p.block} · {p.district}</Text>
          </Pressable>
        ))}
        <Btn label="Continue" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Active: {activePanchayat.name}</Text>
      </ScrollView>
    </View>
  );
}

function AppSettingsScreen({ onBack }: { onBack: () => void }) {
  const { app, updateApp, setBiometricEnabled, setPin, panchayats, addPanchayat, deletePanchayat, updatePanchayat } = useStore();
  const [name, setName] = useState('');
  const [block, setBlock] = useState('');
  const [dist, setDist] = useState('');
  const [newPin, setNewPin] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  const [pending, setPending] = useState<null | (() => void)>(null);

  return (
    <View style={styles.page}>
      <Header title="App Settings" onBack={onBack} badge="S-Last" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.section}>Security</Text>
        <Field label="Change PIN (new)" value={newPin} onChangeText={setNewPin} secureTextEntry keyboardType="numeric" />
        <Btn
          label="Update PIN"
          onPress={() => {
            if (newPin.length < 4) return Alert.alert('PIN ≥ 4');
            setPending(() => async () => {
              await setPin(newPin);
              setNewPin('');
              Alert.alert('PIN updated');
            });
            setPinOpen(true);
          }}
        />
        <Btn
          label="Biometric (next build)"
          variant="outline"
          onPress={() => Alert.alert('Biometric', 'Is build me PIN login stable rakhne ke liye biometric native module band hai.')}
        />
        <Btn
          label={`Screen badges: ${app.showScreenBadge ? 'ON' : 'OFF'}`}
          variant="outline"
          onPress={() => updateApp({ showScreenBadge: !app.showScreenBadge })}
        />

        <Text style={styles.section}>Theme colour (6 रंग)</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {(Object.keys(THEMES) as (keyof typeof THEMES)[]).map((id) => {
            const t = THEMES[id];
            const on = (app.themeId || 'green') === id;
            return (
              <Pressable
                key={id}
                onPress={() => updateApp({ themeId: id })}
                style={{
                  alignItems: 'center',
                  gap: 4,
                  padding: 6,
                  borderRadius: 12,
                  borderWidth: 2,
                  borderColor: on ? t.swatch : 'transparent',
                  backgroundColor: on ? C.secondary : 'transparent',
                }}
              >
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: t.swatch, borderWidth: 2, borderColor: 'rgba(0,0,0,0.15)' }} />
                <Text style={{ fontSize: 11, color: on ? t.swatch : C.mutedForeground, fontWeight: on ? '800' : '600' }}>
                  {t.hindi}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={styles.meta}>चुनते ही पूरी ऐप का रंग बदल जाएगा (फिर से खोलने पर भी यही रहेगा)।</Text>

        <Text style={styles.section}>App logo (8 चिन्ह)</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {LOGO_CHOICES.map((l) => (
            <Pressable
              key={l.id}
              onPress={() => updateApp({ logoId: l.id })}
              style={{
                width: 52,
                height: 52,
                borderRadius: 12,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 2,
                borderColor: app.logoId === l.id ? C.primary : C.border,
                backgroundColor: app.logoId === l.id ? C.primarySoft : C.card,
              }}
            >
              <Feather name={l.icon} size={20} color={app.logoId === l.id ? C.primary : C.mutedForeground} />
              <Text style={{ fontSize: 8, color: C.mutedForeground, marginTop: 2 }}>{l.name}</Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.section}>Panchayat master</Text>
        <Field label="Name" value={name} onChangeText={setName} />
        <Field label="Block" value={block} onChangeText={setBlock} />
        <Field label="District" value={dist} onChangeText={setDist} />
        <Btn label="Add panchayat" icon="plus" onPress={() => name.trim() && addPanchayat({ name: name.trim(), block: block || '—', district: dist || '—' })} />
        {panchayats.map((p) => (
          <View key={p.id} style={styles.card}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <View style={styles.row}>
              <Btn
                label="Delete"
                variant="danger"
                onPress={() => {
                  setPending(() => async () => {
                    const r = await deletePanchayat(p.id);
                    if (!r.ok) Alert.alert(r.error || 'Error');
                  });
                  setPinOpen(true);
                }}
              />
            </View>
          </View>
        ))}
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm Admin PIN" onCancel={() => setPinOpen(false)} onOk={() => { setPinOpen(false); pending?.(); setPending(null); }} />
    </View>
  );
}

function FYScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { financialYears, activeFinancialYearId, setActiveFinancialYearId, activeFy, activePanchayat, totalOpening, totalIncome, totalExpense, currentBalance, fyTransactions } = useStore();
  return (
    <View style={styles.page}>
      <Header title="वित्तीय वर्ष" eyebrow={activePanchayat.name} onBack={onBack} badge="S-05" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>Entries are FY-scoped. Only balances carry to next year — not old entries.</Text>
        {financialYears.map((fy) => (
          <Pressable key={fy.id} onPress={() => setActiveFinancialYearId(fy.id)} style={[styles.card, activeFinancialYearId === fy.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{fy.label} {fy.locked ? '🔒' : ''}</Text>
            <Text style={styles.meta}>{fy.start} → {fy.end}</Text>
          </Pressable>
        ))}
        <View style={styles.stats}>
          <Stat label="Opening" v={formatINR(totalOpening)} />
          <Stat label="Income" v={formatINR(totalIncome)} />
          <Stat label="Expense" v={formatINR(totalExpense)} />
          <Stat label="Balance" v={formatINR(currentBalance)} />
          <Stat label="Txns (this FY)" v={String(fyTransactions.length)} />
        </View>
        <Btn label="FY Home" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Selected {activeFy.label}</Text>
      </ScrollView>
    </View>
  );
}

function Stat({ label, v }: { label: string; v: string }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.meta}>{label}</Text>
      <Text style={styles.cardTitle}>{v}</Text>
    </View>
  );
}

/** Next FY derive — hardcoded '2027–28' bug fix (FY hamesha current FY ke baad) */
function nextFyParts(fy: { end: string }): { label: string; start: string; end: string } {
  const endYear = parseInt(fy.end.slice(0, 4), 10) || new Date().getFullYear();
  const startY = endYear;
  const start = `${startY}-04-01`;
  const end = `${startY + 1}-03-31`;
  const label = `${startY}–${String((startY + 1) % 100).padStart(2, '0')}`;
  return { label, start, end };
}

function FYSettingsScreen({ onBack }: { onBack: () => void }) {
  const {
    fySettings,
    updateFySettings,
    activeFunds,
    addFund,
    updateFundOpening,
    deleteFundFy,
    addFinancialYear,
    closeFinancialYearCarryForward,
    activeFy,
    fundOpening,
  } = useStore();
  const [fn, setFn] = useState('');
  const [fo, setFo] = useState('0');
  const [editId, setEditId] = useState<string | null>(null);
  const [bal, setBal] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  // pending ko deliberately loose rakha hai: kuch actions Promise<void>, kuch
  // Promise<{ok,error}> return karte hain — dono chalayein
  const [pending, setPending] = useState<null | (() => unknown)>(null);
  // bug fix: controlled Field store value se render hota tha — range check reject hote hi
  // field reset ho jati thi, isliye user kabhi naya number type hi nahi kar pata tha
  const [lineInput, setLineInput] = useState(String(fySettings.lineCount));
  const lineNum = parseInt(lineInput, 10);
  const lineValid = Number.isFinite(lineNum) && lineNum >= 16 && lineNum <= 40;
  const nx = nextFyParts(activeFy);

  const runPending = async () => {
    setPinOpen(false);
    const fnToDo = pending;
    setPending(null);
    if (!fnToDo) return;
    const r: unknown = await fnToDo();
    if (r && typeof r === 'object' && 'ok' in r && !(r as { ok: boolean }).ok) {
      Alert.alert('नहीं हुआ', String((r as { error?: string }).error || '—'));
    }
  };

  return (
    <View style={styles.page}>
      <Header title="FY / Cashbook Settings" onBack={onBack} badge="S-05" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.section}>Lines (txn = L−4)</Text>
        <Field
          label="Total lines (16–40, default 25)"
          value={lineInput}
          onChangeText={(v) => {
            setLineInput(v);
            const n = parseInt(v, 10);
            if (Number.isFinite(n) && n >= 16 && n <= 40) updateFySettings({ lineCount: n });
          }}
          keyboardType="numeric"
        />
        {!lineValid ? <Text style={styles.err}>16–40 के बीच डालें — मान तभी लागू होगा</Text> : null}
        <Text style={styles.meta}>Transaction lines now: {transactionLineCount(lineValid ? lineNum : fySettings.lineCount)}</Text>
        <View style={styles.row}>
          <Btn label="Gap 1" variant={fySettings.blankLineGap === 1 ? 'primary' : 'outline'} onPress={() => updateFySettings({ blankLineGap: 1 })} />
          <Btn label="Gap 2" variant={fySettings.blankLineGap === 2 ? 'primary' : 'outline'} onPress={() => updateFySettings({ blankLineGap: 2 })} />
        </View>
        <Btn
          label={fySettings.allowSchemeNegative ? 'Scheme minus: ON' : 'Scheme minus: OFF'}
          variant="soft"
          onPress={() => updateFySettings({ allowSchemeNegative: !fySettings.allowSchemeNegative })}
        />
        <Field label="Entry colour" value={fySettings.entryFontColor} onChangeText={(v) => updateFySettings({ entryFontColor: v })} />
        <Field label="श्री पोते colour" value={fySettings.shriPoteColor} onChangeText={(v) => updateFySettings({ shriPoteColor: v })} />
        <Field label="Page bg" value={fySettings.pageBackground} onChangeText={(v) => updateFySettings({ pageBackground: v })} />

        <Text style={styles.section}>Schemes (this device book)</Text>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>
              {formatINR(fundOpening(f))} · {f.openingSource === 'carry-forward' ? '↩ CF' : '✎ Manual'} · इस FY का opening
            </Text>
            <View style={styles.row}>
              <Btn
                label="Edit opening"
                variant="outline"
                onPress={() => {
                  setEditId(f.id);
                  setBal(String(fundOpening(f)));
                }}
              />
              <Btn
                label="Delete (इस FY से)"
                variant="danger"
                onPress={() => {
                  setPending(() => () => deleteFundFy(f.id));
                  setPinOpen(true);
                }}
              />
            </View>
            {editId === f.id ? (
              <>
                <Field label="Opening balance" value={bal} onChangeText={setBal} keyboardType="numeric" />
                <Btn
                  label="Save"
                  onPress={() => {
                    updateFundOpening(f.id, parseFloat(bal) || 0, 'manual');
                    setEditId(null);
                  }}
                />
              </>
            ) : null}
          </View>
        ))}
        <Field label="New scheme" value={fn} onChangeText={setFn} />
        <Field label="Opening" value={fo} onChangeText={setFo} keyboardType="numeric" />
        <Btn label="Add scheme" icon="plus" onPress={() => { addFund(fn, parseFloat(fo) || 0, 'manual'); setFn(''); setFo('0'); }} />

        <Text style={styles.section}>New FY (empty entries)</Text>
        <Text style={styles.meta}>
          अगला FY: {nx.label} ({nx.start} → {nx.end}) — current FY {activeFy.label} से derive
        </Text>
        {/* C11 decision: FY add/lock par bhi PIN re-confirm compulsory */}
        <Btn
          label={`Add FY ${nx.label} (empty) — PIN confirm`}
          onPress={() => {
            setPending(() => () => addFinancialYear(nx.label, nx.start, nx.end));
            setPinOpen(true);
          }}
        />
        <Btn
          label={`Close current FY → carry balances only to ${nx.label} — PIN confirm`}
          variant="soft"
          onPress={() => {
            setPending(() => () => closeFinancialYearCarryForward(activeFy.id, nx.label, nx.start, nx.end));
            setPinOpen(true);
          }}
        />
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm" onCancel={() => { setPinOpen(false); setPending(null); }} onOk={runPending} />
    </View>
  );
}

function HomeScreen({ go, back }: { go: (s: Stage) => void; back: () => void }) {
  const {
    activeFy, activePanchayat, currentBalance, totalIncome, totalExpense, fyTransactions,
    totalOpening, categories, bankLines,
  } = useStore();
  // J.1 — dashboard flags: incomplete category paths + untagged/open bank lines
  const incompleteCount = fyTransactions.filter(
    (t) => t.status === 'active' && (!t.schemeId || isPathIncomplete(t, categories))
  ).length;
  const openBankLines = bankLines.filter((l) => l.fyId === activeFy.id && !l.postedTxnId && !l.ignored).length;
  return (
    <View style={styles.page}>
      <Header title={`FY ${activeFy.label}`} eyebrow={activePanchayat.name} onBack={back} badge="S-06" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.stats}>
          <Stat label="Opening" v={formatINR(totalOpening)} />
          <Stat label="Balance" v={formatINR(currentBalance)} />
          <Stat label="Income" v={formatINR(totalIncome)} />
          <Stat label="Expense" v={formatINR(totalExpense)} />
          <Stat label="Entries" v={String(fyTransactions.filter((t) => t.status === 'active').length)} />
        </View>
        {incompleteCount > 0 ? (
          <Text style={[styles.err, { marginBottom: 6 }]}>
            ⚠ {incompleteCount} entries incomplete (scheme/category path missing) — Monthly check → Incomplete
          </Text>
        ) : null}
        {openBankLines > 0 ? (
          <Text style={[styles.meta, { marginBottom: 6 }]}>⚠ {openBankLines} bank lines pending tag/post</Text>
        ) : null}
        {[
          ['cashbook', 'book', 'Cashbook', '25-line Option A · dual grid'],
          ['entry', 'plus-circle', 'Add Income / Expense', 'Multi-column + scheme'],
          ['funds', 'layers', 'Fund heads', 'Opening + delete'],
          ['categories', 'git-branch', 'Categories 3-level', 'Income & expense trees'],
          ['monthly', 'check-circle', 'Monthly check', 'All txns + fix missing'],
          ['goswara', 'pie-chart', 'गोशवारा', 'Till-date auto'],
          ['ledgers', 'list', 'Ledgers', 'Auto from entries'],
          ['reports', 'bar-chart-2', 'Reports hub', 'CSV share'],
          ['bank', 'credit-card', 'Bank statement', 'Tag + post'],
          ['works', 'briefcase', 'Works / MB / Bills / CC', 'Full stack'],
          ['backup', 'hard-drive', 'Backup / Export', 'JSON + CSV'],
          ['closing', 'lock', 'FY समापन wizard', 'जाँच → गोशवारा → backup → lock'],
          ['formats', 'file-text', 'प्रपत्र / Formats Centre', 'गोशवारा, प्रपत्र-1/4, Ledger, Bank, CC'],
          ['masters', 'sliders', 'Masters (BSR/Items/Holiday/Worker)', 'दर सूची + flags'],
          // bug fix: 'closing' tile pehle DO baar tha (duplicate key + duplicate entry)
        ].map(([id, icon, title, sub]) => (
          <Pressable key={id} style={styles.homeRow} onPress={() => go(id as Stage)}>
            <View style={styles.homeIcon}><Feather name={icon as any} size={18} color={C.primary} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{title}</Text>
              <Text style={styles.meta}>{sub}</Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

/* Instruction #15 — entry se wapas aane par usi page + usi zoom par rehna chahiye */
const cashbookUI = { page: 0, zoom: 1 };

function CashbookScreen({ back, go, onEdit }: { back: () => void; go: (s: Stage) => void; onEdit: (txnId: string) => void }) {
  const {
    fyTransactions, activeFunds, fySettings, activePanchayat, activeFy, cancelTransaction,
    exportCsvForFy, fyPages, addPage, insertPageAfter, deletePage, fundOpening,
  } = useStore();
  const [pageIdx, setPageIdx] = useState(cashbookUI.page);
  /* instruction #10 + #15 — ek side phone par fit + pinch/± zoom */
  const [zoom, setZoom] = useState(cashbookUI.zoom);
  const [cancelTxn, setCancelTxn] = useState<Transaction | null>(null);

  // +2 blank pages auto-reserve after last entry date (old master 19.4.2)
  React.useEffect(() => {
    const activeCount = fyTransactions.filter((t) => t.status === 'active').length;
    const needed = activeCount > 0 ? 2 : 1;
    if (fyPages.length < needed) {
      // bug fix: label loop-index se clash karta tha — addPage apna pageNo khud assign karta hai
      for (let i = fyPages.length; i < needed; i++) addPage();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fyTransactions.length, fyPages.length]);

  const L = fySettings.lineCount;
  const txnMax = transactionLineCount(L);
  const gap = fySettings.blankLineGap;

  const safeIdx = Math.min(pageIdx, Math.max(0, fyPages.length - 1));
  const curPage = fyPages[safeIdx] || null;
  const isLastPage = safeIdx >= fyPages.length - 1;

  // instruction #15: page/zoom persist (entry → back = wahin par)
  React.useEffect(() => {
    cashbookUI.page = safeIdx;
  }, [safeIdx]);
  React.useEffect(() => {
    cashbookUI.zoom = zoom;
  }, [zoom]);

  const sortTx = (a: Transaction, b: Transaction) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt);
  const sideOfTx = (t: Transaction) => (t.type === 'transfer' ? 'expense' : t.type);

  /**
   * C.3/C.7 — इस page के दोनों zones:
   * assigned txn अपने page पर; unassigned last page पर (legacy fallback).
   * Cancelled txns भी line घेरते हैं (print पर लाल strike) — totals से बाहर रहते हैं.
   * D1/C.8 — blankLineGap 2 = हर entry के बाद 1 खाली line.
   */
  const zoneFor = (side: 'income' | 'expense'): (Transaction | null)[] => {
    const list = fyTransactions
      .filter((t) => {
        if (sideOfTx(t) !== side) return false;
        if (t.pageId) return t.pageId === curPage?.id;
        return isLastPage;
      })
      .sort(sortTx);
    const zone: (Transaction | null)[] = [];
    for (const t of list) {
      if (zone.length >= txnMax) break;
      zone.push(t);
      if (gap === 2 && zone.length < txnMax) zone.push(null);
    }
    while (zone.length < txnMax) zone.push(null);
    return zone;
  };

  const zoneInc = zoneFor('income');
  const zoneExp = zoneFor('expense');
  const activeInc = zoneInc.filter((t): t is Transaction => !!t && t.status === 'active');
  const activeExp = zoneExp.filter((t): t is Transaction => !!t && t.status === 'active');

  const fundIds = activeFunds.map((f) => f.id);

  // C.6 — इस page का श्री पोते = पिछले page की बचत पोते (page 1 = FY opening) + D17 CF/Manual
  const openingByFund = pageOpenings(
    activeFunds.map((f) => ({ id: f.id, openingBalance: fundOpening(f) })),
    fyPages,
    fyTransactions,
    safeIdx
  );
  const prevLastDate =
    safeIdx <= 0
      ? activeFy.start
      : (() => {
          const prev = fyPages[safeIdx - 1];
          const tx = fyTransactions.filter((t) => t.pageId === prev.id && t.status === 'active').sort(sortTx);
          return tx.length ? tx[tx.length - 1].date : '';
        })();
  const cfLabel =
    safeIdx > 0
      ? 'Carry-forward — पिछले पृष्ठ की बचत पोते'
      : activeFunds.some((f) => f.openingSource === 'carry-forward')
        ? 'Carry-forward — पिछले FY की समापन शेष'
        : 'Manual — हाथ से भरा';

  // C.5 — हर amount column के लिए नीचे के 3 row
  const aay: Record<string, number> = {};
  const vyay: Record<string, number> = {};
  for (const f of fundIds) {
    aay[f] = activeInc.reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
    vyay[f] = activeExp.reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
  }
  const shriOf = (f: string) => openingByFund[f] || 0;
  const aayOf = (f: string) => aay[f] || 0;
  const vyayOf = (f: string) => vyay[f] || 0;
  const mahayogLOf = (f: string) => shriOf(f) + aayOf(f);
  const bachatOf = (f: string) => mahayogLOf(f) - vyayOf(f);
  const mahayogROf = (f: string) => vyayOf(f) + bachatOf(f);

  /* ── C.3 column layout — fixed text columns + रकम group (dynamic funds + कुल) ── */
  type Col = { key: string; label: string; w: number };
  /* instruction #10 — पतला layout (चौड़ाई घटाई ताकि एक side phone पर बैठे; बाक़ी zoom ± से) */
  const amtCols: Col[] = [
    ...activeFunds.map((f) => ({ key: f.id, label: f.shortName, w: 46 })),
    { key: '_tot', label: 'कुल', w: 52 },
  ];
  const leftCols: Col[] = [
    { key: 'date', label: 'दिनांक', w: 44 },
    { key: 'ref', label: 'चेक, DD, इन्वॉइस न. व दिनांक', w: 58 },
    { key: 'party', label: 'किस से प्राप्त किया', w: 72 },
    { key: 'detail', label: 'विवरण', w: 66 },
    { key: 'lf', label: 'L.F.', w: 18 },
  ];
  const rightCols: Col[] = [
    { key: 'date', label: 'दिनांक', w: 44 },
    { key: 'ref', label: 'वाउचर नं. व दिनांक', w: 58 },
    { key: 'party', label: 'भुगतान किसको किया गया', w: 74 },
    { key: 'detail', label: 'किस कार्य पेटे भुगतान', w: 70 },
    { key: 'lf', label: 'L.F.', w: 18 },
    { key: 'asset', label: 'परि. रजि. पृ.', w: 32 },
  ];
  /* instruction #10 + #15 — दोनों sides = एक table; zoom se chaudii scale hoti hai */
  const tableW = Math.round(
    (32 +
      leftCols.reduce((s, c) => s + c.w, 0) +
      rightCols.reduce((s, c) => s + c.w, 0) +
      amtCols.reduce((s, c) => s + c.w, 0) * 2) *
      zoom +
      24
  );

  type RowKind = 'shri' | 'txn' | 'aayYog' | 'poorvPote' | 'mahayogL' | 'vyayYog' | 'bachat' | 'mahayogR';

  const kindBg = (kind: string) =>
    kind === 'shri'
      ? 'rgba(198,40,40,0.06)'
      : ['aayYog', 'poorvPote', 'mahayogL', 'vyayYog', 'bachat', 'mahayogR'].includes(kind)
        ? 'rgba(27,94,32,0.08)'
        : undefined;
  const kindColor = (kind: string) => {
    if (kind === 'shri' || kind === 'poorvPote') return fySettings.shriPoteColor;
    if (['aayYog', 'vyayYog', 'bachat', 'mahayogL', 'mahayogR'].includes(kind)) return fySettings.summaryFontColor;
    if (kind === 'txn') return fySettings.entryFontColor;
    return C.mutedForeground;
  };

  const cell = (
    k: string,
    w: number,
    text: string,
    o: { bold?: boolean; right?: boolean; color?: string; bg?: string; strike?: boolean; lines?: number; sub?: string } = {}
  ) => (
    <View
      key={k}
      style={{
        // instruction #10/#15 — zoom se cell ki चौड़ाई + font दोनों scale (एक side fit)
        width: Math.max(6, Math.round(w * zoom)),
        borderRightWidth: StyleSheet.hairlineWidth,
        borderRightColor: '#a9c6b2',
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: '#a9c6b2',
        paddingHorizontal: Math.max(1, Math.round(3 * zoom)),
        paddingVertical: 2,
        justifyContent: 'center',
        backgroundColor: o.bg,
      }}
    >
      <Text
        numberOfLines={o.lines ?? 1}
        style={{
          fontSize: Math.max(6, Math.round(9 * zoom)),
          fontWeight: o.bold ? '800' : '600',
          color: o.color || C.foreground,
          textAlign: o.right ? 'right' : 'left',
          textDecorationLine: o.strike ? 'line-through' : undefined,
        }}
      >
        {text}
      </Text>
      {o.sub ? (
        <Text
          numberOfLines={1}
          style={{
            fontSize: Math.max(5, Math.round(8 * zoom)),
            color: o.color || C.mutedForeground,
            textDecorationLine: o.strike ? 'line-through' : undefined,
          }}
        >
          {o.sub}
        </Text>
      ) : null}
    </View>
  );

  const amtCells = (k: string, get: (f: string) => number, kind: string, showZero: boolean) => {
    const wOf = (id: string) => (amtCols.find((c) => c.key === id) || { w: 70 }).w;
    const mk = (id: string) => {
      const v = id === '_tot' ? fundIds.reduce((s, f) => s + get(f), 0) : get(id);
      const txt = v === 0 && !showZero ? '' : formatINR(v);
      return cell(`${k}-${id}`, wOf(id), txt, {
        right: true,
        bold: kind !== 'txn',
        color: kind === 'txn' ? fySettings.entryFontColor : kindColor(kind),
        bg: kindBg(kind),
      });
    };
    return [...fundIds.map(mk), mk('_tot')];
  };

  const txnTextCell = (c: Col, t: Transaction, i: number) => {
    const cancelled = t.status === 'cancelled';
    const val =
      c.key === 'date'
        ? t.date
        : c.key === 'ref'
          ? t.reference || ''
          : c.key === 'party'
            ? t.type === 'transfer'
              ? `⇄ ${t.party}`
              : t.party
            : c.key === 'detail'
              ? t.detail || ''
              : c.key === 'lf'
                ? t.ledgerFolio || ''
                : c.key === 'asset'
                  ? t.assetPage || ''
                  : '';
    return cell(`t${i}-${c.key}`, c.w, val, {
      color: cancelled ? C.expense : fySettings.entryFontColor,
      strike: cancelled,
      sub: cancelled ? `रद्द: ${t.cancelReason || '—'}` : undefined,
    });
  };

  const onTxnAction = (t: Transaction) => {
    if (t.status === 'cancelled') {
      Alert.alert(
        'रद्द शुद्धि',
        `${t.date} · ${t.party}\n${formatINR(sumAmounts(t.amounts))}\nकारण: ${t.cancelReason || '—'}`,
        [{ text: 'ठीक है' }]
      );
      return;
    }
    Alert.alert('शुद्धि', `${t.date} · ${t.party}\n${formatINR(sumAmounts(t.amounts))}`, [
      { text: 'बंद', style: 'cancel' },
      { text: 'सुधारें (Edit)', onPress: () => onEdit(t.id) },
      { text: 'रद्द करें…', style: 'destructive', onPress: () => setCancelTxn(t) },
    ]);
  };

  /** C.3/C.7 — Excel-register style table: line# + text cols + रकम group */
  const renderTable = (side: 'L' | 'R') => {
    const textCols = side === 'L' ? leftCols : rightCols;
    const zone = side === 'L' ? zoneInc : zoneExp;
    const totalTextW = 16 + textCols.reduce((s, c) => s + c.w, 0);
    const totalAmtW = amtCols.reduce((s, c) => s + c.w, 0);

    type FRow = { line: number; kind: RowKind; label: string; get: (f: string) => number };
    const footers: FRow[] =
      side === 'L'
        ? [
            { line: L - 2, kind: 'aayYog', label: 'आय योग', get: aayOf },
            { line: L - 1, kind: 'poorvPote', label: 'पूर्व पोते', get: shriOf },
            { line: L, kind: 'mahayogL', label: 'महायोग', get: mahayogLOf },
          ]
        : [
            { line: L - 2, kind: 'vyayYog', label: 'व्यय योग', get: vyayOf },
            { line: L - 1, kind: 'bachat', label: 'बचत पोते', get: bachatOf },
            { line: L, kind: 'mahayogR', label: 'महायोग', get: mahayogROf },
          ];

    return (
      <View style={{ flex: 1, borderRightWidth: side === 'L' ? 2 : 0, borderRightColor: '#1e6048' }}>
        <View style={{ backgroundColor: side === 'L' ? '#1e6048' : '#3d5a4a', paddingVertical: 5, paddingHorizontal: 4 }}>
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 11, textAlign: 'center' }}>
            {side === 'L' ? 'प्राप्ति (आय)' : 'भुगतान (व्यय)'}
          </Text>
        </View>

        {/* header row 1 — रकम group spans amount columns */}
        <View style={{ flexDirection: 'row', backgroundColor: '#dceee4' }}>
          {cell('h1-span', totalTextW, '', { bold: true })}
          {cell('h1-amt', totalAmtW, 'रकम (₹)', { bold: true, right: true })}
        </View>
        {/* header row 2 — column labels */}
        <View style={{ flexDirection: 'row', backgroundColor: '#eaf5ec' }}>
          {cell('h2-line', 16, '#', { bold: true, lines: 2 })}
          {textCols.map((c) => cell(`h2-${c.key}`, c.w, c.label, { bold: true, lines: 3 }))}
          {amtCols.map((c) => cell(`h2a-${c.key}`, c.w, c.label, { bold: true, right: true, lines: 2 }))}
        </View>

        {/* line 1 — श्री पोते राशि (प्राप्ति side) / खाली (भुगतान side) */}
        <View style={{ flexDirection: 'row' }}>
          {cell('s-line', 16, '1', { bold: true, color: '#78909c', bg: kindBg('shri') })}
          {textCols.map((c) =>
            side === 'L' && c.key === 'party'
              ? cell('s-party', c.w, 'श्री पोते राशि', {
                  bold: true,
                  color: fySettings.shriPoteColor,
                  bg: kindBg('shri'),
                  sub: cfLabel,
                  lines: 2,
                })
              : cell(`s-${c.key}`, c.w, side === 'L' && c.key === 'date' ? prevLastDate : '', { bg: kindBg('shri') })
          )}
          {side === 'L' ? amtCells('s', shriOf, 'shri', true) : amtCells('s', () => 0, 'txn', false)}
        </View>

        {/* txn zone (D3: txnMax lines; blank cell tap = नई entry) */}
        {zone.map((t, i) => {
          const lineNo = i + 2;
          const key = `z${side}-${i}`;
          if (!t) {
            return (
              <Pressable key={key} onPress={() => go('entry')} style={{ flexDirection: 'row' }}>
                {cell('bl', 16, String(lineNo), { color: '#78909c' })}
                {textCols.map((c) => cell(`bt-${c.key}`, c.w, ''))}
                {amtCols.map((c) => cell(`ba-${c.key}`, c.w, ''))}
              </Pressable>
            );
          }
          const cancelled = t.status === 'cancelled';
          return (
            <Pressable
              key={key}
              onLongPress={() => onTxnAction(t)}
              style={{ flexDirection: 'row', backgroundColor: cancelled ? 'rgba(163,78,70,0.07)' : undefined }}
            >
              {cell('tl', 16, String(lineNo), { color: '#78909c' })}
              {textCols.map((c) => txnTextCell(c, t, i))}
              {amtCells(`t${i}`, (f) => Number(t.amounts[f]) || 0, 'txn', false)}
            </Pressable>
          );
        })}

        {/* bottom 3 rows — C.5 formulas per column */}
        {footers.map((fr) => (
          <View key={`f-${fr.kind}`} style={{ flexDirection: 'row', backgroundColor: kindBg(fr.kind) }}>
            {cell('fl', 16, String(fr.line), { bold: true, color: '#78909c', bg: kindBg(fr.kind) })}
            {textCols.map((c) =>
              c.key === 'party'
                ? cell(`fp-${fr.kind}`, c.w, fr.label, {
                    bold: true,
                    color: kindColor(fr.kind),
                    bg: kindBg(fr.kind),
                    lines: 2,
                  })
                : cell(`ft-${fr.kind}-${c.key}`, c.w, '', { bg: kindBg(fr.kind) })
            )}
            {amtCells(`f${fr.kind}`, fr.get, fr.kind, true)}
          </View>
        ))}
      </View>
    );
  };

  return (
    <View style={[styles.page, { backgroundColor: fySettings.pageBackground }]}>
      <Header
        title="Cashbook"
        eyebrow={`${activePanchayat.name} · ${activeFy.label} · पृष्ठ ${curPage ? curPage.pageNo : '—'}`}
        onBack={back}
        badge="S-07"
        action={
          <IconBtn
            name="share-2"
            onPress={async () => {
              const csv = exportCsvForFy();
              await Share.share({ message: csv, title: 'Cashbook CSV' });
            }}
          />
        }
      />
      {/* Page navigator — Excel-style manual pagination (user request #1) */}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: '#0e3d2e' }}>
        <Pressable
          onPress={() => setPageIdx(Math.max(0, safeIdx - 1))}
          style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>◀</Text>
        </Pressable>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12, flex: 1, textAlign: 'center' }}>
          {curPage ? `${curPage.label} · ${safeIdx + 1}/${fyPages.length}` : 'कोई page नहीं'}
        </Text>
        <Pressable
          onPress={() => setPageIdx(Math.min(fyPages.length - 1, safeIdx + 1))}
          style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>▶</Text>
        </Pressable>
        {/* instruction #15 — zoom: pinch nahi to ± se page chhota/bada */}
        <Pressable
          onPress={() => setZoom((z) => Math.max(0.5, Math.round((z - 0.1) * 10) / 10))}
          style={{ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>−</Text>
        </Pressable>
        <Pressable
          onPress={() => setZoom(1)}
          style={{ paddingHorizontal: 8, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.28)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 11 }}>{Math.round(zoom * 100)}%</Text>
        </Pressable>
        <Pressable
          onPress={() => setZoom((z) => Math.min(1.8, Math.round((z + 0.1) * 10) / 10))}
          style={{ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>+</Text>
        </Pressable>
        <Pressable
          onPress={() =>
            Alert.alert('Page', 'क्या करना है?', [
              { text: 'अगला page जोड़ें', onPress: () => addPage() },
              { text: 'इस page के बाद insert', onPress: () => curPage && insertPageAfter(curPage.id) },
              { text: 'इस page को हटाएँ', style: 'destructive', onPress: () => curPage && deletePage(curPage.id) },
              { text: 'रद्द', style: 'cancel' },
            ])
          }
          style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, backgroundColor: '#f0b429' }}
        >
          <Text style={{ color: '#123b2c', fontWeight: '800', fontSize: 12 }}>+ Page</Text>
        </Pressable>
      </View>
      <ScrollView horizontal contentContainerStyle={{ minWidth: '100%' }}>
        <ScrollView contentContainerStyle={{ padding: 8, paddingBottom: 40, minWidth: tableW }}>
          <Text style={styles.hint}>
            {L} lines · txn lines {txnMax} · C.3 dual grid: दिनांक / चेक / विवरण / L.F. + नकद व बैंक columns · bottom-3 auto (C.5)
          </Text>
          <View style={styles.row}>
            <Btn label="+ Entry" icon="plus" onPress={() => go('entry')} />
          </View>

          {/* Fund strip — current balance + CF/Manual indicator (D17) */}
          <ScrollView horizontal style={{ marginBottom: 6 }}>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              {activeFunds.map((f) => (
                <View
                  key={f.id}
                  style={{
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: '#c9dfca',
                    borderRadius: 8,
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                  }}
                >
                  <Text style={{ fontSize: 10, fontWeight: '800', color: fySettings.shriPoteColor }}>
                    {f.shortName} {f.openingSource === 'carry-forward' ? '↩CF' : '✎'}
                  </Text>
                  <Text style={{ fontSize: 10, color: C.foreground }}>
                    {formatINR(schemeBalance(f.id, fundOpening(f), fyTransactions))}
                  </Text>
                </View>
              ))}
            </View>
          </ScrollView>

          {/* Dual page — side-by-side प्राप्ति | भुगतान grid (C.7) */}
          <View
            style={{
              flexDirection: 'row',
              backgroundColor: '#f3faf3',
              borderWidth: 2,
              borderColor: '#1e6048',
              minHeight: 400,
            }}
          >
            {renderTable('L')}
            {renderTable('R')}
          </View>

          <Text style={[styles.meta, { marginTop: 8 }]}>
            Long-press = सुधार/रद्द · खाली cell tap = नई entry · Summary lines auto · Page {safeIdx + 1}/{fyPages.length} · + Page (Excel जैसा, बीच में भी insert)
          </Text>
        </ScrollView>
      </ScrollView>
      {cancelTxn ? (
        <CancelModal
          txn={cancelTxn}
          onCancel={() => setCancelTxn(null)}
          onConfirm={async (reason) => {
            const r = await cancelTransaction(cancelTxn.id, reason);
            setCancelTxn(null);
            if (!r.ok) Alert.alert(r.error || 'रद्द नहीं हुआ');
          }}
        />
      ) : null}
    </View>
  );
}

function EntryScreen({ back, editTxnId, onClearEdit }: { back: () => void; editTxnId?: string | null; onClearEdit?: () => void }) {
  const {
    activeFunds, addTransaction, updateTransaction, categories, fyTransactions, addTransferCashToBank,
    activeFy, getTransaction, works, addCategory, renameCategory, archiveCategory,
  } = useStore();
  const editTxn = editTxnId ? getTransaction(editTxnId) : null;
  const [type, setType] = useState<'income' | 'expense'>(editTxn ? (editTxn.type === 'expense' ? 'expense' : 'income') : 'income');
  const [date, setDate] = useState(editTxn?.date || toIsoLocal(new Date()));
  const [party, setParty] = useState(editTxn?.party || '');
  /* instruction #9 — सिर्फ़ date, किससे प्राप्त, राशि, योजना, श्रेणी; एक entry में एक ही scheme */
  const schemeFunds = activeFunds.filter((f) => f.id !== 'cash');
  const [schemeId, setSchemeId] = useState(
    editTxn?.schemeId || (activeFunds.some((f) => f.id === 'own') ? 'own' : schemeFunds[0]?.id || activeFunds[0]?.id || 'sfc')
  );
  const [amount, setAmount] = useState(() => {
    if (!editTxn) return '';
    const keys = Object.keys(editTxn.amounts);
    const v = editTxn.amounts[editTxn.schemeId] ?? (keys.length ? editTxn.amounts[keys[0]] : 0);
    return v ? String(v) : '';
  });
  /* instruction #7 — expense: कार्य (works dropdown) | अन्य (श्रेणी tree) */
  const [expKind, setExpKind] = useState<'work' | 'other'>(editTxn?.expenseKind === 'work' ? 'work' : 'other');
  const [workId, setWorkId] = useState<string | null>(editTxn?.workId || null);
  const [workAddOpen, setWorkAddOpen] = useState(false);
  const [catMgrOpen, setCatMgrOpen] = useState(false);
  const [catAddOpen, setCatAddOpen] = useState<null | 'l1' | 'l2' | 'l3'>(null);
  const [catAddName, setCatAddName] = useState('');
  const [detail, setDetail] = useState(editTxn?.detail || '');
  const [note, setNote] = useState(editTxn?.note || '');
  const [cat1, setCat1] = useState<string | null>(editTxn?.categoryId || null);
  const [cat2, setCat2] = useState<string | null>(editTxn?.subcategoryId || null);
  const [cat3, setCat3] = useState<string | null>(editTxn?.subSubcategoryId || null);
  const [assetPage, setAssetPage] = useState(editTxn?.assetPage || '');
  const [ledgerFolio, setLedgerFolio] = useState(editTxn?.ledgerFolio || '');
  const [reference, setReference] = useState(editTxn?.reference || '');
  /* वैकल्पिक विवरण default बंद — main form सिर्फ़ ज़रूरी फ़ील्ड (instruction #9) */
  const [showMore, setShowMore] = useState(
    !!(editTxn && (editTxn.detail || editTxn.reference || editTxn.ledgerFolio || editTxn.note || editTxn.assetPage))
  );
  const [bankFundId, setBankFundId] = useState(() => {
    const first = activeFunds.find((f) => f.id !== 'cash');
    return first ? first.id : 'sfc';
  });
  const [err, setErr] = useState('');
  const roots = categories.filter((c) => c.kind === type && c.level === 1 && !c.archived);
  const categoryNames: Record<string, string> = {};
  for (const c of categories) categoryNames[c.id] = c.name;
  // E: cascading L2/L3 chips
  const level2 = categories.filter((c) => c.parentId === cat1 && !c.archived);
  const level3 = categories.filter((c) => c.parentId === cat2 && !c.archived);

  // switching type invalidates non-applicable path
  React.useEffect(() => {
    setCat2(null);
    setCat3(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  const workSel = fyWorks.find((w) => w.id === workId) || null;

  const save = async () => {
    setErr('');
    const n = Number(amount.trim());
    if (!Number.isFinite(n) || n <= 0) return setErr('राशि > 0 भरें (एक ही योजना के लिए)');
    if (type === 'expense' && expKind === 'work' && !workId) return setErr('कार्य चुनें (या dropdown में से नया जोड़ें)');
    if (type === 'expense' && expKind === 'other' && !cat1) return setErr('श्रेणी चुनें');
    if (!isValidIsoDate(date)) return setErr('तारीख अमान्य — YYYY-MM-DD');
    /* एक entry = एक scheme (instruction #9) */
    /* कार्य चुनने पर उसी की योजना auto-select (instruction #8) */
    const effScheme = expKind === 'work' && workSel ? workSel.schemeId : schemeId;
    const am: Record<string, number> = { [effScheme]: n };

    // Part M duplicate voucher warning — save से पहले पुष्टि
    const dup = fyTransactions.find(
      (t) =>
        t.id !== editTxnId &&
        t.status === 'active' &&
        t.type === type &&
        reference.trim() &&
        t.reference === reference.trim()
    );
    const doSave = async () => {
      const payload = {
        type,
        date,
        reference: reference.trim(),
        ledgerFolio: ledgerFolio.trim(),
        party: party.trim(),
        detail: detail.trim(),
        note: note.trim(),
        schemeId: effScheme,
        amounts: am,
        categoryId: type === 'expense' && expKind === 'work' ? null : cat1,
        subcategoryId: type === 'expense' && expKind === 'work' ? null : cat2,
        subSubcategoryId: type === 'expense' && expKind === 'work' ? null : cat3,
        assetPage: assetPage.trim(),
        workId: type === 'expense' && expKind === 'work' ? workId : null,
        expenseKind: type === 'expense' ? expKind : null,
      };
      if (editTxnId) {
        const r = await updateTransaction(editTxnId, payload);
        if (!r.ok) return setErr(r.error);
        onClearEdit?.();
        return back();
      }
      const r = await addTransaction(payload);
      if (!r.ok) return setErr(r.error);
      back();
    };

    if (dup) {
      Alert.alert(
        'संभावित दोहरा वाउचर',
        `वाउचर/रसीद \"${dup.reference}\" पहले से है:\n${dup.date} · ${dup.party} · ${formatINR(
          Object.values(dup.amounts).reduce((s, v) => s + v, 0)
        )}\n\nफिर भी सहेजना है?`,
        [
          { text: 'वापस', style: 'cancel' },
          { text: 'हाँ, सहेजें', onPress: doSave },
        ]
      );
      return;
    }
    await doSave();
  };

  const close = () => {
    onClearEdit?.();
    back();
  };

  return (
    <View style={styles.page}>
      <Header title={editTxn ? 'Entry — सुधार' : 'Add entry'} onBack={close} badge={type === 'income' ? 'S-08' : 'S-09'} />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="Income" variant={type === 'income' ? 'primary' : 'outline'} onPress={() => setType('income')} />
          <Btn label="Expense" variant={type === 'expense' ? 'danger' : 'outline'} onPress={() => setType('expense')} />
        </View>
        <Text style={styles.hint}>
          सिर्फ़ ज़रूरी फ़ील्ड — तारीख, किससे प्राप्त/किसको भुगतान, राशि, योजना, श्रेणी · एक entry = एक योजना · तारीख FY ({activeFy.start} → {activeFy.end}) के भीतर
        </Text>
        <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} />
        {!isValidIsoDate(date) ? <Text style={styles.err}>तारीख format अमान्य — जैसे 2026-09-24</Text> : null}
        <Field label={type === 'income' ? 'किससे प्राप्त' : 'किसको भुगतान'} value={party} onChangeText={setParty} />
        <Field label="राशि (₹)" value={amount} onChangeText={setAmount} keyboardType="numeric" />
        <SelectField
          label="योजना / Scheme *"
          value={activeFunds.find((f) => f.id === (expKind === 'work' && workSel ? workSel.schemeId : schemeId))?.name || schemeId}
          options={schemeFunds.map((f) => ({ key: f.id, label: f.name, sub: f.shortName }))}
          onSelect={setSchemeId}
          hint={expKind === 'work' && workSel ? `कार्य चुनने पर उसकी योजना auto-select: ${activeFunds.find((f) => f.id === workSel.schemeId)?.name || workSel.schemeId}` : 'नकद (Cash) योजना नहीं — सिर्फ़ लेन-देन का माध्यम है; default Own Fund।'}
        />

        {type === 'expense' ? (
          <>
            <Text style={styles.section}>खर्च का प्रकार (instruction #7)</Text>
            <View style={styles.row}>
              <Btn label="कार्य (Work)" variant={expKind === 'work' ? 'primary' : 'outline'} onPress={() => setExpKind('work')} />
              <Btn label="अन्य (Other)" variant={expKind === 'other' ? 'danger' : 'outline'} onPress={() => setExpKind('other')} />
            </View>
            {expKind === 'work' ? (
              <SelectField
                label="कार्य चुनें *"
                value={workSel ? workSel.name : ''}
                placeholder="works की सूची से चुनें"
                options={fyWorks.map((w) => ({
                  key: w.id,
                  label: w.name,
                  sub: activeFunds.find((f) => f.id === w.schemeId)?.shortName,
                }))}
                onSelect={(id) => {
                  setWorkId(id);
                  const w = fyWorks.find((x) => x.id === id);
                  if (w) setSchemeId(w.schemeId); // instruction #8: योजना auto-select
                }}
                onAddNew={() => setWorkAddOpen(true)}
                addNewLabel="+ नया कार्य जोड़ें (फ़ॉर्म खुलेगा)"
                hint="सूची में कार्य नहीं है? नीचे से जोड़ें — योजना/AS/TS/FS/MB सब भरा जाएगा।"
              />
            ) : null}
          </>
        ) : null}

        {!(type === 'expense' && expKind === 'work') ? (
          <>
            <Text style={styles.section}>श्रेणी (L1 → L2 → L3)</Text>
            <View style={styles.chips}>
              {roots.map((c) => (
                <Pressable key={c.id} onPress={() => { setCat1(c.id); setCat2(null); setCat3(null); }} style={[styles.chip, cat1 === c.id && styles.chipOn]}>
                  <Text style={{ color: cat1 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                </Pressable>
              ))}
              <Pressable onPress={() => { setCatAddOpen('l1'); setCatAddName(''); }} style={[styles.chip, { borderStyle: 'dashed' }]}>
                <Text style={{ color: C.primary, fontSize: 12, fontWeight: '800' }}>+ नई श्रेणी</Text>
              </Pressable>
            </View>
            {level2.length || cat1 ? (
              <View style={styles.chips}>
                {level2.map((c) => (
                  <Pressable key={c.id} onPress={() => { setCat2(c.id); setCat3(null); }} style={[styles.chip, cat2 === c.id && styles.chipOn]}>
                    <Text style={{ color: cat2 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
                {cat1 ? (
                  <Pressable onPress={() => { setCatAddOpen('l2'); setCatAddName(''); }} style={[styles.chip, { borderStyle: 'dashed' }]}>
                    <Text style={{ color: C.primary, fontSize: 12, fontWeight: '800' }}>+ उपश्रेणी</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : null}
            {level3.length || cat2 ? (
              <View style={styles.chips}>
                {level3.map((c) => (
                  <Pressable key={c.id} onPress={() => setCat3(c.id)} style={[styles.chip, cat3 === c.id && styles.chipOn]}>
                    <Text style={{ color: cat3 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
                {cat2 ? (
                  <Pressable onPress={() => { setCatAddOpen('l3'); setCatAddName(''); }} style={[styles.chip, { borderStyle: 'dashed' }]}>
                    <Text style={{ color: C.primary, fontSize: 12, fontWeight: '800' }}>+ उप-उपश्रेणी</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : null}
            <Btn label="श्रेणी प्रबंधन (जोड़ें / बदलें / हटाएँ)" variant="outline" icon="folder" onPress={() => setCatMgrOpen(true)} />
            {cat1 ? (
              <Text style={styles.meta}>
                Path: {categoryPathLabel({ categoryId: cat1, subcategoryId: cat2, subSubcategoryId: cat3 }, categoryNames)}
              </Text>
            ) : null}
          </>
        ) : (
          <Text style={styles.meta}>
            कार्य: {workSel?.name} · योजना {activeFunds.find((f) => f.id === (workSel?.schemeId || ''))?.name || '—'}
            {workSel?.sanctionRef ? ` · ${workSel.sanctionRef}` : ''}
          </Text>
        )}

        <Btn
          label={showMore ? '▲ वैकल्पिक विवरण छिपाएँ' : '▼ और विवरण (वैकल्पिक) — वाउचर, L.F., नोट'}
          variant="soft"
          onPress={() => setShowMore((s) => !s)}
        />
        {showMore ? (
          <>
            <Field label="Detail" value={detail} onChangeText={setDetail} />
            <Field
              label={type === 'income' ? 'रसीद/चेक क्रमांक' : 'वाउचर/चेक क्रमांक'}
              value={reference}
              onChangeText={setReference}
            />
            <Field label="L.F. (Ledger Folio — ledger से cross-verify होगा)" value={ledgerFolio} onChangeText={setLedgerFolio} placeholder="जैसे 12" />
            <Field label="Note" value={note} onChangeText={setNote} multiline />
            {type === 'expense' ? (
              <Field label="परिसंपत्ति रजिस्टर पृष्ठ संख्या (C.3.2)" value={assetPage} onChangeText={setAssetPage} placeholder="जैसे 4" />
            ) : null}
            <Btn
              label="⧉ पिछली entry से copy (repeat template)"
              variant="soft"
              onPress={() => {
                const last = fyTransactions.filter((t) => t.type === type && t.status === 'active').slice(-1)[0];
                if (!last) return Alert.alert('कोई पिछली entry नहीं', 'पहले एक entry बनाएँ');
                setParty(last.party);
                setDetail(last.detail);
                setNote(last.note);
                setSchemeId(last.schemeId);
                const keys = Object.keys(last.amounts);
                setAmount(last.amounts[keys[0]] ? String(last.amounts[keys[0]]) : '');
                setCat1(last.categoryId);
                setCat2(last.subcategoryId);
                setCat3(last.subSubcategoryId);
                setReference('');
                Alert.alert('Copy हो गया', 'दिनांक/राशि जाँच कर Save करें');
              }}
            />
            <Btn
              label="⇄ नकद से बैंक जमा (transfer — आय/व्यय नहीं)"
              variant="outline"
              onPress={() => {
                const total = Number(amount.trim());
                const bankFund = activeFunds.find((f) => f.id === bankFundId);
                if (!Number.isFinite(total) || !(total > 0)) return Alert.alert('राशि डालें');
                if (!isValidIsoDate(date)) return Alert.alert('अमान्य दिनांक', 'YYYY-MM-DD जैसे 2026-09-24 भरें');
                if (!bankFund) return Alert.alert('कोई बैंक fund नहीं');
                Alert.alert('नकद → बैंक जमा', `₹${total} को ${bankFund.shortName} में जमा करें?\n(नकद घटेगा, बैंक बढ़ेगा — आय/व्यय नहीं)`, [
                  { text: 'नहीं', style: 'cancel' },
                  {
                    text: 'जमा करें',
                    onPress: async () => {
                      const r = await addTransferCashToBank(date, total, bankFund.id, note || detail);
                      if (r.ok) close();
                      else Alert.alert(r.error || 'Fail');
                    },
                  },
                ]);
              }}
            />
            <Text style={styles.section}>बैंक fund (transfer destination)</Text>
            <View style={styles.chips}>
              {activeFunds
                .filter((f) => f.id !== 'cash')
                .map((f) => (
                  <Pressable key={f.id} onPress={() => setBankFundId(f.id)} style={[styles.chip, bankFundId === f.id && styles.chipOn]}>
                    <Text style={{ color: bankFundId === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
                  </Pressable>
                ))}
            </View>
          </>
        ) : null}
        {err ? <Text style={styles.err}>{err}</Text> : null}
        <Btn label={editTxn ? 'सुधार सहेजें' : 'Save'} icon="check" onPress={save} />
        {editTxn ? <Btn label="रद्द करें" variant="outline" onPress={close} /> : null}
      </ScrollView>

      {/* instruction #7 — dropdown list me hi naya kary (poora form) */}
      <Modal visible={workAddOpen} transparent animationType="slide" onRequestClose={() => setWorkAddOpen(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '92%' }]}>
            <Text style={styles.modalTitle}>नया कार्य जोड़ें</Text>
            <ScrollView keyboardShouldPersistTaps="handled">
              <WorkAddForm
                onAdded={(w) => {
                  setWorkId(w.id);
                  const nw = works.find((x) => x.id === w.id);
                  if (nw) setSchemeId(nw.schemeId); // योजना auto-select (instruction #8)
                  setWorkAddOpen(false);
                }}
              />
            </ScrollView>
            <Btn label="बंद करें" variant="outline" onPress={() => setWorkAddOpen(false)} />
          </View>
        </View>
      </Modal>

      {/* instruction #7 — श्रेणी: जोड़ें / बदलें / हटाएँ (यहीं से) */}
      <Modal visible={!!catAddOpen} transparent animationType="fade" onRequestClose={() => setCatAddOpen(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>
              {catAddOpen === 'l1' ? 'नई श्रेणी' : catAddOpen === 'l2' ? 'नई उपश्रेणी' : 'नई उप-उपश्रेणी'}
            </Text>
            <Field label="नाम" value={catAddName} onChangeText={setCatAddName} />
            <Btn
              label="सहेजें"
              onPress={async () => {
                if (!catAddName.trim()) return Alert.alert('नाम चाहिए');
                const parentId = catAddOpen === 'l1' ? null : catAddOpen === 'l2' ? cat1 : cat2;
                await addCategory(type, catAddName.trim(), parentId);
                setCatAddName('');
                setCatAddOpen(null);
              }}
            />
            <Btn label="रद्द" variant="outline" onPress={() => setCatAddOpen(null)} />
          </View>
        </View>
      </Modal>
      <Modal visible={catMgrOpen} transparent animationType="slide" onRequestClose={() => setCatMgrOpen(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '88%' }]}>
            <Text style={styles.modalTitle}>श्रेणी प्रबंधन — {type === 'income' ? 'आय' : 'व्यय'}</Text>
            <ScrollView keyboardShouldPersistTaps="handled" style={{ maxHeight: 460 }}>
              <CatLevelList
                kind={type}
                parentId={null}
                title="स्तर 1 (मुख्य श्रेणी)"
                selectedId={cat1}
                onPick={(id) => { setCat1(id); setCat2(null); setCat3(null); }}
              />
              {cat1 ? (
                <CatLevelList kind={type} parentId={cat1} title="स्तर 2 (उपश्रेणी)" selectedId={cat2} onPick={(id) => { setCat2(id); setCat3(null); }} />
              ) : null}
              {cat2 ? (
                <CatLevelList kind={type} parentId={cat2} title="स्तर 3 (उप-उपश्रेणी)" selectedId={cat3} onPick={setCat3} />
              ) : null}
              <Text style={styles.meta}>टैप = उसे चुनें · ✎ = नाम बदलें · 🗑 = हटाएँ (archive — पुरानी entries सुरक्षित)</Text>
            </ScrollView>
            <Btn label="बंद करें" variant="outline" onPress={() => setCatMgrOpen(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

/** श्रेणी स्तर की सूची — चुनना/जोड़ना/नाम बदलना/हटाना यहीं से (instruction #7) */
function CatLevelList({
  kind,
  parentId,
  title,
  selectedId,
  onPick,
}: {
  kind: 'income' | 'expense';
  parentId: string | null;
  title: string;
  selectedId: string | null;
  onPick: (id: string) => void;
}) {
  const { categories, addCategory, renameCategory, archiveCategory } = useStore();
  const [nm, setNm] = useState('');
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const list = categories.filter((c) => c.kind === kind && c.parentId === parentId && !c.archived);
  return (
    <View style={{ marginBottom: 6 }}>
      <Text style={styles.section}>{title}</Text>
      {list.map((c) => (
        <View key={c.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
          <Pressable style={{ flex: 1 }} onPress={() => onPick(c.id)}>
            <Text style={{ fontWeight: selectedId === c.id ? '800' : '600', color: selectedId === c.id ? C.primary : C.foreground }}>
              {selectedId === c.id ? '✓ ' : ''}
              {c.name}
            </Text>
          </Pressable>
          <IconBtn
            name="edit-3"
            onPress={() => {
              setEditId(c.id);
              setEditName(c.name);
            }}
          />
          <IconBtn name="trash-2" onPress={() => archiveCategory(c.id)} />
        </View>
      ))}
      <View style={styles.row}>
        <Field label="नई श्रेणी का नाम" value={nm} onChangeText={setNm} />
      </View>
      <Btn
        label="+ जोड़ें"
        variant="soft"
        onPress={async () => {
          if (!nm.trim()) return;
          await addCategory(kind, nm.trim(), parentId);
          setNm('');
        }}
      />
      <Modal visible={!!editId} transparent animationType="fade" onRequestClose={() => setEditId(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>नाम बदलें</Text>
            <Field label="नाम" value={editName} onChangeText={setEditName} />
            <Btn
              label="सहेजें"
              onPress={async () => {
                if (editId && editName.trim()) await renameCategory(editId, editName.trim());
                setEditId(null);
              }}
            />
            <Btn label="रद्द" variant="outline" onPress={() => setEditId(null)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

function CategoriesScreen({ back }: { back: () => void }) {
  const { categories, addCategory, archiveCategory, renameCategory } = useStore();
  const [kind, setKind] = useState<'income' | 'expense'>('income');
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState<string | null>(null);
  const list = categories.filter((c) => c.kind === kind && !c.archived);

  return (
    <View style={styles.page}>
      <Header title="Categories" onBack={back} badge="S-Cat" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="Income tree" variant={kind === 'income' ? 'primary' : 'outline'} onPress={() => setKind('income')} />
          <Btn label="Expense tree" variant={kind === 'expense' ? 'primary' : 'outline'} onPress={() => setKind('expense')} />
        </View>
        {list.map((c) => (
          <View key={c.id} style={styles.card}>
            <Text style={styles.cardTitle}>{'  '.repeat(c.level - 1)}{c.name} <Text style={styles.meta}>L{c.level}</Text></Text>
            <View style={styles.row}>
              <Btn label="Add child" variant="outline" onPress={() => setParentId(c.id)} />
              <Btn label="Archive" variant="danger" onPress={() => archiveCategory(c.id)} />
            </View>
          </View>
        ))}
        <Field label="New name" value={name} onChangeText={setName} />
        <Text style={styles.meta}>Parent: {parentId || 'root (level 1)'}</Text>
        <Btn
          label="Add node"
          onPress={() => {
            addCategory(kind, name, parentId);
            setName('');
            setParentId(null);
          }}
        />
      </ScrollView>
    </View>
  );
}

function MastersScreen({ back }: { back: () => void }) {
  const { bsrRates, itemMasters, holidays, workerRates, addBsrRate, addItemMaster, addHoliday, addWorkerRate, activeFy } = useStore();
  const [tab, setTab] = useState<'bsr' | 'items' | 'holiday' | 'workers'>('bsr');
  const [bItem, setBItem] = useState('');
  const [bUnit, setBUnit] = useState('');
  const [bRate, setBRate] = useState('');
  const [iName, setIName] = useState('');
  const [iWhole, setIWhole] = useState(true);
  const [iLast, setILast] = useState(false);
  const [iBasic, setIBasic] = useState(false);
  const [hDate, setHDate] = useState('');
  const [hName, setHName] = useState('');
  const [wRole, setWRole] = useState<'karigar' | 'labour' | 'mate'>('labour');
  const [wName, setWName] = useState('');
  const [wRate, setWRate] = useState('');
  return (
    <View style={styles.page}>
      <Header title="Masters" onBack={back} badge="S-36" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="BSR" variant={tab === 'bsr' ? 'primary' : 'outline'} onPress={() => setTab('bsr')} />
          <Btn label="Items" variant={tab === 'items' ? 'primary' : 'outline'} onPress={() => setTab('items')} />
          <Btn label="Holiday" variant={tab === 'holiday' ? 'primary' : 'outline'} onPress={() => setTab('holiday')} />
          <Btn label="Workers" variant={tab === 'workers' ? 'primary' : 'outline'} onPress={() => setTab('workers')} />
        </View>
        {tab === 'bsr' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>BSR — वार्षिक दर सूची ({bsrRates.length})</Text>
            <Text style={styles.meta}>पुराने साल read-only. Rate band: BSR−10…−20% safe.</Text>
            {bsrRates.map((b) => (
              <Text key={b.id} style={styles.meta}>
                {b.year} · {b.itemName} · {b.unit || '—'} · ₹{b.rate}
              </Text>
            ))}
            <Field label={`Item (${activeFy.label})`} value={bItem} onChangeText={setBItem} />
            <View style={styles.row}>
              <Field label="Unit" value={bUnit} onChangeText={setBUnit} />
              <Field label="Rate" value={bRate} onChangeText={setBRate} keyboardType="numeric" />
            </View>
            <Btn
              label="BSR rate जोड़ें"
              onPress={() => {
                if (!bItem.trim() || !(parseFloat(bRate) > 0)) return Alert.alert('Item + rate चाहिए');
                addBsrRate({ year: activeFy.label, itemName: bItem.trim(), unit: bUnit.trim(), rate: parseFloat(bRate) });
                setBItem('');
                setBRate('');
              }}
            />
          </View>
        ) : null}
        {tab === 'items' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Item master ({itemMasters.length})</Text>
            {itemMasters.map((i) => (
              <Text key={i.id} style={styles.meta}>
                {i.name} · {i.wholeNumberOnly ? 'पूर्ण संख्या' : 'दशमलव'}{i.lastBillOnly ? ' · अंतिम-बिल' : ''}{i.basicItem ? ' · आधारभूत' : ''}
              </Text>
            ))}
            <Field label="Item name" value={iName} onChangeText={setIName} />
            <View style={styles.row}>
              <Btn label={`पूर्ण: ${iWhole ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setIWhole(!iWhole)} />
              <Btn label={`अंतिम-बिल: ${iLast ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setILast(!iLast)} />
              <Btn label={`आधारभूत: ${iBasic ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setIBasic(!iBasic)} />
            </View>
            <Btn
              label="Item जोड़ें"
              onPress={() => {
                if (!iName.trim()) return Alert.alert('नाम चाहिए');
                addItemMaster({ name: iName.trim(), wholeNumberOnly: iWhole, lastBillOnly: iLast, basicItem: iBasic });
                setIName('');
              }}
            />
          </View>
        ) : null}
        {tab === 'holiday' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Holiday master ({holidays.length})</Text>
            <Text style={styles.meta}>पखवाड़ा गणना में रविवार + ये छुट्टियाँ घटेंगी</Text>
            {holidays.map((h) => (
              <Text key={h.id} style={styles.meta}>{h.date} · {h.name}</Text>
            ))}
            <View style={styles.row}>
              <Field label="दिनांक" value={hDate} onChangeText={setHDate} />
              <Field label="नाम" value={hName} onChangeText={setHName} />
            </View>
            <Btn
              label="छुट्टी जोड़ें"
              onPress={() => {
                if (!hDate) return Alert.alert('दिनांक चाहिए');
                addHoliday({ year: hDate.slice(0, 4), date: hDate, name: hName || 'छुट्टी' });
                setHDate('');
                setHName('');
              }}
            />
          </View>
        ) : null}
        {tab === 'workers' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Workers / Role rates ({workerRates.length})</Text>
            {workerRates.map((w) => (
              <Text key={w.id} style={styles.meta}>
                {w.year} · {w.role} · {w.name || '(group)'} · ₹{w.dailyRate}/दिन
              </Text>
            ))}
            <View style={styles.row}>
              <Btn label="मेट" variant={wRole === 'mate' ? 'primary' : 'outline'} onPress={() => setWRole('mate')} />
              <Btn label="कारीगर" variant={wRole === 'karigar' ? 'primary' : 'outline'} onPress={() => setWRole('karigar')} />
              <Btn label="लेबर" variant={wRole === 'labour' ? 'primary' : 'outline'} onPress={() => setWRole('labour')} />
            </View>
            <View style={styles.row}>
              <Field label="नाम (optional)" value={wName} onChangeText={setWName} />
              <Field label={`दर (${activeFy.label})`} value={wRate} onChangeText={setWRate} keyboardType="numeric" />
            </View>
            <Btn
              label="Worker rate जोड़ें"
              onPress={() => {
                if (!(parseFloat(wRate) > 0)) return Alert.alert('दर चाहिए');
                addWorkerRate({ role: wRole, name: wName.trim(), year: activeFy.label, dailyRate: parseFloat(wRate) });
                setWName('');
                setWRate('');
              }}
            />
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}

function MonthlyScreen({ back }: { back: () => void }) {
  const { fyTransactions, updateTransaction, cancelTransaction, activeFunds, categories } = useStore();
  const [filter, setFilter] = useState<'all' | 'incomplete' | 'cancelled'>('all');
  const [editId, setEditId] = useState<string | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Transaction | null>(null);
  const [editParty, setEditParty] = useState('');
  const [editDetail, setEditDetail] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editNote, setEditNote] = useState('');
  const [editScheme, setEditScheme] = useState('');
  const [editRef, setEditRef] = useState('');
  const [editAsset, setEditAsset] = useState('');
  const [editCat, setEditCat] = useState<string | null>(null);
  const [editCat2, setEditCat2] = useState<string | null>(null);
  const [editCat3, setEditCat3] = useState<string | null>(null);
  const [editAmounts, setEditAmounts] = useState<Record<string, string>>({});
  const [editFolio, setEditFolio] = useState('');
  const [editErr, setEditErr] = useState('');
  const [month, setMonth] = useState('');

  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;

  const list = fyTransactions.filter((t) => {
    if (month && !t.date.startsWith(month)) return false;
    // J.2 — incomplete = scheme ya category path ka deepest level missing
    if (filter === 'incomplete')
      return t.status === 'active' && (!t.schemeId || isPathIncomplete(t, categories));
    if (filter === 'cancelled') return t.status === 'cancelled';
    return true;
  });

  const openEdit = (t: Transaction) => {
    setEditId(t.id);
    setEditErr('');
    setEditParty(t.party);
    setEditDetail(t.detail);
    setEditDate(t.date);
    setEditNote(t.note);
    setEditScheme(t.schemeId);
    setEditCat(t.categoryId);
    setEditCat2(t.subcategoryId);
    setEditCat3(t.subSubcategoryId);
    setEditRef(t.reference || '');
    setEditAsset(t.assetPage || '');
    setEditFolio(t.ledgerFolio || '');
    const am: Record<string, string> = {};
    for (const f of activeFunds) am[f.id] = t.amounts[f.id] ? String(t.amounts[f.id]) : '';
    setEditAmounts(am);
  };

  const saveEdit = async () => {
    if (!editId) return;
    // Part M: non-numeric / negative amount block (pehle chup-chaap skip ho jata tha)
    const am: Record<string, number> = {};
    for (const f of activeFunds) {
      const raw = (editAmounts[f.id] || '').trim();
      if (!raw) continue;
      const n = Number(raw);
      if (!Number.isFinite(n)) return setEditErr(`${f.shortName}: \"${raw}\" अमान्य राशि`);
      if (n < 0) return setEditErr(`${f.shortName}: ऋणात्मक राशि अनुमति नहीं`);
      if (n > 0) am[f.id] = n;
    }
    const r = await updateTransaction(editId, {
      party: editParty.trim(),
      detail: editDetail.trim(),
      date: editDate,
      note: editNote.trim(),
      reference: editRef.trim(),
      schemeId: editScheme,
      categoryId: editCat,
      subcategoryId: editCat2,
      subSubcategoryId: editCat3,
      ledgerFolio: editFolio.trim(),
      assetPage: editAsset.trim(),
      amounts: am,
    });
    // bug fix: pehle result check hi nahi hota tha — guard violation chup-chaap save ho jata tha
    if (!r.ok) return setEditErr(r.error || 'सहेजा नहीं जा सका');
    setEditId(null);
    Alert.alert('सुधार सहेज लिया', undefined, [{ text: 'OK' }]);
  };

  const editing = fyTransactions.find((t) => t.id === editId);
  const editRoots = editing ? categories.filter((c) => c.kind === editing.type && c.level === 1 && !c.archived) : [];
  const editL2 = categories.filter((c) => c.parentId === editCat && !c.archived);
  const editL3 = categories.filter((c) => c.parentId === editCat2 && !c.archived);

  return (
    <View style={styles.page}>
      <Header title="Monthly check" onBack={back} badge="S-MC" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Field label="महीना filter (YYYY-MM, खाली = सब)" value={month} onChangeText={setMonth} placeholder="2026-09" />
        <View style={styles.row}>
          <Btn label="All" variant={filter === 'all' ? 'primary' : 'outline'} onPress={() => setFilter('all')} />
          <Btn label="Incomplete" variant={filter === 'incomplete' ? 'primary' : 'outline'} onPress={() => setFilter('incomplete')} />
          <Btn label="Cancelled" variant={filter === 'cancelled' ? 'primary' : 'outline'} onPress={() => setFilter('cancelled')} />
        </View>
        {list.length === 0 ? (
          <Empty title="No rows" why="Is FY/filter me entries nahi" steps={['Add cashbook entry', 'Filter badlein']} />
        ) : null}
        {list.map((t) => (
          <View key={t.id} style={styles.card}>
            <Text
              style={[
                styles.cardTitle,
                t.status === 'cancelled' ? { textDecorationLine: 'line-through', color: C.expense } : null,
              ]}
            >
              {t.date} · {t.type} · {t.party || '(no party)'} {t.status === 'cancelled' ? '· रद्द' : ''}
            </Text>
            <Text style={styles.meta}>
              {formatINR(sumAmounts(t.amounts))} · scheme={t.schemeId || 'MISSING'} ·{' '}
              {categoryPathLabel(t, catNames) || 'cat=MISSING'}
            </Text>
            {t.status === 'cancelled' ? (
              <Text style={[styles.meta, { color: C.expense }]}>कारण: {t.cancelReason || '—'}</Text>
            ) : null}
            <View style={styles.row}>
              <Btn label="✏ Edit" onPress={() => openEdit(t)} />
              {t.status === 'active' ? (
                <Btn label="Cancel entry" variant="danger" onPress={() => setCancelTarget(t)} />
              ) : null}
            </View>
          </View>
        ))}
      </ScrollView>

      {cancelTarget ? (
        <CancelModal
          txn={cancelTarget}
          onCancel={() => setCancelTarget(null)}
          onConfirm={async (reason) => {
            const r = await cancelTransaction(cancelTarget.id, reason);
            setCancelTarget(null);
            if (!r.ok) Alert.alert(r.error || 'रद्द नहीं हुआ');
          }}
        />
      ) : null}

      {/* Full edit modal — har transaction par sudhaar */}
      <Modal visible={!!editId} animationType="slide">
        <View style={[styles.page, { paddingTop: 50 }]}>
          <Header title="Entry सुधारें" onBack={() => setEditId(null)} badge="S-MC" />
          <ScrollView contentContainerStyle={styles.pad}>
            <Field label="दिनांक" value={editDate} onChangeText={setEditDate} />
            {!isValidIsoDate(editDate) ? <Text style={styles.err}>तारीख format अमान्य — जैसे 2026-09-24</Text> : null}
            <Field label={editing?.type === 'income' ? 'किससे प्राप्त' : 'किसको भुगतान'} value={editParty} onChangeText={setEditParty} />
            <Field label="Detail" value={editDetail} onChangeText={setEditDetail} />
            <Field
              label={editing?.type === 'income' ? 'रसीद/चेक क्रमांक' : 'वाउचर/चेक क्रमांक'}
              value={editRef}
              onChangeText={setEditRef}
            />
            <Field label="L.F. (Ledger Folio)" value={editFolio} onChangeText={setEditFolio} />
            {editing?.type === 'expense' ? (
              <Field label="परिसंपत्ति रजिस्टर पृष्ठ" value={editAsset} onChangeText={setEditAsset} />
            ) : null}
            <Field label="Note" value={editNote} onChangeText={setEditNote} multiline />
            <Text style={styles.section}>Scheme *</Text>
            <View style={styles.chips}>
              {activeFunds.map((f) => (
                <Pressable key={f.id} onPress={() => setEditScheme(f.id)} style={[styles.chip, editScheme === f.id && styles.chipOn]}>
                  <Text style={{ color: editScheme === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
                </Pressable>
              ))}
            </View>
            <Text style={styles.section}>Amounts by fund</Text>
            {activeFunds.map((f) => (
              <Field
                key={f.id}
                label={f.shortName}
                value={editAmounts[f.id] || ''}
                onChangeText={(v) => setEditAmounts((a) => ({ ...a, [f.id]: v }))}
                keyboardType="numeric"
              />
            ))}
            <Text style={styles.section}>Category path (L1 → L2 → L3)</Text>
            <View style={styles.chips}>
              {editRoots.map((c) => (
                <Pressable key={c.id} onPress={() => { setEditCat(c.id); setEditCat2(null); setEditCat3(null); }} style={[styles.chip, editCat === c.id && styles.chipOn]}>
                  <Text style={{ color: editCat === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                </Pressable>
              ))}
            </View>
            {editL2.length ? (
              <View style={styles.chips}>
                {editL2.map((c) => (
                  <Pressable key={c.id} onPress={() => { setEditCat2(c.id); setEditCat3(null); }} style={[styles.chip, editCat2 === c.id && styles.chipOn]}>
                    <Text style={{ color: editCat2 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
            {editL3.length ? (
              <View style={styles.chips}>
                {editL3.map((c) => (
                  <Pressable key={c.id} onPress={() => setEditCat3(c.id)} style={[styles.chip, editCat3 === c.id && styles.chipOn]}>
                    <Text style={{ color: editCat3 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
            {editCat ? (
              <Text style={styles.meta}>
                Path: {categoryPathLabel({ categoryId: editCat, subcategoryId: editCat2, subSubcategoryId: editCat3 }, catNames)}
              </Text>
            ) : null}
            {editErr ? <Text style={styles.err}>{editErr}</Text> : null}
            <View style={styles.row}>
              <Btn label="Save" icon="check" onPress={saveEdit} />
              <Btn label="Cancel" variant="outline" onPress={() => setEditId(null)} />
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

function GoswaraScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, activeFunds, totalOpening, categories, activePanchayat, activeFy, bankLines } = useStore();
  const active = fyTransactions.filter((t) => t.status === 'active');
  if (active.length === 0) {
    return (
      <View style={styles.page}>
        <Header title="गोशवारा" onBack={back} badge="S-27" />
        <View style={styles.pad}>
          <Empty title="गोशवारा खाली" why="Is FY me abhi koi entry nahi" steps={['Cashbook me income/expense add karein', 'Ledgers auto update ho jayenge']} />
        </View>
      </View>
    );
  }
  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;
  const g = buildGoswara(fyTransactions, catNames, totalOpening);
  /* instruction #11 — गोशवारा hamesha do-sided (upload ki Excel jaisa), share me PDF/Excel */
  const hdr: FmtHeader = {
    panchayat: activePanchayat.name,
    block: activePanchayat.block,
    district: activePanchayat.district,
    fy: activeFy.label,
    formName: 'वार्षिक आय - व्यय सामान्य रोकड़ बही (गोशवारा) — till date',
  };
  const share = async () => {
    /* बैंक शेष = statement lines का net (credit − debit); नकद = कुल शेष − बैंक,
       ताकि spec का समीकरण (आय महायोग = व्यय महायोग) सही बैठे */
    const fyBank = bankLines.filter((l) => l.fyId === activeFy.id && !l.ignored);
    const antimBank = fyBank.reduce((s, l) => s + (l.side === 'credit' ? l.amount : -l.amount), 0);
    const body = goswaraHtml({
      header: hdr,
      rows: g.rows,
      aayYog: g.aayYog,
      vyayYog: g.vyayYog,
      prarambhikNagad: g.prarambhikNagad,
      prarambhikBank: 0,
      antimNagad: Math.round((g.antSheshNagad - antimBank) * 100) / 100,
      antimBank: Math.round(antimBank * 100) / 100,
    });
    await askAndShare('गोशवारा (रोकड़ बही)', body, true);
  };
  return (
    <View style={styles.page}>
      <Header title="गोशवारा till date" onBack={back} badge="S-27" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>वार्षिक आय-व्यय सामान्य रोकड़ बही (audit demo format) — हर entry पर auto-update</Text>
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', borderBottomWidth: 1, borderColor: C.border, paddingBottom: 4 }}>
            <Text style={[styles.gosHead, { flex: 2 }]}>नाम मद</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>आय</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>व्यय</Text>
          </View>
          {g.rows.map((r, i) => (
            <View key={i} style={{ flexDirection: 'row', paddingVertical: 3, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: C.border }}>
              <Text style={{ flex: 2, fontSize: 12, color: C.foreground }}>{r.name}</Text>
              <Text style={{ flex: 1, fontSize: 12, textAlign: 'right', color: C.foreground }}>{r.inc ? formatINR(r.inc) : ''}</Text>
              <Text style={{ flex: 1, fontSize: 12, textAlign: 'right', color: C.foreground }}>{r.exp ? formatINR(r.exp) : ''}</Text>
            </View>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.sumLine}>आय योग: {formatINR(g.aayYog)}</Text>
          <Text style={styles.sumLine}>व्यय योग: {formatINR(g.vyayYog)}</Text>
          <Text style={styles.sumLine}>प्रारम्भिक शेष नगद: {formatINR(g.prarambhikNagad)}</Text>
          <Text style={styles.sumLine}>महायोग: {formatINR(g.mahayog)}</Text>
          <Text style={styles.sumLine}>अंतिम शेष नगद: {formatINR(g.antSheshNagad)}</Text>
          <Text style={styles.meta}>प्रारम्भिक/अंतिम शेष बैंक — Bank module linked (statement posted hone par auto)</Text>
        </View>
        <View style={styles.row}>
          <Btn label="Share CSV" icon="share-2" onPress={share} />
          <Btn label="Formats Centre" variant="outline" onPress={() => go('formats')} />
        </View>
        <View style={styles.card}>
          <Text style={styles.meta}>हस्ताक्षर: ______ सरपंच        ______ ग्राम विकास अधिकारी</Text>
        </View>
      </ScrollView>
    </View>
  );
}

function LedgersScreen({ back }: { back: () => void }) {
  const { fyTransactions, activeFunds, totalOpening, activePanchayat, activeFy, fundOpening } = useStore();
  const [fundId, setFundId] = useState<string>('');
  const active = fyTransactions.filter((t) => t.status === 'active');
  const sel = fundId || 'all';
  // D17: fund-wise श्री पोते = is FY ka opening snapshot (global openingBalance nahi)
  const opening = fundId
    ? (() => {
        const f = activeFunds.find((x) => x.id === fundId);
        return f ? fundOpening(f) : 0;
      })()
    : totalOpening;
  const rows = buildLedger(opening, fyTransactions, fundId || undefined);
  /* instruction #11 — खाता बही hamesha do-sided (upload ledger.pdf jaisa), share me PDF/Excel */
  const share = async () => {
    const body = ledgerHtml({
      header: {
        panchayat: activePanchayat.name,
        block: activePanchayat.block,
        district: activePanchayat.district,
        fy: activeFy.label,
        formName: `खाता बही — ${fundId ? activeFunds.find((f) => f.id === fundId)?.name || fundId : 'सभी योजनाएँ'}`,
      },
      rows,
    });
    await askAndShare('खाता बही (Ledger)', body, true);
  };
  return (
    <View style={styles.page}>
      <Header title="Ledgers (खाता बही)" onBack={back} badge="S-28" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>Ledger.pdf format — श्री पोते → जमा/नाम → शेष (हर entry पर auto-update)</Text>
        <View style={styles.chips}>
          <Pressable onPress={() => setFundId('')} style={[styles.chip, sel === 'all' && styles.chipOn]}>
            <Text style={{ color: sel === 'all' ? '#fff' : C.foreground, fontWeight: '700' }}>सभी</Text>
          </Pressable>
          {activeFunds.map((f) => (
            <Pressable key={f.id} onPress={() => setFundId(f.id)} style={[styles.chip, sel === f.id && styles.chipOn]}>
              <Text style={{ color: sel === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
            </Pressable>
          ))}
        </View>
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', borderBottomWidth: 1, borderColor: C.border, paddingBottom: 4 }}>
            <Text style={[styles.gosHead, { flex: 1 }]}>दिनांक</Text>
            <Text style={[styles.gosHead, { flex: 2 }]}>किस से/किस को</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>जमा</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>नाम</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>शेष</Text>
          </View>
          {rows.map((r, i) => (
            <View key={i} style={{ flexDirection: 'row', paddingVertical: 3, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: C.border }}>
              <Text style={{ flex: 1, fontSize: 11, color: C.foreground }}>{r.date.slice(5)}</Text>
              <Text numberOfLines={1} style={{ flex: 2, fontSize: 11, color: C.foreground, paddingHorizontal: 2 }}>{r.party}</Text>
              <Text style={{ flex: 1, fontSize: 11, textAlign: 'right', color: C.primary }}>{r.credit ? formatINR(r.credit) : ''}</Text>
              <Text style={{ flex: 1, fontSize: 11, textAlign: 'right', color: C.expense }}>{r.debit ? formatINR(r.debit) : ''}</Text>
              <Text style={{ flex: 1, fontSize: 11, textAlign: 'right', fontWeight: '700', color: C.foreground }}>{formatINR(r.running)}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

function ReportsScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { exportCsvForFy, fyTransactions, auditLogs, activeFy } = useStore();
  const fyLogs = auditLogs.filter((l) => l.fyId === activeFy.id).slice(0, 25);
  return (
    <View style={styles.page}>
      <Header title="Reports hub" onBack={back} badge="S-34" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>{fyTransactions.length} rows in FY · Share CSV (Excel-readable). PDF layout uses white background per spec.</Text>
        <Btn
          label="Share FY CSV (Excel)"
          icon="share-2"
          onPress={async () => Share.share({ message: exportCsvForFy() })}
        />
        <View style={styles.row}>
          <Btn label="गोशवारा" variant="outline" onPress={() => go('goswara')} />
          <Btn label="Ledger" variant="outline" onPress={() => go('ledgers')} />
        </View>
        <View style={styles.row}>
          <Btn label="प्रपत्र Centre" variant="outline" onPress={() => go('formats')} />
          <Btn label="Monthly check" variant="outline" onPress={() => go('monthly')} />
        </View>

        {/* L.3 audit trail — create / update / cancel sab record */}
        <Text style={styles.section}>Audit trail (L.3 — नवीनतम {fyLogs.length})</Text>
        {fyLogs.length === 0 ? (
          <Text style={styles.meta}>अभी कोई log नहीं — entry बनाने/सुधारने/रद्द करने पर यहाँ दिखेगा।</Text>
        ) : (
          fyLogs.map((l) => (
            <View key={l.id} style={styles.card}>
              <Text style={styles.cardTitle}>
                {l.time.slice(0, 16).replace('T', ' ')} · {l.entity} · {l.action}
              </Text>
              <Text style={styles.meta}>
                {l.field ? `${l.field}: ${l.oldV || '—'} → ${l.newV || '—'}` : l.newV || ''}
                {l.reason ? ` · कारण: ${l.reason}` : ''}
              </Text>
            </View>
          ))
        )}
        <Empty
          title="PDF print layout"
          why="Native PDF renderer hooks to same dataset; CSV share works offline now."
          steps={['Use Share FY CSV in Excel', 'Page PDF engine binds to Option A layout in print module']}
        />
      </ScrollView>
    </View>
  );
}

function BankScreen({ back }: { back: () => void }) {
  const {
    bankAccounts, bankLines, addBankLine, updateBankLine, postBankLineToCashbook,
    activeFunds, activeFy, activePanchayat, works, vendors, categories,
  } = useStore();
  const [narr, setNarr] = useState('');
  const [amt, setAmt] = useState('');
  const [instr, setInstr] = useState('');
  const [side, setSide] = useState<'credit' | 'debit'>('credit');
  const [date, setDate] = useState(toIsoLocal(new Date()));
  /* instruction #13 — statement tagging: योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी */
  const [tagWork, setTagWork] = useState('');
  const [tagVendor, setTagVendor] = useState('');
  const [tagHead, setTagHead] = useState('');
  const [tagNote, setTagNote] = useState('');
  const fyLines = bankLines.filter((l) => l.fyId === activeFy.id);
  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  const heads = categories.filter((c) => c.level === 1 && !c.archived);
  const nameOfWork = (id: string | null | undefined) => fyWorks.find((w) => w.id === id)?.name || '';
  const nameOfVendor = (id: string | null | undefined) => vendors.find((v) => v.id === id)?.name || '';
  const nameOfHead = (id: string | null | undefined) => heads.find((c) => c.id === id)?.name || '';

  /* running balance — statement पर चलता शेष (bank demo sheet जैसा) */
  const sorted = [...fyLines].sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
  const balanceOf = new Map<string, number>();
  {
    let bal = fyLines.length ? 0 : 0;
    for (const l of sorted) {
      if (!l.ignored) bal += l.side === 'credit' ? l.amount : -l.amount;
      balanceOf.set(l.id, bal);
    }
  }

  const addLine = () => {
    // Part G: जमा + नाम दोनों; invalid date / zero amount block
    if (!isValidIsoDate(date)) return Alert.alert('अमान्य दिनांक', 'YYYY-MM-DD जैसे 2026-09-24');
    const n = Number(amt.trim());
    if (!Number.isFinite(n) || !(n > 0)) return Alert.alert('राशि > 0 चाहिए');
    if (!narr.trim()) return Alert.alert('Narration भरें');
    addBankLine({
      accountId: bankAccounts[0]?.id || 'ba1',
      fyId: activeFy.id,
      statementMonth: date.slice(0, 7),
      date,
      narration: narr.trim(),
      amount: n,
      side,
      instrument: instr.trim(),
      schemeId: null,
      workId: tagWork || null,
      vendorId: tagVendor || null,
      categoryId: tagHead || null,
      note: tagNote.trim() || undefined,
      ignored: false,
      postedTxnId: null,
    });
    setNarr('');
    setAmt('');
    setInstr('');
    setTagNote('');
  };

  /* instruction #13 — bank statement share: PDF ya Excel, fields upload Excel jaisa */
  const bankAccount = bankAccounts[0];
  const shareStatement = async () => {
    let bal = 0;
    const rows = sorted
      .filter((l) => !l.ignored)
      .map((l) => {
        bal += l.side === 'credit' ? l.amount : -l.amount;
        const w = works.find((x) => x.id === l.workId);
        const v = vendors.find((x) => x.id === l.vendorId);
        const h = categories.find((x) => x.id === l.categoryId);
        const s = activeFunds.find((x) => x.id === l.schemeId);
        return {
          date: l.date,
          narration: l.narration,
          instrument: l.instrument,
          deposit: l.side === 'credit' ? l.amount : 0,
          withdrawal: l.side === 'debit' ? l.amount : 0,
          balance: Math.round(bal * 100) / 100,
          scheme: s?.name,
          work: w?.name,
          vendor: v?.name,
          head: h?.name,
          note: l.note,
          posted: !!l.postedTxnId,
        };
      });
    const body = bankStatementHtml({
      header: {
        panchayat: activePanchayat.name,
        block: activePanchayat.block,
        district: activePanchayat.district,
        fy: activeFy.label,
        formName: 'बैंक विवरण (Bank statement)',
      },
      accountName: bankAccount?.name || '—',
      accountNo: bankAccount?.accountNo || '—',
      bankName: bankAccount?.bankName || '—',
      rows,
    });
    await askAndShare('बैंक विवरण', body, true);
  };

  return (
    <View style={styles.page}>
      <Header
        title="Bank statement"
        onBack={back}
        badge="S-13"
        action={<IconBtn name="share-2" onPress={shareStatement} />}
      />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          Line add करें → scheme tag → Post (D−1 rule debit पर). OCR/PDF import device build में (Part U).
        </Text>
        {bankAccounts.map((a) => (
          <Text key={a.id} style={styles.meta}>{a.name} · {a.bankName} · {a.accountNo}</Text>
        ))}
        <View style={styles.row}>
          <Btn label="जमा (credit)" variant={side === 'credit' ? 'primary' : 'outline'} onPress={() => setSide('credit')} />
          <Btn label="नाम (debit)" variant={side === 'debit' ? 'danger' : 'outline'} onPress={() => setSide('debit')} />
        </View>
        <Field label="Narration" value={narr} onChangeText={setNarr} />
        <Field label="Amount" value={amt} onChangeText={setAmt} keyboardType="numeric" />
        <Field label="Instrument (चेक/DD/IMPS no.)" value={instr} onChangeText={setInstr} />
        <Field label="Date" value={date} onChangeText={setDate} />
        {/* instruction #13 — योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी */}
        <Text style={styles.section}>Tagging (निकासी/जमा का विवरण)</Text>
        <SelectField
          label="कार्य (Work)"
          value={nameOfWork(tagWork)}
          options={fyWorks.map((w) => ({ key: w.id, label: w.name }))}
          onSelect={setTagWork}
          hint="लागू न हो तो खाली छोड़ें"
        />
        <SelectField
          label="विक्रेता / पक्ष (Vendor / Party)"
          value={nameOfVendor(tagVendor)}
          options={vendors.filter((v) => !v.archived).map((v) => ({ key: v.id, label: v.name }))}
          onSelect={setTagVendor}
        />
        <SelectField
          label="लेखा शीर्ष (Account head)"
          value={nameOfHead(tagHead)}
          options={heads.map((c) => ({ key: c.id, label: c.name }))}
          onSelect={setTagHead}
        />
        <Field label="टिप्पणी (Note)" value={tagNote} onChangeText={setTagNote} />
        <Btn
          label={side === 'credit' ? 'Add credit line' : 'Add debit line'}
          icon="plus"
          onPress={addLine}
        />
        {sorted.map((l) => (
          <View key={l.id} style={styles.card}>
            <Text style={styles.cardTitle}>{l.date} · {l.narration}</Text>
            <Text style={styles.meta}>
              {l.side === 'credit' ? 'जमा' : 'नाम'} {formatINR(l.amount)}
              {l.instrument ? ` · ${l.instrument}` : ''} · शेष {formatINR(balanceOf.get(l.id) || 0)}
              {' · '}{l.ignored ? 'IGNORED' : l.postedTxnId ? 'POSTED' : 'open'}
            </Text>
            {l.workId || l.vendorId || l.categoryId || l.note ? (
              <Text style={styles.meta}>
                {[l.workId ? `कार्य: ${nameOfWork(l.workId)}` : '', l.vendorId ? `पक्ष: ${nameOfVendor(l.vendorId)}` : '',
                  l.categoryId ? `शीर्ष: ${nameOfHead(l.categoryId)}` : '', l.note || ''].filter(Boolean).join(' · ')}
              </Text>
            ) : null}
            <Text style={styles.meta}>scheme tag:</Text>
            <View style={styles.chips}>
              {activeFunds.map((f) => (
                <Pressable
                  key={f.id}
                  style={[styles.chip, l.schemeId === f.id && styles.chipOn]}
                  onPress={() => updateBankLine(l.id, { schemeId: f.id })}
                >
                  <Text style={{ color: l.schemeId === f.id ? '#fff' : C.foreground, fontSize: 11 }}>{f.shortName}</Text>
                </Pressable>
              ))}
            </View>
            <View style={styles.row}>
              {!l.postedTxnId && !l.ignored ? (
                <Btn
                  label="Post to cashbook"
                  onPress={async () => {
                    const r = await postBankLineToCashbook(l.id);
                    if (!r.ok) Alert.alert('Post नहीं हुआ', r.error || 'Fail');
                  }}
                />
              ) : null}
              {!l.postedTxnId && !l.ignored ? (
                <Btn label="Ignore" variant="outline" onPress={() => updateBankLine(l.id, { ignored: true })} />
              ) : null}
              {l.ignored ? (
                <Btn label="Un-ignore" variant="outline" onPress={() => updateBankLine(l.id, { ignored: false })} />
              ) : null}
            </View>
          </View>
        ))}
        {fyLines.length === 0 ? (
          <Empty title="कोई statement line नहीं" why="अभी कोई bank line add नहीं हुई" steps={['ऊपर narration/amount/date भरें', 'जमा या नाम चुनकर line जोड़ें']} />
        ) : null}
      </ScrollView>
    </View>
  );
}

/**
 * Instruction #8 — work add का पूरा फ़ॉर्म (Works screen + Entry की dropdown दोनों में)
 * योजना, A.S./T.S./F.S. क्रमांक+दिनांक, शुरू/पूर्ण तिथि, MB स्थिति + MB विवरण पूछे जाते हैं।
 */
function WorkAddForm({ onAdded }: { onAdded?: (w: { id: string; name: string }) => void }) {
  const { addWork, activeFy, activeFunds } = useStore();
  const [name, setName] = useState('');
  const [ward, setWard] = useState('');
  const [sanction, setSanction] = useState('');
  const [fs, setFs] = useState('');
  const [schemeId, setSchemeId] = useState(activeFunds.find((f) => f.id !== 'cash')?.id || activeFunds[0]?.id || 'sfc');
  const [asNo, setAsNo] = useState('');
  const [asDate, setAsDate] = useState('');
  const [tsNo, setTsNo] = useState('');
  const [tsDate, setTsDate] = useState('');
  const [fsNo, setFsNo] = useState('');
  const [fsDate, setFsDate] = useState('');
  const [start, setStart] = useState('');
  const [complete, setComplete] = useState('');
  const [mbStatus, setMbStatus] = useState<'pending' | 'complete'>('pending');
  const [mbNo, setMbNo] = useState('');
  const [mbPage, setMbPage] = useState('');
  const [mbVal, setMbVal] = useState('');
  const [mbLab, setMbLab] = useState('');
  const [mbHdr, setMbHdr] = useState('');
  const reset = () => {
    setName('');
    setWard('');
    setSanction('');
    setFs('');
    setAsNo('');
    setAsDate('');
    setTsNo('');
    setTsDate('');
    setFsNo('');
    setFsDate('');
    setStart('');
    setComplete('');
    setMbStatus('pending');
    setMbNo('');
    setMbPage('');
    setMbVal('');
    setMbLab('');
    setMbHdr('');
  };
  const num = (s: string) => {
    const n = Number(s.trim());
    return Number.isFinite(n) && n > 0 ? n : undefined;
  };
  const date = (s: string) => (isValidIsoDate(s.trim()) ? s.trim() : undefined);
  return (
    <>
      <Text style={styles.hint}>Instruction #8 — योजना, AS/TS/FS क्रमांक व दिनांक, शुरू/पूर्ण तिथि, MB स्थिति सब पूछे जाते हैं।</Text>
      <Field label="Work name *" value={name} onChangeText={setName} />
      <Field label="Ward / location" value={ward} onChangeText={setWard} />
      <Field label="Sanction reference (स्वीकृति सं.)" value={sanction} onChangeText={setSanction} />

      <Text style={styles.section}>योजना / Scheme (expense entry में यही auto select होगी)</Text>
      <SelectField
        label="योजना चुनें *"
        value={activeFunds.find((f) => f.id === schemeId)?.name || schemeId}
        options={activeFunds
          .filter((f) => f.id !== 'cash')
          .map((f) => ({ key: f.id, label: f.name, sub: f.shortName }))}
        onSelect={setSchemeId}
        hint="नकद (Cash) योजना नहीं — सिर्फ़ लेन-देन का माध्यम है।"
      />

      <Text style={styles.section}>स्वीकृतियाँ</Text>
      <View style={styles.row}>
        <Field label="A.S. क्रमांक (प्रशासनिक)" value={asNo} onChangeText={setAsNo} />
        <Field label="A.S. दिनांक" value={asDate} onChangeText={setAsDate} placeholder="YYYY-MM-DD" />
      </View>
      <View style={styles.row}>
        <Field label="T.S. क्रमांक (तकनीकी)" value={tsNo} onChangeText={setTsNo} />
        <Field label="T.S. दिनांक" value={tsDate} onChangeText={setTsDate} placeholder="YYYY-MM-DD" />
      </View>
      <View style={styles.row}>
        <Field label="F.S. क्रमांक (वित्तीय)" value={fsNo} onChangeText={setFsNo} />
        <Field label="F.S. दिनांक" value={fsDate} onChangeText={setFsDate} placeholder="YYYY-MM-DD" />
      </View>
      <Field label="FS वित्तीय स्वीकृति राशि (₹) — प्रपत्र-1 + CC min() rule" value={fs} onChangeText={setFs} keyboardType="numeric" />

      <Text style={styles.section}>कार्य अवधि</Text>
      <View style={styles.row}>
        <Field label="कार्य शुरू तिथि" value={start} onChangeText={setStart} placeholder="YYYY-MM-DD" />
        <Field label="कार्य पूर्ण तिथि" value={complete} onChangeText={setComplete} placeholder="YYYY-MM-DD" />
      </View>

      <Text style={styles.section}>MB स्थिति (माप पुस्तिका)</Text>
      <View style={styles.row}>
        <Btn label="लंबित (Pending)" variant={mbStatus === 'pending' ? 'primary' : 'outline'} onPress={() => setMbStatus('pending')} />
        <Btn label="पूर्ण (Complete)" variant={mbStatus === 'complete' ? 'primary' : 'outline'} onPress={() => setMbStatus('complete')} />
      </View>
      {mbStatus === 'complete' ? (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>MB विवरण</Text>
          <View style={styles.row}>
            <Field label="MB संख्या" value={mbNo} onChangeText={setMbNo} />
            <Field label="MB पृष्ठ संख्या" value={mbPage} onChangeText={setMbPage} />
          </View>
          <Field label="कुल मूल्यांकन राशि (₹)" value={mbVal} onChangeText={setMbVal} keyboardType="numeric" />
          <View style={styles.row}>
            <Field label="श्रम राशि (₹)" value={mbLab} onChangeText={setMbLab} keyboardType="numeric" />
            <Field label="सामग्री राशि (₹)" value={mbHdr} onChangeText={setMbHdr} keyboardType="numeric" />
          </View>
          <Text style={styles.meta}>सुझाव: ये आँकड़े MB lines (माप पुस्तिका) से मिलाकर रखें — CC पृष्ठ 1 यहीं से भरा जाता है।</Text>
        </View>
      ) : null}

      <Btn
        label="Add work"
        onPress={async () => {
          if (!name.trim()) return Alert.alert('Work name अनिवार्य');
          const id = await addWork({
            fyId: activeFy.id,
            name: name.trim(),
            schemeId,
            ward: ward.trim(),
            sanctionRef: sanction.trim(),
            fsAmount: num(fs),
            materialPrior: 0,
            labourPrior: 0,
            status: complete.trim() ? 'completed' : 'ongoing',
            asNo: asNo.trim() || undefined,
            asDate: date(asDate),
            tsNo: tsNo.trim() || undefined,
            tsDate: date(tsDate),
            fsNo: fsNo.trim() || undefined,
            fsDate: date(fsDate),
            startDate: date(start),
            completeDate: date(complete),
            mbStatus,
            mbNo: mbNo.trim() || undefined,
            mbPage: mbPage.trim() || undefined,
            mbValuation: num(mbVal),
            mbLabourAmount: num(mbLab),
            mbMaterialAmount: num(mbHdr),
          });
          const addedName = name.trim();
          reset();
          onAdded?.({ id, name: addedName });
        }}
      />
    </>
  );
}

function WorksScreen({ back, go }: { back: () => void; go: (s: Stage, workId?: string) => void }) {
  const { works, activeFy, activeFunds } = useStore();
  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  return (
    <View style={styles.page}>
      <Header title="Works" onBack={back} badge="S-18" />
      <ScrollView contentContainerStyle={styles.pad}>
        <WorkAddForm />
        {fyWorks.map((w) => (
          <Pressable key={w.id} style={styles.homeRow} onPress={() => go('workDetail', w.id)}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{w.name}</Text>
              <Text style={styles.meta}>
                {w.status} · योजना {activeFunds.find((f) => f.id === w.schemeId)?.name || w.schemeId}
                {w.ward ? ` · ward ${w.ward}` : ''}
                {w.sanctionRef ? ` · ${w.sanctionRef}` : ''}
                {w.fsAmount ? ` · FS ${formatINR(w.fsAmount)}` : ''}
                {w.mbStatus === 'complete' ? ' · MB ✓' : ''}
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
        {fyWorks.length === 0 ? <Empty title="No works" why="Is FY me work nahi" steps={['Add work name above', 'Open for MB / Bills / CC']} /> : null}
      </ScrollView>
    </View>
  );
}

function WorkDetailScreen({ back, workId, go }: { back: () => void; workId: string; go: (s: Stage, wid?: string) => void }) {
  const { works, mbLines, bills } = useStore();
  const w = works.find((x) => x.id === workId);
  if (!w) {
    // K.5: dead click nahi — empty state + steps
    return (
      <View style={styles.page}>
        <Header title="Work" onBack={back} badge="S-18" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="यह work delete/hide हो गया होगा" steps={['Works list पर वापस जाएँ', 'दूसरा work चुनें']} />
        </View>
      </View>
    );
  }
  const mb = mbLines.filter((m) => m.workId === workId);
  const bl = bills.filter((b) => b.workId === workId);
  const mbVal = mb.reduce((s, m) => s + m.qty * m.rate, 0);
  return (
    <View style={styles.page}>
      <Header title={w.name} onBack={back} badge="S-19" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.meta}>FS वित्तीय स्वीकृति: {w.fsAmount ? formatINR(w.fsAmount) : '— (Works me जोड़ें)'} · sanction {w.sanctionRef || '—'} · ward {w.ward || '—'}</Text>
        <Text style={styles.meta}>Prior material {formatINR(w.materialPrior)} · labour {formatINR(w.labourPrior)}</Text>
        <Text style={styles.cardTitle}>MB valuation {formatINR(mbVal)} ({mb.length} lines)</Text>
        <Text style={styles.meta}>Bills {bl.length}</Text>
        <Btn label="मन-डे स्वीकृति (नई / सूची)" icon="clipboard" onPress={() => go('manday', w.id)} />
        <Btn label="MB entry" variant="soft" onPress={() => go('mb')} />
        <Btn label="Bills" variant="soft" onPress={() => go('bills')} />
        <Btn label="CC (7 pages summary)" variant="outline" onPress={() => go('cc')} />
      </ScrollView>
    </View>
  );
}

function MbScreen({ back, workId, go }: { back: () => void; workId: string; go: (s: Stage, wid?: string) => void }) {
  const { addMbLine, mbLines, works } = useStore();
  const work = works.find((x) => x.id === workId);
  const [item, setItem] = useState('');
  const [qty, setQty] = useState('1');
  const [rate, setRate] = useState('0');
  /* instruction #3: दो अलग पक्ष — सामग्री / श्रम; कारीगर के लिए toggle (default श्रम पक्ष) */
  const [part, setPart] = useState<'material' | 'labour'>('labour');
  const [role, setRole] = useState<'labour' | 'karigar' | 'mate'>('labour');
  const [karigarInLabour, setKarigarInLabour] = useState(true);
  const lines = mbLines.filter((m) => m.workId === workId);
  const inMaterial = (m: MbLine) => m.kind === 'material' || (m.kind === 'artisan' && m.karigarIn === 'material');
  const matLines = lines.filter(inMaterial);
  const labLines = lines.filter((m) => !inMaterial(m));
  const sum = (l: MbLine[]) => l.reduce((s, m) => s + m.qty * m.rate, 0);
  const roleLabel = (m: MbLine) =>
    m.kind === 'material' ? 'सामग्री' : m.kind === 'artisan' ? (m.karigarIn === 'material' ? 'कारीगर (सामग्री में)' : 'कारीगर') : 'श्रम';
  if (!work) {
    return (
      <View style={styles.page}>
        <Header title="MB entry" onBack={back} badge="S-21" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="MB के लिए पहले work चुनें" steps={['Works list खोलें', 'कोई work चुनें']} />
        </View>
      </View>
    );
  }
  const save = () => {
    if (!item.trim()) return Alert.alert('मद चाहिए');
    const q = parseFloat(qty) || 0;
    const r = parseFloat(rate) || 0;
    // कारीगर: toggle decides — श्रम पक्ष (default) या सामग्री पक्ष
    const kind: MbLine['kind'] = part === 'material' ? 'material' : role === 'karigar' ? 'artisan' : 'labour';
    addMbLine({
      workId,
      itemName: item.trim(),
      qty: q,
      rate: r,
      kind: kind as MbLine['kind'],
      ...(role === 'karigar' && part === 'labour' ? { karigarIn: karigarInLabour ? ('labour' as const) : ('material' as const) } : {}),
    });
    setItem('');
    setQty('1');
    setRate('0');
  };
  return (
    <View style={styles.page}>
      <Header title="MB entry" onBack={back} badge="S-21" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{work.name}</Text>
        <Text style={styles.hint}>सामग्री और श्रम — दोनों पक्ष अलग-अलग group होते हैं (नीचे)।</Text>

        <Text style={styles.section}>नई पंक्ति</Text>
        <View style={styles.row}>
          <Btn label="सामग्री पक्ष" variant={part === 'material' ? 'primary' : 'outline'} onPress={() => setPart('material')} />
          <Btn label="श्रम पक्ष" variant={part === 'labour' ? 'primary' : 'outline'} onPress={() => setPart('labour')} />
        </View>
        {part === 'labour' ? (
          <View style={styles.row}>
            <Btn label="श्रमिक" variant={role === 'labour' ? 'primary' : 'outline'} onPress={() => setRole('labour')} />
            <Btn label="कारीगर" variant={role === 'karigar' ? 'primary' : 'outline'} onPress={() => setRole('karigar')} />
            <Btn label="मेट" variant={role === 'mate' ? 'primary' : 'outline'} onPress={() => setRole('mate')} />
          </View>
        ) : null}
        {part === 'labour' && role === 'karigar' ? (
          <View style={styles.card}>
            <Text style={styles.meta}>कारीगर किस part में जोड़ें? (default: श्रम पक्ष)</Text>
            <View style={styles.row}>
              <Btn label="श्रम पक्ष में" variant={karigarInLabour ? 'primary' : 'outline'} onPress={() => setKarigarInLabour(true)} />
              <Btn label="सामग्री पक्ष में" variant={!karigarInLabour ? 'primary' : 'outline'} onPress={() => setKarigarInLabour(false)} />
            </View>
          </View>
        ) : null}
        <Field label="Item / मद" value={item} onChangeText={setItem} placeholder="जैसे: सीमेंट, मजदूरी, गिट्टी 20 मिमी" />
        <View style={styles.row}>
          <Field label="Qty" value={qty} onChangeText={setQty} keyboardType="numeric" />
          <Field label="Rate" value={rate} onChangeText={setRate} keyboardType="numeric" />
        </View>
        <Btn label="MB line जोड़ें" icon="plus" onPress={save} />

        {/* instruction #3: दोनों parts की अलग-अलग grouping + उप-योग */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>सामग्री पक्ष ({matLines.length} lines) · योग {formatINR(sum(matLines))}</Text>
          {matLines.length === 0 ? (
            <Text style={styles.meta}>कोई सामग्री पंक्ति नहीं</Text>
          ) : (
            matLines.map((m) => (
              <Text key={m.id} style={styles.meta}>
                {m.itemName} · {m.qty} × {formatINR(m.rate)} = {formatINR(m.qty * m.rate)}
                {m.kind === 'artisan' ? ' · कारीगर (toggle = सामग्री)' : ''}
              </Text>
            ))
          )}
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>श्रम पक्ष ({labLines.length} lines) · योग {formatINR(sum(labLines))}</Text>
          {labLines.length === 0 ? (
            <Text style={styles.meta}>कोई श्रम पंक्ति नहीं</Text>
          ) : (
            labLines.map((m) => (
              <Text key={m.id} style={styles.meta}>
                {roleLabel(m)} · {m.itemName} · {m.qty} × {formatINR(m.rate)} = {formatINR(m.qty * m.rate)}
              </Text>
            ))
          )}
        </View>
        <View style={styles.summary}>
          <Text style={styles.sumLine}>MB मूल्यांकन = सामग्री {formatINR(sum(matLines))} + श्रम {formatINR(sum(labLines))} = {formatINR(sum(matLines) + sum(labLines))}</Text>
        </View>

        <Btn
          label="मन-डे स्वीकृति / गणना खोलें (अलग sanction)"
          variant="soft"
          icon="clipboard"
          onPress={() => go('manday', workId)}
        />
      </ScrollView>
    </View>
  );
}

/**
 * Instruction #4 — मन-डे स्वीकृति (work sanction ke andar ALAG se sanction):
 *  • desired amount (श्रम/कारीगर राशि) डालते ही desired wage rate + man-days auto
 *  • trial-and-error se nikattam amount ke 2–3 auto options — user ek select kare
 *  • BSR rate add na ho to amount enter karte hi BSR page khulta hai
 *    (labour + material items pehle se listed; sirf us saal ki rate bharni)
 */
function MandayScreen({ back, workId }: { back: () => void; workId: string }) {
  const {
    works,
    mbLines,
    bsrRates,
    workerRates,
    mandayCalcs,
    activeFy,
    itemMasters,
    addMandayCalc,
    deleteMandayCalc,
    addBsrRate,
    updateBsrRate,
    deleteBsrRate,
    addItemMaster,
    updateItemMaster,
    deleteItemMaster,
  } = useStore();
  const work = works.find((x) => x.id === workId);
  const [role, setRole] = useState<'karigar' | 'labour' | 'mate'>('labour');
  const [desired, setDesired] = useState('');
  const [sel, setSel] = useState<{ workers: number; days: number; rate: number; amount: number } | null>(null);
  const [bsrOpen, setBsrOpen] = useState(false);

  const D = parseFloat(desired) || 0;
  const ref = referenceRate(bsrRates, workerRates, activeFy.label, role);
  const R = ref.rate || 0;

  // BSR rate add nahi hai → amount enter karte hi BSR page open (instruction #4)
  React.useEffect(() => {
    if (D > 0 && !R) setBsrOpen(true);
  }, [D, R]);

  // MB component limit (rule: role ki amount MB us-role component se zyada nahi)
  const mbKind: MbLine['kind'] = role === 'karigar' ? 'artisan' : 'labour';
  const mbComponent = mbLines.filter((m) => m.workId === workId && m.kind === mbKind).reduce((s, m) => s + m.qty * m.rate, 0);

  // 2–3 auto options: safe-band rates (पूर्ण BSR / −10% / −20%) par nikattam amount
  const options = React.useMemo(() => {
    if (!(D > 0) || !(R > 0)) return [] as { workers: number; days: number; rate: number; amount: number; remaining: number }[];
    const rates = [R, Math.round(R * 0.9), Math.round(R * 0.8)].filter((v, i, a) => v > 0 && a.indexOf(v) === i);
    const out: { workers: number; days: number; rate: number; amount: number; remaining: number }[] = [];
    for (const rate of rates) {
      const totalMd = Math.floor(D / rate);
      if (totalMd < 1) continue;
      let best: { workers: number; days: number; rate: number; amount: number; remaining: number } | null = null;
      for (const w of [1, 2, 3, 4, 5, 6, 8, 10]) {
        const d = Math.floor(totalMd / w);
        if (d < 1) continue;
        const amount = w * d * rate;
        if (amount > D + 0.001) continue;
        const c = { workers: w, days: d, rate, amount, remaining: Math.round((D - amount) * 100) / 100 };
        if (!best || c.remaining < best.remaining) best = c;
      }
      if (best) out.push(best);
    }
    out.sort((a, b) => a.remaining - b.remaining);
    return out.slice(0, 3);
  }, [D, R]);

  const rc = sel ? rateCheck(sel.rate, R || null) : { ok: true, warn: null as string | null };
  const calcList = mandayCalcs.filter((c) => c.workId === workId);
  if (!work) {
    return (
      <View style={styles.page}>
        <Header title="मन-डे स्वीकृति" onBack={back} badge="S-22" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="स्वीकृति के लिए पहले work चुनें" steps={['Works list खोलें', 'कोई work चुनें']} />
        </View>
      </View>
    );
  }
  return (
    <View style={styles.page}>
      <Header
        title="मन-डे स्वीकृति"
        onBack={back}
        badge="S-22"
        action={<IconBtn name="sliders" onPress={() => setBsrOpen(true)} />}
      />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{work.name}</Text>
        <Text style={styles.hint}>
          यह work की अलग sanction है — श्रम/कारीगर राशि डालते ही दर और मान-दिवस अपने आप। नीचे 2–3 विकल्पों में से चुनें।
        </Text>

        <Text style={styles.section}>भूमिका (role)</Text>
        <View style={styles.row}>
          <Btn label="श्रमिक" variant={role === 'labour' ? 'primary' : 'outline'} onPress={() => { setRole('labour'); setSel(null); }} />
          <Btn label="कारीगर" variant={role === 'karigar' ? 'primary' : 'outline'} onPress={() => { setRole('karigar'); setSel(null); }} />
          <Btn label="मेट" variant={role === 'mate' ? 'primary' : 'outline'} onPress={() => { setRole('mate'); setSel(null); }} />
        </View>

        <Field label="चाहिए राशि / desired amount (₹)" value={desired} onChangeText={(t) => { setDesired(t); setSel(null); }} keyboardType="numeric" />
        {R > 0 ? (
          <Text style={styles.meta}>
            मानक दर ₹{R}/दिन ({ref.source === 'BSR' ? `BSR ${activeFy.label}` : 'Worker master'}) · safe band ₹{Math.round(R * 0.8)}–₹
            {Math.round(R * 0.9)}
          </Text>
        ) : (
          <View style={styles.card}>
            <Text style={styles.err}>BSR दर इस साल ({activeFy.label}) के लिए add नहीं है — नीचे BSR पृष्ठ खुल रहा है।</Text>
            <Btn label={`BSR दर भरें (${activeFy.label})`} icon="sliders" onPress={() => setBsrOpen(true)} />
          </View>
        )}

        {options.length > 0 ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Auto विकल्प — desired राशि के निकटतम (एक चुनें)</Text>
            {options.map((o, i) => {
              const on = sel && sel.rate === o.rate && sel.workers === o.workers && sel.days === o.days;
              return (
                <Pressable
                  key={i}
                  onPress={() => setSel(o)}
                  style={[styles.field, { borderColor: on ? C.primary : C.border, borderWidth: on ? 2 : 1, marginBottom: 8 }]}
                >
                  <Text style={{ fontWeight: '800', color: C.foreground }}>
                    {on ? '✓ ' : ''}{o.workers} × {o.days} दिन × ₹{o.rate} = {formatINR(o.amount)}
                  </Text>
                  <Text style={styles.meta}>शेष {formatINR(o.remaining)} (दर श्रेणी: {o.rate === R ? 'पूर्ण BSR' : o.rate === Math.round(R * 0.9) ? 'BSR−10%' : 'BSR−20%'})</Text>
                </Pressable>
              );
            })}
          </View>
        ) : D > 0 && R > 0 ? <Text style={styles.meta}>इस राशि पर मान-दिवस नहीं बनता — राशि बढ़ाएँ।</Text> : null}

        {rc.warn ? <Text style={styles.err}>{rc.warn}</Text> : null}
        {sel && mbComponent > 0 && sel.amount > mbComponent ? (
          <Text style={styles.err}>राशि {formatINR(sel.amount)} MB श्रम घटक ({formatINR(mbComponent)}) से अधिक — अनुमति नहीं</Text>
        ) : null}
        {sel ? (
          <Btn
            label="यह स्वीकृति save करें (audit trail)"
            icon="check"
            onPress={() => {
              if (mbComponent > 0 && sel.amount > mbComponent) return Alert.alert('MB component से अधिक');
              addMandayCalc({
                workId,
                role,
                workers: sel.workers,
                days: sel.days,
                rate: sel.rate,
                bsrYear: activeFy.label,
                amount: sel.amount,
                mbComponentAmount: mbComponent,
              });
              setDesired('');
              setSel(null);
            }}
          />
        ) : null}

        <Text style={styles.section}>स्वीकृतियाँ ({calcList.length})</Text>
        {calcList.map((c) => (
          <View key={c.id} style={[styles.card, { flexDirection: 'row', alignItems: 'center', gap: 8 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>
                {c.role === 'karigar' ? 'कारीगर' : c.role === 'mate' ? 'मेट' : 'श्रमिक'}: {c.workers} × {c.days} × ₹{c.rate} = {formatINR(c.amount)}
              </Text>
              <Text style={styles.meta}>BSR {c.bsrYear} · MB घटक {formatINR(c.mbComponentAmount)} · {c.createdAt.slice(0, 10)}</Text>
            </View>
            <IconBtn name="trash-2" onPress={() => deleteMandayCalc(c.id)} />
          </View>
        ))}
        {calcList.length === 0 ? <Empty title="अभी कोई स्वीकृति नहीं" why="ऊपर desired amount भरकर एक विकल्प चुनें" steps={['राशि भरें', 'विकल्प चुनें', 'Save करें']} /> : null}
      </ScrollView>

      {/* BSR quick page — sirf active FY ki rate bharni; items add/edit/delete */}
      <BsrYearSheet
        open={bsrOpen}
        onClose={() => setBsrOpen(false)}
        year={activeFy.label}
        bsrRates={bsrRates}
        itemMasters={itemMasters}
        addBsrRate={addBsrRate}
        updateBsrRate={updateBsrRate}
        deleteBsrRate={deleteBsrRate}
        addItemMaster={addItemMaster}
        updateItemMaster={updateItemMaster}
        deleteItemMaster={deleteItemMaster}
      />
    </View>
  );
}

type BsrRow = { key: string; name: string; unit: string; rate: string; bsrId?: string; itemMasterId?: string };

/** BSR page (instruction #4): items pehle se listed — sirf us year ki rate bharni + item add/edit/delete */
function BsrYearSheet({
  open,
  onClose,
  year,
  bsrRates,
  itemMasters,
  addBsrRate,
  updateBsrRate,
  deleteBsrRate,
  addItemMaster,
  updateItemMaster,
  deleteItemMaster,
}: {
  open: boolean;
  onClose: () => void;
  year: string;
  bsrRates: ReturnType<typeof useStore>['bsrRates'];
  itemMasters: ReturnType<typeof useStore>['itemMasters'];
  addBsrRate: ReturnType<typeof useStore>['addBsrRate'];
  updateBsrRate: ReturnType<typeof useStore>['updateBsrRate'];
  deleteBsrRate: ReturnType<typeof useStore>['deleteBsrRate'];
  addItemMaster: ReturnType<typeof useStore>['addItemMaster'];
  updateItemMaster: ReturnType<typeof useStore>['updateItemMaster'];
  deleteItemMaster: ReturnType<typeof useStore>['deleteItemMaster'];
}) {
  const buildRows = React.useCallback((): BsrRow[] => {
    const rows: BsrRow[] = [];
    const seen = new Set<string>();
    const yr = bsrRates.filter((b) => b.year === year);
    for (const t of BSR_TEMPLATE) {
      const b = yr.find((x) => x.itemName.toLowerCase() === t.name.toLowerCase());
      rows.push({ key: 't_' + t.name, name: t.name, unit: b?.unit || t.unit, rate: b ? String(b.rate) : '', bsrId: b?.id });
      seen.add(t.name.toLowerCase());
    }
    for (const im of itemMasters) {
      if (seen.has(im.name.toLowerCase())) continue;
      const b = yr.find((x) => x.itemName.toLowerCase() === im.name.toLowerCase());
      rows.push({ key: 'i_' + im.id, name: im.name, unit: b?.unit || 'नग', rate: b ? String(b.rate) : '', bsrId: b?.id, itemMasterId: im.id });
      seen.add(im.name.toLowerCase());
    }
    for (const b of yr) {
      if (seen.has(b.itemName.toLowerCase())) continue;
      rows.push({ key: 'b_' + b.id, name: b.itemName, unit: b.unit, rate: String(b.rate), bsrId: b.id });
      seen.add(b.itemName.toLowerCase());
    }
    return rows;
  }, [bsrRates, itemMasters, year]);

  const [rows, setRows] = React.useState<BsrRow[]>(buildRows);
  const [newName, setNewName] = useState('');
  const [newUnit, setNewUnit] = useState('नग');
  const [edit, setEdit] = useState<{ key: string; name: string; unit: string } | null>(null);

  React.useEffect(() => {
    if (open) setRows(buildRows());
  }, [open, buildRows]);

  const saveAll = async () => {
    for (const r of rows) {
      const rate = parseFloat(r.rate);
      if (!Number.isFinite(rate) || !(rate > 0)) continue;
      if (r.bsrId) await updateBsrRate(r.bsrId, { rate, unit: r.unit, itemName: r.name, year });
      else await addBsrRate({ year, itemName: r.name, unit: r.unit, rate });
    }
    setRows(buildRows());
    Alert.alert('सहेजा गया', `${year} की दरें update हो गईं`);
  };

  return (
    <Modal visible={open} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalBg}>
        <View style={[styles.modalCard, { maxHeight: '92%' }]}>
          <Text style={styles.modalTitle}>BSR दर — {year}</Text>
          <Text style={styles.meta}>सिर्फ़ इसी साल की दर भरें; बाक़ी साल की दरें वैसी ही रहेंगी (read-only)।</Text>
          <ScrollView style={{ maxHeight: 420 }}>
            {rows.map((r) => (
              <View key={r.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                <Pressable
                  style={{ flex: 1 }}
                  onPress={() => (r.itemMasterId || !r.bsrId ? setEdit({ key: r.key, name: r.name, unit: r.unit }) : undefined)}
                >
                  <Text style={{ fontWeight: '700', color: C.foreground }} numberOfLines={1}>{r.name}</Text>
                  <Text style={{ fontSize: 11, color: C.mutedForeground }}>{r.unit}{r.itemMasterId ? ' · टैप कर edit' : ''}</Text>
                </Pressable>
                <TextInput
                  value={r.rate}
                  onChangeText={(t) => setRows((prev) => prev.map((x) => (x.key === r.key ? { ...x, rate: t } : x)))}
                  keyboardType="numeric"
                  placeholder="दर"
                  placeholderTextColor={C.mutedForeground}
                  style={[styles.field, { width: 96, marginVertical: 0 }]}
                />
                {r.itemMasterId ? (
                  <IconBtn
                    name="trash-2"
                    onPress={() => {
                      deleteItemMaster(r.itemMasterId!);
                      if (r.bsrId) deleteBsrRate(r.bsrId);
                      setRows((prev) => prev.filter((x) => x.key !== r.key));
                    }}
                  />
                ) : null}
              </View>
            ))}
          </ScrollView>
          <View style={styles.row}>
            <Field label="नया मद" value={newName} onChangeText={setNewName} />
            <Field label="इकाई" value={newUnit} onChangeText={setNewUnit} />
          </View>
          <Btn
            label="+ मद जोड़ें (list में आ जाएगा)"
            variant="soft"
            onPress={() => {
              if (!newName.trim()) return Alert.alert('मद का नाम चाहिए');
              addItemMaster({ name: newName.trim(), wholeNumberOnly: false, lastBillOnly: false, basicItem: false });
              setRows((prev) => [...prev, { key: 'n_' + Date.now(), name: newName.trim(), unit: newUnit.trim() || 'नग', rate: '' }]);
              setNewName('');
            }}
          />
          <Btn label="सभी दरें सहेजें" icon="save" onPress={saveAll} />
          <Btn label="बंद करें" variant="outline" onPress={onClose} />
        </View>
      </View>
      {/* item edit */}
      <Modal visible={!!edit} transparent animationType="fade" onRequestClose={() => setEdit(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>मद edit करें</Text>
            <Field label="नाम" value={edit?.name || ''} onChangeText={(t) => setEdit((e) => (e ? { ...e, name: t } : e))} />
            <Field label="इकाई" value={edit?.unit || ''} onChangeText={(t) => setEdit((e) => (e ? { ...e, unit: t } : e))} />
            <Btn
              label="सहेजें"
              onPress={() => {
                if (!edit) return;
                const row = rows.find((x) => x.key === edit.key);
                if (row) {
                  if (row.itemMasterId) updateItemMaster(row.itemMasterId, { name: edit.name.trim() });
                  if (row.bsrId) updateBsrRate(row.bsrId, { itemName: edit.name.trim(), unit: edit.unit.trim() });
                  setRows((prev) => prev.map((x) => (x.key === edit.key ? { ...x, name: edit.name.trim(), unit: edit.unit.trim() } : x)));
                }
                setEdit(null);
              }}
            />
            <Btn label="रद्द" variant="outline" onPress={() => setEdit(null)} />
          </View>
        </View>
      </Modal>
    </Modal>
  );
}

function BillsScreen({ back, workId }: { back: () => void; workId: string }) {
  const { addBill, bills, activeFy, vendors, addVendor, deleteVendor } = useStore();
  const [vendor, setVendor] = useState('');
  const [amount, setAmount] = useState('');
  const [billDate, setBillDate] = useState(toIsoLocal(new Date()));
  const [payDate, setPayDate] = useState('');
  const [pageRef, setPageRef] = useState('');
  const [note, setNote] = useState('');
  /* instruction #5: vendor = dropdown; list me na ho to wahin se add */
  const [vAddOpen, setVAddOpen] = useState(false);
  const [nvName, setNvName] = useState('');
  const [nvPhone, setNvPhone] = useState('');
  const [nvKind, setNvKind] = useState<'material' | 'labour' | 'other'>('material');
  const activeVendors = vendors.filter((v) => !v.archived);
  const list = bills.filter((b) => b.workId === workId);
  return (
    <View style={styles.page}>
      <Header title="Bills" onBack={back} badge="S-25" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>H — Bill register date-wise: bill date + cashbook payment date + page ref</Text>
        <SelectField
          label="Vendor (dropdown)"
          value={vendor}
          placeholder="vendor चुनें"
          options={activeVendors.map((v) => ({ key: v.id, label: v.name, sub: v.phone || undefined }))}
          onSelect={(id) => {
            const v = vendors.find((x) => x.id === id);
            if (v) setVendor(v.name);
          }}
          onAddNew={() => setVAddOpen(true)}
          addNewLabel="+ नया vendor जोड़ें (dropdown list में आ जाएगा)"
        />
        <Field label="Amount" value={amount} onChangeText={setAmount} keyboardType="numeric" />
        <Field label="Bill date (YYYY-MM-DD)" value={billDate} onChangeText={setBillDate} />
        <Field label="Cashbook payment date (YYYY-MM-DD, भुगतान के बाद)" value={payDate} onChangeText={setPayDate} placeholder="2026-09-24" />
        <Field label="Cashbook page ref" value={pageRef} onChangeText={setPageRef} placeholder="पृष्ठ 3" />
        <Field label="Note" value={note} onChangeText={setNote} multiline />
        <Btn
          label="Add bill"
          onPress={() => {
            if (!vendor.trim()) return Alert.alert('Vendor चुनें या जोड़ें');
            const n = Number(amount.trim());
            if (!Number.isFinite(n) || !(n > 0)) return Alert.alert('राशि > 0 चाहिए');
            if (!isValidIsoDate(billDate)) return Alert.alert('Bill date अमान्य (YYYY-MM-DD)');
            if (payDate && !isValidIsoDate(payDate)) return Alert.alert('Payment date अमान्य (YYYY-MM-DD)');
            addBill({
              workId,
              fyId: activeFy.id,
              billDate,
              paymentDate: payDate || billDate,
              pageRef: pageRef.trim(),
              vendor: vendor.trim(),
              amount: n,
              note: note.trim(),
            });
            setVendor('');
            setAmount('');
            setPageRef('');
            setNote('');
          }}
        />
        <Text style={styles.section}>Vendor master ({activeVendors.length})</Text>
        {activeVendors.map((v) => (
          <View key={v.id} style={[styles.card, { flexDirection: 'row', alignItems: 'center', gap: 8 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{v.name}</Text>
              <Text style={styles.meta}>
                {v.kind === 'material' ? 'सामग्री विक्रेता' : v.kind === 'labour' ? 'ठेकेदार/श्रम' : 'अन्य'}
                {v.phone ? ` · ${v.phone}` : ''}
              </Text>
            </View>
            <IconBtn name="trash-2" onPress={async () => { const r = await deleteVendor(v.id); if (!r.ok && r.error) Alert.alert(r.error); }} />
          </View>
        ))}
        {list.map((b) => (
          <View key={b.id} style={styles.card}>
            <Text style={styles.cardTitle}>
              {b.billDate} · {b.vendor} · {formatINR(b.amount)}
            </Text>
            <Text style={styles.meta}>
              भुगतान {b.paymentDate || '—'} · page {b.pageRef || '—'} {b.note ? ` · ${b.note}` : ''}
            </Text>
          </View>
        ))}
        {list.length === 0 ? <Empty title="कोई bill नहीं" why="इस work पर अभी bill add नहीं हुआ" steps={['Vendor dropdown से चुनें', 'राशि भरकर Add bill']} /> : null}
      </ScrollView>
      {/* instruction #5: dropdown list me na mile to yahin se add */}
      <Modal visible={vAddOpen} transparent animationType="fade" onRequestClose={() => setVAddOpen(false)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>नया vendor जोड़ें</Text>
            <Field label="Vendor नाम" value={nvName} onChangeText={setNvName} placeholder="जैसे: शर्मा ट्रेडर्स" />
            <Field label="फोन (वैकल्पिक)" value={nvPhone} onChangeText={setNvPhone} keyboardType="numeric" />
            <Text style={styles.fieldLabel}>प्रकार</Text>
            <View style={styles.row}>
              <Btn label="सामग्री" variant={nvKind === 'material' ? 'primary' : 'outline'} onPress={() => setNvKind('material')} />
              <Btn label="ठेकेदार" variant={nvKind === 'labour' ? 'primary' : 'outline'} onPress={() => setNvKind('labour')} />
              <Btn label="अन्य" variant={nvKind === 'other' ? 'primary' : 'outline'} onPress={() => setNvKind('other')} />
            </View>
            <Btn
              label="सहेजें और चुनें"
              onPress={async () => {
                if (!nvName.trim()) return Alert.alert('नाम चाहिए');
                await addVendor({ name: nvName.trim(), phone: nvPhone.trim() || undefined, kind: nvKind });
                setVendor(nvName.trim());
                setNvName('');
                setNvPhone('');
                setVAddOpen(false);
              }}
            />
            <Btn label="रद्द करें" variant="outline" onPress={() => setVAddOpen(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

function CcScreen({ back, workId }: { back: () => void; workId: string }) {
  const { works, mbLines, bills, workerRolls, fyTransactions, activePanchayat, activeFy, activeFunds, addWorkerRoll } = useStore();
  const w0 = works.find((x) => x.id === workId);
  const [fs, setFs] = useState(w0?.fsAmount ? String(w0.fsAmount) : '');
  const [asAmt, setAsAmt] = useState('');
  const [as, setAs] = useState('');
  const [from, setFrom] = useState(toIsoLocal(new Date()));
  const [to, setTo] = useState(toIsoLocal(new Date()));
  const [rollNo, setRollNo] = useState('');
  const [mate, setMate] = useState('0');
  const [skilled, setSkilled] = useState('0');
  const [unskilled, setUnskilled] = useState('0');
  const [days, setDays] = useState('1');
  const [wMate, setWMate] = useState('0');
  const [wSkilled, setWSkilled] = useState('0');
  const [wUnskilled, setWUnskilled] = useState('0');
  const w = works.find((x) => x.id === workId);
  if (!w) {
    return (
      <View style={styles.page}>
        <Header title="CC (7 pages)" onBack={back} badge="S-26" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="CC के लिए पहले work चुनें" steps={['Works list खोलें', 'कोई work चुनें']} />
        </View>
      </View>
    );
  }
  const rolls = workerRolls.filter((r) => r.workId === workId);
  const c = ccBuild({ work: w, mbLines, bills, rolls, txs: fyTransactions, fsAmount: parseFloat(fs) || w.fsAmount || 0, asAmount: parseFloat(asAmt) || 0 });
  /* instruction #6 — CC ke 7 pages exactly Excel jaisa, share me PDF ya Excel */
  const hdr: FmtHeader = {
    panchayat: activePanchayat.name,
    block: activePanchayat.block,
    district: activePanchayat.district,
    fy: activeFy.label,
    formName: 'कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ)',
  };
  const fundName = activeFunds.find((f) => f.id === w.schemeId)?.name || w.schemeId;
  const share = async () => {
    const body = ccPagesHtml({
      header: hdr,
      work: w,
      c,
      mbLines,
      rolls,
      bills,
      fundName,
      bsrYear: activeFy.label,
      mbNo: w.mbNo,
      mbPage: w.mbPage,
      asNo: w.asNo,
      asDate: w.asDate,
      tsNo: w.tsNo,
      tsDate: w.tsDate,
      fsNo: w.fsNo,
      fsDate: w.fsDate,
    });
    await askAndShare(`CC — ${w.name}`, body);
  };
  const num = (s: string) => parseFloat(s) || 0;
  return (
    <View style={styles.page}>
      <Header title="CC (7 pages)" onBack={back} badge="S-26" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{w.name}</Text>
        <Text style={styles.hint}>{CC_INSTRUCTIONS}</Text>
        <View style={styles.row}>
          <Field label="FS राशि (वित्तीय स्वीकृति)" value={fs} onChangeText={setFs} keyboardType="numeric" />
        </View>
        <View style={styles.row}>
          <Field label="AS/TS राशि (min limit)" value={asAmt} onChangeText={setAsAmt} keyboardType="numeric" />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 1 — कार्य पूर्णता प्रमाण पत्र</Text>
          <Text style={styles.meta}>वास्तविक व्यय (लेखे अनुसार): {formatINR(c.actualExpense)}</Text>
          <Text style={styles.meta}>मूल्यांकन राशि (MB): {formatINR(c.mulyaankan)}</Text>
          <Text style={styles.meta}>श्रम: {formatINR(c.labour)} · सामग्री: {formatINR(c.material)}</Text>
          <Text style={styles.cardTitle}>कुल अनुमत राशि = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)</Text>
          <Text style={styles.sumLine}>{formatINR(c.allowable)}</Text>
          <Text style={styles.meta}>भुगतान योग्य शेष (अनुमत − payments): {formatINR(c.residualMaterial)}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 3 — श्रमिक विवरण (पाक्षिक मस्टरोल)</Text>
          <Text style={styles.meta}>मानव दिवस = श्रमिक संख्या × दिन; व्यय = मानव दिवस × मजदूरी दर (निर्देशिका 2010 अनुसार)</Text>
          {rolls.map((r) => (
            <Text key={r.id} style={styles.meta}>
              {r.fromDate}→{r.toDate} roll {r.rollNo || '—'}: मेट {r.mateCount}×{r.days}द · कुशल {r.skilledCount}×{r.days}द · अकुशल {r.unskilledCount}×{r.days}द ={' '}
              {formatINR(r.mateCount * r.days * r.wageMate + r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled)}
            </Text>
          ))}
          <Text style={styles.sumLine}>कुल श्रम व्यय (rolls): {formatINR(c.mandays.wage)}</Text>
          <Text style={styles.meta}>MB श्रम मद: {formatINR(c.labour)}</Text>
          <Field label="मस्टरोल क्रमांक" value={rollNo} onChangeText={setRollNo} />
          <View style={styles.row}>
            <Field label="दिनांक से" value={from} onChangeText={setFrom} />
            <Field label="दिनांक तक" value={to} onChangeText={setTo} />
          </View>
          <View style={styles.row}>
            <Field label="मेट संख्या" value={mate} onChangeText={setMate} keyboardType="numeric" />
            <Field label="कुशल" value={skilled} onChangeText={setSkilled} keyboardType="numeric" />
            <Field label="अकुशल" value={unskilled} onChangeText={setUnskilled} keyboardType="numeric" />
          </View>
          <View style={styles.row}>
            <Field label="दिन" value={days} onChangeText={setDays} keyboardType="numeric" />
            <Field label="मेट दर" value={wMate} onChangeText={setWMate} keyboardType="numeric" />
          </View>
          <View style={styles.row}>
            <Field label="कुशल दर" value={wSkilled} onChangeText={setWSkilled} keyboardType="numeric" />
            <Field label="अकुशल दर" value={wUnskilled} onChangeText={setWUnskilled} keyboardType="numeric" />
          </View>
          <Btn
            label="पाक्षिक roll जोड़ें"
            onPress={() =>
              addWorkerRoll({
                workId,
                fyId: activeFy.id,
                fromDate: from,
                toDate: to,
                rollNo,
                mateCount: num(mate),
                skilledCount: num(skilled),
                unskilledCount: num(unskilled),
                days: num(days) || 1,
                wageMate: num(wMate),
                wageSkilled: num(wSkilled),
                wageUnskilled: num(wUnskilled),
              })
            }
          />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 4 — सामग्री विवरण (MB अनुसार)</Text>
          {mbLines.filter((m) => m.workId === workId && m.kind === 'material').map((m) => (
            <Text key={m.id} style={styles.meta}>
              {m.itemName} · {m.qty} × {formatINR(m.rate)} = {formatINR(m.qty * m.rate)}
            </Text>
          ))}
          <Text style={styles.sumLine}>सामग्री योग: {formatINR(c.material)}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 2 · 5 · 6 · 7</Text>
          <Text style={styles.meta}>2 — उपयोगिता प्रमाण पत्र: व्यय {formatINR(c.actualExpense)} / अनुमत {formatINR(c.allowable)}</Text>
          <Text style={styles.meta}>5 — तकनीकी निरीक्षण: ग्रामीण कार्य निर्देशिका 2010 प्रावधानों अनुसार मूल्यांकन सत्यापित</Text>
          <Text style={styles.meta}>6 — पूर्ण कार्य फोटो + हस्ताक्षर (सरपंच, VDO, कनिष्ठ अभियंता)</Text>
          <Text style={styles.meta}>7 — पहले व कार्य के दौरान फोटो</Text>
        </View>
        <Btn label="CC PDF / Excel (7 pages) — share" icon="share-2" onPress={share} />
      </ScrollView>
    </View>
  );
}

function FormatsScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, categories, activeFunds, totalOpening, activePanchayat, activeFy, works, mbLines, bills, bankLines, workerRolls, vendors, bankAccounts } = useStore();
  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;
  const fundNames: Record<string, string> = {};
  for (const f of activeFunds) fundNames[f.id] = f.name;
  const hdr = {
    panchayat: activePanchayat.name,
    block: activePanchayat.block,
    district: activePanchayat.district,
    fy: activeFy.label,
  };
  /* instruction #12 — har प्रपत्र: share me PDF ya Excel (Excel-type format, original dikhta hua) */
  const mkHdr = (formName: string): FmtHeader => ({ ...hdr, formName });
  const g = buildGoswara(fyTransactions, catNames, totalOpening);
  const p1 = buildPrapt1(works.filter((w) => w.fyId === activeFy.id), mbLines, fyTransactions, fundNames, (w) => w.materialPrior + w.labourPrior);
  const p4 = buildPrapt4(mbLines);
  /* प्रपत्र-2 (श्रम) — pakhwada rolls से: प्रति role एक row (श्रमिक × दिन × दर) */
  const nameOfWork = (id: string) => works.find((w) => w.id === id)?.name || id;
  const p2: { workName: string; workers: number; days: number; rate: number; amount: number; role?: string }[] = [];
  for (const r of workerRolls.filter((x) => x.fyId === activeFy.id)) {
    const groups: [number, number, string][] = [
      [r.mateCount, r.wageMate, 'मेट'],
      [r.skilledCount, r.wageSkilled, 'कुशल'],
      [r.unskilledCount, r.wageUnskilled, 'अकुशल'],
    ];
    for (const [count, wage, role] of groups) {
      if (count > 0 && wage > 0) {
        p2.push({ workName: nameOfWork(r.workId), workers: count, days: r.days, rate: wage, amount: Math.round(count * r.days * wage * 100) / 100, role });
      }
    }
  }
  const fyBankLines = bankLines.filter((l) => l.fyId === activeFy.id);
  /* बैंक विवरण (#13) — दिनांक/विवरण/संदर्भ/जमा/नाम/शेष + tagging */
  const bankBody = () => {
    let bal = 0;
    const rows = [...fyBankLines]
      .filter((l) => !l.ignored)
      .sort((a, b) => a.date.localeCompare(b.date))
      .map((l) => {
        bal += l.side === 'credit' ? l.amount : -l.amount;
        const w = works.find((x) => x.id === l.workId);
        const v = vendors.find((x) => x.id === l.vendorId);
        const h = categories.find((x) => x.id === l.categoryId);
        const s = activeFunds.find((x) => x.id === l.schemeId);
        return {
          date: l.date,
          narration: l.narration,
          instrument: l.instrument,
          deposit: l.side === 'credit' ? l.amount : 0,
          withdrawal: l.side === 'debit' ? l.amount : 0,
          balance: Math.round(bal * 100) / 100,
          scheme: s?.name,
          work: w?.name,
          vendor: v?.name,
          head: h?.name,
          note: l.note,
          posted: !!l.postedTxnId,
        };
      });
    const acc = bankAccounts[0];
    return bankStatementHtml({
      header: mkHdr('बैंक विवरण (Bank statement)'),
      accountName: acc?.name || '—',
      accountNo: acc?.accountNo || '—',
      bankName: acc?.bankName || '—',
      rows,
    });
  };
  const goswaraBody = () => {
    const fyBank = bankLines.filter((l) => l.fyId === activeFy.id && !l.ignored);
    const antimBank = fyBank.reduce((s, l) => s + (l.side === 'credit' ? l.amount : -l.amount), 0);
    return goswaraHtml({
      header: mkHdr('वार्षिक आय-व्यय सामान्य रोकड़ बही'),
      rows: g.rows,
      aayYog: g.aayYog,
      vyayYog: g.vyayYog,
      prarambhikNagad: g.prarambhikNagad,
      prarambhikBank: 0,
      antimNagad: Math.round((g.antSheshNagad - antimBank) * 100) / 100,
      antimBank: Math.round(antimBank * 100) / 100,
    });
  };
  const ledgerBody = () =>
    ledgerHtml({ header: mkHdr('खाता बही — सभी योजनाएँ'), rows: buildLedger(totalOpening, fyTransactions) });
  return (
    <View style={styles.page}>
      <Header title="प्रपत्र / Formats Centre" onBack={back} badge="S-28" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          आपकी demo files के अनुसार — हर format entries से auto-update होता है (ledger की तरह, कोई generate step नहीं)। Share/Excel me kholen.
        </Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>गोशवारा — वार्षिक आय-व्यय सामान्य रोकड़ बही</Text>
          <Text style={styles.meta}>
            मद {g.rows.length} · आय योग {formatINR(g.aayYog)} · व्यय योग {formatINR(g.vyayYog)} · अंतिम शेष {formatINR(g.antSheshNagad)}
          </Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() => askAndShare('गोशवारा (रोकड़ बही)', goswaraBody(), true)}
            />
            <Btn label="Open" variant="outline" onPress={() => go('goswara')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Ledger — खाता बही</Text>
          <Text style={styles.meta}>श्री पोते → जमा/नाम → शेष (ledger.pdf layout, दो-पक्षीय)</Text>
          <View style={styles.row}>
            <Btn label="PDF / Excel" icon="share-2" onPress={() => askAndShare('खाता बही (Ledger)', ledgerBody(), true)} />
            <Btn label="Open" variant="outline" onPress={() => go('ledgers')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-1 — SFC/TFC/FFC/BRGF कार्य विवरण</Text>
          <Text style={styles.meta}>कार्य {p1.length} · FS/व्यय/मूल्यांकन/स्थिति auto</Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() =>
                askAndShare(
                  'प्रपत्र-1',
                  prapt1Html(p1, mkHdr('SFC/TFC/FFC/BRGF योजनाओं में कार्यों का विवरण — प्रपत्र-1')),
                  true
                )
              }
            />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-2 — निर्माण कार्यों पर व्यय श्रम राशि</Text>
          <Text style={styles.meta}>श्रम rows {p2.length} · मानव दिवस × दर (पाक्षिक rolls से)</Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() => askAndShare('प्रपत्र-2', prapt2Html(p2, mkHdr('निर्माण कार्यों पर व्यय की गयी श्रम राशि — प्रपत्र-2')))}
            />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-4 — निर्माण सामग्री विवरण</Text>
          <Text style={styles.meta}>सामग्री मद {p4.length} · योग {formatINR(p4.reduce((s, r) => s + r.cost, 0))}</Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() => askAndShare('प्रपत्र-4', prapt4Html(p4, mkHdr('निर्माण कार्यों पर व्यय सामग्री — प्रपत्र-4')))}
            />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Bank statement (बैंक विवरण)</Text>
          <Text style={styles.meta}>Lines {fyBankLines.length} · दिनांक/विवरण/संदर्भ/जमा/नाम/शेष + tagging</Text>
          <View style={styles.row}>
            <Btn label="PDF / Excel" icon="share-2" onPress={() => askAndShare('बैंक विवरण', bankBody(), true)} />
            <Btn label="Open" variant="outline" onPress={() => go('bank')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>CC — कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ)</Text>
          <Text style={styles.meta}>Works {works.filter((w) => w.fyId === activeFy.id).length} · पाक्षिक rolls {workerRolls.length} — work detail se open karein</Text>
          <View style={styles.row}>
            <Btn label="Open Works" variant="outline" onPress={() => go('works')} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function ClosingScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { activeFy, fyTransactions, activePanchayat, bankLines, exportBackupJson, closeFinancialYearCarryForward, totalOpening } = useStore();
  const [ack, setAck] = useState({ pages: false, bank: false, attach: false });
  const nx = nextFyParts(activeFy);
  const cancelled = fyTransactions.filter((t) => t.status === 'cancelled').length;
  const untagged = bankLines.filter((l) => l.fyId === activeFy.id && !l.postedTxnId && !l.ignored).length;
  const ready = ack.pages && ack.bank && ack.attach;
  return (
    <View style={styles.page}>
      <Header title={`वित्तीय वर्ष समापन — ${activeFy.label}`} onBack={back} badge="S-45" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>FY lock se pehle: sab jagah janch, final गोशवारा, safe backup (kabhi delete nahi), phir lock.</Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>1. जाँच सूची</Text>
          {[
            ['pages', 'सभी pages जाँचा-परखा (मैन्युअल रूप से सत्यापित)'],
            ['bank', `बैंक statements upload + verify (${untagged} untagged lines बाकी)`],
            ['attach', `Missing attachments की सूची देखी (${cancelled} cancelled entries)`],
          ].map(([k, label]) => (
            <Pressable key={k} onPress={() => setAck((a) => ({ ...a, [k]: !a[k as keyof typeof ack] }))} style={styles.homeRow}>
              <Feather name={ack[k as keyof typeof ack] ? 'check-square' : 'square'} size={18} color={C.primary} />
              <Text style={{ flex: 1, fontSize: 12, color: C.foreground }}>{label}</Text>
            </Pressable>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>2. Final गोशवारा</Text>
          <Text style={styles.meta}>31-03 annual गोशवारा Formats Centre / गोशवारा screen se verify karein</Text>
          <Btn label="गोशवारा खोलें" variant="outline" onPress={() => go('goswara')} />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>3. Operation-पूर्व safe backup</Text>
          <Text style={styles.meta}>यह backup कभी auto-delete नहीं होगा</Text>
          <Btn label="Safe backup share/save" icon="download" onPress={() => Share.share({ message: exportBackupJson(), title: `SAFE-BACKUP-${activeFy.label}` })} />
        </View>
        <Btn
          label="4. FY Lock → नए वर्ष की opening carry-forward"
          variant="danger"
          disabled={!ready}
          onPress={() =>
            Alert.alert(
              'FY lock?',
              `${activeFy.label} read-only archive हो जाएगा. Closing balances (opening ${formatINR(totalOpening)} से गणित) नए FY ${nx.label} की opening बनेंगी.`,
              [
                { text: 'नहीं', style: 'cancel' },
                {
                  text: 'Lock करें',
                  style: 'destructive',
                  onPress: async () => {
                    // bug fix: pehle result check nahi hota tha + hardcoded 2027–28
                    const r = await closeFinancialYearCarryForward(activeFy.id, nx.label, nx.start, nx.end);
                    if (!r.ok) return Alert.alert('FY lock नहीं हुआ', r.error || '—');
                    Alert.alert('FY lock हो गया', `नया FY ${nx.label} खुल गया — opening balances carry-forward`);
                    back();
                  },
                },
              ]
            )
          }
        />
        {!ready ? <Text style={styles.meta}>उपरोक्त तीनों जाँच ✓ करने के बाद ही lock सक्रिय होगा</Text> : null}
      </ScrollView>
    </View>
  );
}

function BackupScreen({ back }: { back: () => void }) {
  const { exportCsvForFy, exportBackupJson, importBackupJson, activePanchayat } = useStore();
  const [restoreText, setRestoreText] = useState('');
  /* instruction #14 — file storage folder me save + app se hi permission */
  const [dirUri, setDirUri] = useState<string | null>(null);
  const [files, setFiles] = useState<BackupEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const now = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  const backupName = `Cashbook-Backup-${activePanchayat.name.replace(/\s+/g, '_')}-${now}`;

  const refresh = React.useCallback(async () => {
    setDirUri(await getBackupDirUri());
    setFiles(await listBackups());
  }, []);
  React.useEffect(() => {
    refresh();
  }, [refresh]);

  const chooseFolder = async () => {
    const uri = await pickBackupDir();
    if (!uri) return; // cancel
    await refresh();
    Alert.alert('फ़ोल्डर जुड़ गया', 'एक बार अनुमति के बाद हर बैकअप इसी फ़ोल्डर में सहेजा जाएगा (फ़ाइलें uninstall पर भी बनी रहेंगी)।');
  };

  const saveToFolder = async () => {
    try {
      if (!dirUri) {
        const uri = await pickBackupDir();
        if (!uri) return;
        setDirUri(uri);
      }
      setBusy(true);
      const p = await saveBackup(`${backupName}.json`, exportBackupJson());
      await refresh();
      Alert.alert('बैकअप सहेजा गया', p);
    } catch (e) {
      Alert.alert('बैकअप fail', String((e as Error)?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const restoreFrom = (f: BackupEntry) =>
    Alert.alert('Restore करें?', `${f.name}\nमौजूदा data replace हो जाएगा — ज़रूरी हो तो पहले नया backup ले लें।`, [
      { text: 'नहीं', style: 'cancel' },
      {
        text: 'Restore',
        style: 'destructive',
        onPress: async () => {
          try {
            const json = await readBackup(f.uri);
            const r = importBackupJson(json);
            if (r.ok) Alert.alert('Restore सफल', 'Data वापस आ गया');
            else Alert.alert('Restore fail', r.error || 'Invalid file');
          } catch (e) {
            Alert.alert('फ़ाइल नहीं पढ़ी', String((e as Error)?.message || e));
          }
        },
      },
    ]);

  return (
    <View style={styles.page}>
      <Header title="Backup & export" onBack={back} badge="S-42" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>बैकअप फ़ोल्डर (storage)</Text>
          <Text style={styles.meta}>
            {dirUri ? `जुड़ा हुआ: ${dirUri}` : 'अभी फ़ोल्डर नहीं चुना — नीचे “फ़ोल्डर चुनें” दबाएँ (एक बार अनुमति, फिर अपने-आप)।'}
          </Text>
          <Btn label={dirUri ? 'फ़ोल्डर बदलें / अनुमति दोबारा दें' : '📁 फ़ोल्डर चुनें (एक बार अनुमति)'} icon="folder" onPress={chooseFolder} />
          <Btn label={busy ? 'सहेजा जा रहा है…' : '⬇ इस फ़ोल्डर में बैकअप फ़ाइल सहेजें'} icon="download" disabled={busy} onPress={saveToFolder} />
          <Btn label="फ़ोल्डर की अनुमति हटाएँ (app से)" variant="outline" icon="x" onPress={async () => { await clearBackupDir(); await refresh(); }} />
          <Text style={styles.meta}>
            फ़ाइल: {backupName}.json — app uninstall करने पर भी फ़ोल्डर में बनी रहती है। Android/data वाले folder में कभी न सहेजें (uninstall पर delete)।
          </Text>
        </View>

        <Text style={styles.section}>फ़ोल्डर की बैकअप फ़ाइलें ({files.length})</Text>
        {files.map((f) => (
          <View key={f.uri} style={[styles.card, { flexDirection: 'row', alignItems: 'center', gap: 8 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle} numberOfLines={2}>{f.name}</Text>
              <Text style={styles.meta}>{f.size ? `${(f.size / 1024).toFixed(1)} KB` : ''}</Text>
            </View>
            <Btn label="Restore" variant="soft" onPress={() => restoreFrom(f)} />
            <IconBtn
              name="trash-2"
              onPress={() =>
                Alert.alert('फ़ाइल हटाएँ?', f.name, [
                  { text: 'नहीं', style: 'cancel' },
                  { text: 'हटाएँ', style: 'destructive', onPress: async () => { await deleteBackup(f.uri); await refresh(); } },
                ])
              }
            />
          </View>
        ))}
        {dirUri && files.length === 0 ? (
          <Empty title="अभी कोई backup file नहीं" why="ऊपर का बैकअप बटन दबाते ही पहली फ़ाइल बन जाएगी" steps={['फ़ोल्डर चुनें', 'बैकअप सहेजें']} />
        ) : null}
        {!dirUri ? (
          <Empty title="फ़ोल्डर नहीं जुड़ा" why="App सीधे storage folder में फ़ाइल नहीं लिख सकती — एक बार अनुमति देनी होती है" steps={['📁 फ़ोल्डर चुनें', 'बैकअप सहेजें', 'Restore यहीं से']} />
        ) : null}

        <Btn label="⬇ Full JSON Backup — Share (WhatsApp/Drive/Files)" icon="share-2" onPress={async () => { await Share.share({ message: exportBackupJson(), title: `${backupName}.json` }); }} />
        <Btn label="Share FY CSV (Excel)" icon="share-2" onPress={() => Share.share({ message: exportCsvForFy() })} />
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Restore (phone transfer / paste)</Text>
          <Text style={styles.meta}>Naye phone par: backup JSON ka text paste karke Restore dabayen. Ya WhatsApp se aayi file ka content copy karein.</Text>
          <Field label="Backup JSON paste karein" value={restoreText} onChangeText={setRestoreText} multiline />
          <Btn
            label="Restore data"
            variant="danger"
            onPress={() => {
              if (!restoreText.trim()) return Alert.alert('JSON paste karein');
              Alert.alert('Restore?', 'Maujuda data replace ho jayega. Pehle backup le lein.', [
                { text: 'नहीं', style: 'cancel' },
                {
                  text: 'Restore',
                  style: 'destructive',
                  onPress: () => {
                    const r = importBackupJson(restoreText);
                    if (r.ok) {
                      setRestoreText('');
                      Alert.alert('Restore safal', 'Data load ho gaya');
                    } else Alert.alert('Restore fail', r.error || 'Invalid');
                  },
                },
              ]);
            }}
          />
        </View>
      </ScrollView>
    </View>
  );
}

function FundsScreen({ back }: { back: () => void }) {
  const { activeFunds, updateFundOpening, deleteFundFy, addFund } = useStore();
  const [name, setName] = useState('');
  const [open, setOpen] = useState('0');
  return (
    <View style={styles.page}>
      <Header title="Fund heads" onBack={back} badge="S-35" />
      <ScrollView contentContainerStyle={styles.pad}>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>{formatINR(f.openingBalance)} · {f.openingSource}</Text>
            <Btn label="Delete (FY)" variant="danger" onPress={() => deleteFundFy(f.id)} />
          </View>
        ))}
        <Field label="New" value={name} onChangeText={setName} />
        <Field label="Opening" value={open} onChangeText={setOpen} keyboardType="numeric" />
        <Btn label="Add" onPress={() => { addFund(name, parseFloat(open) || 0); setName(''); }} />
      </ScrollView>
    </View>
  );
}

function Shell() {
  const [stage, setStage] = useState<Stage>('login');
  const [workId, setWorkId] = useState<string>('');
  const [editTxnId, setEditTxnId] = useState<string | null>(null);
  const { hydrated, app } = useStore();

  // Theme color: App Settings me choose kiya gaya theme yahin apply hota hai
  React.useEffect(() => {
    applyThemeAndStyles(app?.themeId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [app?.themeId]);

  // bug fix: pehle stack state ke andar Alert/setStage (side-effects) chalte the —
  // StrictMode me updater 2 baar chalta hai = duplicate Exit dialog + double nav.
  // Ab navigation-stack ki ek authoritative copy ref me; re-render setStage karta hai.
  const stackRef = useRef<Stage[]>(['login']);

  const go = useCallback((s: Stage, wid?: string) => {
    if (wid) setWorkId(wid);
    stackRef.current = [...stackRef.current, s];
    setStage(s);
  }, []);

  const exitConfirm = useCallback(() => {
    Alert.alert('Exit?', undefined, [
      { text: 'Stay', style: 'cancel' },
      { text: 'Exit', style: 'destructive', onPress: () => BackHandler.exitApp() },
    ]);
  }, []);

  const back = useCallback(() => {
    if (stackRef.current.length <= 1) {
      exitConfirm();
      return;
    }
    stackRef.current = stackRef.current.slice(0, -1);
    setStage(stackRef.current[stackRef.current.length - 1]);
  }, [exitConfirm]);

  React.useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      back();
      return true;
    });
    return () => sub.remove();
  }, [back]);

  if (!hydrated) {
    return (
      <View style={[styles.page, { alignItems: 'center', justifyContent: 'center' }]}>
        <Text>Loading…</Text>
      </View>
    );
  }

  switch (stage) {
    case 'login':
      return <LoginScreen onDone={() => go('panchayat')} />;
    case 'panchayat':
      return <PanchayatScreen onContinue={() => go('fy')} onBack={back} onSettings={() => go('appSettings')} />;
    case 'appSettings':
      return <AppSettingsScreen onBack={back} />;
    case 'fy':
      return <FYScreen onContinue={() => go('home')} onBack={back} onSettings={() => go('fySettings')} />;
    case 'fySettings':
      return <FYSettingsScreen onBack={back} />;
    case 'home':
      return <HomeScreen go={go} back={back} />;
    case 'cashbook':
      return <CashbookScreen back={back} go={go} onEdit={(id) => { setEditTxnId(id); go('entry'); }} />;
    case 'entry':
      return <EntryScreen back={back} editTxnId={editTxnId} onClearEdit={() => setEditTxnId(null)} />;
    case 'funds':
      return <FundsScreen back={back} />;
    case 'categories':
      return <CategoriesScreen back={back} />;
    case 'monthly':
      return <MonthlyScreen back={back} />;
    case 'goswara':
      return <GoswaraScreen back={back} go={go} />;
    case 'ledgers':
      return <LedgersScreen back={back} />;
    case 'reports':
      return <ReportsScreen back={back} go={go} />;
    case 'bank':
      return <BankScreen back={back} />;
    case 'works':
      return <WorksScreen back={back} go={go} />;
    case 'workDetail':
      return <WorkDetailScreen back={back} workId={workId} go={go} />;
    case 'mb':
      return <MbScreen back={back} workId={workId} go={go} />;
    case 'manday':
      return <MandayScreen back={back} workId={workId} />;
    case 'bills':
      return <BillsScreen back={back} workId={workId} />;
    case 'cc':
      return <CcScreen back={back} workId={workId} />;
    case 'formats':
      return <FormatsScreen back={back} go={go} />;
    case 'masters':
      return <MastersScreen back={back} />;
    case 'closing':
      return <ClosingScreen back={back} go={go} />;
    case 'backup':
      return <BackupScreen back={back} />;
    default:
      return <HomeScreen go={go} back={back} />;
  }
}

export default function Index() {
  return <Shell />;
}

// Theme support: styles ab function se bante hain — theme badalne par rebuild
// karna zaroori hai (StyleSheet.create values usi waqt capture karta hai).
function makeStyles() {
  return StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  dark: { flex: 1, backgroundColor: C.darkForest, padding: 24, justifyContent: 'center' },
  loginPad: { gap: 8 },
  brand: { color: C.accent, letterSpacing: 2, fontWeight: '800', fontSize: 12 },
  loginHi: { color: '#fff', fontSize: 28, fontWeight: '800' },
  loginSub: { color: 'rgba(255,255,255,0.7)', marginBottom: 12 },
  header: { backgroundColor: C.primary, paddingHorizontal: 12, paddingBottom: 10 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  eyebrow: { color: 'rgba(255,255,255,0.75)', fontSize: 11 },
  hTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  mark: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  iconBtn: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  pad: { padding: 14, paddingBottom: 40 },
  btn: { flex: 1, flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', paddingVertical: 11, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, marginVertical: 4 },
  btnText: { fontWeight: '800', fontSize: 13 },
  fieldWrap: { marginBottom: 10 },
  fieldLabel: { fontSize: 11, fontWeight: '700', color: C.mutedForeground, marginBottom: 4 },
  field: { borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 11, backgroundColor: C.card, color: C.foreground },
  err: { color: C.expense, marginBottom: 8 },
  hint: { color: C.mutedForeground, fontSize: 12, marginBottom: 10, lineHeight: 17 },
  section: { fontWeight: '800', marginTop: 12, marginBottom: 8, color: C.foreground },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  cardOn: { borderColor: C.primary, backgroundColor: C.primarySoft },
  cardTitle: { fontWeight: '800', color: C.foreground, fontSize: 14 },
  meta: { color: C.mutedForeground, fontSize: 11, marginTop: 3 },
  gosHead: { fontSize: 12, fontWeight: '800', color: C.foreground },
  row: { flexDirection: 'row', gap: 8, marginVertical: 6 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  stat: { width: '47%', backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.border, padding: 10 },
  homeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  homeIcon: { width: 38, height: 38, borderRadius: 11, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
  chipOn: { backgroundColor: C.primary, borderColor: C.primary },
  summary: { marginTop: 14, padding: 12, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.8)', borderWidth: 1, borderColor: C.border },
  sumLine: { fontWeight: '800', marginBottom: 4 },
  empty: { backgroundColor: C.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.border, gap: 6 },
  emptyTitle: { fontWeight: '800', fontSize: 15 },
  emptyWhy: { color: C.mutedForeground, fontSize: 12, lineHeight: 18 },
  emptyStep: { fontSize: 12 },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 22 },
  modalCard: { backgroundColor: C.card, borderRadius: 16, padding: 16, gap: 8 },
  modalTitle: { fontWeight: '800', fontSize: 16 },
  });
}

let styles = StyleSheet.create(makeStyles());

/** Theme change: palette apply + stylesheet rebuild (inline `C.x` + styles dono update). */
function applyThemeAndStyles(themeId?: string) {
  applyTheme(themeId);
  styles = StyleSheet.create(makeStyles());
}
