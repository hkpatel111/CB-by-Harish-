/**
 * 6 themes (old master §16.2 / V.2 #14): हरा (default), नीला, टील, मैरून, बैंगनी, केसरिया.
 * `applyTheme()` base palette ke key colors overwrite karta hai —
 * screens module-level `C.x` se hi padhte hain, isliye runtime par effect lagta hai.
 */
export type ThemeId = 'green' | 'blue' | 'teal' | 'maroon' | 'purple' | 'orange';

export const THEMES: Record<ThemeId, { label: string; hindi: string; swatch: string; overrides: Record<string, string> }> = {
  green: {
    label: 'Green',
    hindi: 'हरा',
    swatch: '#1e6048',
    overrides: {},
  },
  blue: {
    label: 'Blue',
    hindi: 'नीला',
    swatch: '#1d4ed8',
    overrides: {
      background: '#f3f6fb',
      primary: '#1d4ed8',
      primarySoft: '#dce7fb',
      secondary: '#eaf0fa',
      secondaryForeground: '#2b4a86',
      darkForest: '#122c55',
      paperGreen: '#eef3fb',
      paperLine: '#c6d6ee',
      income: '#1d6fb8',
      incomeSoft: '#e0eefb',
      accent: '#c9973a',
      accentSoft: '#f7edd8',
      border: '#d7e1f0',
      input: '#e6ecf6',
      muted: '#edf1f8',
      mutedForeground: '#6b7c96',
    },
  },
  teal: {
    label: 'Teal',
    hindi: 'टील',
    swatch: '#0f766e',
    overrides: {
      background: '#f2f8f7',
      primary: '#0f766e',
      primarySoft: '#d7eeeb',
      secondary: '#e8f3f1',
      secondaryForeground: '#28615b',
      darkForest: '#0b4541',
      paperGreen: '#e9f5f3',
      paperLine: '#c3e2dd',
      income: '#12857b',
      incomeSoft: '#dcf1ee',
      border: '#d3e6e3',
      input: '#e3efed',
      muted: '#ecf4f3',
      mutedForeground: '#68827e',
    },
  },
  maroon: {
    label: 'Maroon',
    hindi: 'मैरून',
    swatch: '#7c2d3b',
    overrides: {
      background: '#faf3f4',
      primary: '#7c2d3b',
      primarySoft: '#f4dde1',
      secondary: '#f7eaec',
      secondaryForeground: '#7a3d47',
      darkForest: '#4d1a24',
      paperGreen: '#f8ecee',
      paperLine: '#eccdd3',
      income: '#9c4a3a',
      incomeSoft: '#f9e6e1',
      border: '#ecd7db',
      input: '#f5e7ea',
      muted: '#f6edef',
      mutedForeground: '#93757c',
      accent: '#c9a13a',
      accentSoft: '#f8efd6',
    },
  },
  purple: {
    label: 'Purple',
    hindi: 'बैंगनी',
    swatch: '#6d28d9',
    overrides: {
      background: '#f7f4fc',
      primary: '#6d28d9',
      primarySoft: '#e8dffb',
      secondary: '#f0eafb',
      secondaryForeground: '#573d94',
      darkForest: '#3b1d73',
      paperGreen: '#f1ecfb',
      paperLine: '#d9cdf3',
      income: '#7c4dd6',
      incomeSoft: '#ece4fb',
      border: '#e2d9f5',
      input: '#eee8fa',
      muted: '#f2eefb',
      mutedForeground: '#8174a0',
      accent: '#c9973a',
      accentSoft: '#f8efd3',
    },
  },
  orange: {
    label: 'Orange',
    hindi: 'केसरिया',
    swatch: '#c2410c',
    overrides: {
      background: '#fdf6f1',
      primary: '#c2410c',
      primarySoft: '#fbe3d5',
      secondary: '#faeee5',
      secondaryForeground: '#8a4a22',
      darkForest: '#732907',
      paperGreen: '#fbf0e8',
      paperLine: '#f0d6c3',
      income: '#b5591c',
      incomeSoft: '#fbe8dc',
      border: '#f0ddd0',
      input: '#f8ebe2',
      muted: '#faf0e9',
      mutedForeground: '#9a7a66',
      accent: '#a9761f',
      accentSoft: '#f8edd6',
    },
  },
};

const colors = {
  light: {
    background: '#f5f7f3',
    foreground: '#14241a',
    card: '#ffffff',
    cardForeground: '#14241a',
    primary: '#1e6048',
    primaryForeground: '#ffffff',
    primarySoft: '#dceee4',
    secondary: '#edf3ee',
    secondaryForeground: '#315540',
    muted: '#eef2ee',
    mutedForeground: '#6c7f72',
    accent: '#d2a94a',
    accentSoft: '#f8efd3',
    income: '#287b58',
    incomeSoft: '#e1f2e8',
    expense: '#a34e46',
    expenseSoft: '#fae8e4',
    warning: '#a86c17',
    warningSoft: '#fff2d9',
    destructive: '#ba4b4b',
    destructiveForeground: '#ffffff',
    border: '#dce5de',
    input: '#e5ece6',
    darkForest: '#123b2c',
    paperGreen: '#e9f4e9',
    paperLine: '#c9dfca',
    redInk: '#b13f3f',
  },
  radius: 18,
};

/** Base green palette — har theme change par isse restore karke override lagate hain. */
const BASE: Record<string, string> = { ...colors.light };

/** Theme apply: base values + selected theme ke overrides. Shallow mutate (screens C.x se hi padhte hain). */
export function applyTheme(id?: string): void {
  const t = THEMES[(id || 'green') as ThemeId] || THEMES.green;
  for (const k of Object.keys(colors.light)) delete (colors.light as Record<string, string>)[k];
  Object.assign(colors.light, BASE, t.overrides);
}

export default colors;
