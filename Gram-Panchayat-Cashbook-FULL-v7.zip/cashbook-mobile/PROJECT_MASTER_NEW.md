# Gram Panchayat Cashbook — PROJECT MASTER (consolidated)

> Consolidated from `PROJECT_MASTER.md` + `PROJECT_MASTER old.md` + user's 15 latest instructions (2026-09). Supersedes both.
>
> **Document purpose:** अब यही एक authoritative requirements + design file है। Sections 0–20 = baseline (`PROJECT_MASTER.md`) का 1:1 mapping (same order/naming)। Section A = user के नवीनतम 15 निर्देश। Section B = पुरानी `.md` से वे instructions जो current spec cover नहीं करता (restore/obsolete verdict सहित)। Section C = old vs new contradictions + decision। Section D = v6 implementation status।
>
> **Sources read:** `PROJECT_MASTER.md` (749 lines), `PROJECT_MASTER old.md` (1926 lines), `F:\Android app\cashbook\` directory listing (no other `.md` exists there — only xlsx/pdf/html/zip), `extracted\cashbook-mobile\app\index.tsx`, `services\*`, `types\models.ts`, `context\AppStore.tsx`.
>
> **Status:** Requirements FINAL for Phase 1; 15 latest instructions folded in (2026-09).
> **Last updated:** 25-09-2026 (this consolidated file created).

---

## 0. Scope, platforms, hard rules   (from baseline)

- **Product:** Hindi-first Android digital cashbook for a Gram Panchayat (Expo / React Native, `com.grampanchayat.cashbook`), **offline-first**, single-device, **Admin-only** (D6).
- **अनिवार्य rules (never violate):**
  1. एक ही `.md` = authoritative spec (अब यही file)।
  2. हर screen के corner पर screen number badge (`S-01` … `S-n`); **App Settings हमेशा अंतिम screen number** (B32 restores bottom-right muted + toggle detail).
  3. FY 1 April → 31 March; **FY isolation** — पुराने FY की transaction rows कभी नए FY में नहीं दिखेंगी; सिर्फ़ closing balances carry (D17).
  4. **SAF `Documents/Cashbook/...` storage mandatory** (D13); backup कभी `Android/data` में नहीं (instruction #14 / B16).
  5. **PDF/Excel share = plain white background** (D14); printed documents **हमेशा हिंदी**, UI English/Hinglish (V.2#13).
  6. Summary lines (श्री पोते राशि, आय योग, पूर्व पोते, व्यय योग, बचत पोते, महायोग) **कभी manually editable नहीं** (C.5 / 19.11).
  7. हर report/page पर compulsory: `Export Excel | Export PDF | Share Excel | Share PDF | Print` (Part F) — instruction #6/#12 के साथ।
  8. Devanagari PDF: Noto Sans Devanagari (+Condensed for grid), **Mangal banned**, `OFL.txt` required, shaping-capable renderer only (V.2#1 / B10).
  9. **Money:** cashbook me paise-precision (2 decimal) store/calculate; display जगह rupee round (Part M, old §12.7).
  10. Demo/sample files = **visual source of truth** for formats (Part U): user की upload की हुई Excel/PDF जैसा ही बनेगा।

---

## 1. Product vision  (baseline PART A)

```text
Digital Cashbook + Side-by-side Income|Expense pages + Configurable N-line pages (default 25)
+ Dynamic fund/scheme columns + Scheme-required multi-column amounts + Category/Sub/Sub-sub taxonomy
+ Work / MB / Bills / CC (Phase 1) + Bank statement → tag → auto entry (Phase 1)
+ Auto ledgers & reports + Annual & till-date गोशवारा + PDF + Excel export/share (compulsory)
+ Grid + form data entry + Backdated correction + audit trail + SAF Documents/Cashbook storage
+ Backup / restore / phone transfer + Period lock + FY closing + Admin-only (multi-role later)
```

---

## 2. Financial year  (baseline PART B)

- FY window 1 Apr → 31 Mar; हर FY का data isolated (pages/statements/attachments under FY id).
- **Carry-forward only balances:** previous FY closing (fund-wise नकद + bank / scheme) → new FY opening **श्री पोते**; previous FY transaction rows never appear.
- New scheme in new year: opening may be manual; Page 1 श्री पोते row shows **Carry-forward vs Manual** indicator (screen + print).
- 31 March: annual गोशवारा → year-close checklist → backup → lock → archive read-only; locked-FY unauthorized edit blocked, corrections only via correction entries + audit.
- Old spec extras still valid: पुराने year archive/read-only; year lock से पहले validation + backup (old §2 — covered).

---

## 3. Cashbook page engine  (baseline PART C)

**Visual source of truth:** user-provided Excel cashbook PDF `DOC-20260622-WA0002` (GP काबजा, पं.समि. साबला, डूंगरपुर, FY 2026-27). Screen **and** PDF/Excel export must match that grid — not a vertical list (C.2 rejects list UI).

- **Page frame (C.1):** `कार्यालय ग्राम पंचायत` + Panchayat name; `पंचायत समिति` + block; `जिला` + district; `वित्तीय वर्ष` + label; `पृष्ठ संख्या` automatic top-right. Landscape preferred for print/PDF; light register tint on screen, **plain white on share** (D14). *No date-range under header; date only on श्री पोते line → B24.*
- **Horizontal split (C.2):** exactly two equal halves — प्राप्ति (left) | भुगतान (right), thick vertical rule, full Excel-like grid lines.
- **Columns (C.3):** Left = दिनांक · चेक/DD/इन्वॉइस नं. व दिनांक · किस से प्राप्त किया · विवरण · L.F. · रकम(नकद + बैंक: SFC, FFC, OWN FUND/INT, MP/MLA/TAD, Other/Security/DD, Total). Right = दिनांक · वाउचर नं. व दिनांक · भुगतान किसको किया (चेक न./मस्टर रोल न.) · किस कार्य पेटे · L.F. · परिसंपत्ति रजिस्टर पृष्ठ सं. · रकम (same fund set). Fund heads dynamic (D5) — default 11 columns; add/rename/archive से बढ़/घट.
- **Row map (C.4):** opening row on प्राप्ति side = **श्री पोते राशि** (भुगतान side blank); middle = blank/txn lines; last 3 rows always present, never edited: **आय योग | व्यय योग**, **पूर्व पोते | बचत पोते**, **महायोग | महायोग**. Wording lock: bottom-left = **पूर्व पोते** (not second श्री पोते).
- **Lines (C.4.1 / D1–D3):** default L = **25** (settings से बदल सकते हैं), `txn lines = L − 4`; new page auto when full **+ manual Add Page** (D9); empty days skip + optional empty-day page (D10).
- **Formulas (C.5):** per fund `f` — आय योग = txn sum; पूर्व पोते = श्री पोते; महायोग_L = आय योग + पूर्व पोते; व्यय योग = txn sum; बचत पोते = महायोग_L − व्यय योग; महायोग_R = व्यय योग + बचत पोते; **both महायोग equal (validation)**.
- **Carry-forward (C.6):** next page/next active date श्री पोते = previous page बचत पोते (per fund). FY change: closing balances only.
- **Mobile UI (C.7):** side-by-side grid (not list); horizontal + vertical scroll; tap cell/`+ Entry` → form; long-press → edit/cancel; badge S-07. *Thin layout + zoom → instruction #10/#15 (Section A).*
- **Export (C.8):** PDF reproduces grid (white, embedded Devanagari); Excel sheet “Cashbook Print” with same headers as C.3.

---

## 4. Income & expense entry  (baseline PART D)

- **Income fields (D.1):** date, invoice no/date, किससे प्राप्त, details, L.F., multi-fund amounts, auto total, **scheme required**, category path, note, attachment. Source list editable: Govt, व्यक्ति, Bank, संस्था, Firm/Vendor, अन्य (+ custom description when अन्य → **B3**).
- **Expense fields (D.2):** date, voucher no/date, party/vendor, **Work या Other**, work name / other category path, L.F., multi-fund amounts, auto total, scheme required, note, attachment, payment mode Cash/Bank. Party master = select/add/search + vendor-wise reports. Work = name required, master select/add, optional code/ward/sanction ref. Other = category tree (Stationery, Printing, भत्ता, बिजली, सफाई, ईंधन, यात्रा, मरम्मत, डाक, बैठक, मोबाइल/इंटरनेट, अन्य, …).
- **Work | Other chooser, in-dropdown “नया work add”, category add/edit/delete यहीं से → instruction #7; work form scheme + AS/TS/FS + dates + MB status → instruction #8; vendor dropdown + in-place add vendor → instruction #5; minimal entry fields + one scheme per entry → instruction #9 (Section A).**
- **Repeat entry (D.3):** “पिछली entry से copy” template (monthly बिजली/सफाई) — implemented.
- **Cancel (D.4):** reason required; print red strikethrough; excluded from totals; stays in audit.
- Defaults: **scheme = SFC**; without scheme save blocked; same-day total expense ≤ that day income-side महायोग; per-scheme negative = FY toggle (default OFF) (D4/D8, old 19.6).

---

## 5. Category / subcategory / sub-subcategory  (baseline PART E)

- Max 3 levels: Category → Subcategory → Sub-sub-category; separate/namespaced trees for Income & Expense (+ Work classification as needed).
- CRUD in Cashbook Settings (S-xx Category tree manager); node in use → **archive, not hard-delete** (old rows keep history).
- Every txn should carry deepest applicable path; incomplete path flaggable in Monthly Check.
- Used for: गोशवारा grouping, ledgers, reports, “same path” txn discovery.

---

## 6. Auto ledgers & reports  (baseline PART F)

- From **first saved txn** of an FY, ledger/report views exist (may show one row). **No “generate report” step.** Every add/edit/cancel/category change → aggregates refresh. Empty state = why + steps.
- Compulsory share row: `Export Excel | Export PDF | Share Excel | Share PDF | Print`.
- Report catalogue (23): page-wise, date-wise, daily/weekly/monthly/range, full FY, income, expense, work-wise, other-category, vendor-wise, fund/scheme-wise, L.F.-wise, category-wise, monthly dashboard, गोशवारा (till-date + annual), backdated, edited/corrected, cancelled, audit trail, validation/incomplete, reconciliation, attachments, pending verification, search results.
- **Contextual reports** on every details screen + drill-down back to source (both directions).
- Excel = editable workbook (multiple sheets, filters, freeze, Hindi headings, formulas) — *default 12-sheet set → B9*. PDF = configured line layout, landscape options, embedded Devanagari, white background, optional watermark/signatures — *full option set → B10*.
- Extra ledgers from old spec: **Material item-wise ledger (Stock Register)**, **labour ledger**, **scheme detail screen**, **fee ledgers (count + amount + list)** → B28.

---

## 7. Bank statement  (baseline PART G, Phase 1)

- Bank account master; upload PDF (password unlock) → AI/OCR → **editable grid** (user corrects before post); tag: scheme, work/category, vendor, लेखा शीर्ष, टिप्पणी (instruction #13); grouping rules (multi-line one instrument), **D−1 date rule**, instrument number; post → structured cashbook entries; month locked for re-upload when entries exist **and** verified; **no bank→cash withdrawal**; optional **Cash → Bank deposit** entry type; files under SAF FY folder.
- Field layout = user's uploaded Excel (दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष) → instruction #13 (Section A).
- Full engine rules (credit placement, 10–15-day grouping window, labour consolidation, account auto-detect/IFSC, duplicate-month warning, register print, UTR reconciliation) → **B25/B26** (restored).

---

## 8. Works, MB, Man-days, Bills, CC  (baseline PART H, Phase 1)

- Ongoing works list with **scheme-wise grouping/filter tabs**; add old work with prior material/labour spend + optional bill-wise history; work payments list → bills → material lines.
- **MB:** मद-वार material + कारीगर + labour; **total valuation**; **material vs labour grouping + कारीगर toggle (default labour)** → instruction #3 (Section A).
- **Man-days / master roll:** named workers and group rows (5 labour × 12 days); pakhwada = 15d − Sundays − holidays (Holiday master), manual override; **full man-days only**; amount ≤ MB component; closer-better rule; app auto-suggests combos (trial-and-error); calc audit trail (rate, man-days, BSR year) → **B37**; rate ≤ BSR with −10…−20% safe band guidance → **B36** (sanction-year default still open = C2).
- **Manday sanction inside sanction** (desired wage rate + man-days auto-calc) → instruction #4 (Section A).
- **Bill register** date-wise: bill date + cashbook payment date + page ref.
- **CC — 7 pages:** (1) Completion certificate (AS/TS/FS, MB refs, valuations, allowable = min rules) (2) UC (3) Labour by pakhwada (4) Material as per MB (5) Technical verification (6) Completion photo + signatures (7) Before & during photos. Output **exactly in user's uploaded Excel format** + share PDF/Excel → instruction #6 (Section A).
- **Live status residual:** after MB = CC allowable − payments (material/labour separate); before MB from FS; special toggle when MB labour > FS labour.
- Masters: BSR (year-wise rates, old years read-only, prefilled items: सीमेंट, रेत, गिट्टी 40/20/12 मिमी, पत्थर, ईंट…), Workers/roles (year-wise), Items (whole/decimal flags, last-bill, basic), Holidays (pakhwada).
- Pending decisions from old spec: material-first payment enforcement (C3), last-bill item list (C4), qty whole/decimal (C5), excess-payment live status → **B38**.

---

## 9. गोशवारा  (baseline PART I)

- **Till date** from FY Home; **annual 31 March** classified income (left) | expense (right) — **always two-sided** like user's uploaded Excel → instruction #11 (Section A).
- Bottom: आय योग, प्रारंभिक बैंक/नकद; व्यय योग, अंतिम बैंक/नकद; महायोग equality check (mismatch → warning/close block).
- Tap head → ledger of that head for the year (implemented).
- Optional monthly reminder (e.g. 5th) to share PDF; **one-tap WhatsApp share to पं.समि./BDO** → **B34**.

---

## 10. Dashboard & Monthly check  (baseline PART J)

- **FY Home:** FY, opening, income, expense, current balance, pages, pending verification, missing attachments, unbalanced/incomplete flags. Quick actions: Add Income/Expense, Cashbook, Reports, Backup, Bank, Works (+ Current Page / Search / Export / Reconciliation → **B11**). Tiles include Material Ledger & Schemes → **B28**.
- **Monthly check:** lists **all** transactions of the period (not only warnings); missing scheme / category path highlighted + filterable; tap row → edit/correct/cancel/fill; also unverified pages, untagged bank lines, missing bill attachments, pending statements.

---

## 11. App flow, settings, security  (baseline PART K)

```text
S-01 Login (Admin PIN + optional biometric)
  → S-02 Panchayat selection + [App Settings]
       → S-05 Financial Year (status + chooser) + [FY / Cashbook Settings]
            → S-06 FY Home → Cashbook | Bank | Works | गोशवारा | Ledgers/Reports |
                Monthly check | Backup | प्रपत्र/Formats | Masters | Closing | …
```

- **App Settings (last screen):** theme colour (**instruction #2**), logo, UI language (English/Hinglish), screen-number badge on/off, change PIN, biometric toggle/re-enrol, Panchayat add/edit/correction/delete (destructive **and edit** = PIN re-confirm), global backup defaults.
- **FY / Cashbook Settings:** FY CRUD (add/close = PIN confirm, C11), scheme/fund CRUD **for this FY** (red delete = this FY only), opening balance editor visible, line count L, blank gap 1|2, allow-scheme-negative ON/OFF, appearance colours, category-tree links, empty-day help text.
- **Auth:** Admin only; PIN to establish; biometric optional; future roles reserved in model only.
- **Navigation:** hardware/in-app back → parent in stack (no exit to Android Home until root confirm); no silent dead clicks — empty states with why + steps; badges renumber when screens added, App Settings always last.
- *Storage-permission screen (S-03) + restore-detected screen (S-04) → **B16/B17** (restored into screen index §15).*

---

## 12. Storage, backup, audit  (baseline PART L, Phase 1)

```text
Documents/Cashbook/<PanchayatName_or_Id>/<FY_Label>/
  database / exports / bank_statements / attachments / backups /
```

- **Backup/restore:** auto-save after txns; manual backup; versioned list; restore; backup before FY lock & before destructive schema/column changes; phone-transfer wizard (backup zip + 4-digit restore code); optional cloud later.
- **Instruction #14** adds: proper file-storage folder chosen by user, app provides the permission (grant once → files persist), files survive uninstall, **never `Android/data`** — code: `services/backupFolder.ts` (SAF folder picker).
- Retention: last 15 daily + 1 permanent monthly snapshot, operation-prior safe backups never auto-deleted; human-readable JSON export (V.2#3). *Zip + manifest + naming + checksum/migrate-restore flow → **B14/B15**.*
- **Audit log:** user, time, entity id, action, field, old/new, reason. Prefer Cancelled/Archived over hard delete. *Edit-reason picklist + correction-entry fields → **B6/B7**.*
- **Attachments:** receipt/bill/voucher/sanction/MB photo/PDF linked to txn; included in backup policy (photo attachment per txn = pending C7).

---

## 13. Validation  (baseline PART M)

Invalid dates; non-numeric amounts; negative-amount prevention per policy; scheme required; category incompleteness warning (Monthly Check); at least one fund amount > 0; Work name if Work / other path if Other; duplicate invoice/voucher warning; expense vs day महायोग; optional scheme minus; महायोग mismatch / unbalanced page warnings; backdated impact confirmation.
*Recovered additions: configurable missing-attachment warning + missing invoice/voucher report (**B12**).*

---

## 14. Data entities  (baseline PART N)

`FinancialYear, Panchayat, Page, PageOpening (per fund), Transaction, TransactionAmount, FundColumn/Scheme, CategoryNode, IncomeSource, Work, Vendor, Attachment, BankAccount, BankStatement, BankLine, MeasurementBook, ManDayEntry, PakhWadaRoll, Bill, BillLine, CompletionCertificate, AuditLog, PeriodLock, User (admin), BackupRecord, AppSettings, FySettings, ExportHistory`.
*Code model (`types/models.ts`) additionally has `Vendor`, work sanction/MB fields, karigar toggle, bank tagging fields — see Section D.*

---

## 15. Screen index  (baseline PART O + restored screens)

| # | Screen | Notes |
|---|--------|--------|
| S-01 | Login | PIN + optional biometric + first-run logo chooser (login button always visible → instruction #1) |
| S-02 | Panchayat selection | + App Settings entry |
| **S-03** | **Storage Permission** | **restored (B16)** — first launch, compulsory `Documents/Cashbook` |
| **S-04** | **Restore Detected** | **restored (B17)** — old backups list → restore + migrate |
| S-05 | Financial Year page | + FY/Cashbook Settings |
| S-06 | FY Home | Dashboard + module tiles |
| S-07 | Cashbook page view | N-line dual grid, thin layout + zoom (#10/#15) |
| S-08 | Add/Edit Income | multi-column + scheme + category; minimal fields (#9) |
| S-09 | Add/Edit Expense | Work/Other (#7), vendor dropdown (#5), scheme + category |
| S-10 | Entry detail / cancel / correct | |
| **S-12** | **Page Verification** | **restored (B13)** — “जाँचा-परखा” stamp + user + date |
| S-11+ | Page list / range share | PDF/Excel white |
| S-13–S-16 | Bank accounts / upload / tag / post | Phase 1; fields = uploaded Excel (#13) |
| S-17–S-26 | Works / MB / Man-days / Bills / CC | incl. **manday sanction-in-sanction** + BSR page (#4) |
| S-27 | गोशवारा | till-date + annual, two-sided (#11) |
| S-28–S-34 | Ledgers & Reports Hub | incl. **Material Ledger (B28)**, **Scheme detail (B28)**, **Fee/Patta ledgers** |
| S-35 | Fund / column settings | full column-manager feature set → **B4** |
| S-36–S-41 | BSR, Workers, Vendors, Items, Holidays, Users | |
| S-42 | Backup & restore | SAF user-chosen folder (#14) |
| S-43 | Global search | |
| S-44 | Export centre | |
| S-45 | FY Closing wizard | |
| S-46 | New phone transfer | zip + 4-digit code |
| S-xx | Category tree manager | Income & expense |
| S-xx | Monthly check (full txn list) | |
| S-**Last** | **App Settings** | theme colour (#2), PIN/biometric, logo, panchayat CRUD |

*(Numbers renumber when screens are added; App Settings always last.)*

---

## 16. Build order & acceptance gate  (baseline PART P + Q)

**Build order:** 1) PIN+biometric+settings security → 2) SAF bootstrap + FY-scoped DB → 3) Panchayat/FY settings hierarchy → 4) Fund columns + page engine (L=25) + openings → 5) Income/expense save (multi-column, scheme required, category) → 6) strict FY filter regression → 7) carry-forward balances only (CF/Manual badge) → 8) auto ledgers/reports pipeline → 9) monthly check → 10) PDF/Excel page export (white) → 11) backup/restore SAF → 12) bank pipeline → 13) Works → MB → Bills → CC → 14) गोशवारा + FY closing → 15) empty-day insert, +2 pages, navigation/empty-state polish.

**Acceptance (Phase 1 gate):** baseline checklist (25-line page, scheme mandatory, summary non-editable, FY isolation, 3-level category, auto reports, monthly check, biometric optional, SAF tree, bank fixture path, MB→bill→CC path, Excel+PDF export, back nav, day-expense guard, auto+manual page) **plus restored checks (B19):** new fund column updates the whole book; archived column keeps data; audit shows old/new values; locked period blocks unauthorized edit.

---

## 17. Deferred / out of scope  (baseline PART R + old §13/§18.6)

- Multi-role Operator/Checker/Approver/Viewer UI; fixed Play-style signing keystore; TDS/GST; multi-device realtime sync; demo/sample training mode (**rejected**).
- **Backlog register (restored from old §13, B30):** bank reconciliation, advance tracking, pending-bills/liabilities register, निधि उपयोग प्रमाण-पत्र, budget vs actual, Hindi number-to-words, voice entry (Hindi), Devanagari numerals toggle, page e-sign/verification stamp, year-comparison report, asset/dead-stock register, onboarding help screens, large-font/dark mode, reminder notifications, multi-Panchayat mode (keep `PanchayatId` in model).

---

## 18. Demo-format locks & round decisions  (baseline PART U)

| # | Topic | FINAL |
|---|--------|--------|
| D21 | Page add | Manual **+ Page**: append **or insert between** pages; insert renumbers; delete re-flows txns; auto page-1 per FY |
| D22 | Formats Centre | FY Home tile **प्रपत्र / Formats Centre** — गोशवारा, Ledger, प्रपत्र-1, प्रपत्र-4, Bank grid, CC — all live, share/export from every card |
| D23 | गोशवारा format | audit demo sheet-1: मद-wise आय\|व्यय, आय/व्यय योग, प्रारंभिक/अंतिम शेष नकद (+bank), महायोग, हस्ताक्षर block |
| D24 | प्रपत्र-1 | audit demo sheet-2: FS ref/राशि (लाख), पूर्व व्यय, आलोच्य वर्ष व्यय, कुल व्यय, स्थिति, मूल्यांकन, MB ref, श्रम/सामग्री split |
| D25 | प्रपत्र-4 | audit demo sheet-3: सामग्री-वार मात्रा/दर/कीमत/योग |
| D26 | Ledger format | ledger.pdf (GP खाता बही): श्री पोते opening → जमा/नाम rows → running शेष; fund-wise or all-funds |
| D27 | CC | cc demo xlsx: 7-page set; **अनुमत = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)**; भुगतान योग्य शेष = अनुमत − payments |
| D28 | Mandays | **पाक्षिक मस्टरोल**: (मेट/कुशल/अकुशल × दिन) × दर = श्रम व्यय; rolls aggregate on CC page-3 |
| D29 | Monthly check | Edit every field + cancel with confirm; month filter (YYYY-MM); cancelled list |
| D30 | Backup | Full JSON backup share/save + restore-by-paste; SAF file-write on device build (#14 extends this) |
| D31 | Data model | `CashbookPage`, `PakhWadaRoll`, `Transaction.pageId`; AsyncStorage key versioned |

Demo mapping: `audit formet demo.xlsx` → गोशवारा/प्रपत्र-1/प्रपत्र-4; `bank statement demo.xlsx` → bank grid; `cc talora chaina mojek.xlsx` → CC 7 pages + mandays; `ledger.pdf` → खाता बही.

---

## 19. Provenance & decision log  (baseline PART S / V / W / VI — pointer)

- **PART S** (contradiction resolution) and **PART W/VI** (C1–C12 user decisions) are re-stated in **Section C** below with old-vs-new verdicts — that is now the single conflict table.
- **PART V merge map** (old doc → current doc, `[ALREADY-COVERED]` / `[CONFLICT]` markers) is superseded by **Section B** (which re-mines the old file from scratch and flags anything still missing).
- Resolved decisions kept as-is: C1 page structure (25 lines), C9 white print, C6 L.F. column (added), C10 logo chooser (added) + default user NOT seeded, C11 FY PIN confirm (added). Open/backlog: **C2** (BSR sanction-year default), **C3** (material-first enforcement), **C4** (last-bill list), **C5** (qty decimals), **C7** (txn photo attachment), **C8** (gap-2), **C12** (patta fields).

---

## 20. CI / build notes  (baseline PART T)

- Expo Android CI: extract → `expo prebuild` → `assembleRelease`; embed **release** JS bundle (debug APK without Metro = “Unable to load script”); strip monorepo `catalog:`/`workspace:` pins; `babel.config.js` with `babel-preset-expo` + `reanimated/plugin`; `newArchEnabled: false` for first stable sideloads; package `com.grampanchayat.cashbook`.
- Sideload signing: per-run debug keystore → update may require uninstall until **fixed keystore** (D15 “Later”).
- Stability trade-offs: biometric native module may be omitted (PIN stays); PDF OCR/SAF wired progressively.
- Always-regression: switching FY must never show previous FY rows.
- *Old CI learnings (JVM17, wrapper, one workflow, logs downloadable) → **B20**.*

---
---

## A. यूज़र के 15 निर्देश (latest, 2026-09)

> हर instruction testable spec wording में; status tag = Section D (v6 code) के आधार पर।

**A1. Login screen layout** — *"login button ab screen par dikh nahi raha; ise neeche/visible jagah par le jao, layout thik karo."*
→ Acceptance: login/set-PIN screen (S-01) पर button हमेशा viewport में दिखे — logo chooser खुले या keyboard आए तब भी; fixed-height layout नहीं, scrollable/keyboard-avoiding container; button field list के ठीक नीचे। **[implemented]**

**A2. Theme colour in App Settings** — *"Main App Settings me 'theme color' ka option add karo."*
→ Acceptance: App Settings (last screen) में theme colour picker (6 themes: हरा/नीला/टील/मैरून/बैंगनी/केसरिया); चुनते ही पूरी app पर colour लागू, selection persist; **printed documents का Hindi format वैसा ही** (theme सिर्फ़ UI)। **[implemented]**

**A3. MB entry — material/labour separation** — *"MB entry page confusing hai — material (सामग्री) aur labour (श्रम) ka alag-alag grouping dikhao; ek toggle do ki कारीगर labour me jaye ya material me (default = labour). Dono ka subtotal alag, valuation line me jodho."*
→ Acceptance: MB screen दो साफ़ sections — **सामग्री** (मद-वार qty × rate) और **श्रम** (कारीगर + लेबर); कारीगर-amount के लिए toggle (labour | material), **default = labour**; हर पक्ष का subtotal अलग दिखे; **Total valuation = material subtotal + labour subtotal** (कारीगर toggle के हिसाब से)। **[implemented]**

**A4. Manday sanction inside sanction + BSR page** — *"work-sanction ke andar ek alag 'manday sanction/sanction inside sanction' kholo: usme labour/karigar amount daalte hi desired wage rate aur man-days apne aap calculate hon (per .md ke hisaab se). Agar us saal BSR rates add nahi hain to BSR page khole — usme pehle se items listed hon (cement, रेत, गिट्टी 40mm/20mm/12mm, पत्थर, ईंट आदि), sirf us year ki rates bharni hon, items add/edit/delete karne ka option. System 2–3 aise combos auto-calculate kare jo desired amount ke karib hon (trial & error), user unme se choose kare."*
→ Acceptance: (a) work detail ke andar अलग **मन-डे स्वीकृति** sub-flow (sanction-in-sanction), केवल labour/karigar amount डालते ही desired wage rate + man-days auto-compute (pakhwada working days, full man-days, amount ≤ MB component, rate ≤ BSR); (b) agar उस year की BSR नहीं → वहीं से **BSR page**: default items पहले से listed (सीमेंट, रेत, गिट्टी 40/20/12 मिमी, पत्थर, ईंट…), सिर्फ़ rates भरनी हों, item add/edit/delete option; (c) app **2–3 सबसे करीब combos** auto-calculate करे (workers × days × rate, trial-and-error), user उनमें से चुने। **[implemented — combo shortlist sorted by closeness; confirm UI shows only 2–3]**

**A5. Vendor dropdown in Bills** — *"Bills me vendor dropdown hon; agar koi vendor nahi hai to wahi par 'add vendor' ka option."*
→ Acceptance: Bill create form में vendor = dropdown (master से); dropdown/list में ही **“नया vendor add”** option, add करते ही वही select हो जाए। **[implemented]**

**A6. CC = exact Excel format + PDF/Excel share** — *"CC ke 7 pages bilkul waise hi Excel format me jaise user ki upload ki hui Excel file hai (format unchanged); share/export me PDF aur Excel — dono ka option dikhe."*
→ Acceptance: CC के सातों पृष्ठ (पूर्णता प्रमाण पत्र, UC, श्रम मस्टर रोल, सामग्री, तकनीकी जाँच, पूर्णता फोटो, पूर्व/दौरान फोटो) **exactly** `cc talora chaina mojek.xlsx` वाले layout में (format unchanged); share row में PDF और Excel दोनों। **[implemented]**

**A7. Cashbook expense-side Work | Other** — *"Cashbook expense-side entry me do option: Work | Other. Work = added works ki dropdown (na ho to dropdown ke andar hi 'naya work add' option); Other = category/sub-category hierarchy jisme add/edit/delete ho."*
→ Acceptance: expense form में साफ़ दो options **कार्य | अन्य**; कार्य = works dropdown + dropdown ke andar hi “नया कार्य” (पूरा form); अन्य = category → sub-category tree, हर level add/rename/delete वहीं से। **[implemented]**

**A8. Work add form fields** — *"Work add karte waqt scheme poochho (expense entry ke dauran wo auto-select hoti rahe), plus A.S. number/date, T.S. number/date, F.S. number/date, work start date, work complete date, MB status (Complete/Pending); agar MB Complete to MB details: Total valuation, labour amount, material amount, page number, MB number (per .md)."*
→ Acceptance: नया work form में — **scheme** (योजना), AS/TS/FS क्रमांक व दिनांक (तीनों), कार्य प्रारंभ तिथि, कार्य पूर्ण तिथि, **MB स्थिति = Complete | Pending**; MB Complete होने पर अतिरिक्त — कुल मूल्यांकन, श्रम राशि, सामग्री राशि, MB पृष्ठ संख्या, MB संख्या; expense entry में work चुनते ही उसकी **scheme auto-select** रहे। **[implemented]**

**A9. Minimal cashbook entry fields** — *"Cashbook entry me sirf ye poochho: date, किससे प्राप्त, amount, scheme, category — ek entry me ek hi scheme, scheme baar-baar mat poochho."*
→ Acceptance: entry form केवल — दिनांक, किससे प्राप्त/भुगतान किसको, राशि (fund amount), योजना, श्रेणी; **एक entry में एक ही scheme**; scheme default (पिछली/work से) रहे तो दोबारा न पूछा जाए; बाक़ी विवरण optional/advanced में। **[implemented]**

**A10. Thin cashbook + own-fund default** — *"Cashbook page ko horizontal me patla karo taki kam se kam ek side phone par fit ho (upload ki Excel layout ke hisaab se); cash sirf transaction medium hai, scheme nahi — cash transactions default me 'own fund' (apna kosh), doosri schemes dropdown se."*
→ Acceptance: ग्रिड चौड़ाई ऐसी कि **कम से कम एक side phone width में fit** हो (uploaded Excel column order/headings वैसे ही, format unchanged), बाक़ी scroll/zoom से; **नकद = माध्यम, योजना नहीं** — cash वाली entry default **Own Fund (अपना कोष)**, दूसरी योजनाएँ dropdown से। **[implemented]**

**A11. गोशवारा & ledger two-sided original format** — *"गोशवारा aur ledger hamesha do-sided (two-side) ho, bilkul waise hi jaise upload ki Excel/PDF — original-type Excel format."*
→ Acceptance: गोशवारा = बायाँ आय मद | दायाँ व्यय मद (दोनों पक्ष); ledger = खाता बही वाला original type (जमा/नाम + running शेष), uploaded `ledger.pdf` / audit demo जैसा; output Excel में वही layout। **[implemented]**

**A12. सभी प्रपत्र — original look + Excel-type + share both** — *"Sabhi प्रपत्र phone par original dikhte hue Excel-type format me hon; share me Excel aur PDF dono ka option ho."*
→ Acceptance: Formats Centre के सभी documents (गोशवारा, ledger, प्रपत्र-1, प्रपत्र-4, bank grid, CC, cashbook page) phone पर original (uploaded sample) जैसे दिखें, Excel-type table format में export हों, और **हर card/share पर Excel + PDF दोनों** option। **[implemented]**

**A13. Bank statement fields = uploaded Excel** — *"Bank statement ke fields bilkul waise hon jaise upload ki Excel (दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष + tagging योजना/कार्य/vendor/लेखा शीर्ष/टिप्पणी)."*
→ Acceptance: statement grid columns exactly — दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष; हर line पर tagging: योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी। **[implemented]**

**A14. Backup/restore in proper folder with app-granted permission** — *"Backup/restore thik se karein — ek proper file storage folder me save hon, iske liye app khud storage-permission dene ka option de (permission grant karke files bani rahein); file uninstall par bhi bani rahe (Android/data wale folder me mat likho)."*
→ Acceptance: एक बार folder picker (SAF) से अपना backup folder चुनो → permission persist; वहीं `Cashbook-Backup-<panchayat>-<timestamp>.json` बने, list/restore/delete वहीं से; folder public (uninstall-safe), **`Android/data` कभी नहीं**; permission revoke हो तो app दोबारा चुनने को कहे। **[implemented — `services/backupFolder.ts` + BackupScreen]**

**A15. Return to same page + zoom** — *"Kisi page ko chun kar entry me jane aur wapas aane par usi page par pahunchna chahiye (first page par na chala jaye); pinch-to-zoom ya +/- zoom controls ho taki dono sides ek saath dekhi ja saken."*
→ Acceptance: cashbook page → entry → back पर **वही page number + वही zoom level**; zoom = pinch **या** `+ / −` controls (+ % indicator, reset), ताकि एक साथ दोनों sides दिखें। **[partially implemented — page+zoom persist + `− / 100% / +` controls present; pinch gesture not found in code]**

---

## B. पुरानी .md से जो लौटाना/जोड़ना है

> Mining rule: `PROJECT_MASTER old.md` का हर section current `PROJECT_MASTER.md` से टकराया गया। जो fully covered है वह यहाँ नहीं है (वे आधे-अधूरे covered भी नीचे हैं)। Each item: instruction → कहाँ मिला → **RESTORE** / **OBSOLETE** (+ क्यों)। Legend: `old.md` = `PROJECT_MASTER old.md`, `cur.md` = `PROJECT_MASTER.md`.

| # | Instruction (old spec) | Where it appeared | Verdict | Why it matters / why obsolete |
|---|---|---|---|---|
| B1 | “Reports में केवल active transaction dates या सभी calendar days दिखाने का option होगा।” | old.md Part A §4, line 134 | **RESTORE** | D10 covers optional empty-day *pages*; the report-side display toggle (active dates only vs all days) is a separate report option — अभी कहीं नहीं है |
| B2 | “Actual transaction date और entry-created date अलग-अलग store होंगी” (+ last-updated, user id) | old.md Part A §4 lines 135–136, §10.1 lines 365–370 | **RESTORE** | Audit/backdated correctness: cur.md L.3 logs only generic fields; per-txn `createdAt/updatedAt/backdated` fields explicit नहीं हैं |
| B3 | Income “अन्य” चुनने पर custom description field खुलेगी | old.md §5.2 line 185 | **RESTORE** | cur.md D.1 में “Other/अन्य” है पर free-text detail खुलने का rule नहीं — नई categories बिना CRUD के भी entry लिखवाने का रास्ता |
| B4 | Fund column manager: add/rename/**Hindi-English label edit**/**stable code**/reorder/enable-disable/archive/**show-hide in print**/**show-hide in reports**/opening balance | old.md §8.1 lines 293–306 | **RESTORE** | cur.md D5/K.3 सिर्फ़ CRUD कहता है; print/report visibility और stable code (exports सुधरें) अभी unspecified |
| B5 | Column change का automatic propagation checklist: existing/new pages, headings, line totals, आय/व्यय योग, श्री/बचत पोते, महायोग, carry-forward, dashboard, reports, Excel, PDF + historical column **archive, never direct delete** | old.md §8.2 lines 308–325 | **RESTORE** | यही regression test है (D5 का acceptance); cur.md में propagation का explicit checklist नहीं |
| B6 | Edit reason picklist: गलत amount / date / category / party / invoice-voucher / fund head / अन्य | old.md §10.2 lines 382–392 | **RESTORE** | cur.md M में edit/cancel हैं पर standard reason dropdown नहीं — audit में reasons comparable नहीं होंगे |
| B7 | Locked-period correction entry fields: original reference, old value, correct value, difference, reason, approval status | old.md §10.3 lines 394–403 | **RESTORE** | cur.md PART B/L.3 सिर्फ़ “correction/adjustment entries + audit” कहता है; fields specify नहीं |
| B8 | Excel-like grid extras: cell tap→edit, duplicate row, sort/filter, search, **freeze header**, column resize/reorder, dropdown validation, dependent dropdowns, auto-save/draft, Excel **import** | old.md §13 lines 517–537 | **PARTIAL RESTORE** | cur.md V.2#2 में form-default + grid optional और copy/paste+undo/redo backlog है; **freeze/duplicate/sort-filter/search/column-resize** restore (grid optional feature); “Excel import” = OBSOLETE (no import path decided; exports only) |
| B9 | Excel workbook default **12 sheets** (Cashbook Print, All Transactions, Income/Expense Summary, Work-wise, Other Category, Vendor, Fund, Monthly, Annual गोशवारा, Validation/Errors, Audit Trail) + raw-data sheet + formulas/filters/freeze/Hindi headings | old.md §14 lines 541–558 | **RESTORE** | cur.md F सिर्फ़ “multiple sheets” कहता है; यह concrete export acceptance list है |
| B10 | PDF export options: A4 **and Legal/A3** landscape, compact/split layout, header/footer, **page numbering**, signature fields, **Draft/Verified/Final watermark**, **password-protected PDF optional**; share targets: **WhatsApp, Email, device storage, print, open in Excel/Google Sheets** | old.md §15 lines 562–591 | **RESTORE** | cur.md F में landscape/watermark/signature संकेत हैं; A3/Legal, page numbering, password PDF, share targets explicit नहीं (WhatsApp = पं.समि./BDO को भेजने का मुख्य रास्ता) |
| B11 | Dashboard quick actions: Current Page, Reports, **Export, Search, Reconciliation** (plus baseline list) | old.md §16 lines 634–643 | **RESTORE** | cur.md J.1 की quick-action list छोटी है; Search/Export/Reconciliation shortcuts FY Home पर चाहिए थे |
| B12 | “Missing attachment warning **configurable**”, “Missing invoice/voucher report”, “Incomplete transaction report” | old.md §17 lines 656–661 | **RESTORE** | cur.md M में duplicate-invoice और incomplete-txn (report 19) हैं; **configurable attachment warning** और **missing invoice/voucher report** नहीं |
| B13 | Page verification stamp: S-12 “जाँचा-परखा” + user + date; admin-only column settings; admin-only locked-period correction | old.md §18 lines 676–686; Part C S-12 line 1477 | **PARTIAL RESTORE** | Page verification RESTORE (FY closing checklist “pages verified” बिना verification screen के खोखला; S-12 index से गायब); admin-only column/correction = already implied by D6 → OK; “export/attachment permissions” separate = **OBSOLETE** (Admin-only, single user — granular permission matrix की ज़रूरत नहीं) |
| B14 | Backup **zip** = DB (WAL checkpoint) + attachments + `manifest.json` (app version, schema version, date, checksum); naming `GP_<Name>_YYYY-MM-DD_vX.Y.zip` | old.md §4.2 lines 1084–1093 | **RESTORE** | cur.md D30/V.2#3 सिर्फ़ JSON backup कहता है; attachments/DB लेने के लिए zip+manifest ज़रूरी; naming = पुरानी files पहचानने में |
| B15 | Restore flow: fresh install पर old backups auto-detect → “पुराना डेटा मिला — Restore करें?” → list (date, size, app version) → checksum verify → **schema migrate करके** restore (sirf copy पर्याप्त नहीं) | old.md §4.3 lines 1095–1101 | **RESTORE** | सीधा instruction #14 का companion; cur.md में restore सिर्फ़ “restore” शब्द है, UX+migrate+integrity unspecified |
| B16 | First launch: `Documents/Cashbook` permission **COMPULSORY** screen (S-03) — बिना आगे नहीं; revoke हो तो सबसे पहले re-grant screen; **`Android/data` में backup कभी नहीं** (uninstall पर delete) | old.md §3 lines 1060–1068; Part C S-03 line 1461 | **RESTORE** | cur.md में S-03 screen index से गायब; instruction #14 को पूरा करने के लिए यही flow है |
| B17 | Screen S-04 “Restore Detected” (first launch / Settings से) — old backups list → select → restore | old.md Part C line 1462 | **RESTORE** | B16 का जोड़ू; Settings से भी खुलना चाहिए |
| B18 | Modular rules: **versioned migrations (no drop/rename, archived flag)**, backup before update, **rollback on failed update**, untrusted code download नहीं, feature manifest/registry, signed modules | old.md §21 lines 750–762 | **PARTIAL RESTORE** | migrations + backup-before-update = RESTORE (V.2#5 में है, यहाँ दोहराया acceptance में); **feature registry/plugin manifest/rollback** = **OBSOLETE** — app अब single Expo bundle है, dynamic feature modules नहीं (old Kotlin/Compose plan) |
| B19 | Acceptance extras: नया fund column जोड़ने पर **पूरी book** update; historical column archive पर data सुरक्षित; audit trail **old/new values** दिखाए; locked period unauthorized edit रोके; Hindi font में कोई black box नहीं | old.md §26 lines 923–943 | **RESTORE** | cur.md Q में ये 4 checks नहीं हैं (font check है) — gate में जोड़ने हैं (already listed in §16 here) |
| B20 | CI learnings: extracted files + official Gradle wrapper > zip; JVM17 fix source में permanent; एक समय में एक active workflow; build logs/APK downloadable | old.md §23 lines 789–878 | **PARTIAL OBSOLETE** | Kotlin/Gradle starter pipeline हट चुका है (अब Expo prebuild, PART T) — JVM/wrapper/zip-extract **OBSOLETE (history)**; **“one active workflow + downloadable logs”** = keep as working rule (T.1) |
| B21 | 2-page demo PDF record + reusable build script (12+12, 30-line, sample totals) | old.md §1.3 lines 998–1003, §24 lines 882–894 | **OBSOLETE** | superseded by real export pipeline (`services/exportDoc.ts`) — numbers/layout अब demo से नहीं, live data से बनते हैं |
| B22 | श्री पोते row की टिप्पणी में source: “विगत वर्ष का बचत शेष” (page 1) / “पूर्व पृष्ठ का बचत पोते” (बाद के pages); पहला साल = admin एक बार fund-wise manual opening | old.md §2.1 lines 1012–1016 | **RESTORE** | cur.md C.6 carry + CF/Manual badge कहता है, पर **print/screen पर यह source text** unspecified — ऑडिट में opening का source यही बताता है |
| B23 | Cashbook appearance settings: default हल्का हरा page tint; **transaction text blue (ball-pen)**; श्री पोते **light red**; top श्री पोते + bottom-3 **bold, size +1**; footer colour configurable; हर option के साथ **detailed on-screen help** | old.md §19.4.3 lines 1806–1818 | **RESTORE** | cur.md C.1 सिर्फ़ “light register tint” कहता है; ink-colour rules रजिस्टर-जैसा look देते हैं और instruction #2 (theme) के साथ जाते हैं |
| B24 | Cashbook header: “सिर्फ़ GP का नाम + वि.व. — **नीचे कोई date range नहीं**”; तिथि **सिर्फ़ श्री पोते की line** के सामने | old.md §16.2 lines 1602–1603 | **RESTORE** | header की composition तो PDF-lock (C.1) जीतती है (§C6), पर **“no date-range band”** और **date-on-श्री-पोते-only** rule अभी भी valid हैं — दोनों files में यह refinement गायब है |
| B25 | Bank account master: bank + खाता संख्या + **IFSC**; statement की a/c से account auto-identify, नया मिले तो एक बार master में; **duplicate-month warning** (period range से); full statement का **register/full-format print**; reconciliation = cheque/UTR reference | old.md §11.1 lines 1262–1265 | **RESTORE** | cur.md G सिर्फ़ “Bank account master” कहता है — auto-detect, duplicate warning, UTR reconciliation, full print unspecified हैं |
| B26 | Bank auto-entry engine full rules: credit = credit date पर (month-end mode optional); **10–15 day grouping window → एक दिन/एक page**, बड़ा range → 2 pages (हर group पर अलग balance condition); **labour consolidation suggestion** (same-same debits → एक entry); work dropdown for कार्य payments; AS/FS/TS किसी भी समय; review screen एक-tap accept | old.md §11.2 lines 1268–1298 | **RESTORE** | cur.md G में सिर्फ़ “grouping rules + D−1” (संक्षेप); V.2#11 में detail है पर **coded = D−1 + balance only** — बाक़ी rules spec में explicit रहने चाहिए |
| B27 | Privacy note (Round 4, **final — इस पर आगे चर्चा नहीं**): bank/estimate data cloud AI को जा सकता है — GP का data वैसे भी RTI/public-domain में; भविष्य में offline OCR optional | old.md §11.1 line 1266, §18.5 lines 1696–1697 | **RESTORE (as recorded decision)** | cur.md से गायब; दो online exceptions (AI estimate, bank OCR) का legal/privacy आधार यही है — re-litigate न हो, इसलिए दर्ज करना ज़रूरी |
| B28 | FY Home tiles/ledgers: **Material Ledger (Stock Register)** — वस्तु-wise कुल + full ledger; **Schemes tile** → scheme detail (opening, income, expenditure, payment vouchers); **Labour ledger** (man-days, rates); fee ledgers count + full list | old.md §15.2 lines 1421–1422, §12 lines 1306–1346 | **RESTORE** | cur.md F की report list में ये generic reports हैं पर **distinct screens/tiles** (S-28/S-30/S-31/S-32) गायब हैं; stock register तो audit में मुख्य register है |
| B29 | पट्टा income entry extra fields: पट्टा क्रमांक (auto-suggest), पट्टाधारक नाम, जारी दिनांक — पट्टा ledger में दिखें | old.md §12.6 lines 1341–1346 | **RESTORE (pending C12)** | cur.md PART VI में यह open backlog है; ऑडिट का सीधा सवाल “साल में कितने पट्टे” — इसलिए रखना है |
| B30 | Future features (18 items: bank reconciliation, advance register, liabilities register, निधि उपयोग प्रमाण-पत्र, budget vs actual, Hindi number-to-words, voice entry, templates, Devanagari numerals, e-sign stamp, year comparison, asset register, onboarding help, large-font/dark mode, reminders, multi-Panchayat/PanchayatId, TDS/GST, multi-device sync) | old.md §13 lines 1357–1378 | **RESTORE (as backlog register)** | cur.md PART R में सिर्फ़ 5 चीज़ें हैं; बाक़ी 13 (जिनमें से templates/reminder कुछ हद तक बन चुके हैं) भूल जाएँगी — इसलिए §17 में restore |
| B31 | Launch/panchayat page: Sample-3 dropdown minimal style, deep-green gradient header, **time-based English greeting**, “**100% ऑफ़लाइन · डेटा सुरक्षित**” note | old.md §15.1 lines 1402–1407 | **PARTIAL RESTORE** | Greeting = already backlog (V.2#17) — keep; **offline-note text + dropdown minimal style** = RESTORE (trust signal, instruction-adjacent); M3 light-green theme = superseded by #2 theme picker |
| B32 | Screen badge: **bottom-right corner**, muted/light colour, hide/show toggle in Settings (default visible) | old.md §15.3 lines 1426–1431 | **RESTORE (detail)** | cur.md K.2 में on/off है, position/muted styling unspecified — design lock के लिए |
| B33 | Distinct screens dropped from condensed index: S-03 permission, S-04 restore-detected, S-12 page verification, **S-23 Master Roll**, **S-28 Material Ledger**, **S-30 Scheme ledger**, **S-32 Patta/Fee ledgers** | old.md Part C lines 1461–1545 | **RESTORE** | cur.md O में ranges (S-17–S-26, S-28–S-34) ने इन्हें absorb कर लिया — implementation भूल न जाए, इसलिए §15 में वापस नामित |
| B34 | गोशवारा: हर महीने की **5 तारीख़ reminder notification** + **one-tap WhatsApp PDF share** (पं.समि./BDO को) | old.md §17.1(9) lines 1665, S-27 line 1513 | **PARTIAL RESTORE** | cur.md I में “optional monthly reminder” है; **WhatsApp one-tap share** गायब है — वही तो असली काम है |
| B35 | Cash/bank practice: नकद शुल्क का **मिश्रित उपयोग** (कुछ daily खर्च, कुछ बैंक जमा); **हर नकद राशि बैंक में जमा करना ज़रूरी नहीं** — जमा आंशिक और optional | old.md §17.1(2) lines 1656–1658 | **RESTORE** | cur.md G में “no bank→cash + cash→bank deposit type” है, पर **partial/optional deposit** का rule नहीं — instruction #10 (cash = माध्यम, own fund) के साथ यही GP practice है |
| B36 | Rate rules: **HARD RULE rate ≤ BSR**; safe band BSR से 10–20% कम (कारण: cross-FY काम में ऊँची BSR → **audit में recoverable**); **स्वीकृति वर्ष की BSR default**; ऊँची चुनने पर तुरंत warning; **CC में हमेशा दिखे किस वर्ष की BSR से गणना** | old.md §7.2 lines 1139–1148 | **RESTORE** | cur.md H में सिर्फ़ “rate band guidance” (D-spirit); sanction-year default = open **C2** — audit-rationale और “BSR year on CC” दोनों spec में explicitly रहने चाहिए |
| B37 | हर man-days calculation **audit trail** में जाए (rate, man-days, BSR year) — certificate के पीछे का गणित दोबारा दिखे | old.md §7.3(5) line 1156 | **RESTORE** | V.2#8 में “partial” — calc audit log के बिना CC का गणित verify नहीं होता |
| B38 | Bill module rules: **material-first payment** (labour/MR payment warning या strict block, configurable); **last-bill items** (पानी/टेंकर/मशीनरी/वाइब्रेटर/मिक्सर/डिस्प्ले बोर्ड/पॉलिश) सिर्फ़ last bill में; **qty flags** (cement/ईंट = whole, loose = decimal); **basic items front-load suggestion**; **material bills योग = CC material validation**; payment-time **live spend status + excess-payment warning** | old.md §8 lines 1178–1216 | **RESTORE (pending C3/C4/C5)** | cur.md PART VI में ये open backlog हैं (masters बने हुए हैं) — audit के ये exactly वो rules हैं जो अक्सर टूटते हैं; इसलिए Section B में visible रखना ज़रूरी |
| B39 | CC/UC **format = actual Rajasthan Panchayati Raj sample** जब user दे — layout उसी के अनुसार | old.md §10 line 1248 | **RESTORE (as rule)** | demo xlsx अब lock है (D27), पर “user का actual sample = final format” का नियम भविष्य के प्रपत्रों (रसीद/पर्ची भी) पर लागू होना चाहिए |
| B40 | AI Estimate Reader: cloud OCR, **mandatory operator review step**, offline-policy exception #1, needs 2–3 sample estimate PDFs | old.md §9 lines 1219–1228 | **RESTORE (as deferred module)** | V.2#10 में है पर “deferred” के साथ duplicate न हो, इसलिए यहाँ register में दर्ज — requirement (review अनिवार्य) कभी हल्की न पड़े |
| B41 | Main-page/S-02 GP dropdown minimal style + “प्रवेश करें” button; **Panchayat selection हर बार दिखे**; FY page पर सिर्फ़ FY status + chooser | old.md §14 rows 8–11 lines 1393–1396, §15.1 | **RESTORE (confirm)** | cur.md K.1 flow में implicit है; “हर बार” और FY page की सादगी explicitly confirm कर लेना चाहिए (बदलाव = decision required) |
| B42 | Report rule: हर report में compulsory Excel/PDF export + share + print (22 reports) | old.md §12 lines 478–513 | *already covered* | cur.md F (23 reports + compulsory share row) — **no action** (listed only for completeness of the mining pass) |
| B43 | 30-line structure, श्री पोते twice (line 1 + 29), 26/27 split, green print hybrid, default user “Harish Patidar”, 47-screen fixed numbering, Kotlin/Room starter, demo-PDF pipeline | old.md §3/§2.2, §16.1, §18.2, §23–25, §27 | **OBSOLETE** | superseded by PDF-sample lock (25 lines, C1), user decisions C9/C10, Expo/AsyncStorage stack, live export pipeline — see Section C |

**Count: 43 mined items — 34 RESTORE (some partial), 9 OBSOLETE / already-covered.**

---

## C. विरोधाभास (contradictions) old vs new

| # | Old spec said | New spec says | Decision | Why |
|---|---|---|---|---|
| C-1 | हर पृष्ठ **30 lines**; income 26 txn + expense 27 txn (26/27 split) | **25 lines**, txn = L − 4 (21) | **NEW wins** | User decision C1 (24-09): real Excel/PDF sample (`DOC-20260622-WA0002`) का grid = source of truth, 30-line mode नहीं |
| C-2 | श्री पोते **दो बार** (line 1 + line 29, symmetry) | श्री पोते **सिर्फ़ top**; bottom-left = **पूर्व पोते** | **NEW wins** | PDF wording lock (C.4/C.9) — sample page पर bottom label “पूर्व पोते” है; repeat = double-count risk |
| C-3 | Page background हल्का हरा (#e9f4e9) + **hybrid print option** (रंगीन/सफ़ेद) | Screen: light register tint; **share/PDF = white only** (D14) | **NEW wins (C9)** | User decision: white-only print (ink cost + official copies); screen tint रहेगा (B23 appearance rules) |
| C-4 | Header = “सिर्फ़ GP नाम + वि.व.”, नीचे कोई date range नहीं | Header = GP + पं.समिति + जिला + वि.व. + पृष्ठ संख्या (C.1) | **NEW wins for composition; OLD rule kept (B24)** | C.1 = actual sample PDF lock; **date-range band नहीं** वाला refinement अभी भी लागू |
| C-5 | Line-count setting default **30** (19.2.3) | Default **25** (D1) | **NEW wins** | Same PDF lock as C-1; setting still allows L change |
| C-6 | Default fund = Cash column (§8) + separately entry scheme required | Cash = **माध्यम, योजना नहीं**; cash txn default **Own Fund**; दूसरी schemes dropdown (#10) | **NEW wins (reinforced)** | Instruction #10 (2026-09) explicit; own-fund column already in sample PDF |
| C-7 | **Sanction-year BSR default** + higher-year warning + CC shows BSR year (§7.2) | cur.md: सिर्फ़ “rate band −10…−20% guidance”; sanction-year default **not implemented** | **OLD wins as intent → OPEN (C2)** | Audit-rationale (recoverable risk) unchanged; pending user go-ahead in PART VI backlog |
| C-8 | Material-first payment **enforcement** (warning/strict block configurable) | cur.md silent | **OLD restored → OPEN (C3)** | Payment sequence = audit finding; user decision pending |
| C-9 | Last-bill items fixed list; whole/decimal qty flags | cur.md silent (masters hold flags) | **OLD restored → OPEN (C4/C5)** | Data model ready; UI rules pending user confirmation |
| C-10 | L.F. column दोनों forms में | cur.md entry form में L.F. नहीं (PDF C.3 में column है) | **OLD wins → DONE (C6, implemented)** | Ledger↔entry cross-verify के लिए L.F. ज़रूरी (user decision VI) |
| C-11 | Har transaction attachment (receipt/bill photo + PDF) | note-only; attachments backlog (C7) | **OPEN (C7)** | old rule restore on user confirmation; expo-image-picker present |
| C-12 | Blank-line gap Option A/B (default 1) | D1: gap 1|2 in settings | **NEW (same content)** | No real conflict — setting exists; default = 1 (C8 minor) |
| C-13 | First-run **8-logo chooser** + default user “Harish Patidar — Operator” | Logo fixed in app.json; admin generic | **SPLIT:** logo chooser **OLD restored (C10, implemented)**; default user **NEW wins** | User ने logo chooser चुना, default user seed नहीं चुना (PART VI) |
| C-14 | Password re-confirm on panchayat **and FY** edit/delete | panchayat destructive/edit only | **OLD wins → DONE (C11, implemented)** | FY add/close पर भी PIN confirm (user decision VI) |
| C-15 | पट्टा extra fields (क्रमांक/पट्टाधारक/जारी दिनांक) | not present | **OPEN (C12)** | Restore as backlog |
| C-16 | Screen index **exactly 47** (S-01…S-47), App Settings S-47 | Condensed index, renumber freely; App Settings **always last** | **NEW wins (process)** | Same intent; numbers now fluid — Section 15 restores missing *names* (B33) even if numbers shift |
| C-17 | Multi-role (Operator/Checker/Approver/Viewer) lists | **Admin only** (D6/19.1) | **NEW wins (agreed)** | old doc itself marks multi-role deferred (Round 5) — not a real conflict |
| C-18 | PDF: HTML→Chromium/Android-native shaping pipeline (ReportLab banned) | Expo `expo-print` + embedded Devanagari | **No conflict — requirement restated** | Binding rule = **shaping-capable renderer + Noto, Mangal banned**; expo-print (Chromium print pipeline) satisfies it — keep B10 font rules as the acceptance test |
| C-19 | Backup = zip + manifest + retention; restore = migrate + checksum | Backup = JSON share/save + retention (D30/V.2#3); restore unspecified | **NEW wins for what's built; OLD restored as target (B14/B15)** | JSON keeps “readable in 5 years”; zip/migrate flow needed for full-fidelity restore (#14) |
| C-20 | Demo/sample training mode | **Rejected** | **Agreed — OUT (both)** | old §17.2 rejected, cur.md PART R keeps it out |

---

## D. Implementation status (v6)

> Evidence: `extracted\cashbook-mobile\app\index.tsx` (3,925 lines; 27 screens + Pin/Cancel modals), `services/` (`backupFolder, exportDoc, formats, mandays, pageEngine`), `types/models.ts`, `context/AppStore.tsx`. All 15 instructions carry code markers (`/* instruction #N */`).

**Screens present (Stage union):** login, panchayat, appSettings, fy, fySettings, home, cashbook, entry, funds, categories, monthly, goswara, reports, ledgers, backup, bank, works, workDetail, mb, manday, bills, cc, formats, masters, closing. **Not present as dedicated screens:** S-03 storage-permission gate, S-04 restore-detected, page-verification, material-ledger/stock-register tile, scheme-detail screen (see B16/B17/B13/B28).

| # | Instruction | Status | Evidence |
|---|---|---|---|
| 1 | Login button visible / layout fixed | **Implemented** | `LoginScreen` — `KeyboardAvoidingView` + `ScrollView flexGrow` (comment: “fixed-height screen → login button niche chala jata tha”) |
| 2 | Theme colour in App Settings | **Implemented** | `AppSettingsScreen` “Theme colour (6 रंग)”, `app.themeId`, `applyThemeAndStyles` |
| 3 | MB material/labour grouping + कारीगर toggle (default labour) | **Implemented** | `MbScreen` (two parts + subtotals), `models.ts` `karigarIn: 'labour' \| 'material'` default labour |
| 4 | Manday sanction-in-sanction + prefilled BSR page + 2–3 closest combos | **Implemented (verify combo count)** | `MandayScreen` + BSR page (items pre-seeded: सीमेंट/रेत/गिट्टी 40-20-12/पत्थर/ईंट…), `AppStore` rate-missing → BSR open, `services/mandays.ts suggestCombos()` sorted by closeness, **returns top 8** — UI must show only 2–3 |
| 5 | Bills vendor dropdown + add-in-place | **Implemented** | `BillsScreen` — `vendors`, `addVendor`, dropdown + “यहीं से add” |
| 6 | CC 7 pages in uploaded Excel format + PDF/Excel share | **Implemented** | `CcScreen`, `services/formats.ts` CC section (पृष्ठ 1…7), `exportDoc.ts` (expo-print PDF + .xls) |
| 7 | Expense Work \| Other, in-dropdown new work, category CRUD | **Implemented** | `EntryScreen` “खर्च का प्रकार”, in-list “नया कार्य”, `CategoriesScreen`/category level list add-rename-delete |
| 8 | Work form: scheme, AS/TS/FS, dates, MB status + MB details | **Implemented** | `WorkForm` “Instruction #8 — योजना, AS/TS/FS …, शुरू/पूर्ण तिथि, MB स्थिति”, `models.ts` sanction/MB block; scheme auto-select on work pick in entry |
| 9 | Minimal entry fields, one scheme per entry, no repeat asking | **Implemented** | `EntryScreen` “instruction #9 — सिर्फ़ date, किससे प्राप्त, राशि, योजना, श्रेणी”; one-scheme save |
| 10 | Thin cashbook (one side fits) + cash = medium, default own fund | **Implemented** | `CashbookScreen` narrowed columns + scale (instruction #10), hint “नकद … default Own Fund” |
| 11 | गोशवारा + ledger two-side, original Excel/PDF type | **Implemented** | `formats.ts buildGoswara` (मद-wise आय\|व्यय), ledger = खाता बही rows (श्री पोते → जमा/नाम → running शेष) |
| 12 | सभी प्रपत्र original look + Excel-type + Excel & PDF share | **Implemented** | `FormatsScreen` + `formats.ts` (गोशवारा/प्रपत्र-1/प्रपत्र-4/ledger/bank/CC) + `exportDoc.shareFormat` (PDF \| Excel dialog) |
| 13 | Bank statement fields = uploaded Excel + 5-way tagging | **Implemented** | `BankScreen` “instruction #13”, `models.ts` `BankLine` + `vendorId/categoryId/note` tagging |
| 14 | Backup/restore in user folder, app-granted permission, uninstall-safe, no `Android/data` | **Implemented (device test pending)** | `services/backupFolder.ts` — SAF `Directory.pickDirectoryAsync`, permission persisted, list/read/delete in that folder; `BackupScreen` |
| 15 | Return to same page + zoom (pinch or ±) | **Partially implemented** | `cashbookUI = { page, zoom }` persists across entry→back; `− / reset / +%` controls present; **no pinch-gesture handler found** — pinch still pending |

**Not covered by the 15 but built in v6 (from `services/` + screens):** page engine (L, txn = L−4, carry-forward), FY closing wizard, formats centre, masters (BSR/Item/Holiday/Worker/Vendor), monthly check, FY settings with PIN confirm, 8-logo first-run chooser.

**Known gaps to track (mostly Section B):** S-03/S-04 permission+restore screens, page verification stamp, material ledger/scheme-detail tiles, zip+manifest backup & migrate-restore flow, PDF option set (page numbers/A3/watermark), Excel 12-sheet workbook, edit-reason picklist, correction-entry fields, sanction-year BSR default (C2), material-first/last-bill/qty rules (C3–C5), txn attachments (C7), patta fields (C12), pinch zoom, WhatsApp one-tap गोशवारा share.

---

**End of consolidated master document.** Implementation and GitHub issues should quote section ids (e.g. `C.2`, `A4`, `B15`, `C-7`, `D-4`).
