/** PROJECT_MASTER Part C — page engine helpers
 *  NOTE: प्रपत्र/ledger/गोशवारा builders `services/formats.ts` me hain (yahan duplicate nahi). */

import type { CategoryNode } from '@/types/models';

/** Local-time ISO date (UTC toISOString IST me 1 din peeche deta tha — bug fix) */
export function toIsoLocal(d: Date) {
  const m = `${d.getMonth() + 1}`.padStart(2, '0');
  const day = `${d.getDate()}`.padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

/** Part M: invalid date guard — strict YYYY-MM-DD + real calendar date */
export function isValidIsoDate(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split('-').map((n) => parseInt(n, 10));
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

/** D3 / C.4.1: txn lines = totalLines − 4 (1 श्री पोते zone + 3 footer) */
export function transactionLineCount(totalLines: number) {
  return Math.max(1, totalLines - 4);
}

export function sumAmounts(amounts: Record<string, number>) {
  return Object.values(amounts).reduce((s, a) => s + (Number(a) || 0), 0);
}

export function formatINR(n: number) {
  const neg = n < 0;
  const abs = Math.abs(Math.round(n * 100) / 100);
  const [r, p] = abs.toFixed(2).split('.');
  return `${neg ? '-' : ''}₹${r.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}.${p}`;
}

export type TxLike = {
  /** 'transfer' = नकद→बैंक जमा (income/expense nahi — Part G) */
  type: 'income' | 'expense' | 'transfer';
  date: string;
  status: string;
  amounts: Record<string, number>;
  schemeId: string;
  pageId?: string | null;
};

/** Day महायोग: opening + income through date − expense before date (D8 guard) */
export function dayMahayog(opening: number, txs: TxLike[], date: string): number {
  const active = txs.filter((t) => t.status === 'active');
  const incomeToDate = active
    .filter((t) => t.type === 'income' && t.date <= date)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const expenseBefore = active
    .filter((t) => t.type === 'expense' && t.date < date)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
  return opening + incomeToDate - expenseBefore;
}

export function dayExpenseTotal(txs: TxLike[], date: string) {
  return txs
    .filter((t) => t.status === 'active' && t.type === 'expense' && t.date === date)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
}

/** Per-fund balance. income/transfer = add (transfer amounts signed: cash −X, bank +X),
 *  expense = subtract — नकद→बैंक जमा per-fund sahi rakhta hai. */
export function schemeBalance(fundId: string, opening: number, txs: TxLike[]) {
  const active = txs.filter((t) => t.status === 'active');
  const inc = active
    .filter((t) => t.type === 'income' || t.type === 'transfer')
    .reduce((s, t) => s + (Number(t.amounts[fundId]) || 0), 0);
  const exp = active
    .filter((t) => t.type === 'expense')
    .reduce((s, t) => s + (Number(t.amounts[fundId]) || 0), 0);
  return opening + inc - exp;
}

/**
 * C.6 carry-forward: page[n] श्री पोते राशि[fund] = page[n−1] बचत पोते[fund].
 * targetIdx = jis page ka opening chahiye (0 = FY opening).
 */
export function pageOpenings(
  funds: { id: string; openingBalance: number }[],
  pages: { id: string }[],
  txns: TxLike[],
  targetIdx: number
): Record<string, number> {
  const open: Record<string, number> = {};
  for (const f of funds) open[f.id] = f.openingBalance;
  const upto = Math.max(0, Math.min(targetIdx, pages.length));
  for (let i = 0; i < upto; i++) {
    const pid = pages[i].id;
    for (const t of txns) {
      if (t.status !== 'active' || t.pageId !== pid) continue;
      for (const f of funds) {
        const a = Number(t.amounts[f.id]) || 0;
        if (t.type === 'income' || t.type === 'transfer') open[f.id] += a;
        else if (t.type === 'expense') open[f.id] -= a;
      }
    }
  }
  return open;
}

/** E / D29: full category path label — "शुल्क › जन्म प्रमाण" */
export function categoryPathLabel(
  t: { categoryId: string | null; subcategoryId: string | null; subSubcategoryId: string | null },
  names: Record<string, string>
) {
  const ids = [t.categoryId, t.subcategoryId, t.subSubcategoryId].filter(Boolean) as string[];
  if (!ids.length) return '';
  return ids.map((id) => names[id] || id).join(' › ');
}

/** J.2 incomplete flag: category path ka deepest applicable level bhara hona chahiye */
export function isPathIncomplete(
  t: { categoryId: string | null; subcategoryId: string | null; subSubcategoryId: string | null },
  categories: CategoryNode[]
) {
  if (!t.categoryId) return true;
  const hasChild = (pid: string) => categories.some((c) => c.parentId === pid && !c.archived);
  if (!hasChild(t.categoryId)) return false; // leaf level-1 → path complete
  if (!t.subcategoryId) return true;
  if (!hasChild(t.subcategoryId)) return false;
  return !t.subSubcategoryId;
}
