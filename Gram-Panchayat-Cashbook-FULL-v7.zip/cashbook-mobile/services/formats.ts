/**
 * formats.ts — GP formats from user-provided demo files.
 * हर entry add/edit/cancel पर ये builders re-run होते हैं (ledger-like auto update).
 * Sources: audit formet demo.xlsx, bank statement demo.xlsx,
 *          cc talora chaina mojek.xlsx, ledger.pdf (standard खाता बही)
 */
import type { Bill, MbLine, PakhwadaRoll, Transaction, Work } from '@/types/models';
import { formatINR, sumAmounts } from './pageEngine';

export type FmtHeader = {
  panchayat: string;
  block: string;
  district: string;
  fy: string;
  formName: string;
  extra?: string;
};

function head(h: FmtHeader): string[] {
  const L = [
    `कार्यालय ${h.panchayat}`,
    `पं.समिति — ${h.block}  |  जिला — ${h.district}`,
    `वित्तीय वर्ष: ${h.fy}`,
  ];
  if (h.extra) L.push(h.extra);
  L.push(h.formName);
  return L;
}

function csvJoin(rows: (string | number)[][]) {
  return rows
    .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(','))
    .join('\n');
}

const R = (n: number) => (Math.round(n * 100) / 100).toFixed(2);

/* ═══════════ 1. गोशवारा — audit demo sheet 1 (वार्षिक आय-व्यय सामान्य रोकड़ बही) ═══════════ */

export type GoswaraRow = { name: string; inc: number; exp: number };

export function buildGoswara(
  txs: Pick<Transaction, 'type' | 'status' | 'schemeId' | 'amounts' | 'categoryId' | 'subcategoryId' | 'subSubcategoryId' | 'party' | 'detail'>[],
  categoryNames: Record<string, string>,
  opening: number
) {
  const active = txs.filter((t) => t.status === 'active');
  const mad = new Map<string, GoswaraRow>();
  for (const t of active) {
    if (t.type === 'transfer') continue; // नकद→बैंक जमा आय/व्यय नहीं (Part G)
    // E.3: मद = full category path (L1 › L2 › L3)
    const ids = [t.categoryId, t.subcategoryId, t.subSubcategoryId].filter(Boolean) as string[];
    const key = ids.length ? ids.join('/') : `scheme:${t.schemeId}`;
    const name = ids.length
      ? ids.map((id) => categoryNames[id] || id).join(' › ')
      : `योजना: ${t.schemeId}`;
    if (!mad.has(key)) {
      mad.set(key, { name, inc: 0, exp: 0 });
    }
    const e = mad.get(key)!;
    const tot = sumAmounts(t.amounts);
    if (t.type === 'income') e.inc += tot;
    else if (t.type === 'expense') e.exp += tot;
  }
  const aayYog = active.filter((t) => t.type === 'income').reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const vyayYog = active.filter((t) => t.type === 'expense').reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const mahayog = opening + aayYog;
  return {
    rows: [...mad.values()],
    aayYog,
    vyayYog,
    prarambhikNagad: opening,
    mahayog,
    antSheshNagad: mahayog - vyayYog,
  };
}

export function goswaraCsv(g: ReturnType<typeof buildGoswara>, h: FmtHeader) {
  const rows: (string | number)[][] = head(h).map((t) => [t]);
  rows.push([]);
  rows.push(['क्र.', 'नाम मद', 'आय', 'व्यय']);
  g.rows.forEach((r, i) => rows.push([i + 1, r.name, R(r.inc), R(r.exp)]));
  rows.push(['', 'आय योग', R(g.aayYog), '']);
  rows.push(['', 'व्यय योग', '', R(g.vyayYog)]);
  rows.push(['', 'प्रारम्भिक शेष नगद', R(g.prarambhikNagad), '']);
  rows.push(['', 'महायोग', R(g.mahayog), '']);
  rows.push(['', 'अंतिम शेष नगद', R(g.antSheshNagad), '']);
  rows.push(['', 'प्रारम्भिक शेष बैंक', '', '']); // bank module se auto
  rows.push(['', 'अंतिम शेष बैंक', '', '']);
  rows.push([]);
  rows.push(['हस्ताक्षर', '', '', '']);
  rows.push(['सरपंच', '', '', '']);
  rows.push(['ग्राम विकास अधिकारी', '', '', '']);
  return csvJoin(rows);
}

/* ═══════════ 2. प्रपत्र-1 — SFC/TFC/FFC/BRGF कार्य विवरण (audit demo sheet 2) ═══════════ */

export type Prapt1Row = {
  workName: string;
  schemeName: string;
  fsRef: string;
  fsLakh: number;
  priorExpense: number;
  yearExpense: number;
  totalExpense: number;
  status: string;
  mulyaankan: number;
  mbRef: string;
  labourAmount: number;
  materialAmount: number;
};

export function buildPrapt1(
  works: Work[],
  mbLines: MbLine[],
  txs: Pick<Transaction, 'type' | 'status' | 'workId' | 'amounts' | 'schemeId'>[],
  fundNames: Record<string, string>,
  priorFor: (w: Work) => number
): Prapt1Row[] {
  return works.map((w) => {
    const labour = mbLines.filter((m) => m.workId === w.id && m.kind !== 'material').reduce((s, m) => s + m.qty * m.rate, 0);
    const material = mbLines.filter((m) => m.workId === w.id && m.kind === 'material').reduce((s, m) => s + m.qty * m.rate, 0);
    const yearExp = txs
      .filter((t) => t.status === 'active' && t.type === 'expense' && t.workId === w.id)
      .reduce((s, t) => s + sumAmounts(t.amounts), 0);
    const prior = priorFor(w);
    return {
      workName: w.name,
      schemeName: fundNames[w.schemeId] || w.schemeId,
      fsRef: w.sanctionRef || '—',
      fsLakh: (w.fsAmount || 0) / 100000, // FS वित्तीय स्वीकृति राशि → लाख (D24)
      priorExpense: prior,
      yearExpense: yearExp,
      totalExpense: prior + yearExp,
      status: w.status === 'completed' ? 'पूर्ण' : 'प्रगतिरत',
      mulyaankan: labour + material, // MB valuation
      mbRef: `MB ${mbLines.filter((m) => m.workId === w.id).length} lines`,
      labourAmount: labour,
      materialAmount: material,
    };
  });
}

export function prapt1Csv(rows: Prapt1Row[], h: FmtHeader) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  out.push([
    'क्र.',
    'कार्य का नाम',
    'योजना का नाम',
    'वित्तीय स्वीकृति क्रमांक/दिनांक',
    'स्वीकृत राशि (लाख)',
    'पूर्व में किया गया व्यय',
    'आलोच्य वर्ष में व्यय',
    'आलोच्य वर्ष तक कुल व्यय',
    'कार्य की स्थिति',
    'मूल्यांकन राशि',
    'MB संदर्भ',
    'श्रम राशि',
    'सामग्री राशि',
  ]);
  rows.forEach((r, i) =>
    out.push([
      i + 1,
      r.workName,
      r.schemeName,
      r.fsRef,
      r.fsLakh,
      R(r.priorExpense),
      R(r.yearExpense),
      R(r.totalExpense),
      r.status,
      R(r.mulyaankan),
      r.mbRef,
      R(r.labourAmount),
      R(r.materialAmount),
    ])
  );
  return csvJoin(out);
}

/* ═══════════ 3. प्रपत्र-4 — निर्माण कार्यों पर व्यय की गयी सामग्री राशि (audit demo sheet 3) ═══════════ */

export type Prapt4Row = { name: string; qty: number; unit: string; rate: number; cost: number };

export function buildPrapt4(mbLines: MbLine[]): Prapt4Row[] {
  const byItem = new Map<string, Prapt4Row>();
  for (const m of mbLines.filter((x) => x.kind === 'material')) {
    const key = m.itemName.trim() || 'अन्य';
    if (!byItem.has(key)) byItem.set(key, { name: key, qty: 0, unit: '', rate: m.rate, cost: 0 });
    const e = byItem.get(key)!;
    e.qty += m.qty;
    e.rate = m.rate || e.rate;
    e.cost += m.qty * m.rate;
  }
  return [...byItem.values()];
}

export function prapt4Csv(rows: Prapt4Row[], h: FmtHeader) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  out.push(['नाम सामग्री', 'मात्रा', 'इकाई', 'दर', 'कीमत', 'योग']);
  rows.forEach((r) => out.push([r.name, r.qty, r.unit, R(r.rate), R(r.cost), R(r.cost)]));
  const tot = rows.reduce((s, r) => s + r.cost, 0);
  out.push(['योग', '', '', '', R(tot), R(tot)]);
  return csvJoin(out);
}

/* ═══════════ 4. Bank statement grid (bank demo) — tag → post pipeline ke saath ═══════════ */

export function bankStatementCsv(
  lines: { date: string; narration: string; side: string; amount: number; instrument: string; schemeId: string | null; postedTxnId: string | null }[],
  h: FmtHeader
) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  out.push(['दिनांक', 'विवरण', 'जमा/नाम', 'राशि', 'चेक/इन्स्ट्रूमेंट', 'योजना टैग', 'पोस्ट']);
  lines.forEach((l) =>
    out.push([l.date, l.narration, l.side === 'credit' ? 'जमा' : 'नाम', R(l.amount), l.instrument || '—', l.schemeId || '—', l.postedTxnId ? 'हाँ' : 'नहीं'])
  );
  return csvJoin(out);
}

/* ═══════════ 5. Ledger — standard GP खाता बही (ledger.pdf layout) ═══════════ */

export type LedgerRow = { date: string; ref: string; folio: string; party: string; detail: string; debit: number; credit: number; running: number };

export function buildLedger(
  opening: number,
  txs: Pick<Transaction, 'type' | 'date' | 'reference' | 'party' | 'detail' | 'status' | 'amounts' | 'ledgerFolio'>[],
  fundId?: string
): LedgerRow[] {
  const rows: LedgerRow[] = [
    { date: '', ref: '', folio: '', party: 'श्री पोते राशि', detail: 'प्रारंभिक शेष', debit: 0, credit: 0, running: opening },
  ];
  let running = opening;
  for (const t of txs.filter((x) => x.status === 'active').sort((a, b) => a.date.localeCompare(b.date))) {
    // transfer = signed per-fund amount (cash −X / bank +X); all-funds view = net 0 → skip
    const amt = fundId ? Number(t.amounts[fundId]) || 0 : sumAmounts(t.amounts);
    if (!amt) continue;
    const signed = t.type === 'expense' ? -amt : amt; // income +, expense −, transfer ± (signed input)
    running += signed;
    rows.push({
      date: t.date,
      ref: t.reference || '—',
      folio: t.ledgerFolio || '',
      party: t.party,
      detail: t.detail,
      debit: signed < 0 ? Math.abs(signed) : 0,
      credit: signed > 0 ? signed : 0,
      running,
    });
  }
  return rows;
}

export function ledgerCsv(rows: LedgerRow[], h: FmtHeader) {
  const out: (string | number)[][] = head(h).map((t) => [t]);
  out.push([]);
  out.push(['दिनांक', 'चेक/DD/वाउचर न.', 'L.F.', 'किस से प्राप्त / किसको भुगतान', 'विवरण', 'जमा', 'नाम', 'शेष']);
  rows.forEach((r) => out.push([r.date, r.ref, r.folio || '', r.party, r.detail, r.credit ? R(r.credit) : '', r.debit ? R(r.debit) : '', R(r.running)]));
  const dr = rows.reduce((s, r) => s + r.debit, 0);
  const cr = rows.reduce((s, r) => s + r.credit, 0);
  // bug fix: योग row 7 cells thi → columns shift ho rahe the; ab 8 cells (header alignment)
  out.push(['योग', '', '', '', '', R(cr), R(dr), R(rows[rows.length - 1]?.running || 0)]);
  return csvJoin(out);
}

/* ═══════════ 6. CC — कार्य पूर्णता प्रमाण पत्र (cc demo, 7 pages) ═══════════ */

export const CC_INSTRUCTIONS =
  'मार्गदर्शिका: कार्य का मूल्यांकन ग्रामीण कार्य निर्देशिका 2010 के प्रावधानों अनुसार। ' +
  'अनुमत राशि = स्वीकृत राशि की सीमा में (वास्तविक व्यय, मूल्यांकन राशि) में से जो कम हो।';

export function ccBuild(input: {
  work: Work;
  mbLines: MbLine[];
  bills: Bill[];
  rolls: PakhwadaRoll[];
  txs: Pick<Transaction, 'type' | 'status' | 'workId' | 'amounts'>[];
  fsAmount: number;
  asAmount: number;
}) {
  const labourLines = input.mbLines.filter((m) => m.workId === input.work.id && m.kind !== 'material');
  const materialLines = input.mbLines.filter((m) => m.workId === input.work.id && m.kind === 'material');
  const labour = labourLines.reduce((s, m) => s + m.qty * m.rate, 0);
  const material = materialLines.reduce((s, m) => s + m.qty * m.rate, 0);
  const mulyaankan = labour + material;
  const paid = input.bills.filter((b) => b.workId === input.work.id).reduce((s, b) => s + b.amount, 0);
  const actualExpense = input.txs
    .filter((t) => t.status === 'active' && t.type === 'expense' && t.workId === input.work.id)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
  // अनुमत राशि = min(FS, मूल्यांकन, वास्तविक व्यय) — स्वीकृति सीमा के भीतर
  const allowable = Math.min(
    input.fsAmount > 0 ? input.fsAmount : Infinity,
    input.asAmount > 0 ? input.asAmount : Infinity,
    mulyaankan > 0 ? mulyaankan : Infinity,
    actualExpense > 0 ? actualExpense : Infinity
  );
  const finite = Number.isFinite(allowable) ? allowable : 0;
  return {
    labour,
    material,
    mulyaankan,
    paid,
    actualExpense,
    allowable: finite,
    residualMaterial: Math.max(0, finite - paid),
    mandays: input.rolls.reduce(
      (acc, r) => ({
        mate: acc.mate + r.mateCount * r.days,
        skilled: acc.skilled + r.skilledCount * r.days,
        unskilled: acc.unskilled + r.unskilledCount * r.days,
        wage: acc.wage + (r.mateCount * r.days * r.wageMate + r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled),
      }),
      { mate: 0, skilled: 0, unskilled: 0, wage: 0 }
    ),
  };
}

export function ccCsv(
  c: ReturnType<typeof ccBuild>,
  h: FmtHeader,
  work: { name: string; sanctionRef: string; ward: string }
) {
  const out: (string | number)[][] = [];
  out.push(head(h));
  out.push([]);
  out.push(['कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ) — ' + work.name]);
  out.push([]);
  out.push(['पृष्ठ 1 — कार्य पूर्णता प्रमाण पत्र']);
  out.push(['1- कार्य का नाम', work.name]);
  out.push(['4- वास्तविक व्यय (लेखे अनुसार)', R(c.actualExpense)]);
  out.push(['5- माप पुस्तिका में मूल्यांकन राशि', R(c.mulyaankan)]);
  out.push(['8- कुल अनुमत राशि (min rules)', R(c.allowable)]);
  out.push(['भुगतान योग्य राशि / शेष', R(c.residualMaterial)]);
  out.push([]);
  out.push(['पृष्ठ 2 — उपयोगिता प्रमाण पत्र (UC)']);
  out.push(['कुल व्यय', R(c.actualExpense), 'अनुमत', R(c.allowable)]);
  out.push([]);
  out.push(['पृष्ठ 3 — श्रमिकों पर व्यय का विवरण (पाक्षिक मस्टरोल)']);
  out.push(['मेट मानव दिवस', c.mandays.mate]);
  out.push(['कुशल मानव दिवस', c.mandays.skilled]);
  out.push(['अकुशल मानव दिवस', c.mandays.unskilled]);
  out.push(['कुल श्रम व्यय (mandays × wage rate)', R(c.mandays.wage)]);
  out.push(['MB श्रम मद योग', R(c.labour)]);
  out.push(['नोट', 'मानव दिवस = श्रमिक संख्या × दिन; व्यय = मानव दिवस × दर (निर्देशिका अनुसार)']);
  out.push([]);
  out.push(['पृष्ठ 4 — सामग्री पर व्यय का विवरण (MB अनुसार)']);
  out.push(['सामग्री योग', R(c.material)]);
  out.push([]);
  out.push(['पृष्ठ 5 — तकनीकी निरीक्षण रिपोर्ट']);
  out.push(['मूल्यांकन जांच', 'ग्रामीण कार्य निर्देशिका 2010 अनुसार']);
  out.push([]);
  out.push(['पृष्ठ 6 — पूर्ण कार्य का फोटो + हस्ताक्षर']);
  out.push(['पृष्ठ 7 — पहले व कार्य के दौरान फोटो']);
  out.push([]);
  out.push(['हस्ताक्षर — सरपंच', '', 'ग्राम विकास अधिकारी', '', 'कनिष्ठ अभियंता']);
  return csvJoin(out);
}

export { formatINR };
