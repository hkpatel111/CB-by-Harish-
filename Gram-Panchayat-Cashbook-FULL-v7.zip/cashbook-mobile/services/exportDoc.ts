/**
 * exportDoc.ts — instructions #6, #11, #12, #13
 * Har format ka export/share: **PDF** (expo-print, print-ready) + **Excel** (.xls table file).
 * HTML table hi dono jagah chalta hai → format ek hi jagah likho, do share button.
 *
 * D14: print/PDF white background hi (screen ka green tint share me nahi jata).
 */
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { File, Paths } from 'expo-file-system';

export const DOC_CSS = `
  * { box-sizing: border-box; }
  body {
    font-family: 'Noto Sans Devanagari', 'Mangal', 'Nirmala UI', 'Segoe UI', sans-serif;
    font-size: 12px; color: #111; background: #fff; margin: 0;
  }
  h1 { font-size: 16px; text-align: center; margin: 6px 0 2px; }
  .head { text-align: center; line-height: 1.5; margin-bottom: 6px; }
  .head .sm { font-size: 11px; color: #333; }
  table { border-collapse: collapse; width: 100%; margin-bottom: 8px; }
  th, td { border: 1px solid #444; padding: 3px 5px; font-size: 11px; vertical-align: top; }
  th { background: #e8f2ec; font-weight: 700; text-align: center; }
  .r { text-align: right; }
  .c { text-align: center; }
  .b { font-weight: 700; }
  .pg { page-break-before: always; }
  .sign td { height: 46px; vertical-align: bottom; font-size: 11px; }
  .note { font-size: 10px; color: #333; margin-top: 4px; }
  .two td { width: 50%; }
  @page { size: A4 portrait; margin: 10mm; }
  @page landscape { size: A4 landscape; margin: 8mm; }
`;

export type DocOpts = {
  title: string;
  body: string;
  /** register/goswara jaise chaude formats ke liye landscape */
  landscape?: boolean;
};

/** Printable HTML document (PDF yahi leta hai) */
export function docHtml({ title, body, landscape }: DocOpts): string {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>
<style>${DOC_CSS}${landscape ? 'body{ } @page { size: A4 landscape; margin: 8mm; }' : ''}</style>
</head><body>${body}</body></html>`;
}

/** Excel (.xls) ke liye Office-compatible HTML wrapper (Excel isi ko kholta hai) */
export function xlsDoc({ title, body }: { title: string; body: string }): string {
  return `<!doctype html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
<head><meta charset="utf-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>
<x:Name>${esc(title)}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions>
</x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
<style>${DOC_CSS}</style></head><body>${body}</body></html>`;
}

export function esc(s: unknown): string {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function shareUri(uri: string, fileName: string, mime: string) {
  const ok = await Sharing.isAvailableAsync();
  if (!ok) throw new Error('इस device पर share उपलब्ध नहीं');
  await Sharing.shareAsync(uri, { mimeType: mime, dialogTitle: fileName });
}

/** HTML → PDF file → system share sheet */
export async function sharePdf(doc: DocOpts): Promise<void> {
  const html = docHtml(doc);
  const { uri } = await Print.printToFileAsync({ html, base64: false });
  await shareUri(uri, `${doc.title}.pdf`, 'application/pdf');
}

/** HTML table → .xls file → system share sheet (Excel me format bana rehta hai) */
export async function shareExcel(title: string, body: string): Promise<void> {
  const name = `${title}.xls`;
  const file = new File(Paths.cache, name);
  file.create({ overwrite: true, intermediates: true });
  file.write(xlsDoc({ title, body }));
  await shareUri(file.uri, name, 'application/vnd.ms-excel');
}

/** Form screen: user poochhe PDF / Excel (instruction #6, #11, #12) */
export async function askAndShare(title: string, body: string, landscape = false): Promise<void> {
  const { Alert } = await import('react-native');
  await new Promise<void>((resolve) => {
    Alert.alert(
      `${title}`,
      'किस format में भेजें?',
      [
        { text: 'PDF', onPress: async () => { try { await sharePdf({ title, body, landscape }); } catch (e) { Alert.alert('PDF fail', String((e as Error).message || e)); } finally { resolve(); } } },
        { text: 'Excel', onPress: async () => { try { await shareExcel(title, body); } catch (e) { Alert.alert('Excel fail', String((e as Error).message || e)); } finally { resolve(); } } },
        { text: 'रद्द', style: 'cancel', onPress: () => resolve() },
      ],
      { cancelable: true }
    );
  });
}

/** कुल योग row जैसी helper — table string बनाने में */
export function th(cells: string[]): string {
  return `<tr>${cells.map((c) => `<th>${esc(c)}</th>`).join('')}</tr>`;
}

export function tr(cells: (string | number)[], cls?: string): string {
  return `<tr class="${cls || ''}">${cells
    .map((c) => `<td class="${typeof c === 'number' ? 'r' : ''}">${esc(c)}</td>`)
    .join('')}</tr>`;
}
