/**
 * backupFolder.ts — instruction #14
 * Backup file ko user ke apne storage folder me save/restore (SAF se ek baar permission).
 *  • Folder picker = Android Storage Access Framework → permission install bhar persist
 *    (dobara mat poochho; revoke ho jaye to UI phir se folder chune ko kahega).
 *  • Files: Cashbook-Backup-<panchayat>-<YYYY-MM-DD_HHMM>.json (manifest name inside).
 *  • Folder me hi backup list → seedha restore; file delete bhi yahin se.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Directory, File } from 'expo-file-system';

const KEY = 'gpc-cashbook-backup-dir';

let cachedUri: string | null = null;
let loaded = false;

export async function getBackupDirUri(): Promise<string | null> {
  if (loaded) return cachedUri;
  try {
    cachedUri = await AsyncStorage.getItem(KEY);
  } catch {
    cachedUri = null;
  }
  loaded = true;
  return cachedUri;
}

/** Ek baar folder chuno (SAF permission persist rehti hai) — cancel par null */
export async function pickBackupDir(): Promise<string | null> {
  try {
    const d = await Directory.pickDirectoryAsync(cachedUri || undefined);
    if (!d?.uri) return null;
    cachedUri = d.uri;
    loaded = true;
    await AsyncStorage.setItem(KEY, d.uri);
    return d.uri;
  } catch {
    return null; // user ne cancel kiya
  }
}

export async function clearBackupDir(): Promise<void> {
  cachedUri = null;
  loaded = true;
  await AsyncStorage.removeItem(KEY);
}

/** JSON backup file folder me likho (overwrite) */
export async function saveBackup(fileName: string, content: string): Promise<string> {
  const uri = await getBackupDirUri();
  if (!uri) throw new Error('पहले बैकअप फ़ोल्डर चुनें');
  const dir = new Directory(uri);
  if (!dir.exists) throw new Error('चुना गया फ़ोल्डर अब उपलब्ध नहीं — फिर से चुनें');
  const file = new File(dir, fileName);
  if (file.exists) file.delete();
  file.create({ overwrite: true, intermediates: true });
  file.write(content);
  return file.uri;
}

export type BackupEntry = { name: string; uri: string; size?: number };

export async function listBackups(): Promise<BackupEntry[]> {
  const uri = await getBackupDirUri();
  if (!uri) return [];
  try {
    const dir = new Directory(uri);
    if (!dir.exists) return [];
    const out: BackupEntry[] = [];
    for (const e of dir.list()) {
      if (!(e instanceof File)) continue;
      const n = e.name || '';
      if (!n.toLowerCase().endsWith('.json')) continue;
      let size: number | undefined;
      try {
        size = (e.info() as { size?: number }).size;
      } catch {
        size = undefined;
      }
      out.push({ name: n, uri: e.uri, size });
    }
    // naam me timestamp hai → newest pehle
    return out.sort((a, b) => b.name.localeCompare(a.name));
  } catch {
    return []; // permission chali gayi → folder dobara chunwao
  }
}

export async function readBackup(uri: string): Promise<string> {
  return new File(uri).text();
}

export async function deleteBackup(uri: string): Promise<void> {
  const f = new File(uri);
  if (f.exists) f.delete();
}
