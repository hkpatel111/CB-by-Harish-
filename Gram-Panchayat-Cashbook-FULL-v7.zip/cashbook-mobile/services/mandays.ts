/**
 * mandays.ts — Man-days distribution engine (old master B §7, merged PART V.2 #8)
 * नियम: पूरा मान-दिन ही; राशि ≤ MB component; BSR −10..20% safe band;
 * pakhwada = 15 − रविवार − छुट्टियाँ; हर calc audit में।
 */
import type { BsrRate, HolidayEntry } from '@/types/models';
import { toIsoLocal } from './pageEngine';

export function pakhwadaWorkingDays(
  fromDate: string,
  toDate: string,
  holidays: HolidayEntry[]
): { sundays: number; holidays: number; total: number; working: number } {
  const from = new Date(fromDate + 'T00:00:00');
  const to = new Date(toDate + 'T00:00:00');
  let total = 0;
  let sundays = 0;
  const holidaySet = new Set(holidays.map((h) => h.date));
  let holidayCount = 0;
  const d = new Date(from);
  while (d <= to) {
    total++;
    const dow = d.getDay();
    // bug fix: toISOString (UTC) IST me previous din deta tha → holidays kabhi match nahi hote the
    const iso = toIsoLocal(d);
    if (dow === 0) sundays++;
    else if (holidaySet.has(iso)) holidayCount++;
    d.setDate(d.getDate() + 1);
  }
  return { total, sundays, holidays: holidayCount, working: total - sundays - holidayCount };
}

/** BSR −10..20% safe band (old master §7.2). Recommended rate range from BSR. */
export function bsrBand(bsr: number) {
  return { min: Math.round(bsr * 0.8), max: Math.round(bsr * 0.9), bsr };
}

/** Rate validation: BSR se zyada kabhi nahi; BSR ke kareeb = warning (recoverable risk). */
export function rateCheck(rate: number, bsr: number | null): { ok: boolean; warn: string | null } {
  if (bsr == null) return { ok: true, warn: null };
  if (rate > bsr) return { ok: false, warn: `दर ₹${rate} BSR (₹${bsr}) से अधिक — अनुमति नहीं` };
  if (rate > bsrBand(bsr).max) return { ok: true, warn: `दर BSR−10% से ऊपर है — ऑडिट में recoverable बन सकती है (safe band ₹${bsrBand(bsr).min}–₹${bsrBand(bsr).max})` };
  return { ok: true, warn: null };
}

export type MandayCombo = {
  role: 'karigar' | 'labour' | 'mate';
  workers: number;
  days: number;
  rate: number;
  amount: number;
  remaining: number;
};

/** Amount ≤ MB component; पूरा मान-दिन; jitna kareeb utna behtar. Combos suggest karta hai. */
export function suggestCombos(
  targetAmount: number,
  rate: number,
  maxWorkers: number,
  maxDays: number,
  role: MandayCombo['role'] = 'labour'
): MandayCombo[] {
  const combos: MandayCombo[] = [];
  if (!(rate > 0) || !(targetAmount > 0)) return combos;
  for (let w = 1; w <= maxWorkers; w++) {
    for (let d = 1; d <= maxDays; d++) {
      const amount = w * d * rate;
      if (amount <= targetAmount + 0.001 && w * d >= Math.floor(targetAmount / rate) - 2) {
        combos.push({ role, workers: w, days: d, rate, amount, remaining: Math.round((targetAmount - amount) * 100) / 100 });
      }
    }
  }
  combos.sort((a, b) => a.remaining - b.remaining);
  return combos.slice(0, 8);
}

export function findBsr(bsrRates: BsrRate[], year: string, itemName: string): BsrRate | null {
  const exact = bsrRates.find((b) => b.year === year && b.itemName.toLowerCase() === itemName.trim().toLowerCase());
  if (exact) return exact;
  return bsrRates.find((b) => b.itemName.toLowerCase() === itemName.trim().toLowerCase()) || null;
}

/** Role reference rate: BSR me role mile to wo, warna Worker master (B §6) ka year-wise rate. */
export function referenceRate(
  bsrRates: BsrRate[],
  workerRates: { role: string; year: string; dailyRate: number }[],
  year: string,
  role: string
): { rate: number | null; source: 'BSR' | 'Worker' | null } {
  const b = findBsr(bsrRates, year, role);
  if (b) return { rate: b.rate, source: 'BSR' };
  const w = workerRates.find((x) => x.year === year && x.role === role && x.dailyRate > 0);
  if (w) return { rate: w.dailyRate, source: 'Worker' };
  const anyYear = workerRates.find((x) => x.role === role && x.dailyRate > 0);
  if (anyYear) return { rate: anyYear.dailyRate, source: 'Worker' };
  return { rate: null, source: null };
}

export { formatINR } from './pageEngine';
