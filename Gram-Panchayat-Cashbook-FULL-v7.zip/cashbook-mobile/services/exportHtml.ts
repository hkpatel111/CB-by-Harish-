/**
 * exportHtml.ts — instructions #6, #11, #12, #13
 *
 * Government GP (ग्राम पंचायत) forms ke **HTML builders** — PDF (expo-print) aur
 * Excel (.xls) dono ke liye. Har builder sirf INNER body string return karta hai;
 * caller `docHtml({ title, body, landscape })` (PDF) ya `xlsDoc({ title, body })`
 * (Excel) se wrap kare — ya seedha `askAndShare(title, body, landscape)` chalaye.
 *
 * AUTHORITATIVE sources (cell-by-cell dumps):
 *   - cc talora chaina mojek.xlsx → CC, UC, Labour, Material, Tech report, Photo
 *   - audit formet demo.xlsx      → Sheet2 गोशवारा, Sheet3 प्रपत्र-1,
 *                                   Sheet4 प्रपत्र-4, Sheet5 प्रपत्र-2, Sheet6 पट्टे
 *   - ledger.pdf (standard खाता बही), bank statement spec fields
 *
 * LANDSCAPE note: गोशवारा / खाता बही (ledger) / बैंक विवरण (bank) / प्रपत्र-1 ke liye
 * caller `landscape: true` pass kare — ye दो-पक्षीय chaude register hain.
 *
 * Rules: har dynamic text `esc()` se, table header row `th([...])` se, data rows
 * `tr()` (text/counts) ya `mRow()` (Indian-grouping money) se. Koi naya npm
 * dependency nahi. Saara user-visible text Hindi (Devanagari), registrar tone.
 */
import { esc, th, tr } from '@/services/exportDoc';
import type { ccBuild, FmtHeader, GoswaraRow, LedgerRow, Prapt1Row, Prapt4Row } from '@/services/formats';
import type { Bill, MbLine, PakhwadaRoll, Work } from '@/types/models';

/** ccBuild (formats.ts) ke output ka type — CC pages isi ko accept karte hain */
type CcData = ReturnType<typeof ccBuild>;

/* ═══════════ local helpers ═══════════ */

/** formatINR jaisa Indian grouping — AppStore se import mat karo (wo React context khinchta hai) */
const inr = (n: number): string =>
  (Number.isFinite(n) ? n : 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Count / quantity / serial — bina paise ke, right align (tr() ka number-cell) */
const numText = (v: number): string => String(Number.isFinite(v) ? Math.round(v * 100) / 100 : 0);

const cellS = (v: string): string => `<td>${esc(v)}</td>`;
/** Money cell — Indian grouping + right align */
const cellM = (n: number): string => `<td class="r">${esc(inr(n))}</td>`;
/** Count cell — plain number, right align */
const cellQ = (v: number): string => `<td class="r">${esc(numText(v))}</td>`;
/** Colspan cell */
const span = (text: string, cols: number, cls = ''): string => `<td colspan="${cols}" class="${cls}">${esc(text)}</td>`;

/** Row banaye pehle se bane cells se (colspan / mixed rows ke liye) */
const row = (cells: string[], cls = ''): string => `<tr class="${cls}">${cells.join('')}</tr>`;

/** Money row — string = text cell, number = grouped money cell (right align) */
const mRow = (values: (string | number)[], cls = ''): string =>
  row(
    values.map((v) => (typeof v === 'number' ? cellM(v) : cellS(v))),
    cls
  );

/** Pura row ek hi cell me (section heading / note) */
const spanRow = (text: string, cols: number, cls = ''): string => row([span(text, cols, cls)]);

/** Office header block — formats.ts head() jaisa, formName/title last line (bold) */
function headBlock(h: FmtHeader, title?: string): string {
  const lines: string[] = [
    `कार्यालय ${h.panchayat}`,
    `पंचायत समिति — ${h.block}  |  जिला — ${h.district}`,
    `वित्तीय वर्ष: ${h.fy}`,
  ];
  if (h.extra) lines.push(h.extra);
  lines.push(h.formName);
  if (title) lines.push(title);
  return `<div class="head">${lines
    .map((t, i) => `<div class="${i === lines.length - 1 ? 'b' : 'sm'}">${esc(t)}</div>`)
    .join('')}</div>`;
}

/** खाली sign-space wali table — header row th() se (label upar, signature neeche) */
function signTable(labels: string[]): string {
  return `<table class="sign">${th(labels)}<tr>${labels.map(() => '<td></td>').join('')}</tr></table>`;
}

/** Photo placeholder box (print me haath se photo chipkane ke liye jagah) */
function photoBox(caption: string, height = 110): string {
  const pad = Math.max(12, Math.round(height / 2) - 14);
  return (
    `<div style="border:1px dashed #777;height:${height}px;padding-top:${pad}px;` +
    `text-align:center;color:#555;font-size:11px;">${esc(caption)}<br />[ फोटो यहाँ लगाएँ ]</div>`
  );
}

/** Empty-value dash (form me kabhi blank cell nahi) */
const dash = (v?: string): string => (v && String(v).trim() ? String(v) : '—');

/** श्रम/सामग्री विभाजन — मस्टरोल वेतन पहले, शेष सामग्री मद (MB ratio fallback) */
function splitMads(lekhayTotal: number, labFromRolls: number, labShare: number): [number, number] {
  if (lekhayTotal <= 0) return [0, 0];
  const base = labFromRolls > 0 ? labFromRolls : lekhayTotal * labShare;
  const lab = Math.min(Math.max(0, base), lekhayTotal);
  const labR = Math.round(lab * 100) / 100;
  return [labR, Math.round((lekhayTotal - labR) * 100) / 100];
}

/** MbLine ka इकाई guess (MB me unit field nahi hai) — fallback '—' */
function unitFor(item: string): string {
  const t = item.toLowerCase();
  if (/सीमेन्ट|सीमेंट|cement|बोरी|bag/.test(t)) return 'बोरी';
  if (/रेत|reti|गिट्टी|gitti|पत्थर|pathar|मुरूम|रोड़ी/.test(t)) return 'घन मीटर';
  if (/पोध|पौध|ट्री गार्ड/.test(t)) return 'नग';
  if (/टेंकर|टेनकर|tenkr|मिक्सर|मीक्षर|वाइब्रेटर|वाउबरेटर|वईब्रेटर|डंपर|मशीन|days|दिन/.test(t)) return 'दिन';
  return '—';
}

/* ═══════════ 1. CC — कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ) ═══════════ */

export function ccPagesHtml(a: {
  header: FmtHeader;
  work: Work;
  c: CcData;
  mbLines: MbLine[];
  rolls: PakhwadaRoll[];
  bills: Bill[];
  fundName: string;
  bsrYear?: string;
  mbNo?: string;
  mbPage?: string;
  asNo?: string;
  asDate?: string;
  tsNo?: string;
  tsDate?: string;
  fsNo?: string;
  fsDate?: string;
}): string {
  const h = a.header;
  const w = a.work;
  const c = a.c;

  const mbLines = a.mbLines.filter((m) => m.workId === w.id);
  const rolls = a.rolls
    .filter((r) => r.workId === w.id)
    .slice()
    .sort((x, y) => (x.fromDate + x.rollNo).localeCompare(y.fromDate + y.rollNo));
  const bills = a.bills.filter((b) => b.workId === w.id);

  const asNo = a.asNo ?? w.asNo ?? '';
  const asDate = a.asDate ?? w.asDate ?? '';
  const tsNo = a.tsNo ?? w.tsNo ?? '';
  const tsDate = a.tsDate ?? w.tsDate ?? '';
  const fsNo = a.fsNo ?? w.fsNo ?? '';
  const fsDate = a.fsDate ?? w.fsDate ?? '';
  const mbNo = a.mbNo ?? w.mbNo ?? '';
  const mbPage = a.mbPage ?? w.mbPage ?? '';

  const agency = `ग्राम पंचायत ${h.panchayat}`;
  const fsLakh = (w.fsAmount || 0) / 100000;
  const labShare = c.mulyaankan > 0 ? c.labour / c.mulyaankan : 0;
  const lekhayTotal = c.actualExpense || c.paid || 0;
  const [labActual, matActual] = splitMads(lekhayTotal, c.mandays.wage, labShare);

  /** Page ka office-head — cc demo Sheet "CC" ke header rows se */
  const ccHead = (pageNo: string, title: string): string =>
    `<div class="head">` +
    `<div class="sm">( परिशिष्ट 16 )</div>` +
    `<div class="b">${esc(`कार्यालय ग्राम पंचायत — ${h.panchayat}   पं. स. — ${h.block}   जिला- ${h.district} (राज.)`)}</div>` +
    `<div class="b">${esc(title)}</div>` +
    `<div class="sm">पंचायत / पंचायत समिति / जिला परिषद द्वारा</div>` +
    `<div class="sm">${esc(`पृष्ठ ${pageNo} — ${h.fy}`)}</div>` +
    `</div>`;

  /* ── पृष्ठ 1 — CC ── */
  const pg1 =
    ccHead('1', 'कार्य पूर्णता प्रमाण पत्र') +
    `<table>` +
    th(['अनुक्रम एवं विवरण', 'विवरण / राशि', 'पूरक विवरण', 'मान / दिनांक']) +
    tr(['1- ग्राम पंचायत-', h.panchayat, 'पं. स. / जिला', `${h.block} / ${h.district}`]) +
    tr(['2- कार्य का नाम-', w.name, 'वार्ड', dash(w.ward)]) +
    tr(['3- योजना का नाम-', a.fundName, 'एजेंसी-', agency]) +
    tr(['4 - प्रशासनिक स्वीकृति क्रमांक-', dash(asNo), 'दिनांक', dash(asDate)]) +
    tr(['5- तकनीकी स्वीकृति क्रमांक-', dash(tsNo), 'दिनांक', dash(tsDate)]) +
    tr(['6- वित्तीय स्वीकृति क्रमांक-', dash(fsNo), 'दिनांक', dash(fsDate)]) +
    mRow([
      '7- स्वीकृत राशि-',
      w.fsAmount ? fsLakh : '—',
      'लाख रुपये',
      w.fsAmount ? `(${inr(w.fsAmount)} रुपये)` : '—',
    ]) +
    tr(['8- कार्य शुरू करने की तिथि-', dash(w.startDate), '', '']) +
    tr(['9- कार्य पूर्ण होने की तिथि-', dash(w.completeDate), '', '']) +
    spanRow('10- कार्य पर व्यय लेखे के अनुसार-', 4, 'b') +
    mRow(['अ. श्रम मद (मस्टरोल अनुसार)', labActual, 'ब. सामग्री मद', matActual]) +
    mRow(['कुल राशि-', lekhayTotal, '', '']) +
    spanRow('11- मूल्यांकन के अनुसार-', 4, 'b') +
    mRow(['अ. श्रम मद', c.labour, 'ब. सामग्री मद', c.material]) +
    mRow(['कुल राशि-', c.mulyaankan, 'कुल अनुमत राशि', c.allowable]) +
    tr(['माप पुस्तिका संख्या', dash(mbNo), 'पृष्ठ संख्या', dash(mbPage)]) +
    mRow(['कुल अनुमत राशि', c.allowable, 'नकद राशि (बिल भुगतान)', c.paid]) +
    mRow(['कुल व्यय (लेखे)', lekhayTotal, 'शेष भुगतान योग्य', c.residualMaterial]) +
    `</table>` +
    `<p class="note">${esc(
      'नोट — श्रम/सामग्री मद का विभाजन मस्टरोल एवं माप पुस्तिका के आधार पर किया गया है। ' +
        'कुल अनुमत राशि = स्वीकृत राशि की सीमा में (वास्तविक व्यय, मूल्यांकन राशि) में से जो कम हो।'
    )}</p>` +
    `<p>${esc(
      `समायोजन योग्य है। यह भी प्रमाणित किया जाता है की उपरोक्त सृजित परिसंपत्ति का दिनांक __________ को कार्यकारी संस्था ग्राम पंचायत ${h.panchayat}` +
        ' के द्वारा विभाग को हस्तांतरित कर दिया गया है तथा प्राप्त करने वाले विभाग के सक्षम अधिकारी से रसीद प्राप्त कर ली गई है ।'
    )}</p>` +
    `<p>${esc('इस कार्य का परिसंपत्तियों के लिए संधारित विकास पंजिका रजिस्टर मे क्रम संख्या __________ पर इंद्राज कर लिया गया है ।')}</p>` +
    signTable([`सरपंच, ग्राम पंचायत ${h.panchayat}`, `ग्राम विकास अधिकारी, ग्राम पंचायत ${h.panchayat}`]) +
    `<div class="head">` +
    `<div class="b">मूल्यांकन जांच प्रमाण पत्र</div>` +
    `<div class="sm">( मार्गदर्शिका के पैरा संख्या 10.2 मे उल्लेखित सक्षम अधिकारी द्वारा दिया जावेगा )</div>` +
    `</div>` +
    `<p>${esc(
      'उपरोक्त पूर्णता पत्र की जांच कर प्रमाणित किया जाता है की कार्य का मूल्यांकन ग्रामीण कार्य निर्देशिका 2010 के प्रावधानों के अनुसार किया गया है। ' +
        'कार्य का निष्पादन ग्रामीण कार्य निर्देशिका 2010 के मापदण्डों एवम् तकमिने के अनुसार हुआ है। कार्य के माप एवम् मूल्यांकन का सत्यापित किया जाकर'
    )}</p>` +
    `<p><b>${esc('इस कार्य पर अनुमत राशि')}</b> <b>${esc(inr(c.allowable))}</b> <b>${esc('के समायोजन की अभिशंसा की जाती है ।')}</b></p>` +
    signTable(['हस्ताक्षर सक्षम प्राधिकृत अधिकारी', 'पदनाम एवम् कार्यालय का पता']);

  /* ── पृष्ठ 2 — UC (उपयोगिता प्रमाण पत्र) ── */
  const pg2 =
    `<div class="head">` +
    `<div class="b">${esc(`कार्यालय ग्राम पंचायत — ${h.panchayat}   पं. स. — ${h.block}   जिला- ${h.district} (राज.)`)}</div>` +
    `<div class="b">उपयोगिता प्रमाण पत्र</div>` +
    `<div class="sm">${esc(`ग्राम पंचायत — ${h.panchayat}   पं. स. — ${h.block}   जिला — ${h.district}`)}</div>` +
    `<div class="sm">${esc(`पृष्ठ 2 — ${h.fy}`)}</div>` +
    `</div>` +
    `<table>` +
    th(['अनुक्रम एवं विवरण', 'विवरण / राशि', 'पूरक विवरण', 'मान / दिनांक']) +
    tr(['1- कार्य का नाम', w.name, '', '']) +
    tr(['2- योजना का नाम', a.fundName, '', '']) +
    tr(['3- वित्तीय स्वीकृति क्रमांक', dash(fsNo), 'दिनांक', dash(fsDate)]) +
    mRow(['4- वास्तविक कार्य का विवरण, मोके पर माप अनुसार व्यय राशि', lekhayTotal, '', '']) +
    mRow(['5- माप पुस्तिका मे उल्लेखित मूल्यांकन राशि', c.mulyaankan, '', '']) +
    tr(['6- माप पुस्तिका संख्या', dash(mbNo), 'पृष्ठ संख्या', dash(mbPage)]) +
    spanRow('7- कार्य पर वास्तविक व्यय लेखो के अनुसार', 4, 'b') +
    mRow(['अ. श्रम मद', labActual, '', '']) +
    mRow(['ब. सामग्री मद', matActual, '', '']) +
    mRow(['योग', lekhayTotal, '', '']) +
    mRow(['8- अनुमत राशि', c.allowable, '', '']) +
    spanRow(
      '(अनुमत राशि वह होगी जो स्वीकृत राशि की सीमा मे वास्तविक व्यय एवम् मूल्यांकन राशि मे से जो भी काम हो । )',
      4,
      'note'
    ) +
    spanRow(
      `प्रमाणित किया जाता है की उपरोक्त कार्य पर कुल व्यय राशि ${inr(lekhayTotal)} का उपयोग कर लिया गया है । कार्य का क्रियान्वयन ग्रामीण कार्य निर्देशिका 2010 के प्रावधानों के अनुसार किया गया है ।`,
      4
    ) +
    `</table>` +
    signTable([`सरपंच, ग्राम पंचायत ${h.panchayat}`, `ग्राम विकास अधिकारी, ग्राम पंचायत ${h.panchayat}`]) +
    `<div class="head">` +
    `<div class="b">मूल्यांकन जांच प्रमाण पत्र</div>` +
    `</div>` +
    `<p>${esc(
      'उपरोक्त उपयोगिता प्रमाण पत्र की जांच कर प्रमाणित किया जाता है की कार्य का मूल्यांकन ग्रामीण कार्य निर्देशिका 2010 के प्रावधानों के अनुसार किया गया है । ' +
        'कार्य का निष्पादन ग्रामीण कार्य निर्देशिका 2010 के मापदण्डों एवम् तकमिने के अनुसार हुआ है ।'
    )}</p>` +
    `<p>${esc('इस कार्य पर किए गए निम्नानुसार व्यय के समायोजन की अभिशंसा की जाती है ।')}</p>` +
    mRow(['अनुमत राशि', c.allowable, '', '']) +
    signTable(['हस्ताक्षर सक्षम प्राधिकृत अधिकारी', 'पदनाम एवम् कार्यालय का पता']);

  /* ── पृष्ठ 3 — Labour (पाक्षिक श्रम मस्टरोल) ── */
  const labourGroups: { label: string; rolls: PakhwadaRoll[] }[] = [];
  for (const r of rolls) {
    const label = `${r.fromDate} से ${r.toDate}`;
    const g = labourGroups.find((x) => x.label === label);
    if (g) g.rolls.push(r);
    else labourGroups.push({ label, rolls: [r] });
  }
  let sl = 0;
  const labourRows: string[] = [];
  let tMateMd = 0;
  let tSkilledMd = 0;
  let tUnskilledMd = 0;
  let tDays = 0;
  let tMandays = 0;
  let tWage = 0;
  for (const g of labourGroups) {
    let sm = 0;
    let ss = 0;
    let su = 0;
    let sd = 0;
    let smd = 0;
    let sw = 0;
    for (const r of g.rolls) {
      sl += 1;
      const md = (r.mateCount + r.skilledCount + r.unskilledCount) * r.days;
      const wage =
        r.mateCount * r.days * r.wageMate + r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled;
      sm += r.mateCount;
      ss += r.skilledCount;
      su += r.unskilledCount;
      sd += r.days;
      smd += md;
      sw += wage;
      labourRows.push(
        row([
          cellQ(sl),
          cellS(`${g.label}`),
          cellS(dash(r.rollNo)),
          cellQ(r.mateCount),
          cellQ(r.skilledCount),
          cellQ(r.unskilledCount),
          cellQ(r.days),
          cellQ(md),
          cellM(r.wageMate),
          cellM(r.wageSkilled),
          cellM(r.wageUnskilled),
          cellM(wage),
        ])
      );
    }
    labourRows.push(
      row(
        [
          span(`पाक्षिक योग — ${g.label}`, 3, 'b'),
          cellQ(sm),
          cellQ(ss),
          cellQ(su),
          cellQ(sd),
          cellQ(smd),
          cellS(''),
          cellS(''),
          cellS(''),
          cellM(sw),
        ],
        'b'
      )
    );
  }
  for (const r of rolls) {
    tMateMd += r.mateCount * r.days;
    tSkilledMd += r.skilledCount * r.days;
    tUnskilledMd += r.unskilledCount * r.days;
    tDays += r.days;
    tMandays += (r.mateCount + r.skilledCount + r.unskilledCount) * r.days;
    tWage += r.mateCount * r.days * r.wageMate + r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled;
  }

  const pg3 =
    `<div class="head">` +
    `<div class="b">श्रमिकों पर व्यय का विवरण (पाक्षिक मस्टरोल)</div>` +
    `<div class="sm">${esc(`कार्य का नाम- ${w.name}`)}</div>` +
    `<div class="sm">${esc(`ग्राम पंचायत — ${h.panchayat}  |  पृष्ठ 3 — ${h.fy}`)}</div>` +
    `</div>` +
    `<table>` +
    th([
      'क्र.स.',
      'पाक्षिक मस्टरोल की दिनांक',
      'मस्टरोल क्रमांक',
      'मेट',
      'कुशल',
      'अकुशल',
      'दिन',
      'सृजित मानव दिवस',
      'मेट दर',
      'कुशल दर',
      'अकुशल दर',
      'राशि (रु.)',
    ]) +
    (labourRows.length
      ? labourRows.join('') +
        row(
          [
            span('कुल योग (मानव दिवस — मेट / कुशल / अकुशल)', 3, 'b'),
            cellQ(tMateMd),
            cellQ(tSkilledMd),
            cellQ(tUnskilledMd),
            cellQ(tDays),
            cellQ(tMandays),
            cellS(''),
            cellS(''),
            cellS(''),
            cellM(tWage),
          ],
          'b'
        )
      : spanRow('कोई पाक्षिक मस्टरोल दर्ज नहीं', 12, 'c')) +
    `</table>` +
    `<p class="note">${esc(
      'नोट — मानव दिवस = श्रमिक संख्या × दिन; राशि = मानव दिवस × दर (ग्रामीण कार्य निर्देशिका 2010)। ' +
        'कुल योग पंक्ति में मेट/कुशल/अकुशल स्तंभ क्रमशः कुल मानव दिवस दर्शाते हैं। ' +
        `MB श्रम मद योग: ${inr(c.labour)} | मस्टरोल श्रम व्यय: ${inr(c.mandays.wage)}`
    )}</p>` +
    signTable(['हस्ताक्षर — ग्राम सचिव', 'हस्ताक्षर — कनिष्ठ तकनीय सहायक', 'हस्ताक्षर — सरपंच', 'हस्ताक्षर — ग्राम विकास अधिकारी']);

  /* ── पृष्ठ 4 — Material (MB अनुसार मद-वार) ── */
  const mats = mbLines.filter((m) => m.kind === 'material');
  const matRows = mats.map((m, i) =>
    row([
      cellQ(i + 1),
      cellS(m.itemName || 'अन्य'),
      cellQ(m.qty),
      cellS(unitFor(m.itemName)),
      cellM(m.rate),
      cellM(m.qty * m.rate),
    ])
  );
  const billRows = bills.map((b, i) =>
    row([cellQ(i + 1), cellS(dash(b.billDate)), cellS(b.vendor || '—'), cellS(dash(b.pageRef)), cellM(b.amount)])
  );
  const pg4 =
    `<div class="head">` +
    `<div class="b">सामग्री पर व्यय का विवरण (माप पुस्तिका अनुसार)</div>` +
    `<div class="sm">${esc(`कार्य का नाम- ${w.name}`)}</div>` +
    `<div class="sm">${esc(`ग्राम पंचायत- ${h.panchayat}  |  पृष्ठ 4 — ${h.fy}`)}</div>` +
    `</div>` +
    `<table>` +
    th(['क्रस', 'सामग्री का विवरण', 'मात्रा', 'इकाई', `BSR दर${a.bsrYear ? ` (${a.bsrYear})` : ''} (रु.)`, 'मूल्यांकन (रु.)']) +
    (matRows.length ? matRows.join('') : spanRow('कोई सामग्री पंक्ति दर्ज नहीं', 6, 'c')) +
    mRow(['', 'सामग्री मद योग', '', '', '', c.material], 'b') +
    `</table>` +
    `<table>` +
    th(['क्रस', 'बिल दिनांक', 'विक्रेता / पक्ष', 'पृष्ठ / प्रपत्र सं.', 'भुगतान राशि (रु.)']) +
    (billRows.length ? billRows.join('') : spanRow('कोई बिल दर्ज नहीं', 5, 'c')) +
    mRow(['', 'बिलों के भुगतान योग', '', '', c.paid], 'b') +
    `</table>` +
    `<table>` +
    th(['तुलना विवरण', 'राशि (रु.)', 'आधार / टिप्पणी']) +
    mRow(['सामग्री मद — मूल्यांकन', c.material, 'माप पुस्तिका अनुसार']) +
    mRow(['श्रम मद — मूल्यांकन', c.labour, 'माप पुस्तिका अनुसार']) +
    mRow(['कुल मूल्यांकन राशि', c.mulyaankan, 'श्रम + सामग्री']) +
    mRow(['बिलों के भुगतान योग', c.paid, 'दर्ज बिल अनुसार']) +
    mRow(['वास्तविक व्यय (लेखे)', c.actualExpense, 'क्रियान्वित लेन-देन अनुसार']) +
    mRow(['कुल अनुमत राशि', c.allowable, 'स्वीकृति/व्यय/मूल्यांकन में न्यूनतम']) +
    mRow(['भुगतान शेष (अनुमत − बिल योग)', c.residualMaterial, 'शेष देय']) +
    mRow(['मूल्यांकन एवं बिल योग में अंतर', c.mulyaankan - c.paid, 'तुलना हेतु (स्वीकृत/अवशेष)']) +
    `</table>` +
    signTable(['हस्ताक्षर — ग्राम सचिव', 'हस्ताक्षर — कनिष्ठ अभियंता', 'हस्ताक्षर — सरपंच', 'हस्ताक्षर — ग्राम विकास अधिकारी']);

  /* ── पृष्ठ 5 — तकनीकी निरीक्षण रिपोर्ट ── */
  const pg5 =
    `<div class="head">` +
    `<div class="b">तकनीकी निरीक्षण रिपोर्ट</div>` +
    `<div class="sm">${esc(`पृष्ठ 5 — ${h.fy}`)}</div>` +
    `</div>` +
    `<table>` +
    th(['अनुक्रम एवं विवरण', 'विवरण']) +
    tr(['1- कार्य का नाम-', w.name]) +
    tr(['2- ग्राम पंचायत-', h.panchayat]) +
    tr(['3- योजना का नाम-', a.fundName]) +
    tr(['4- कार्यकारी एजेंसी-', agency]) +
    tr(['5- कार्य प्रारंभ / पूर्ण तिथि-', `${dash(w.startDate)} / ${dash(w.completeDate)}`]) +
    `</table>` +
    `<p>${esc(
      'हम निम्न हस्ताक्षरकर्ता ने उक्त कार्य का भौतिक एवम् तकनीकी दृष्टिकोण से निरीक्षण (भौतिक सत्यापन) किया। ' +
        'कार्य मे प्रयुक्त निर्माण सामग्री, कार्य का डिजाइन एवम् गुणवत्ता उचित पाई गई । उक्त कार्य ग्रामीण कार्य निर्देशिका 2010 के मापदण्डों अनुरूप पाया गया — गुणवत्ता प्रमाणित।'
    )}</p>` +
    `<table>` +
    th(['नाम', 'पद', 'दिनांक', 'हस्ताक्षर']) +
    tr(['________________________', `कनिष्ठ अभियंता (JTA), पं.स. ${h.block}`, '____________', '']) +
    tr(['________________________', `सहायक अभियंता, पं.स. ${h.block}`, '____________', '']) +
    tr(['________________________', `ग्राम विकास अधिकारी, ग्राम पंचायत ${h.panchayat}`, '____________', '']) +
    `</table>` +
    signTable(['सरपंच, ग्राम पंचायत ' + h.panchayat, 'ग्राम विकास अधिकारी, ग्राम पंचायत ' + h.panchayat]);

  /* ── पृष्ठ 6 — पूर्ण कार्य फोटो + हस्ताक्षर ── */
  const pg6 =
    `<div class="head">` +
    `<div class="b">${esc(`कार्यालय ग्राम पंचायत — ${h.panchayat}   पं. स. — ${h.block}   जिला- ${h.district}`)}</div>` +
    `<div class="b">पूर्ण कार्य का फोटो एवं हस्ताक्षर</div>` +
    `<div class="sm">${esc(`पृष्ठ 6 — ${h.fy}`)}</div>` +
    `</div>` +
    `<table>` +
    th(['अनुक्रम एवं विवरण', 'विवरण']) +
    tr(['1- कार्य का नाम-', w.name]) +
    tr(['2- ग्राम पंचायत-', h.panchayat]) +
    tr(['3- योजना का नाम-', a.fundName]) +
    tr(['4- कार्यकारी एजेंसी-', agency]) +
    tr(['5- कार्य प्रारंभ होने की दिनांक-', dash(w.startDate)]) +
    tr(['6- कार्य पूर्ण होने की दिनांक-', dash(w.completeDate)]) +
    `</table>` +
    `<table>` +
    th(['पूर्ण कार्य का फोटो (दिनांक, स्थान एवं कार्य विवरण सहित)']) +
    row([cellS(photoBox('पूर्ण कार्य का फोटो', 240))]) +
    `</table>` +
    `<p class="note">${esc('फोटो में दिनांक, स्थान एवं कार्य का नाम स्पष्ट दिखाई देना चाहिए।')}</p>` +
    signTable(['हस्ताक्षर — सरपंच', 'हस्ताक्षर — ग्राम विकास अधिकारी', 'हस्ताक्षर — कनिष्ठ अभियंता (JTA)']);

  /* ── पृष्ठ 7 — कार्य से पूर्व व कार्यकाल के फोटो + सामाजिक अंकेक्षण ── */
  const pg7 =
    `<div class="head">` +
    `<div class="b">${esc(`कार्यालय ग्राम पंचायत — ${h.panchayat}   पं. स. — ${h.block}   जिला- ${h.district}`)}</div>` +
    `<div class="b">कार्य से पूर्व एवं कार्यकाल के फोटो</div>` +
    `<div class="sm">${esc(`कार्य का नाम- ${w.name}  |  पृष्ठ 7 — ${h.fy}`)}</div>` +
    `</div>` +
    `<table>` +
    th(['फोटो क्र.', 'अवस्था', 'विवरण / स्थान', 'दिनांक', 'फोटो']) +
    row([cellQ(1), cellS('कार्य से पूर्व'), cellS('कार्य प्रारंभ से पूर्व की स्थिति'), cellS('____________'), cellS(photoBox('कार्य से पूर्व — 1'))]) +
    row([cellQ(2), cellS('कार्य से पूर्व'), cellS('दूसरा दृश्य / स्थल'), cellS('____________'), cellS(photoBox('कार्य से पूर्व — 2'))]) +
    row([cellQ(3), cellS('कार्यकाल'), cellS('निर्माण कार्य चलते समय'), cellS('____________'), cellS(photoBox('कार्यकाल — 1'))]) +
    row([cellQ(4), cellS('कार्यकाल'), cellS('दूसरा दृश्य / श्रमिक एवं सामग्री'), cellS('____________'), cellS(photoBox('कार्यकाल — 2'))]) +
    `</table>` +
    `<p class="note">${esc(
      'सामाजिक अंकेक्षण (Social Audit) — उपरोक्त फोटो ग्राम सभा की बैठक में प्रदर्शित किए जाएँगे तथा कार्य स्थल पर लगाई गई सूचना पट्ट पर कार्य का नाम, ' +
        'स्वीकृत राशि, कार्य प्रारंभ एवं पूर्ण तिथि, श्रमिकों की संख्या तथा मस्टरोल विवरण अंकित किया जाएगा। कोई भी हितधारक आपत्ति दर्ज करा सकता है।'
    )}</p>` +
    signTable(['हस्ताक्षर — सरपंच', 'हस्ताक्षर — ग्राम विकास अधिकारी', 'हस्ताक्षर — कनिष्ठ अभियंता (JTA)']);

  return [pg1, pg2, pg3, pg4, pg5, pg6, pg7].join('<div class="pg"></div>');
}

/* ═══════════ 2. गोशवारा — दो-पक्षीय वार्षिक आय-व्यय सामान्य रोकड़ बही ═══════════
 * audit demo Sheet2 ki tarah: LEFT = प्राप्ति/आय, RIGHT = भुगतान/व्यय.
 * CALLER: landscape: true pass kare (chauda दो-पक्षीय register).
 */

export function goswaraHtml(a: {
  header: FmtHeader;
  rows: GoswaraRow[];
  aayYog: number;
  vyayYog: number;
  prarambhikNagad: number;
  prarambhikBank: number;
  antimNagad: number;
  antimBank: number;
}): string {
  const left = a.rows.filter((r) => r.inc !== 0);
  const right = a.rows.filter((r) => r.exp !== 0);
  const n = Math.max(left.length, right.length);
  const body: string[] = [];
  for (let i = 0; i < n; i++) {
    const L = left[i];
    const R = right[i];
    body.push(
      row([
        cellQ(i + 1),
        cellS(L ? L.name : ''),
        L ? cellM(L.inc) : cellS(''),
        cellQ(i + 1),
        cellS(R ? R.name : ''),
        R ? cellM(R.exp) : cellS(''),
      ])
    );
  }
  if (!n) body.push(spanRow('कोई आय/व्यय प्रविष्टि नहीं', 6, 'c'));

  const aayMahayog = a.aayYog + a.prarambhikBank + a.prarambhikNagad;
  const vyayMahayog = a.vyayYog + a.antimBank + a.antimNagad;
  const equal = Math.abs(aayMahayog - vyayMahayog) < 0.01;

  body.push(
    mRow(['', 'आय योग', a.aayYog, 'व्यय योग', a.vyayYog, ''], 'b'),
    mRow(['', 'प्रारंभिक बैंक शेष', a.prarambhikBank, 'अंतिम बैंक शेष', a.antimBank, '']),
    mRow(['', 'प्रारंभिक नकद शेष', a.prarambhikNagad, 'अंतिम नकद शेष', a.antimNagad, '']),
    mRow(['', 'महायोग', aayMahayog, 'महायोग', vyayMahayog, ''], 'b'),
    spanRow(
      `सूत्र — आय महायोग = आय योग ${inr(a.aayYog)} + प्रारंभिक बैंक शेष ${inr(a.prarambhikBank)} + प्रारंभिक नकद शेष ${inr(
        a.prarambhikNagad
      )} = ${inr(aayMahayog)}`,
      6,
      'note'
    ),
    spanRow(
      `सूत्र — व्यय महायोग = व्यय योग ${inr(a.vyayYog)} + अंतिम बैंक शेष ${inr(a.antimBank)} + अंतिम नकद शेष ${inr(
        a.antimNagad
      )} = ${inr(vyayMahayog)}`,
      6,
      'note'
    ),
    spanRow(
      equal
        ? `समीकरण जाँच — आय महायोग ${inr(aayMahayog)} = व्यय महायोग ${inr(vyayMahayog)} : बराबर (सत्य)`
        : `समीकरण जाँच — आय महायोग ${inr(aayMahayog)} ≠ व्यय महायोग ${inr(vyayMahayog)} : बराबर नहीं, पुनः जाँच करें`,
      6,
      'b'
    )
  );

  return (
    headBlock(a.header) +
    `<table>` +
    th(['क्र.', 'आय का विवरण (प्राप्तिपक्ष)', 'राशि (रु.)', 'क्र.', 'व्यय का विवरण (भुगतानपक्ष)', 'राशि (रु.)']) +
    body.join('') +
    `</table>` +
    signTable(['सरपंच', 'ग्राम विकास अधिकारी'])
  );
}

/* ═══════════ 3. खाता बही (ledger) — दो-पक्षीय, ledger.pdf layout ═══════════
 * CALLER: landscape: true pass kare.
 */

export function ledgerHtml(a: { header: FmtHeader; rows: LedgerRow[] }): string {
  const openingRow = a.rows.find((r) => !r.debit && !r.credit && (/पोते/.test(r.party) || /प्रारंभिक/.test(r.detail)));
  const opening = openingRow ? openingRow.running : 0;
  const cr = a.rows.filter((r) => r.credit > 0);
  const dr = a.rows.filter((r) => r.debit > 0);
  const n = Math.max(cr.length, dr.length);
  const body: string[] = [
    row([
      span('श्री पोते राशि — प्रारंभिक शेष', 4, 'b'),
      cellM(opening),
      span('श्री पोते राशि — प्रारंभिक शेष', 4, 'b'),
      cellM(opening),
    ]),
  ];
  for (let i = 0; i < n; i++) {
    const L = cr[i];
    const R = dr[i];
    body.push(
      row([
        cellS(L ? L.date : ''),
        cellS(L ? `${L.party}${L.detail ? ' — ' + L.detail : ''}` : ''),
        cellS(L ? L.folio : ''),
        L ? cellM(L.credit) : cellS(''),
        L ? cellM(L.running) : cellS(''),
        cellS(R ? R.date : ''),
        cellS(R ? `${R.party}${R.detail ? ' — ' + R.detail : ''}` : ''),
        cellS(R ? R.folio : ''),
        R ? cellM(R.debit) : cellS(''),
        R ? cellM(R.running) : cellS(''),
      ])
    );
  }
  if (!n) body.push(spanRow('कोई प्राप्ति/भुगतान प्रविष्टि नहीं', 10, 'c'));

  const totalCr = cr.reduce((s, r) => s + r.credit, 0);
  const totalDr = dr.reduce((s, r) => s + r.debit, 0);
  const lastCr = cr.length ? cr[cr.length - 1].running : opening;
  const lastDr = dr.length ? dr[dr.length - 1].running : opening;
  body.push(
    row(
      [
        span('कुल योग (प्राप्ति)', 3, 'b'),
        cellM(totalCr),
        cellM(lastCr),
        span('कुल योग (भुगतान)', 3, 'b'),
        cellM(totalDr),
        cellM(lastDr),
      ],
      'b'
    )
  );

  return (
    headBlock(a.header) +
    `<table>` +
    th([
      'दिनांक',
      'विवरण / किस से प्राप्त',
      'L.F.',
      'जमा राशि (रु.)',
      'चल शेष (रु.)',
      'दिनांक',
      'विवरण / किसको भुगतान',
      'L.F.',
      'नाम राशि (रु.)',
      'चल शेष (रु.)',
    ]) +
    body.join('') +
    `</table>` +
    signTable(['सरपंच', 'ग्राम विकास अधिकारी'])
  );
}

/* ═══════════ 4. प्रपत्र-1 — SFC/TFC/FFC/BRGF कार्य विवरण (audit Sheet3) ═══════════
 * CALLER: 16 स्तंभ हैं — landscape pass kare to behtar chhapega.
 */

export function prapt1Html(rows: Prapt1Row[], header: FmtHeader): string {
  const split = (total: number, share: number): [string, string] => {
    if (!total) return ['', ''];
    const l = Math.round(total * share * 100) / 100;
    return [inr(l), inr(Math.round((total - l) * 100) / 100)];
  };

  const body: string[] = [];
  let tFs = 0;
  let tPrior = 0;
  let tYear = 0;
  let tTotal = 0;
  let tMulya = 0;
  let tShesh = 0;
  rows.forEach((r, i) => {
    const share = r.mulyaankan > 0 ? r.labourAmount / r.mulyaankan : 0;
    const [pl, ps] = split(r.priorExpense, share);
    const [yl, ys] = split(r.yearExpense, share);
    const shesh = r.mulyaankan - r.totalExpense;
    tFs += r.fsLakh;
    tPrior += r.priorExpense;
    tYear += r.yearExpense;
    tTotal += r.totalExpense;
    tMulya += r.mulyaankan;
    tShesh += shesh;
    body.push(
      row([
        cellQ(i + 1),
        cellS(r.workName),
        cellS(r.schemeName),
        cellS(r.fsRef),
        cellM(r.fsLakh),
        cellS(pl),
        cellS(ps),
        cellM(r.priorExpense),
        cellS(yl),
        cellS(ys),
        cellM(r.yearExpense),
        cellM(r.totalExpense),
        cellS(r.status),
        cellM(r.mulyaankan),
        cellS(r.mbRef),
        cellM(shesh),
      ])
    );
  });
  if (!body.length) body.push(spanRow('कोई कार्य दर्ज नहीं', 16, 'c'));
  body.push(
    row(
      [
        span('योग', 4, 'b'),
        cellM(tFs),
        cellS(''),
        cellS(''),
        cellM(tPrior),
        cellS(''),
        cellS(''),
        cellM(tYear),
        cellM(tTotal),
        cellS(''),
        cellM(tMulya),
        cellS(''),
        cellM(tShesh),
      ],
      'b'
    )
  );

  return (
    headBlock(header, 'प्रपत्र - 1') +
    `<p class="note c">${esc('SFC/TFC/FFC/BRGF व विभिन्न योजना अंतर्गत कराए गये कार्यों का विवरण')}</p>` +
    `<table>` +
    th([
      'क्रस',
      'कार्य का नाम',
      'योजना का नाम',
      'वित्तीय स्वी क्र / दिनांक',
      'स्वी राशि (लाखों मे)',
      'पूर्व — श्रम राशि',
      'पूर्व — सामग्री राशि',
      'पूर्व में किया गया व्यय (योग)',
      'आलोच्य — श्रम राशि',
      'आलोच्य — सामग्री राशि',
      'आलोच्य वर्ष में व्यय (योग)',
      'आलोच्य वर्ष तक कुल व्यय',
      'कार्य की स्थिति (पूर्ण / प्रगतिरत)',
      'मूल्यांकन राशि',
      'MB.No./Page No.',
      'शेष राशि (मूल्यांकन − कुल व्यय)',
    ]) +
    body.join('') +
    `</table>` +
    `<p class="note">${esc('नोट — श्रम/सामग्री विभाजन माप पुस्तिका के अनुपात में किया गया है; योग राशि मूल लेन-देन अनुसार है।')}</p>` +
    signTable(['हस्ताक्षर', 'ग्राम विकास अधिकारी'])
  );
}

/* ═══════════ 5. प्रपत्र-4 — निर्माण कार्यों पर व्यय सामग्री राशि (audit Sheet4) ═══════════ */

export function prapt4Html(rows: Prapt4Row[], header: FmtHeader): string {
  const body = rows.map((r, i) =>
    row([cellQ(i + 1), cellS(r.name), cellQ(r.qty), cellS(r.unit || '—'), cellM(r.rate), cellM(r.cost), cellM(r.cost)])
  );
  const total = rows.reduce((s, r) => s + r.cost, 0);
  if (!body.length) body.push(spanRow('कोई सामग्री दर्ज नहीं', 7, 'c'));
  body.push(row([span('योग', 5, 'b'), cellM(total), cellM(total)], 'b'));

  return (
    headBlock(header, 'प्रपत्र 4') +
    `<p class="note c">${esc('निर्माण कार्यों पर व्यय की गयी सामग्री राशि का विवरण')}</p>` +
    `<table>` +
    th(['क्रस', 'नाम सामग्री', 'मात्रा', 'इकाई', 'दर (रु.)', 'कीमत (रु.)', 'योग (रु.)']) +
    body.join('') +
    `</table>` +
    `<p class="note">${esc('नोट — माप पुस्तिका (MB) की सामग्री पंक्तियों के आधार पर, audit format Sheet4 अनुसार।')}</p>` +
    signTable(['हस्ताक्षर', 'ग्राम विकास अधिकारी'])
  );
}

/* ═══════════ 6. प्रपत्र-2 — निर्माण कार्यों पर व्यय श्रम राशि (audit Sheet5) ═══════════ */

export function prapt2Html(
  rows: { workName: string; workers: number; days: number; rate: number; amount: number; role?: string }[],
  header: FmtHeader
): string {
  const body = rows.map((r, i) =>
    row([
      cellQ(i + 1),
      cellS(r.workName),
      cellS(r.role || 'श्रमिक'),
      cellQ(r.workers),
      cellQ(r.days),
      cellQ(r.workers * r.days),
      cellM(r.rate),
      cellM(r.amount),
    ])
  );
  const total = rows.reduce((s, r) => s + r.amount, 0);
  const totalMd = rows.reduce((s, r) => s + r.workers * r.days, 0);
  if (!body.length) body.push(spanRow('NIL — कोई श्रम व्यय दर्ज नहीं', 8, 'c'));
  body.push(
    row(
      [span('योग', 3, 'b'), cellS(''), cellS(''), cellQ(totalMd), cellS(''), cellM(total)],
      'b'
    )
  );

  return (
    headBlock(header, 'प्रपत्र - 2') +
    `<p class="note c">${esc('निर्माण कार्यों पर व्यय की गयी श्रम राशि का विवरण')}</p>` +
    `<table>` +
    th([
      'क्रस',
      'कार्य का नाम',
      'श्रमिक का प्रकार',
      'श्रमिकों की संख्या',
      'दिन',
      'मानव दिवस',
      'दर (रु.)',
      'कुल व्यय (रु.)',
    ]) +
    body.join('') +
    `</table>` +
    `<p class="note">${esc('नोट — मानव दिवस = श्रमिक संख्या × दिन; कुल व्यय = मानव दिवस × दर।')}</p>` +
    signTable(['हस्ताक्षर', 'ग्राम विकास अधिकारी'])
  );
}

/* ═══════════ 7. आबादी भूमि पट्टे पंजिका (audit Sheet6) ═══════════ */

export function pattaHtml(a: {
  header: FmtHeader;
  rows: { date: string; from: string; amount: number; ref: string }[];
}): string {
  const body = a.rows.map((r, i) =>
    row([cellQ(i + 1), cellS(dash(r.date)), cellS(r.from), cellS(dash(r.ref)), cellM(r.amount)])
  );
  const total = a.rows.reduce((s, r) => s + r.amount, 0);
  if (!body.length) body.push(spanRow('कोई पट्टा दर्ज नहीं', 5, 'c'));
  body.push(row([span('योग', 4, 'b'), cellM(total)], 'b'));

  return (
    headBlock(a.header, 'आबादी भूमि मे पट्टे जारी करना का विवरण') +
    `<table>` +
    th(['क्र.स.', 'दिनांक', 'पट्टाधारक व्यक्ति का नाम एवं पिता', 'संदर्भ / प्रपत्र क्र.', 'राशि (रु.)']) +
    body.join('') +
    `</table>` +
    signTable(['हस्ताक्षर', 'ग्राम विकास अधिकारी'])
  );
}

/* ═══════════ 8. बैंक विवरण (bank statement spec fields) ═══════════
 * CALLER: landscape: true pass kare (6 + 7 स्तंभ wali चौड़ी tables).
 */

export function bankStatementHtml(a: {
  header: FmtHeader;
  accountName: string;
  accountNo: string;
  bankName: string;
  rows: {
    date: string;
    narration: string;
    instrument: string;
    deposit: number;
    withdrawal: number;
    balance: number;
    scheme?: string;
    work?: string;
    vendor?: string;
    head?: string;
    note?: string;
    posted?: boolean;
  }[];
}): string {
  const totalDep = a.rows.reduce((s, r) => s + (r.deposit || 0), 0);
  const totalWd = a.rows.reduce((s, r) => s + (r.withdrawal || 0), 0);
  const lastBal = a.rows.length ? a.rows[a.rows.length - 1].balance : 0;

  const stmt = a.rows.map((r) =>
    mRow([r.date, r.narration, r.instrument || '—', r.deposit ? r.deposit : '', r.withdrawal ? r.withdrawal : '', r.balance])
  );
  if (!stmt.length) stmt.push(spanRow('कोई बैंक प्रविष्टि नहीं', 6, 'c'));
  else stmt.push(row([span('कुल', 3, 'b'), cellM(totalDep), cellM(totalWd), cellM(lastBal)], 'b'));

  const tag = a.rows.map((r) => {
    const bits = [r.note || '', r.posted === undefined ? '' : r.posted ? 'लेखांकन: हाँ' : 'लेखांकन: नहीं'].filter(Boolean);
    return tr([r.date, r.narration, r.scheme || '—', r.work || '—', r.vendor || '—', r.head || '—', bits.join(' · ') || '—']);
  });
  if (!tag.length) tag.push(spanRow('कोई टैग प्रविष्टि नहीं', 7, 'c'));

  return (
    headBlock(a.header, 'बैंक विवरण (Bank Statement)') +
    `<table>` +
    th(['खाता का नाम', 'खाता संख्या', 'बैंक का नाम']) +
    tr([a.accountName, a.accountNo, a.bankName]) +
    `</table>` +
    `<table>` +
    th(['दिनांक', 'विवरण (Narration)', 'संदर्भ / चेक संख्या', 'जमा (Deposit)', 'निकासी (Withdrawal)', 'शेष (Balance)']) +
    stmt.join('') +
    `</table>` +
    `<table>` +
    th(['दिनांक', 'विवरण', 'योजना', 'कार्य', 'विक्रेता / पक्ष', 'लेखा शीर्ष', 'टिप्पणी']) +
    tag.join('') +
    `</table>` +
    `<p class="note">${esc(
      'नोट — ऊपर का पहला खंड बैंक का विवरण तथा नीचे का खंड उन्हीं प्रविष्टियों को योजना / कार्य / विक्रेता / लेखा शीर्ष से टैग करने हेतु है।'
    )}</p>` +
    signTable(['सरपंच', 'ग्राम विकास अधिकारी'])
  );
}
