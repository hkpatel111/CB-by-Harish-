# Gram Panchayat Cashbook — Phase 1 Full Source

Hindi-first offline digital cashbook for Gram Panchayats (Rajasthan pattern).
**Single source of truth:** `PROJECT_MASTER.md` (Parts A–VI). Quote Part/section ids in issues.

**Prototype:** `Cashbook-Prototype.html` (repo/package root) — browser me poora app feature-check ke liye.

---

## Run

```bash
cd cashbook-mobile
npm install        # ya pnpm install
npx expo start     # dev
npx tsc --noEmit   # typecheck
```

Android release APK: Expo prebuild → `assembleRelease` (Part T notes). Package: `com.grampanchayat.cashbook`.

## Implemented features (complete checklist)

### Security & Navigation
- Admin-only login, PIN set/login, PIN change (App Settings), biometric toggle (device build)
- **8-logo chooser first-run** (Login) + logo change in App Settings (C10)
- 6 themes, UI language hi/en/hinglish, screen badges S-01…S-Last (toggle)
- Round-5 hierarchy: Login → Panchayat (+App Settings) → FY (+FY/Cashbook Settings) → FY Home
- Hardware/in-app back → parent; root par exit confirm
- **PIN re-confirm:** panchayat CRUD destructive actions + **FY add + FY close/lock** (C11)

### Panchayat & FY
- Panchayat CRUD (naam/block/district)
- FY CRUD, FY lock (read-only archive)
- **FY isolation strict** — entries never leak across FY; only closing balances → opening श्री पोते (CF/Manual indicator)
- FY Closing wizard: 3-checklist → गोशवारा → operation-prior safe backup → lock → carry-forward

### Cashbook page engine (S-07)
- Dual grid प्राप्ति|भुगतान side-by-side, Excel-register look
- **25 lines** (L settings se 16–40), txn lines = L−4; line1 expense blank (C1 final: 25-line PDF lock)
- Top श्री पोते राशि (fund-wise) लाल; bottom-3 auto: आय योग/पूर्व पोते/महायोग | व्यय योग/बचत पोते/महायोग — non-editable, left/right महायोग equality
- **Manual pagination:** + Page (next), **insert between pages** (renumber), delete; +2 blank pages reserve; unassigned txns last page
- Carry-forward: next page श्री पोते = prev बचत पोते
- Appearance: page bg (green tint), entry font, श्री पोते colour, summary colour
- Long-press/click txn → edit/cancel (cancel = audit me, totals se out)

### Income/Expense entry (S-08/S-09)
- Multi-column fund amounts, **scheme required** (default SFC), category path L1(+L2/L3 via tree)
- **L.F. ledger folio** field (C6) — ledger/CSV me dikhta hai, cross-verification
- **रसीद/वाउचर क्रमांक** reference field
- **Repeat template:** पिछली entry से copy
- **नकद→बैंक जमा** transfer type (cash−, bank+, आय/व्यय नहीं); **bank→cash kabhi nahi**
- Guards: day expense ≤ day महायोग; scheme-negative FY toggle (default OFF); ≥1 amount > 0
- Paise-precision (2-decimal) storage

### Masters (old-master §5–§7 → PART V.2)
- **BSR** year-wise दर सूची (item/unit/rate)
- **Item flags:** पूर्ण संख्या only / अंतिम-बिल only / आधारभूत (data ready; enforcement backlog C4/C5)
- **Holiday master** year-wise (pakhwada calc me use)
- **Worker rates:** मेट/कारीगर/लेबर year-wise daily rates

### Man-days engine (MB me, S-21/22)
- MB lines: material | कारीगर (artisan) | लेबर
- Calculator: पखवाड़ा = दिन − रविवार − holidays auto; **BSR−10…20% safe band** (BSR se upar block, kareeb par warning); **amount ≤ MB component** block; full man-days only
- Combo auto-suggestions (BSR−15% rate, MB cap ke andar)
- Har calculation **audit trail** (rate, man-days, BSR year)

### Works → Bills → CC (S-17…S-26)
- Works list (FY-scoped), live खर्च status (MB valuation vs bills vs cashbook actual)
- Bills: bill date + payment date + बही page ref + vendor (material-first enforcement backlog C3)
- **CC 7 pages** (cc demo xlsx format): अनुमत राशि = **min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)**; भुगतान योग्य शेष; पृष्ठ-3 पाक्षिक मस्टरोल (मेट/कुशल/अकुशल × दिन × दर); पृष्ठ-4 material MB से; 2/5/6/7 content; CSV export

### Bank statement (S-13, Part G)
- Account master, manual statement lines (credit/debit)
- Tag scheme → **Post to cashbook** (structured entry, double-post guard)
- **D−1 rule** (old-master §11.2): debit → ek din pehle agar us din balance sufficient, warna statement date
- Month re-upload lock concept; ignore option; bank→cash blocked

### Ledgers, गोशवारा, Reports (Part F)
- Auto from first entry — no generate step; har add/edit/cancel par refresh
- **गोशवारा** audit-demo format: मद-wise आय|व्यय + आय/व्यय योग + प्रारम्भिक/अंतिम शेष नगद (बैंक linked) + महायोग + हस्ताक्षर; **मद-tap drill-down ledger**
- **Ledger खाता बही** (ledger.pdf layout): श्री पोते → जमा/नाम → running शेष; L.F. column; fund-wise/all
- Reports hub + direct links; **CSV exports** har format se: Cashbook, Ledger, गोशवारा, प्रपत्र-1, प्रपत्र-4, Bank grid, CC
- **प्रपत्र-1** (works: FS ref, prior/year/total व्यय, स्थिति, मूल्यांकन, श्रम/सामग्री split), **प्रपत्र-4** (material-wise मात्रा/दर/कीमत)

### Monthly check
- All txns list; **month filter (YYYY-MM)**; Incomplete / **Cancelled** filters
- **Full Edit modal** per txn: date, party, detail, **L.F.**, note, scheme, category, amounts
- Cancel with confirm (audit me rehta hai)

### Backup & Restore (S-42, L.2)
- **Full JSON backup** — share/save (kisi bhi app se file ban jati hai)
- **Restore by paste/select** — phone transfer
- Operation-prior safe backup (FY lock se pehle, never auto-deleted)
- Retention policy (device build): 15 daily + monthly permanent (doc §4.2)
- SAF `Documents/Cashbook/<GP>/<FY>/` layout (device build)

### Formats Centre (S-28-tile, D22)
FY Home tile — गोशवारा, Ledger, प्रपत्र-1, प्रपत्र-4, Bank grid, CC — sab auto-update, har card se share/export.

## Documented-but-device-build features (jaan-bujhkar)
| Feature | Status |
|---|---|
| True PDF export (white bg, Devanagari embed, Noto — no Mangal) | Device build (expo-print/Chromium pipeline) |
| Bank statement PDF OCR/AI cloud reading | Deferred module (mandatory review screen ke saath) |
| SAF folder write + auto daily backup | Device build permissions |
| Photo attachments (bills/CC 6-7) | Backlog C7 |
| Biometric unlock | Device build native module |
| AI Estimate Reader | Deferred (sample estimates chahiye) |

## Backlog (user-approved pending, PART VI)
C3 material-first payment enforcement · C4 last-bill items enforce · C5 qty decimal rules · C7 photo attachments · C12 पट्टा extra fields (क्रमांक/पट्टाधारक/दिनांक) · pakhwada auto-day-count default in calc · number-to-words · reminders

## Data model (v5)
`CashbookPage`, `PakhwadaRoll`, `BsrRate`, `ItemMaster`, `HolidayEntry`, `WorkerRate`, `MandayCalc`, `Transaction.pageId`, `Transaction.ledgerFolio`, `AppSettings.logoId` — AsyncStorage key `gpc-cashbook-v5` (HTML prototype: localStorage, JSON-compatible).

## Acceptance quick-test (prototype se)
1. Login → logo → PIN → seed demo → 6 entries + work + MB + roll
2. Cashbook: महायोग left = right; + Page insert beech me
3. Entry: L.F. + repeat + transfer; guard: badi expense block
4. गोशवारा मद-click drill-down; Ledger running शेष
5. MB calculator: BSR se upar rate block; MB cap block
6. CC: min() rule + पाक्षिक roll योग
7. Bank: debit post → D−1 date lagta hai
8. Closing: checklist → backup → PIN → lock → new FY openings
