# Gram Panchayat Cashbook — PROJECT MASTER (consolidated)

> Consolidated from `PROJECT_MASTER.md` + `PROJECT_MASTER old.md` + user's 15 latest instructions (2026-09). Supersedes both.
>
> **Document purpose:** अब यही एक authoritative requirements + design file है। Sections 0–20 = baseline (`PROJECT_MASTER.md`) का 1:1 mapping (same order/naming)। Section A = user के नवीनतम 15 निर्देश। Section B = पुरानी `.md` से वे instructions जो current spec cover नहीं करता (restore/obsolete verdict सहित)। Section C = old vs new contradictions + decision। Section D = v6 implementation status।
>
> **Sources read:** `PROJECT_MASTER.md` (749 lines), `PROJECT_MASTER old.md` (1926 lines), `F:\Android app\cashbook\` directory listing (no other `.md` exists there — only xlsx/pdf/html/zip), `extracted\cashbook-mobile\app\index.tsx`, `services\*`, `types\models.ts`, `context\AppStore.tsx`.
>
> **Status:** Requirements FINAL for Phase 1; 15 latest instructions folded in (2026-09).
> **Last updated:** 25-09-2026 (this consolidated file created).

---

## 0. Scope, platforms, hard rules   (from baseline)

- **Product:** Hindi-first Android digital cashbook for a Gram Panchayat (Expo / React Native, `com.grampanchayat.cashbook`), **offline-first**, single-device, **Admin-only** (D6).
- **अनिवार्य rules (never violate):**
  1. एक ही `.md` = authoritative spec (अब यही file)।
  2. हर screen के corner पर screen number badge (`S-01` … `S-n`); **App Settings हमेशा अंतिम screen number** (B32 restores bottom-right muted + toggle detail).
  3. FY 1 April → 31 March; **FY isolation** — पुराने FY की transaction rows कभी नए FY में नहीं दिखेंगी; सिर्फ़ closing balances carry (D17).
  4. **SAF `Documents/Cashbook/...` storage mandatory** (D13); backup कभी `Android/data` में नहीं (instruction #14 / B16).
  5. **PDF/Excel share = plain white background** (D14); printed documents **हमेशा हिंदी**, UI English/Hinglish (V.2#13).
  6. Summary lines (श्री पोते राशि, आय योग, पूर्व पोते, व्यय योग, बचत पोते, महायोग) **कभी manually editable नहीं** (C.5 / 19.11).
  7. हर report/page पर compulsory: `Export Excel | Export PDF | Share Excel | Share PDF | Print` (Part F) — instruction #6/#12 के साथ।
  8. Devanagari PDF: Noto Sans Devanagari (+Condensed for grid), **Mangal banned**, `OFL.txt` required, shaping-capable renderer only (V.2#1 / B10).
  9. **Money:** cashbook me paise-precision (2 decimal) store/calculate; display जगह rupee round (Part M, old §12.7).
  10. Demo/sample files = **visual source of truth** for formats (Part U): user की upload की हुई Excel/PDF जैसा ही बनेगा।

---

## 1. Product vision  (baseline PART A)

```text
Digital Cashbook + Side-by-side Income|Expense pages + Configurable N-line pages (default 25)
+ Dynamic fund/scheme columns + Scheme-required multi-column amounts + Category/Sub/Sub-sub taxonomy
+ Work / MB / Bills / CC (Phase 1) + Bank statement → tag → auto entry (Phase 1)
+ Auto ledgers & reports + Annual & till-date गोशवारा + PDF + Excel export/share (compulsory)
+ Grid + form data entry + Backdated correction + audit trail + SAF Documents/Cashbook storage
+ Backup / restore / phone transfer + Period lock + FY closing + Admin-only (multi-role later)
```

---

## 2. Financial year  (baseline PART B)

- FY window 1 Apr → 31 Mar; हर FY का data isolated (pages/statements/attachments under FY id).
- **Carry-forward only balances:** previous FY closing (fund-wise नकद + bank / scheme) → new FY opening **श्री पोते**; previous FY transaction rows never appear.
- New scheme in new year: opening may be manual; Page 1 श्री पोते row shows **Carry-forward vs Manual** indicator (screen + print).
- 31 March: annual गोशवारा → year-close checklist → backup → lock → archive read-only; locked-FY unauthorized edit blocked, corrections only via correction entries + audit.
- Old spec extras still valid: पुराने year archive/read-only; year lock से पहले validation + backup (old §2 — covered).

---

## 3. Cashbook page engine  (baseline PART C)

**Visual source of truth:** user-provided Excel cashbook PDF `DOC-20260622-WA0002` (GP काबजा, पं.समि. साबला, डूंगरपुर, FY 2026-27). Screen **and** PDF/Excel export must match that grid — not a vertical list (C.2 rejects list UI).

- **Page frame (C.1):** `कार्यालय ग्राम पंचायत` + Panchayat name; `पंचायत समिति` + block; `जिला` + district; `वित्तीय वर्ष` + label; `पृष्ठ संख्या` automatic top-right. Landscape preferred for print/PDF; light register tint on screen, **plain white on share** (D14). *No date-range under header; date only on श्री पोते line → B24.*
- **Horizontal split (C.2):** exactly two equal halves — प्राप्ति (left) | भुगतान (right), thick vertical rule, full Excel-like grid lines.
- **Columns (C.3):** Left = दिनांक · चेक/DD/इन्वॉइस नं. व दिनांक · किस से प्राप्त किया · विवरण · L.F. · रकम(नकद + बैंक: SFC, FFC, OWN FUND/INT, MP/MLA/TAD, Other/Security/DD, Total). Right = दिनांक · वाउचर नं. व दिनांक · भुगतान किसको किया (चेक न./मस्टर रोल न.) · किस कार्य पेटे · L.F. · परिसंपत्ति रजिस्टर पृष्ठ सं. · रकम (same fund set). Fund heads dynamic (D5) — default 11 columns; add/rename/archive से बढ़/घट.
- **Row map (C.4):** opening row on प्राप्ति side = **श्री पोते राशि** (भुगतान side blank); middle = blank/txn lines; last 3 rows always present, never edited: **आय योग | व्यय योग**, **पूर्व पोते | बचत पोते**, **महायोग | महायोग**. Wording lock: bottom-left = **पूर्व पोते** (not second श्री पोते).
- **Lines (C.4.1 / D1–D3):** default L = **25** (settings से बदल सकते हैं), `txn lines = L − 4`; new page auto when full **+ manual Add Page** (D9); empty days skip + optional empty-day page (D10).
- **Formulas (C.5):** per fund `f` — आय योग = txn sum; पूर्व पोते = श्री पोते; महायोग_L = आय योग + पूर्व पोते; व्यय योग = txn sum; बचत पोते = महायोग_L − व्यय योग; महायोग_R = व्यय योग + बचत पोते; **both महायोग equal (validation)**.
- **Carry-forward (C.6):** next page/next active date श्री पोते = previous page बचत पोते (per fund). FY change: closing balances only.
- **Mobile UI (C.7):** side-by-side grid (not list); horizontal + vertical scroll; tap cell/`+ Entry` → form; long-press → edit/cancel; badge S-07. *Thin layout + zoom → instruction #10/#15 (Section A).*
- **Export (C.8):** PDF reproduces grid (white, embedded Devanagari); Excel sheet “Cashbook Print” with same headers as C.3.

---

## 4. Income & expense entry  (baseline PART D)

- **Income fields (D.1):** date, invoice no/date, किससे प्राप्त, details, L.F., multi-fund amounts, auto total, **scheme required**, category path, note, attachment. Source list editable: Govt, व्यक्ति, Bank, संस्था, Firm/Vendor, अन्य (+ custom description when अन्य → **B3**).
- **Expense fields (D.2):** date, voucher no/date, party/vendor, **Work या Other**, work name / other category path, L.F., multi-fund amounts, auto total, scheme required, note, attachment, payment mode Cash/Bank. Party master = select/add/search + vendor-wise reports. Work = name required, master select/add, optional code/ward/sanction ref. Other = category tree (Stationery, Printing, भत्ता, बिजली, सफाई, ईंधन, यात्रा, मरम्मत, डाक, बैठक, मोबाइल/इंटरनेट, अन्य, …).
- **Work | Other chooser, in-dropdown “नया work add”, category add/edit/delete यहीं से → instruction #7; work form scheme + AS/TS/FS + dates + MB status → instruction #8; vendor dropdown + in-place add vendor → instruction #5; minimal entry fields + one scheme per entry → instruction #9 (Section A).**
- **Repeat entry (D.3):** “पिछली entry से copy” template (monthly बिजली/सफाई) — implemented.
- **Cancel (D.4):** reason required; print red strikethrough; excluded from totals; stays in audit.
- Defaults: **scheme = SFC**; without scheme save blocked; same-day total expense ≤ that day income-side महायोग; per-scheme negative = FY toggle (default OFF) (D4/D8, old 19.6).

---

## 5. Category / subcategory / sub-subcategory  (baseline PART E)

- Max 3 levels: Category → Subcategory → Sub-sub-category; separate/namespaced trees for Income & Expense (+ Work classification as needed).
- CRUD in Cashbook Settings (S-xx Category tree manager); node in use → **archive, not hard-delete** (old rows keep history).
- Every txn should carry deepest applicable path; incomplete path flaggable in Monthly Check.
- Used for: गोशवारा grouping, ledgers, reports, “same path” txn discovery.

---

## 6. Auto ledgers & reports  (baseline PART F)

- From **first saved txn** of an FY, ledger/report views exist (may show one row). **No “generate report” step.** Every add/edit/cancel/category change → aggregates refresh. Empty state = why + steps.
- Compulsory share row: `Export Excel | Export PDF | Share Excel | Share PDF | Print`.
- Report catalogue (23): page-wise, date-wise, daily/weekly/monthly/range, full FY, income, expense, work-wise, other-category, vendor-wise, fund/scheme-wise, L.F.-wise, category-wise, monthly dashboard, गोशवारा (till-date + annual), backdated, edited/corrected, cancelled, audit trail, validation/incomplete, reconciliation, attachments, pending verification, search results.
- **Contextual reports** on every details screen + drill-down back to source (both directions).
- Excel = editable workbook (multiple sheets, filters, freeze, Hindi headings, formulas) — *default 12-sheet set → B9*. PDF = configured line layout, landscape options, embedded Devanagari, white background, optional watermark/signatures — *full option set → B10*.
- Extra ledgers from old spec: **Material item-wise ledger (Stock Register)**, **labour ledger**, **scheme detail screen**, **fee ledgers (count + amount + list)** → B28.

---

## 7. Bank statement  (baseline PART G, Phase 1)

- Bank account master; upload PDF (password unlock) → AI/OCR → **editable grid** (user corrects before post); tag: scheme, work/category, vendor, लेखा शीर्ष, टिप्पणी (instruction #13); grouping rules (multi-line one instrument), **D−1 date rule**, instrument number; post → structured cashbook entries; month locked for re-upload when entries exist **and** verified; **no bank→cash withdrawal**; optional **Cash → Bank deposit** entry type; files under SAF FY folder.
- Field layout = user's uploaded Excel (दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष) → instruction #13 (Section A).
- Full engine rules (credit placement, 10–15-day grouping window, labour consolidation, account auto-detect/IFSC, duplicate-month warning, register print, UTR reconciliation) → **B25/B26** (restored).

---

## 8. Works, MB, Man-days, Bills, CC  (baseline PART H, Phase 1)

- Ongoing works list with **scheme-wise grouping/filter tabs**; add old work with prior material/labour spend + optional bill-wise history; work payments list → bills → material lines.
- **MB:** मद-वार material + कारीगर + labour; **total valuation**; **material vs labour grouping + कारीगर toggle (default labour)** → instruction #3 (Section A).
- **Man-days / master roll:** named workers and group rows (5 labour × 12 days); pakhwada = 15d − Sundays − holidays (Holiday master), manual override; **full man-days only**; amount ≤ MB component; closer-better rule; app auto-suggests combos (trial-and-error); calc audit trail (rate, man-days, BSR year) → **B37**; rate ≤ BSR with −10…−20% safe band guidance → **B36** (sanction-year default still open = C2).
- **Manday sanction inside sanction** (desired wage rate + man-days auto-calc) → instruction #4 (Section A).
- **Bill register** date-wise: bill date + cashbook payment date + page ref.
- **CC — 7 pages:** (1) Completion certificate (AS/TS/FS, MB refs, valuations, allowable = min rules) (2) UC (3) Labour by pakhwada (4) Material as per MB (5) Technical verification (6) Completion photo + signatures (7) Before & during photos. Output **exactly in user's uploaded Excel format** + share PDF/Excel → instruction #6 (Section A).
- **Live status residual:** after MB = CC allowable − payments (material/labour separate); before MB from FS; special toggle when MB labour > FS labour.
- Masters: BSR (year-wise rates, old years read-only, prefilled items: सीमेंट, रेत, गिट्टी 40/20/12 मिमी, पत्थर, ईंट…), Workers/roles (year-wise), Items (whole/decimal flags, last-bill, basic), Holidays (pakhwada).
- Pending decisions from old spec: material-first payment enforcement (C3), last-bill item list (C4), qty whole/decimal (C5), excess-payment live status → **B38**.

---

## 9. गोशवारा  (baseline PART I)

- **Till date** from FY Home; **annual 31 March** classified income (left) | expense (right) — **always two-sided** like user's uploaded Excel → instruction #11 (Section A).
- Bottom: आय योग, प्रारंभिक बैंक/नकद; व्यय योग, अंतिम बैंक/नकद; महायोग equality check (mismatch → warning/close block).
- Tap head → ledger of that head for the year (implemented).
- Optional monthly reminder (e.g. 5th) to share PDF; **one-tap WhatsApp share to पं.समि./BDO** → **B34**.

---

## 10. Dashboard & Monthly check  (baseline PART J)

- **FY Home:** FY, opening, income, expense, current balance, pages, pending verification, missing attachments, unbalanced/incomplete flags. Quick actions: Add Income/Expense, Cashbook, Reports, Backup, Bank, Works (+ Current Page / Search / Export / Reconciliation → **B11**). Tiles include Material Ledger & Schemes → **B28**.
- **Monthly check:** lists **all** transactions of the period (not only warnings); missing scheme / category path highlighted + filterable; tap row → edit/correct/cancel/fill; also unverified pages, untagged bank lines, missing bill attachments, pending statements.

---

## 11. App flow, settings, security  (baseline PART K)

```text
S-01 Login (Admin PIN + optional biometric)
  → S-02 Panchayat selection + [App Settings]
       → S-05 Financial Year (status + chooser) + [FY / Cashbook Settings]
            → S-06 FY Home → Cashbook | Bank | Works | गोशवारा | Ledgers/Reports |
                Monthly check | Backup | प्रपत्र/Formats | Masters | Closing | …
```

- **App Settings (last screen):** theme colour (**instruction #2**), logo, UI language (English/Hinglish), screen-number badge on/off, change PIN, biometric toggle/re-enrol, Panchayat add/edit/correction/delete (destructive **and edit** = PIN re-confirm), global backup defaults.
- **FY / Cashbook Settings:** FY CRUD (add/close = PIN confirm, C11), scheme/fund CRUD **for this FY** (red delete = this FY only), opening balance editor visible, line count L, blank gap 1|2, allow-scheme-negative ON/OFF, appearance colours, category-tree links, empty-day help text.
- **Auth:** Admin only; PIN to establish; biometric optional; future roles reserved in model only.
- **Navigation:** hardware/in-app back → parent in stack (no exit to Android Home until root confirm); no silent dead clicks — empty states with why + steps; badges renumber when screens added, App Settings always last.
- *Storage-permission screen (S-03) + restore-detected screen (S-04) → **B16/B17** (restored into screen index §15).*

---

## 12. Storage, backup, audit  (baseline PART L, Phase 1)

```text
Documents/Cashbook/<PanchayatName_or_Id>/<FY_Label>/
  database / exports / bank_statements / attachments / backups /
```

- **Backup/restore:** auto-save after txns; manual backup; versioned list; restore; backup before FY lock & before destructive schema/column changes; phone-transfer wizard (backup zip + 4-digit restore code); optional cloud later.
- **Instruction #14** adds: proper file-storage folder chosen by user, app provides the permission (grant once → files persist), files survive uninstall, **never `Android/data`** — code: `services/backupFolder.ts` (SAF folder picker).
- Retention: last 15 daily + 1 permanent monthly snapshot, operation-prior safe backups never auto-deleted; human-readable JSON export (V.2#3). *Zip + manifest + naming + checksum/migrate-restore flow → **B14/B15**.*
- **Audit log:** user, time, entity id, action, field, old/new, reason. Prefer Cancelled/Archived over hard delete. *Edit-reason picklist + correction-entry fields → **B6/B7**.*
- **Attachments:** receipt/bill/voucher/sanction/MB photo/PDF linked to txn; included in backup policy (photo attachment per txn = pending C7).

---

## 13. Validation  (baseline PART M)

Invalid dates; non-numeric amounts; negative-amount prevention per policy; scheme required; category incompleteness warning (Monthly Check); at least one fund amount > 0; Work name if Work / other path if Other; duplicate invoice/voucher warning; expense vs day महायोग; optional scheme minus; महायोग mismatch / unbalanced page warnings; backdated impact confirmation.
*Recovered additions: configurable missing-attachment warning + missing invoice/voucher report (**B12**).*

---

## 14. Data entities  (baseline PART N)

`FinancialYear, Panchayat, Page, PageOpening (per fund), Transaction, TransactionAmount, FundColumn/Scheme, CategoryNode, IncomeSource, Work, Vendor, Attachment, BankAccount, BankStatement, BankLine, MeasurementBook, ManDayEntry, PakhWadaRoll, Bill, BillLine, CompletionCertificate, AuditLog, PeriodLock, User (admin), BackupRecord, AppSettings, FySettings, ExportHistory`.
*Code model (`types/models.ts`) additionally has `Vendor`, work sanction/MB fields, karigar toggle, bank tagging fields — see Section D.*

---

## 15. Screen index  (baseline PART O + restored screens)

| # | Screen | Notes |
|---|--------|--------|
| S-01 | Login | PIN + optional biometric + first-run logo chooser (login button always visible → instruction #1) |
| S-02 | Panchayat selection | + App Settings entry |
| **S-03** | **Storage Permission** | **restored (B16)** — first launch, compulsory `Documents/Cashbook` |
| **S-04** | **Restore Detected** | **restored (B17)** — old backups list → restore + migrate |
| S-05 | Financial Year page | + FY/Cashbook Settings |
| S-06 | FY Home | Dashboard + module tiles |
| S-07 | Cashbook page view | N-line dual grid, thin layout + zoom (#10/#15) |
| S-08 | Add/Edit Income | multi-column + scheme + category; minimal fields (#9) |
| S-09 | Add/Edit Expense | Work/Other (#7), vendor dropdown (#5), scheme + category |
| S-10 | Entry detail / cancel / correct | |
| **S-12** | **Page Verification** | **restored (B13)** — “जाँचा-परखा” stamp + user + date |
| S-11+ | Page list / range share | PDF/Excel white |
| S-13–S-16 | Bank accounts / upload / tag / post | Phase 1; fields = uploaded Excel (#13) |
| S-17–S-26 | Works / MB / Man-days / Bills / CC | incl. **manday sanction-in-sanction** + BSR page (#4) |
| S-27 | गोशवारा | till-date + annual, two-sided (#11) |
| S-28–S-34 | Ledgers & Reports Hub | incl. **Material Ledger (B28)**, **Scheme detail (B28)**, **Fee/Patta ledgers** |
| S-35 | Fund / column settings | full column-manager feature set → **B4** |
| S-36–S-41 | BSR, Workers, Vendors, Items, Holidays, Users | |
| S-42 | Backup & restore | SAF user-chosen folder (#14) |
| S-43 | Global search | |
| S-44 | Export centre | |
| S-45 | FY Closing wizard | |
| S-46 | New phone transfer | zip + 4-digit code |
| S-xx | Category tree manager | Income & expense |
| S-xx | Monthly check (full txn list) | |
| S-**Last** | **App Settings** | theme colour (#2), PIN/biometric, logo, panchayat CRUD |

*(Numbers renumber when screens are added; App Settings always last.)*

---

## 16. Build order & acceptance gate  (baseline PART P + Q)

**Build order:** 1) PIN+biometric+settings security → 2) SAF bootstrap + FY-scoped DB → 3) Panchayat/FY settings hierarchy → 4) Fund columns + page engine (L=25) + openings → 5) Income/expense save (multi-column, scheme required, category) → 6) strict FY filter regression → 7) carry-forward balances only (CF/Manual badge) → 8) auto ledgers/reports pipeline → 9) monthly check → 10) PDF/Excel page export (white) → 11) backup/restore SAF → 12) bank pipeline → 13) Works → MB → Bills → CC → 14) गोशवारा + FY closing → 15) empty-day insert, +2 pages, navigation/empty-state polish.

**Acceptance (Phase 1 gate):** baseline checklist (25-line page, scheme mandatory, summary non-editable, FY isolation, 3-level category, auto reports, monthly check, biometric optional, SAF tree, bank fixture path, MB→bill→CC path, Excel+PDF export, back nav, day-expense guard, auto+manual page) **plus restored checks (B19):** new fund column updates the whole book; archived column keeps data; audit shows old/new values; locked period blocks unauthorized edit.

---

## 17. Deferred / out of scope  (baseline PART R + old §13/§18.6)

- Multi-role Operator/Checker/Approver/Viewer UI; fixed Play-style signing keystore; TDS/GST; multi-device realtime sync; demo/sample training mode (**rejected**).
- **Backlog register (restored from old §13, B30):** bank reconciliation, advance tracking, pending-bills/liabilities register, निधि उपयोग प्रमाण-पत्र, budget vs actual, Hindi number-to-words, voice entry (Hindi), Devanagari numerals toggle, page e-sign/verification stamp, year-comparison report, asset/dead-stock register, onboarding help screens, large-font/dark mode, reminder notifications, multi-Panchayat mode (keep `PanchayatId` in model).

---

## 18. Demo-format locks & round decisions  (baseline PART U)

| # | Topic | FINAL |
|---|--------|--------|
| D21 | Page add | Manual **+ Page**: append **or insert between** pages; insert renumbers; delete re-flows txns; auto page-1 per FY |
| D22 | Formats Centre | FY Home tile **प्रपत्र / Formats Centre** — गोशवारा, Ledger, प्रपत्र-1, प्रपत्र-4, Bank grid, CC — all live, share/export from every card |
| D23 | गोशवारा format | audit demo sheet-1: मद-wise आय\|व्यय, आय/व्यय योग, प्रारंभिक/अंतिम शेष नकद (+bank), महायोग, हस्ताक्षर block |
| D24 | प्रपत्र-1 | audit demo sheet-2: FS ref/राशि (लाख), पूर्व व्यय, आलोच्य वर्ष व्यय, कुल व्यय, स्थिति, मूल्यांकन, MB ref, श्रम/सामग्री split |
| D25 | प्रपत्र-4 | audit demo sheet-3: सामग्री-वार मात्रा/दर/कीमत/योग |
| D26 | Ledger format | ledger.pdf (GP खाता बही): श्री पोते opening → जमा/नाम rows → running शेष; fund-wise or all-funds |
| D27 | CC | cc demo xlsx: 7-page set; **अनुमत = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)**; भुगतान योग्य शेष = अनुमत − payments |
| D28 | Mandays | **पाक्षिक मस्टरोल**: (मेट/कुशल/अकुशल × दिन) × दर = श्रम व्यय; rolls aggregate on CC page-3 |
| D29 | Monthly check | Edit every field + cancel with confirm; month filter (YYYY-MM); cancelled list |
| D30 | Backup | Full JSON backup share/save + restore-by-paste; SAF file-write on device build (#14 extends this) |
| D31 | Data model | `CashbookPage`, `PakhWadaRoll`, `Transaction.pageId`; AsyncStorage key versioned |

Demo mapping: `audit formet demo.xlsx` → गोशवारा/प्रपत्र-1/प्रपत्र-4; `bank statement demo.xlsx` → bank grid; `cc talora chaina mojek.xlsx` → CC 7 pages + mandays; `ledger.pdf` → खाता बही.

---

## 19. Provenance & decision log  (baseline PART S / V / W / VI — pointer)

- **PART S** (contradiction resolution) and **PART W/VI** (C1–C12 user decisions) are re-stated in **Section C** below with old-vs-new verdicts — that is now the single conflict table.
- **PART V merge map** (old doc → current doc, `[ALREADY-COVERED]` / `[CONFLICT]` markers) is superseded by **Section B** (which re-mines the old file from scratch and flags anything still missing).
- Resolved decisions kept as-is: C1 page structure (25 lines), C9 white print, C6 L.F. column (added), C10 logo chooser (added) + default user NOT seeded, C11 FY PIN confirm (added). Open/backlog: **C2** (BSR sanction-year default), **C3** (material-first enforcement), **C4** (last-bill list), **C5** (qty decimals), **C7** (txn photo attachment), **C8** (gap-2), **C12** (patta fields).

---

## 20. CI / build notes  (baseline PART T)

- Expo Android CI: extract → `expo prebuild` → `assembleRelease`; embed **release** JS bundle (debug APK without Metro = “Unable to load script”); strip monorepo `catalog:`/`workspace:` pins; `babel.config.js` with `babel-preset-expo` + `reanimated/plugin`; `newArchEnabled: false` for first stable sideloads; package `com.grampanchayat.cashbook`.
- Sideload signing: per-run debug keystore → update may require uninstall until **fixed keystore** (D15 “Later”).
- Stability trade-offs: biometric native module may be omitted (PIN stays); PDF OCR/SAF wired progressively.
- Always-regression: switching FY must never show previous FY rows.
- *Old CI learnings (JVM17, wrapper, one workflow, logs downloadable) → **B20**.*

---
---

## A. यूज़र के 15 निर्देश (latest, 2026-09)

> हर instruction testable spec wording में; status tag = Section D (v6 code) के आधार पर।

**A1. Login screen layout** — *"login button ab screen par dikh nahi raha; ise neeche/visible jagah par le jao, layout thik karo."*
→ Acceptance: login/set-PIN screen (S-01) पर button हमेशा viewport में दिखे — logo chooser खुले या keyboard आए तब भी; fixed-height layout नहीं, scrollable/keyboard-avoiding container; button field list के ठीक नीचे। **[implemented]**

**A2. Theme colour in App Settings** — *"Main App Settings me 'theme color' ka option add karo."*
→ Acceptance: App Settings (last screen) में theme colour picker (6 themes: हरा/नीला/टील/मैरून/बैंगनी/केसरिया); चुनते ही पूरी app पर colour लागू, selection persist; **printed documents का Hindi format वैसा ही** (theme सिर्फ़ UI)। **[implemented]**

**A3. MB entry — material/labour separation** — *"MB entry page confusing hai — material (सामग्री) aur labour (श्रम) ka alag-alag grouping dikhao; ek toggle do ki कारीगर labour me jaye ya material me (default = labour). Dono ka subtotal alag, valuation line me jodho."*
→ Acceptance: MB screen दो साफ़ sections — **सामग्री** (मद-वार qty × rate) और **श्रम** (कारीगर + लेबर); कारीगर-amount के लिए toggle (labour | material), **default = labour**; हर पक्ष का subtotal अलग दिखे; **Total valuation = material subtotal + labour subtotal** (कारीगर toggle के हिसाब से)। **[implemented]**

**A4. Manday sanction inside sanction + BSR page** — *"work-sanction ke andar ek alag 'manday sanction/sanction inside sanction' kholo: usme labour/karigar amount daalte hi desired wage rate aur man-days apne aap calculate hon (per .md ke hisaab se). Agar us saal BSR rates add nahi hain to BSR page khole — usme pehle se items listed hon (cement, रेत, गिट्टी 40mm/20mm/12mm, पत्थर, ईंट आदि), sirf us year ki rates bharni hon, items add/edit/delete karne ka option. System 2–3 aise combos auto-calculate kare jo desired amount ke karib hon (trial & error), user unme se choose kare."*
→ Acceptance: (a) work detail ke andar अलग **मन-डे स्वीकृति** sub-flow (sanction-in-sanction), केवल labour/karigar amount डालते ही desired wage rate + man-days auto-compute (pakhwada working days, full man-days, amount ≤ MB component, rate ≤ BSR); (b) agar उस year की BSR नहीं → वहीं से **BSR page**: default items पहले से listed (सीमेंट, रेत, गिट्टी 40/20/12 मिमी, पत्थर, ईंट…), सिर्फ़ rates भरनी हों, item add/edit/delete option; (c) app **2–3 सबसे करीब combos** auto-calculate करे (workers × days × rate, trial-and-error), user उनमें से चुने। **[implemented — combo shortlist sorted by closeness; confirm UI shows only 2–3]**

**A5. Vendor dropdown in Bills** — *"Bills me vendor dropdown hon; agar koi vendor nahi hai to wahi par 'add vendor' ka option."*
→ Acceptance: Bill create form में vendor = dropdown (master से); dropdown/list में ही **“नया vendor add”** option, add करते ही वही select हो जाए। **[implemented]**

**A6. CC = exact Excel format + PDF/Excel share** — *"CC ke 7 pages bilkul waise hi Excel format me jaise user ki upload ki hui Excel file hai (format unchanged); share/export me PDF aur Excel — dono ka option dikhe."*
→ Acceptance: CC के सातों पृष्ठ (पूर्णता प्रमाण पत्र, UC, श्रम मस्टर रोल, सामग्री, तकनीकी जाँच, पूर्णता फोटो, पूर्व/दौरान फोटो) **exactly** `cc talora chaina mojek.xlsx` वाले layout में (format unchanged); share row में PDF और Excel दोनों। **[implemented]**

**A7. Cashbook expense-side Work | Other** — *"Cashbook expense-side entry me do option: Work | Other. Work = added works ki dropdown (na ho to dropdown ke andar hi 'naya work add' option); Other = category/sub-category hierarchy jisme add/edit/delete ho."*
→ Acceptance: expense form में साफ़ दो options **कार्य | अन्य**; कार्य = works dropdown + dropdown ke andar hi “नया कार्य” (पूरा form); अन्य = category → sub-category tree, हर level add/rename/delete वहीं से। **[implemented]**

**A8. Work add form fields** — *"Work add karte waqt scheme poochho (expense entry ke dauran wo auto-select hoti rahe), plus A.S. number/date, T.S. number/date, F.S. number/date, work start date, work complete date, MB status (Complete/Pending); agar MB Complete to MB details: Total valuation, labour amount, material amount, page number, MB number (per .md)."*
→ Acceptance: नया work form में — **scheme** (योजना), AS/TS/FS क्रमांक व दिनांक (तीनों), कार्य प्रारंभ तिथि, कार्य पूर्ण तिथि, **MB स्थिति = Complete | Pending**; MB Complete होने पर अतिरिक्त — कुल मूल्यांकन, श्रम राशि, सामग्री राशि, MB पृष्ठ संख्या, MB संख्या; expense entry में work चुनते ही उसकी **scheme auto-select** रहे। **[implemented]**

**A9. Minimal cashbook entry fields** — *"Cashbook entry me sirf ye poochho: date, किससे प्राप्त, amount, scheme, category — ek entry me ek hi scheme, scheme baar-baar mat poochho."*
→ Acceptance: entry form केवल — दिनांक, किससे प्राप्त/भुगतान किसको, राशि (fund amount), योजना, श्रेणी; **एक entry में एक ही scheme**; scheme default (पिछली/work से) रहे तो दोबारा न पूछा जाए; बाक़ी विवरण optional/advanced में। **[implemented]**

**A10. Thin cashbook + own-fund default** — *"Cashbook page ko horizontal me patla karo taki kam se kam ek side phone par fit ho (upload ki Excel layout ke hisaab se); cash sirf transaction medium hai, scheme nahi — cash transactions default me 'own fund' (apna kosh), doosri schemes dropdown se."*
→ Acceptance: ग्रिड चौड़ाई ऐसी कि **कम से कम एक side phone width में fit** हो (uploaded Excel column order/headings वैसे ही, format unchanged), बाक़ी scroll/zoom से; **नकद = माध्यम, योजना नहीं** — cash वाली entry default **Own Fund (अपना कोष)**, दूसरी योजनाएँ dropdown से। **[implemented]**

**A11. गोशवारा & ledger two-sided original format** — *"गोशवारा aur ledger hamesha do-sided (two-side) ho, bilkul waise hi jaise upload ki Excel/PDF — original-type Excel format."*
→ Acceptance: गोशवारा = बायाँ आय मद | दायाँ व्यय मद (दोनों पक्ष); ledger = खाता बही वाला original type (जमा/नाम + running शेष), uploaded `ledger.pdf` / audit demo जैसा; output Excel में वही layout। **[implemented]**

**A12. सभी प्रपत्र — original look + Excel-type + share both** — *"Sabhi प्रपत्र phone par original dikhte hue Excel-type format me hon; share me Excel aur PDF dono ka option ho."*
→ Acceptance: Formats Centre के सभी documents (गोशवारा, ledger, प्रपत्र-1, प्रपत्र-4, bank grid, CC, cashbook page) phone पर original (uploaded sample) जैसे दिखें, Excel-type table format में export हों, और **हर card/share पर Excel + PDF दोनों** option। **[implemented]**

**A13. Bank statement fields = uploaded Excel** — *"Bank statement ke fields bilkul waise hon jaise upload ki Excel (दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष + tagging योजना/कार्य/vendor/लेखा शीर्ष/टिप्पणी)."*
→ Acceptance: statement grid columns exactly — दिनांक, विवरण, संदर्भ/चेक सं., जमा, निकासी, शेष; हर line पर tagging: योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी। **[implemented]**

**A14. Backup/restore in proper folder with app-granted permission** — *"Backup/restore thik se karein — ek proper file storage folder me save hon, iske liye app khud storage-permission dene ka option de (permission grant karke files bani rahein); file uninstall par bhi bani rahe (Android/data wale folder me mat likho)."*
→ Acceptance: एक बार folder picker (SAF) से अपना backup folder चुनो → permission persist; वहीं `Cashbook-Backup-<panchayat>-<timestamp>.json` बने, list/restore/delete वहीं से; folder public (uninstall-safe), **`Android/data` कभी नहीं**; permission revoke हो तो app दोबारा चुनने को कहे। **[implemented — `services/backupFolder.ts` + BackupScreen]**

**A15. Return to same page + zoom** — *"Kisi page ko chun kar entry me jane aur wapas aane par usi page par pahunchna chahiye (first page par na chala jaye); pinch-to-zoom ya +/- zoom controls ho taki dono sides ek saath dekhi ja saken."*
→ Acceptance: cashbook page → entry → back पर **वही page number + वही zoom level**; zoom = pinch **या** `+ / −` controls (+ % indicator, reset), ताकि एक साथ दोनों sides दिखें। **[partially implemented — page+zoom persist + `− / 100% / +` controls present; pinch gesture not found in code]**

---

## B. पुरानी .md से जो लौटाना/जोड़ना है

> Mining rule: `PROJECT_MASTER old.md` का हर section current `PROJECT_MASTER.md` से टकराया गया। जो fully covered है वह यहाँ नहीं है (वे आधे-अधूरे covered भी नीचे हैं)। Each item: instruction → कहाँ मिला → **RESTORE** / **OBSOLETE** (+ क्यों)। Legend: `old.md` = `PROJECT_MASTER old.md`, `cur.md` = `PROJECT_MASTER.md`.

| # | Instruction (old spec) | Where it appeared | Verdict | Why it matters / why obsolete |
|---|---|---|---|---|
| B1 | “Reports में केवल active transaction dates या सभी calendar days दिखाने का option होगा।” | old.md Part A §4, line 134 | **RESTORE** | D10 covers optional empty-day *pages*; the report-side display toggle (active dates only vs all days) is a separate report option — अभी कहीं नहीं है |
| B2 | “Actual transaction date और entry-created date अलग-अलग store होंगी” (+ last-updated, user id) | old.md Part A §4 lines 135–136, §10.1 lines 365–370 | **RESTORE** | Audit/backdated correctness: cur.md L.3 logs only generic fields; per-txn `createdAt/updatedAt/backdated` fields explicit नहीं हैं |
| B3 | Income “अन्य” चुनने पर custom description field खुलेगी | old.md §5.2 line 185 | **RESTORE** | cur.md D.1 में “Other/अन्य” है पर free-text detail खुलने का rule नहीं — नई categories बिना CRUD के भी entry लिखवाने का रास्ता |
| B4 | Fund column manager: add/rename/**Hindi-English label edit**/**stable code**/reorder/enable-disable/archive/**show-hide in print**/**show-hide in reports**/opening balance | old.md §8.1 lines 293–306 | **RESTORE** | cur.md D5/K.3 सिर्फ़ CRUD कहता है; print/report visibility और stable code (exports सुधरें) अभी unspecified |
| B5 | Column change का automatic propagation checklist: existing/new pages, headings, line totals, आय/व्यय योग, श्री/बचत पोते, महायोग, carry-forward, dashboard, reports, Excel, PDF + historical column **archive, never direct delete** | old.md §8.2 lines 308–325 | **RESTORE** | यही regression test है (D5 का acceptance); cur.md में propagation का explicit checklist नहीं |
| B6 | Edit reason picklist: गलत amount / date / category / party / invoice-voucher / fund head / अन्य | old.md §10.2 lines 382–392 | **RESTORE** | cur.md M में edit/cancel हैं पर standard reason dropdown नहीं — audit में reasons comparable नहीं होंगे |
| B7 | Locked-period correction entry fields: original reference, old value, correct value, difference, reason, approval status | old.md §10.3 lines 394–403 | **RESTORE** | cur.md PART B/L.3 सिर्फ़ “correction/adjustment entries + audit” कहता है; fields specify नहीं |
| B8 | Excel-like grid extras: cell tap→edit, duplicate row, sort/filter, search, **freeze header**, column resize/reorder, dropdown validation, dependent dropdowns, auto-save/draft, Excel **import** | old.md §13 lines 517–537 | **PARTIAL RESTORE** | cur.md V.2#2 में form-default + grid optional और copy/paste+undo/redo backlog है; **freeze/duplicate/sort-filter/search/column-resize** restore (grid optional feature); “Excel import” = OBSOLETE (no import path decided; exports only) |
| B9 | Excel workbook default **12 sheets** (Cashbook Print, All Transactions, Income/Expense Summary, Work-wise, Other Category, Vendor, Fund, Monthly, Annual गोशवारा, Validation/Errors, Audit Trail) + raw-data sheet + formulas/filters/freeze/Hindi headings | old.md §14 lines 541–558 | **RESTORE** | cur.md F सिर्फ़ “multiple sheets” कहता है; यह concrete export acceptance list है |
| B10 | PDF export options: A4 **and Legal/A3** landscape, compact/split layout, header/footer, **page numbering**, signature fields, **Draft/Verified/Final watermark**, **password-protected PDF optional**; share targets: **WhatsApp, Email, device storage, print, open in Excel/Google Sheets** | old.md §15 lines 562–591 | **RESTORE** | cur.md F में landscape/watermark/signature संकेत हैं; A3/Legal, page numbering, password PDF, share targets explicit नहीं (WhatsApp = पं.समि./BDO को भेजने का मुख्य रास्ता) |
| B11 | Dashboard quick actions: Current Page, Reports, **Export, Search, Reconciliation** (plus baseline list) | old.md §16 lines 634–643 | **RESTORE** | cur.md J.1 की quick-action list छोटी है; Search/Export/Reconciliation shortcuts FY Home पर चाहिए थे |
| B12 | “Missing attachment warning **configurable**”, “Missing invoice/voucher report”, “Incomplete transaction report” | old.md §17 lines 656–661 | **RESTORE** | cur.md M में duplicate-invoice और incomplete-txn (report 19) हैं; **configurable attachment warning** और **missing invoice/voucher report** नहीं |
| B13 | Page verification stamp: S-12 “जाँचा-परखा” + user + date; admin-only column settings; admin-only locked-period correction | old.md §18 lines 676–686; Part C S-12 line 1477 | **PARTIAL RESTORE** | Page verification RESTORE (FY closing checklist “pages verified” बिना verification screen के खोखला; S-12 index से गायब); admin-only column/correction = already implied by D6 → OK; “export/attachment permissions” separate = **OBSOLETE** (Admin-only, single user — granular permission matrix की ज़रूरत नहीं) |
| B14 | Backup **zip** = DB (WAL checkpoint) + attachments + `manifest.json` (app version, schema version, date, checksum); naming `GP_<Name>_YYYY-MM-DD_vX.Y.zip` | old.md §4.2 lines 1084–1093 | **RESTORE** | cur.md D30/V.2#3 सिर्फ़ JSON backup कहता है; attachments/DB लेने के लिए zip+manifest ज़रूरी; naming = पुरानी files पहचानने में |
| B15 | Restore flow: fresh install पर old backups auto-detect → “पुराना डेटा मिला — Restore करें?” → list (date, size, app version) → checksum verify → **schema migrate करके** restore (sirf copy पर्याप्त नहीं) | old.md §4.3 lines 1095–1101 | **RESTORE** | सीधा instruction #14 का companion; cur.md में restore सिर्फ़ “restore” शब्द है, UX+migrate+integrity unspecified |
| B16 | First launch: `Documents/Cashbook` permission **COMPULSORY** screen (S-03) — बिना आगे नहीं; revoke हो तो सबसे पहले re-grant screen; **`Android/data` में backup कभी नहीं** (uninstall पर delete) | old.md §3 lines 1060–1068; Part C S-03 line 1461 | **RESTORE** | cur.md में S-03 screen index से गायब; instruction #14 को पूरा करने के लिए यही flow है |
| B17 | Screen S-04 “Restore Detected” (first launch / Settings से) — old backups list → select → restore | old.md Part C line 1462 | **RESTORE** | B16 का जोड़ू; Settings से भी खुलना चाहिए |
| B18 | Modular rules: **versioned migrations (no drop/rename, archived flag)**, backup before update, **rollback on failed update**, untrusted code download नहीं, feature manifest/registry, signed modules | old.md §21 lines 750–762 | **PARTIAL RESTORE** | migrations + backup-before-update = RESTORE (V.2#5 में है, यहाँ दोहराया acceptance में); **feature registry/plugin manifest/rollback** = **OBSOLETE** — app अब single Expo bundle है, dynamic feature modules नहीं (old Kotlin/Compose plan) |
| B19 | Acceptance extras: नया fund column जोड़ने पर **पूरी book** update; historical column archive पर data सुरक्षित; audit trail **old/new values** दिखाए; locked period unauthorized edit रोके; Hindi font में कोई black box नहीं | old.md §26 lines 923–943 | **RESTORE** | cur.md Q में ये 4 checks नहीं हैं (font check है) — gate में जोड़ने हैं (already listed in §16 here) |
| B20 | CI learnings: extracted files + official Gradle wrapper > zip; JVM17 fix source में permanent; एक समय में एक active workflow; build logs/APK downloadable | old.md §23 lines 789–878 | **PARTIAL OBSOLETE** | Kotlin/Gradle starter pipeline हट चुका है (अब Expo prebuild, PART T) — JVM/wrapper/zip-extract **OBSOLETE (history)**; **“one active workflow + downloadable logs”** = keep as working rule (T.1) |
| B21 | 2-page demo PDF record + reusable build script (12+12, 30-line, sample totals) | old.md §1.3 lines 998–1003, §24 lines 882–894 | **OBSOLETE** | superseded by real export pipeline (`services/exportDoc.ts`) — numbers/layout अब demo से नहीं, live data से बनते हैं |
| B22 | श्री पोते row की टिप्पणी में source: “विगत वर्ष का बचत शेष” (page 1) / “पूर्व पृष्ठ का बचत पोते” (बाद के pages); पहला साल = admin एक बार fund-wise manual opening | old.md §2.1 lines 1012–1016 | **RESTORE** | cur.md C.6 carry + CF/Manual badge कहता है, पर **print/screen पर यह source text** unspecified — ऑडिट में opening का source यही बताता है |
| B23 | Cashbook appearance settings: default हल्का हरा page tint; **transaction text blue (ball-pen)**; श्री पोते **light red**; top श्री पोते + bottom-3 **bold, size +1**; footer colour configurable; हर option के साथ **detailed on-screen help** | old.md §19.4.3 lines 1806–1818 | **RESTORE** | cur.md C.1 सिर्फ़ “light register tint” कहता है; ink-colour rules रजिस्टर-जैसा look देते हैं और instruction #2 (theme) के साथ जाते हैं |
| B24 | Cashbook header: “सिर्फ़ GP का नाम + वि.व. — **नीचे कोई date range नहीं**”; तिथि **सिर्फ़ श्री पोते की line** के सामने | old.md §16.2 lines 1602–1603 | **RESTORE** | header की composition तो PDF-lock (C.1) जीतती है (§C6), पर **“no date-range band”** और **date-on-श्री-पोते-only** rule अभी भी valid हैं — दोनों files में यह refinement गायब है |
| B25 | Bank account master: bank + खाता संख्या + **IFSC**; statement की a/c से account auto-identify, नया मिले तो एक बार master में; **duplicate-month warning** (period range से); full statement का **register/full-format print**; reconciliation = cheque/UTR reference | old.md §11.1 lines 1262–1265 | **RESTORE** | cur.md G सिर्फ़ “Bank account master” कहता है — auto-detect, duplicate warning, UTR reconciliation, full print unspecified हैं |
| B26 | Bank auto-entry engine full rules: credit = credit date पर (month-end mode optional); **10–15 day grouping window → एक दिन/एक page**, बड़ा range → 2 pages (हर group पर अलग balance condition); **labour consolidation suggestion** (same-same debits → एक entry); work dropdown for कार्य payments; AS/FS/TS किसी भी समय; review screen एक-tap accept | old.md §11.2 lines 1268–1298 | **RESTORE** | cur.md G में सिर्फ़ “grouping rules + D−1” (संक्षेप); V.2#11 में detail है पर **coded = D−1 + balance only** — बाक़ी rules spec में explicit रहने चाहिए |
| B27 | Privacy note (Round 4, **final — इस पर आगे चर्चा नहीं**): bank/estimate data cloud AI को जा सकता है — GP का data वैसे भी RTI/public-domain में; भविष्य में offline OCR optional | old.md §11.1 line 1266, §18.5 lines 1696–1697 | **RESTORE (as recorded decision)** | cur.md से गायब; दो online exceptions (AI estimate, bank OCR) का legal/privacy आधार यही है — re-litigate न हो, इसलिए दर्ज करना ज़रूरी |
| B28 | FY Home tiles/ledgers: **Material Ledger (Stock Register)** — वस्तु-wise कुल + full ledger; **Schemes tile** → scheme detail (opening, income, expenditure, payment vouchers); **Labour ledger** (man-days, rates); fee ledgers count + full list | old.md §15.2 lines 1421–1422, §12 lines 1306–1346 | **RESTORE** | cur.md F की report list में ये generic reports हैं पर **distinct screens/tiles** (S-28/S-30/S-31/S-32) गायब हैं; stock register तो audit में मुख्य register है |
| B29 | पट्टा income entry extra fields: पट्टा क्रमांक (auto-suggest), पट्टाधारक नाम, जारी दिनांक — पट्टा ledger में दिखें | old.md §12.6 lines 1341–1346 | **RESTORE (pending C12)** | cur.md PART VI में यह open backlog है; ऑडिट का सीधा सवाल “साल में कितने पट्टे” — इसलिए रखना है |
| B30 | Future features (18 items: bank reconciliation, advance register, liabilities register, निधि उपयोग प्रमाण-पत्र, budget vs actual, Hindi number-to-words, voice entry, templates, Devanagari numerals, e-sign stamp, year comparison, asset register, onboarding help, large-font/dark mode, reminders, multi-Panchayat/PanchayatId, TDS/GST, multi-device sync) | old.md §13 lines 1357–1378 | **RESTORE (as backlog register)** | cur.md PART R में सिर्फ़ 5 चीज़ें हैं; बाक़ी 13 (जिनमें से templates/reminder कुछ हद तक बन चुके हैं) भूल जाएँगी — इसलिए §17 में restore |
| B31 | Launch/panchayat page: Sample-3 dropdown minimal style, deep-green gradient header, **time-based English greeting**, “**100% ऑफ़लाइन · डेटा सुरक्षित**” note | old.md §15.1 lines 1402–1407 | **PARTIAL RESTORE** | Greeting = already backlog (V.2#17) — keep; **offline-note text + dropdown minimal style** = RESTORE (trust signal, instruction-adjacent); M3 light-green theme = superseded by #2 theme picker |
| B32 | Screen badge: **bottom-right corner**, muted/light colour, hide/show toggle in Settings (default visible) | old.md §15.3 lines 1426–1431 | **RESTORE (detail)** | cur.md K.2 में on/off है, position/muted styling unspecified — design lock के लिए |
| B33 | Distinct screens dropped from condensed index: S-03 permission, S-04 restore-detected, S-12 page verification, **S-23 Master Roll**, **S-28 Material Ledger**, **S-30 Scheme ledger**, **S-32 Patta/Fee ledgers** | old.md Part C lines 1461–1545 | **RESTORE** | cur.md O में ranges (S-17–S-26, S-28–S-34) ने इन्हें absorb कर लिया — implementation भूल न जाए, इसलिए §15 में वापस नामित |
| B34 | गोशवारा: हर महीने की **5 तारीख़ reminder notification** + **one-tap WhatsApp PDF share** (पं.समि./BDO को) | old.md §17.1(9) lines 1665, S-27 line 1513 | **PARTIAL RESTORE** | cur.md I में “optional monthly reminder” है; **WhatsApp one-tap share** गायब है — वही तो असली काम है |
| B35 | Cash/bank practice: नकद शुल्क का **मिश्रित उपयोग** (कुछ daily खर्च, कुछ बैंक जमा); **हर नकद राशि बैंक में जमा करना ज़रूरी नहीं** — जमा आंशिक और optional | old.md §17.1(2) lines 1656–1658 | **RESTORE** | cur.md G में “no bank→cash + cash→bank deposit type” है, पर **partial/optional deposit** का rule नहीं — instruction #10 (cash = माध्यम, own fund) के साथ यही GP practice है |
| B36 | Rate rules: **HARD RULE rate ≤ BSR**; safe band BSR से 10–20% कम (कारण: cross-FY काम में ऊँची BSR → **audit में recoverable**); **स्वीकृति वर्ष की BSR default**; ऊँची चुनने पर तुरंत warning; **CC में हमेशा दिखे किस वर्ष की BSR से गणना** | old.md §7.2 lines 1139–1148 | **RESTORE** | cur.md H में सिर्फ़ “rate band guidance” (D-spirit); sanction-year default = open **C2** — audit-rationale और “BSR year on CC” दोनों spec में explicitly रहने चाहिए |
| B37 | हर man-days calculation **audit trail** में जाए (rate, man-days, BSR year) — certificate के पीछे का गणित दोबारा दिखे | old.md §7.3(5) line 1156 | **RESTORE** | V.2#8 में “partial” — calc audit log के बिना CC का गणित verify नहीं होता |
| B38 | Bill module rules: **material-first payment** (labour/MR payment warning या strict block, configurable); **last-bill items** (पानी/टेंकर/मशीनरी/वाइब्रेटर/मिक्सर/डिस्प्ले बोर्ड/पॉलिश) सिर्फ़ last bill में; **qty flags** (cement/ईंट = whole, loose = decimal); **basic items front-load suggestion**; **material bills योग = CC material validation**; payment-time **live spend status + excess-payment warning** | old.md §8 lines 1178–1216 | **RESTORE (pending C3/C4/C5)** | cur.md PART VI में ये open backlog हैं (masters बने हुए हैं) — audit के ये exactly वो rules हैं जो अक्सर टूटते हैं; इसलिए Section B में visible रखना ज़रूरी |
| B39 | CC/UC **format = actual Rajasthan Panchayati Raj sample** जब user दे — layout उसी के अनुसार | old.md §10 line 1248 | **RESTORE (as rule)** | demo xlsx अब lock है (D27), पर “user का actual sample = final format” का नियम भविष्य के प्रपत्रों (रसीद/पर्ची भी) पर लागू होना चाहिए |
| B40 | AI Estimate Reader: cloud OCR, **mandatory operator review step**, offline-policy exception #1, needs 2–3 sample estimate PDFs | old.md §9 lines 1219–1228 | **RESTORE (as deferred module)** | V.2#10 में है पर “deferred” के साथ duplicate न हो, इसलिए यहाँ register में दर्ज — requirement (review अनिवार्य) कभी हल्की न पड़े |
| B41 | Main-page/S-02 GP dropdown minimal style + “प्रवेश करें” button; **Panchayat selection हर बार दिखे**; FY page पर सिर्फ़ FY status + chooser | old.md §14 rows 8–11 lines 1393–1396, §15.1 | **RESTORE (confirm)** | cur.md K.1 flow में implicit है; “हर बार” और FY page की सादगी explicitly confirm कर लेना चाहिए (बदलाव = decision required) |
| B42 | Report rule: हर report में compulsory Excel/PDF export + share + print (22 reports) | old.md §12 lines 478–513 | *already covered* | cur.md F (23 reports + compulsory share row) — **no action** (listed only for completeness of the mining pass) |
| B43 | 30-line structure, श्री पोते twice (line 1 + 29), 26/27 split, green print hybrid, default user “Harish Patidar”, 47-screen fixed numbering, Kotlin/Room starter, demo-PDF pipeline | old.md §3/§2.2, §16.1, §18.2, §23–25, §27 | **OBSOLETE** | superseded by PDF-sample lock (25 lines, C1), user decisions C9/C10, Expo/AsyncStorage stack, live export pipeline — see Section C |

**Count: 43 mined items — 34 RESTORE (some partial), 9 OBSOLETE / already-covered.**

---

## C. विरोधाभास (contradictions) old vs new

| # | Old spec said | New spec says | Decision | Why |
|---|---|---|---|---|
| C-1 | हर पृष्ठ **30 lines**; income 26 txn + expense 27 txn (26/27 split) | **25 lines**, txn = L − 4 (21) | **NEW wins** | User decision C1 (24-09): real Excel/PDF sample (`DOC-20260622-WA0002`) का grid = source of truth, 30-line mode नहीं |
| C-2 | श्री पोते **दो बार** (line 1 + line 29, symmetry) | श्री पोते **सिर्फ़ top**; bottom-left = **पूर्व पोते** | **NEW wins** | PDF wording lock (C.4/C.9) — sample page पर bottom label “पूर्व पोते” है; repeat = double-count risk |
| C-3 | Page background हल्का हरा (#e9f4e9) + **hybrid print option** (रंगीन/सफ़ेद) | Screen: light register tint; **share/PDF = white only** (D14) | **NEW wins (C9)** | User decision: white-only print (ink cost + official copies); screen tint रहेगा (B23 appearance rules) |
| C-4 | Header = “सिर्फ़ GP नाम + वि.व.”, नीचे कोई date range नहीं | Header = GP + पं.समिति + जिला + वि.व. + पृष्ठ संख्या (C.1) | **NEW wins for composition; OLD rule kept (B24)** | C.1 = actual sample PDF lock; **date-range band नहीं** वाला refinement अभी भी लागू |
| C-5 | Line-count setting default **30** (19.2.3) | Default **25** (D1) | **NEW wins** | Same PDF lock as C-1; setting still allows L change |
| C-6 | Default fund = Cash column (§8) + separately entry scheme required | Cash = **माध्यम, योजना नहीं**; cash txn default **Own Fund**; दूसरी schemes dropdown (#10) | **NEW wins (reinforced)** | Instruction #10 (2026-09) explicit; own-fund column already in sample PDF |
| C-7 | **Sanction-year BSR default** + higher-year warning + CC shows BSR year (§7.2) | cur.md: सिर्फ़ “rate band −10…−20% guidance”; sanction-year default **not implemented** | **OLD wins as intent → OPEN (C2)** | Audit-rationale (recoverable risk) unchanged; pending user go-ahead in PART VI backlog |
| C-8 | Material-first payment **enforcement** (warning/strict block configurable) | cur.md silent | **OLD restored → OPEN (C3)** | Payment sequence = audit finding; user decision pending |
| C-9 | Last-bill items fixed list; whole/decimal qty flags | cur.md silent (masters hold flags) | **OLD restored → OPEN (C4/C5)** | Data model ready; UI rules pending user confirmation |
| C-10 | L.F. column दोनों forms में | cur.md entry form में L.F. नहीं (PDF C.3 में column है) | **OLD wins → DONE (C6, implemented)** | Ledger↔entry cross-verify के लिए L.F. ज़रूरी (user decision VI) |
| C-11 | Har transaction attachment (receipt/bill photo + PDF) | note-only; attachments backlog (C7) | **OPEN (C7)** | old rule restore on user confirmation; expo-image-picker present |
| C-12 | Blank-line gap Option A/B (default 1) | D1: gap 1|2 in settings | **NEW (same content)** | No real conflict — setting exists; default = 1 (C8 minor) |
| C-13 | First-run **8-logo chooser** + default user “Harish Patidar — Operator” | Logo fixed in app.json; admin generic | **SPLIT:** logo chooser **OLD restored (C10, implemented)**; default user **NEW wins** | User ने logo chooser चुना, default user seed नहीं चुना (PART VI) |
| C-14 | Password re-confirm on panchayat **and FY** edit/delete | panchayat destructive/edit only | **OLD wins → DONE (C11, implemented)** | FY add/close पर भी PIN confirm (user decision VI) |
| C-15 | पट्टा extra fields (क्रमांक/पट्टाधारक/जारी दिनांक) | not present | **OPEN (C12)** | Restore as backlog |
| C-16 | Screen index **exactly 47** (S-01…S-47), App Settings S-47 | Condensed index, renumber freely; App Settings **always last** | **NEW wins (process)** | Same intent; numbers now fluid — Section 15 restores missing *names* (B33) even if numbers shift |
| C-17 | Multi-role (Operator/Checker/Approver/Viewer) lists | **Admin only** (D6/19.1) | **NEW wins (agreed)** | old doc itself marks multi-role deferred (Round 5) — not a real conflict |
| C-18 | PDF: HTML→Chromium/Android-native shaping pipeline (ReportLab banned) | Expo `expo-print` + embedded Devanagari | **No conflict — requirement restated** | Binding rule = **shaping-capable renderer + Noto, Mangal banned**; expo-print (Chromium print pipeline) satisfies it — keep B10 font rules as the acceptance test |
| C-19 | Backup = zip + manifest + retention; restore = migrate + checksum | Backup = JSON share/save + retention (D30/V.2#3); restore unspecified | **NEW wins for what's built; OLD restored as target (B14/B15)** | JSON keeps “readable in 5 years”; zip/migrate flow needed for full-fidelity restore (#14) |
| C-20 | Demo/sample training mode | **Rejected** | **Agreed — OUT (both)** | old §17.2 rejected, cur.md PART R keeps it out |

---

## D. Implementation status (v6)

> Evidence: `extracted\cashbook-mobile\app\index.tsx` (3,925 lines; 27 screens + Pin/Cancel modals), `services/` (`backupFolder, exportDoc, formats, mandays, pageEngine`), `types/models.ts`, `context/AppStore.tsx`. All 15 instructions carry code markers (`/* instruction #N */`).

**Screens present (Stage union):** login, panchayat, appSettings, fy, fySettings, home, cashbook, entry, funds, categories, monthly, goswara, reports, ledgers, backup, bank, works, workDetail, mb, manday, bills, cc, formats, masters, closing. **Not present as dedicated screens:** S-03 storage-permission gate, S-04 restore-detected, page-verification, material-ledger/stock-register tile, scheme-detail screen (see B16/B17/B13/B28).

| # | Instruction | Status | Evidence |
|---|---|---|---|
| 1 | Login button visible / layout fixed | **Implemented** | `LoginScreen` — `KeyboardAvoidingView` + `ScrollView flexGrow` (comment: “fixed-height screen → login button niche chala jata tha”) |
| 2 | Theme colour in App Settings | **Implemented** | `AppSettingsScreen` “Theme colour (6 रंग)”, `app.themeId`, `applyThemeAndStyles` |
| 3 | MB material/labour grouping + कारीगर toggle (default labour) | **Implemented** | `MbScreen` (two parts + subtotals), `models.ts` `karigarIn: 'labour' \| 'material'` default labour |
| 4 | Manday sanction-in-sanction + prefilled BSR page + 2–3 closest combos | **Implemented (verify combo count)** | `MandayScreen` + BSR page (items pre-seeded: सीमेंट/रेत/गिट्टी 40-20-12/पत्थर/ईंट…), `AppStore` rate-missing → BSR open, `services/mandays.ts suggestCombos()` sorted by closeness, **returns top 8** — UI must show only 2–3 |
| 5 | Bills vendor dropdown + add-in-place | **Implemented** | `BillsScreen` — `vendors`, `addVendor`, dropdown + “यहीं से add” |
| 6 | CC 7 pages in uploaded Excel format + PDF/Excel share | **Implemented** | `CcScreen`, `services/formats.ts` CC section (पृष्ठ 1…7), `exportDoc.ts` (expo-print PDF + .xls) |
| 7 | Expense Work \| Other, in-dropdown new work, category CRUD | **Implemented** | `EntryScreen` “खर्च का प्रकार”, in-list “नया कार्य”, `CategoriesScreen`/category level list add-rename-delete |
| 8 | Work form: scheme, AS/TS/FS, dates, MB status + MB details | **Implemented** | `WorkForm` “Instruction #8 — योजना, AS/TS/FS …, शुरू/पूर्ण तिथि, MB स्थिति”, `models.ts` sanction/MB block; scheme auto-select on work pick in entry |
| 9 | Minimal entry fields, one scheme per entry, no repeat asking | **Implemented** | `EntryScreen` “instruction #9 — सिर्फ़ date, किससे प्राप्त, राशि, योजना, श्रेणी”; one-scheme save |
| 10 | Thin cashbook (one side fits) + cash = medium, default own fund | **Implemented** | `CashbookScreen` narrowed columns + scale (instruction #10), hint “नकद … default Own Fund” |
| 11 | गोशवारा + ledger two-side, original Excel/PDF type | **Implemented** | `formats.ts buildGoswara` (मद-wise आय\|व्यय), ledger = खाता बही rows (श्री पोते → जमा/नाम → running शेष) |
| 12 | सभी प्रपत्र original look + Excel-type + Excel & PDF share | **Implemented** | `FormatsScreen` + `formats.ts` (गोशवारा/प्रपत्र-1/प्रपत्र-4/ledger/bank/CC) + `exportDoc.shareFormat` (PDF \| Excel dialog) |
| 13 | Bank statement fields = uploaded Excel + 5-way tagging | **Implemented** | `BankScreen` “instruction #13”, `models.ts` `BankLine` + `vendorId/categoryId/note` tagging |
| 14 | Backup/restore in user folder, app-granted permission, uninstall-safe, no `Android/data` | **Implemented (device test pending)** | `services/backupFolder.ts` — SAF `Directory.pickDirectoryAsync`, permission persisted, list/read/delete in that folder; `BackupScreen` |
| 15 | Return to same page + zoom (pinch or ±) | **Partially implemented** | `cashbookUI = { page, zoom }` persists across entry→back; `− / reset / +%` controls present; **no pinch-gesture handler found** — pinch still pending |

**Not covered by the 15 but built in v6 (from `services/` + screens):** page engine (L, txn = L−4, carry-forward), FY closing wizard, formats centre, masters (BSR/Item/Holiday/Worker/Vendor), monthly check, FY settings with PIN confirm, 8-logo first-run chooser.

**Known gaps to track (mostly Section B):** S-03/S-04 permission+restore screens, page verification stamp, material ledger/scheme-detail tiles, zip+manifest backup & migrate-restore flow, PDF option set (page numbers/A3/watermark), Excel 12-sheet workbook, edit-reason picklist, correction-entry fields, sanction-year BSR default (C2), material-first/last-bill/qty rules (C3–C5), txn attachments (C7), patta fields (C12), pinch zoom, WhatsApp one-tap गोशवारा share.

---

**End of consolidated master document.** Implementation and GitHub issues should quote section ids (e.g. `C.2`, `A4`, `B15`, `C-7`, `D-4`).

---

## E. v8 implementation round (26-09-2026) — user ki 30-point correction list

> Deliverables: `Gram-Panchayat-Cashbook-FULL-v8.zip` (repo root par, 30 files, `node_modules` nahi,
> forward-slash paths, full project — configs + package-lock shamil) + `.github/workflows/build-apk.yml`
> (workflow name **v8**).
>
> Chalane ka tarika: **Actions → Build APK (Gram Panchayat Cashbook v8) → Run workflow**
> (ya `git tag v8 && git push origin v8`).

| # | Correction | Status | Kahan laga |
|---|---|---|---|
| 1 | Biometric हटाओ | done | LoginScreen — button + description + `setBiometricEnabled` hataya |
| 2 | Logo options हटाओ + folder ka `cashbook logo.jpg` | done | `LOGO_CHOICES` gayab; `assets/images/cashbook-logo.png` (1024×1024) login + App Settings dono me |
| 3 | FY home → Opening balance click → scheme-wise + edit (PIN/fingerprint) | done | `SchemeDrillModal` + `PinModal` + `updateFundOpening` |
| 4 / 8 | Income / Expense / Balance click → real-time scheme-wise | done | `Stat` pressable, FYScreen aur HomeScreen dono par |
| 5 | Entry click → scheme-wise count + amount | done | drill `txns` |
| 6 | Colour swatch picker (code input नहीं) | done | `ColorSwatchField` + `COLOR_SWATCHES` — FY Settings ke 4 colour fields |
| 7 | Cash कोई योजना नहीं — अपना कोष 2 columns (नगद + बैंक) | done | cashbook `amtCols = schemeCols + ownCols + कुल`; header row-1 योजना / अपना कोष / कुल |
| 9 | Expense से `परि. रजि. पृ.` column हटाओ; 9b footer uniform font colour | done | `rightCols` से `asset` हटाया; footer rows में `kindColor` |
| 10 | Entry click → edit; FY setting back-date edit on/off (off = read-only) | done | `FySettings.allowBackDateEdit` (default on) |
| 11 | Blank lines entry के समय (FY gap setting हटाओ) | done | `blankLineGap` 1..4 → 0..3 blank lines; EntryScreen chips |
| 12 | Pre-selected L1/L2/L3 श्रेणी नहीं — सिर्फ़ add/delete | done | flat leaf-category `SelectField` |
| 13 | DD/MM/YYYY | done | `fmtDate()` (pageEngine) सभी FY/date cells में |
| 14 | Expense का `कार्य` एक category की तरह | done | `categoryId = workCatId`, subcategories null |
| 15 | Month dropdown (manual नहीं); 15b हर महीने का month-end page अपने-आप | done | MonthlyScreen `SelectField`; `syncMonthlyPages()` |
| 16 | गोशवारा / ledger दो-पक्षीय (cashbook जैसा) | done | गोशवारा आय/व्यय panels; ledger जमा/नाम panels + चलता शेष |
| 17 | असली `.xlsx` share | done | `services/xlsx.ts` (हाथ से बना OOXML/ZIP writer, नया dependency नहीं) |
| 18 | Ledger में work/bill/vendor/AS-FS-TS संख्या+तिथि + ZP/PS प्रथम किस्त रसीद | done | LedgersScreen enriched rows + `ZP / PS प्रथम किस्त — रसीद` card |
| 19 | कार्य में funding-agency dropdown (add/edit/delete) | done | `FundingAgency` master + WorkAddForm `SelectField` + manager modal |
| 20 | Audit engine `audit formet demo.xlsx` की 6 sheets | done | Formats → **Audit workbook**: full गोशवारा · गोशवारा · प्रपत्र-1 · सामग्री ऑडिट · श्रम ऑडिट · पट्टा ऑडिट (`shareWorkbook`) |
| 21 | PDF default A4 + orientation option | done | `docHtml` का एक ही सही `@page` rule + `chooseOrientationThenShare` |
| 22 | Bank statement Excel-जैसा page | done | column letters A–E, WITHDRAWAL(DR) / DEPOSIT(CR), चलता शेष + list toggle |
| 23 | अलग Work / MB / Bill / CC tiles + work detail drill-down | done | 4 home tiles; `WorkPicker`; WorkDetailScreen (AS/TS/FS + तिथि, स्वीकृति, शुरू/पूर्ण, बिल, कुल भुगतान) |
| 24 | MB click → कार्य विवरण पहले से भरा + MB details (कुल/श्रम/कारीगर valuation, item-wise मात्रा + BSR दर, karigar toggle) | done | MbScreen auto work card + BSR hint + valuation split |
| 24b | Bills → works → payment entries → entry क्लिक → विवरण | done | `WorkPicker` + card tap → बिल विवरण modal (तिथि, vendor, MB सामग्री पंक्तियाँ) |
| 25 | CC click → Excel-जैसी sheets, Excel + PDF share | done | `askAndShare` (PDF A4 orientation / असली `.xlsx`) |
| 26 | MB सिर्फ़ valuation; mandays CC labour से; defaults कारीगर 600 / श्रमिक 260; trial-error solver (60000 → 20 × 235 × 255 = 59925); MR composition wizard (10+2 / 15+1 / +5) पाक्षिक split | done | `DEFAULT_ROLE_RATE`, चौड़ा workers sweep, `minPeople` hint, MR wizard (size / कारीगर / count → स्वतः note) → `MandayCalc.muster` |
| 27 | Backup custom storage path + install के बाद permission | done | SAF `Directory.pickDirectoryAsync`, persist permission, `expo-file-system` plugin |
| 28 | FY closing → file/database/zip share (text नहीं); format centre → पूरा A4 page | done | `shareRawFile` / `shareZipBundle` (json + गोशवारा.html + खाता बही.html + README); Formats → "पूरा Formats Centre A4" |
| 29 | Worker की list नहीं — सिर्फ़ counting + mandays | done | Masters → `मान-दिवस` tab (aggregate), Workers roster हटाया |
| 30 | BSR: mandays calculate नहीं होते, page बार-बार खुलता, boxes खाली | done | default दर 600/260 fallback; auto-`setBsrOpen(true)` effect हटाया; modal inputs का background अलग (`Field bg` + सफ़ेद दर box) |

**Verification:** `tsc --noEmit` EXIT=0 · `expo export --platform android` EXIT=0 (4.8 MB `.hbc` bundle).

---

## Section F — v9 (19-point correction list)

> **Zip:** `Gram-Panchayat-Cashbook-FULL-v9.zip` (repo root, forward-slash paths,
> full project — configs + package-lock shamil, `node_modules/.git/.expo/android/ios/dist/.idea/.vs/out/.cache` nahi)
> + `.github/workflows/build-apk.yml` (workflow name **v9**).
>
> Chalane ka tarika: **Actions → Build APK (Gram Panchayat Cashbook v9) → Run workflow**
> (ya `git tag v9 && git push origin v9`).

| # | Correction | Status | Kahan laga |
|---|---|---|---|
| 1 | Launcher icon aapka jpg (1024 full-bleed) | done | `assets/images/cashbook-icon.png` (icon + favicon), `cashbook-icon-foreground.png` (#123b2c canvas + logo 634px) → `app.json` `icon` + `adaptiveIcon.foregroundImage` + `splash.image`; `version` 1.0.2 / `versionCode` 3 (CI me `expo prebuild` icon regenerate karta hai) |
| 2 | FY main + FY home tiles = 2-tile grid (6 tiles) | done | `Stat` (tile style outermost, `width:47.5%` flexGrow/Shrink 0), `statLabel/statValue/statHint/statPressed`; FYScreen + HomeScreen me 6th टाइल **रद्द (cancelled)** |
| 3 | Cashbook: month-end page sirf month ki last date ke baad; baaki waqt current date ka page; back-date sirf usi entry tap par; nayi entry par date ke baad "is date ka page / agla possible page" (suggestion = agla); ek page ki saari dates ek hi hon; zabardasti alag date = us date ka naya page | done | `types/models.ts` `CashbookPage.date?`; `pageEngine.monthLastDay()`; `AppStore.withPageDates` (migration), `dateLabel/pageDate/insertDatePage`, date-based `assignPageFor`, `syncMonthlyPages` (sirf month-end < aaj; **future ke auto month-end pages bhi delete** — un par entry nahi honi chahiye), `pageOptionsForDate/ensurePageForDate/pageDateOf`, `addTransaction({... pageId})`; hydrate chain `stripSchemeCats(migratePages(withPageDates(withOpeningsSnapshot(seedBsrItems(mergeRaw(p))))))`; EntryScreen date-blur `askPageForDate` (सुझाव: अगला पन्ना / {date} का नया पन्ना / बाद में); CashbookScreen `ensurePageForDate(todayInFy())` + `gotoTodayFy` effect + header `· {date}` |
| 4 | Cashbook share → PDF/Excel + page-range select | done | CashbookScreen share → page-range modal → `askAndShare(title, body, true)` |
| 5 | Categories se SFC/FFC hatana | done | `seedCategories` se `inc-sfc/inc-ffc` gayab; `stripSchemeCats()` hydrate + `importBackupJson` chain me |
| 6 | "Amounts by fund" = ek hi राशि column | done | MonthlyScreen edit modal me ek hi `editAmount` |
| 7 | Category path se SFC/FFC hatana | done | `stripSchemeCats()` + edit path me `aliveCat()` (purane category id clear) |
| 8 | Phone back button entry-edit par kaam kare | done | MonthlyScreen edit Modal `onRequestClose` + local `BackHandler` listener; PinModal/CancelModal `onRequestClose` |
| 9 | गोशवारा share/table = Excel-type layout | done | GoswaraScreen `tblBox/tblHead/tblHeadCell/tblRow/tblCell/tblTot`; button "Share — PDF / Excel" |
| 10 | Manday count rework — **'मेट' hataya**; श्रेणी/कारीगर ki alag-alag राशि; real-time निकटतम; dono me se ek-ek chuno → total (labour + karigar); MR detail (23 श्रमिक / 7 कारीगर → 3 × 10-10 MR); per-MR karigar split, baaki sab श्रमिक; MR ek-ek karke bharein; wahi detail work ke CC Excel format me | done | `MandayScreen` pura naya: `mandayOptions()` (days fix, rate −5/−10/−15/−20/−10%/−20% → sabse kam bache **3 options**, useMemo par real-time), `desiredLab` + `desiredKar` do alag fields, ek-ek option pick → **कुल योग** card; MR composition (size chips + apni size, count = auto ya custom, har MR me **कारीगर / श्रमिक dono custom inputs** — "pehle कारीगर, baaki श्रमिक"); save → 1 `MandayCalc` + N `PakhwadaRoll` (`rollNo MR-1…`, `mateCount:0`, `skilledCount`=कारीगर, `unskilledCount`=श्रमिक, `sourceId`) → **CC पृष्ठ 3 (Excel) me wahi detail**; `deleteMandayCalc` apne rolls bhi delete |
| 11 | AS/TS/FS + dates add karne par **MB entry** me mention hona chahiye | done | MbScreen "कार्य विवरण (auto) — स्वीकृति व MB" card ab alag-alag label lines: योजना/स्वीकृति सं./एजेंसी, **A.S. (प्रशासनिक) — क्रमांक + दिनांक**, **T.S. (तकनीकी)**, **F.S. (वित्तीय)**, FS राशि + MB मूल्यांकन, शुरू→पूर्ण + MB नं./पृष्ठ |
| 12 | MB detail se **'मेट'** hatana; सामग्री qty & rate column patle | done | MbScreen role buttons sirf **श्रमिक / कारीगर**; qty-rate fields `Field grow` (row me poori chaurai); HTML tables me `cols(...)` colgroup → CC पृष्ठ 4 (6 col: 6/30/12/10/19/23) aur प्रपत्र-4 (7 col: 6/26/11/9/14/17/17) — मात्रा/दर/मूल्यांकन ab patle nahi |
| 13 | Labour side par श्रेणी/कारीगर ko **item nahi puchna**; सामग्री items = **BSR dropdown + usi dropdown me "नया item"** | done | MbScreen: `part==='labour'` par Item field gayab, naam apne-aap श्रमिक/कारीगर, दर `referenceRate()` se auto; `part==='material'` par `SelectField` = BSR(active FY) + ItemMaster ki poori list + aakhir me **➕ नया item…** (usi dropdown me) → 'new' chunne par free-text naam; BSR select karte hi दर auto |
| 14 | MR composition: MR labour/karigar count custom, phir per-MR karigar/labour split bhi custom | done | MR size chips (5/10/15/20) + **apni numeric size**; MR count chips (1–6) ya **स्वतः** (ceil(लोग/size), up to 60); har MR ka card `MR i/n — X कारीगर + Y श्रमिक = Z/size` with 2 numeric inputs; validation (कुल कारीगर/श्रमिक match + per-MR ≤ size) |
| 15 | Bank statement **Excel upload** (PDF nahi) → app parse karke statement + cashbook bhare, phir edit | done | BankScreen "⬇ Excel / CSV फ़ाइल से import" (`File.pickFileAsync`) → `.xlsx` = `parseXlsx` (har sheet ko koshish) / `.csv` = `parseCsv(bytesToText)`; header detect `DATE · NARRATION · Scheme · WITHDRAWAL (DR) · DEPOSIT (CR) · BALANCE · vendor · Particulars · Other` (+ txn date/val date, debit/credit, cheque/UTR); Excel serial + DD/MM/YYYY + YYYY-MM-DD date, ₹/,/(neg) amount, Scheme → fund match, duplicate skip; phir har row **edit modal** (`BankLineEditor` — दिनांक/विवरण/राशि/जमा-नाम/संदर्भ/योजना/कार्य/विक्रेता/शीर्ष/टिप्पणी) + **"सबको cashbook में Post करें"** bulk post; sheet row tap = edit |
| 16 | Backup folder "backup fail" — SAF `File.create` kaam nahi karta → `directory.createFile` | done | `services/backupFolder.ts` `saveBackup(string\|Uint8Array)` → `Directory.createFile(name, mime)` (purana same-name delete); `listBackups` `.json/.csv/.xlsx/.zip`; `readBackupBytes` |
| 17 | Full JSON backup share as `.json`/`.zip` **file** | done | `BackupScreen.shareBackupFile` (`shareRawFile`/`shareZipBundle`), `encode()` json/csv/xlsx/zip |
| 18 | "Share FY CSV" share kare — har jagah format match | done | ReportsScreen `shareFyCsv()` → `shareRawFile` (module-level), `Share` import hataya |
| 19 | Restore **excel / csv / json** accept kare | done | `services/zipread.ts` (hand-written DEFLATE inflater + ZIP reader), `xlsxread.ts` (OOXML regex parser), `backupCodec.ts` (`backupToCsv/Xlsx/Zip`, `parseCsv`, `csvToXlsx`, `parseBackupText/Bytes`); paste-restore bhi `parseBackupText` se |

**Verification:** `tsc --noEmit` EXIT=0 · `expo export --platform android` EXIT=0 (4.9 MB `.hbc` bundle).


---

## Section G — v10 (30-point correction list)

> **Zip:** `Gram-Panchayat-Cashbook-FULL-v10.zip` (repo root, forward-slash entry paths,
> prefix `cashbook-mobile/`, poora project — configs + `package-lock.json` shamil;
> `node_modules` `.git` `.expo` `android` `ios` `dist` `.idea` `.vs` `out` `.cache` bahar)
>
> **Workflow:** `.github/workflows/build-apk.yml` →
> `name: Build APK (Gram Panchayat Cashbook v10)` + `ZIP=./Gram-Panchayat-Cashbook-FULL-v10.zip`
>
> **Run:** GitHub → Actions → **"Build APK (Gram Panchayat Cashbook v10)"** → **Run workflow**

### G.1 — App banane ke liye zaroori details (kisi bhi tool se banane ke liye)

Ye steps kisi bhi machine par chalao — output same aayega:

1. **Zip extract** karo (forward-slash entries, `cashbook-mobile/` prefix) → `extracted/cashbook-mobile/`
2. **Node 20+** (local par Node 24 bhi chalta hai), phir:
   `cd extracted/cashbook-mobile && npm ci --no-audit --no-fund`
3. **Typecheck (fail-fast):** `npm run typecheck` (= `tsc -p tsconfig.json --noEmit`) → exit 0 chahiye
4. **Native project banao:** `npx expo prebuild --platform android --no-install`
   (`-y` mat likhna — SDK 57 me aisa flag nahi hai)
5. **APK:** `cd android && ./gradlew assembleRelease --no-daemon --stacktrace`
6. **Output:** `android/app/build/outputs/apk/release/*.apk`

Bundle sanity check (optional):
`npx expo export --platform android --output-dir <any-folder>` → exit 0.

**Nayi dependency (v10):** `expo-local-authentication@~57.0.3` — `package.json` +
`package-lock.json` dono updated hain, isliye `npm ci` se hi install ho jaata hai aur
`expo prebuild` + Gradle autolinking use kar leta hai. Koi config-plugin entry zaroori nahi.
Android par koi extra permission declare karni padti nahi (BiometricPrompt).

** zaroori environment/rule (same as v9):**
- App **offline-first** hai — koi server/API nahi. Poora data device par AsyncStorage me.
- हर पंचायत का **अलग database** (`panchayatId` scoping) — naya panchayat = fresh seed.
- Share hamesha **asli file** ho (PDF/Excel/CSV/JSON/ZIP), kabhi text message nahi.
- Devanagari text UTF-8 me hi likho — `Set-Content` se `?` ban jaate hain (node / UTF-8 writer use karo).

### G.2 — 30-point list (status)

| # | Requirement | Status | Implementation |
|---|---|---|---|
| 1 | Naya panchayat banate hi **doosre panchayat ka data bilkul na dikhe** — har panchayat ka alag database | done | `types/models.ts` — 18 record types me `panchayatId?`; `AppStore` me `SCOPED_KEYS` + `scopeData(raw)` (view) + `runScoped(action)` (action scoped chalta hai, baaki panchayat ki rows wapas merge, nayi rows `prev.activePanchayatId` stamp) + `setData` wrapper; `addPanchayat` naye DB ko **fresh `uid()` ids** ke sath seed karta hai (funds/categories `catIdMap` remap, fundingAgencies, bankAccounts fallback `ba1`, bsrRates, itemMasters, workerRates, `openingBalance: 0`) aur transactions/works/mbLines/bills/bankLines/pages/workers/vendors/holidays/mandayCalcs **khaali**; `deletePanchayat` `setDataRaw` se seedha purges (`panchayatId===id` ya `panchayatId==null && cur===id`) |
| 2 | FY tile popup ka **niche wala box dikhta nahi** tha | done | Modal-overflow root fix: `useModalBodyMax(pct, reserve)` → `Math.max(150, Math.round((height-44)*pct) - reserve)`; `modalCard` ka `maxHeight` % ab clip karta hai kyunki andar ka ScrollView pixel-exact hai. Har lambe modal par lagaya: `SelectField`, `SchemeDrillModal`, `EntryScreen`, `BankLineEditor`, `WorkAddForm`, `BsrYearSheet`, `BillsScreen`, `WorksScreen`, `WorkDetailScreen`, `CcScreen`, `CategoriesScreen` |
| 3 | Cashbook me **aaya/kharch ki lines parallel** (line 15 ↔ line 15) | done | Dual grid — dono paksh ek hi row-grid par |
| 4 | आय श्रेणी popup layout | done | Same `useModalBodyMax` + tree/list layout |
| 5 | Scheme chunne ke baad **cash ya bank** poochho | done | `Transaction.medium?: 'cash'`+'`bank`'+`null`; EntryScreen me scheme SelectField ke turant baad "लेन-देन का माध्यम" segmented buttons; `medium` save payload me; `buildLedger` Pick me `medium` + detail tag ` · नकद` / ` · बैंक` |
| 6 | Cashbook me **apna fund pehle**, phir **2 column (cash, bank)** | done | Own-fund row पहली; do amount columns |
| 7 | Cashbook ki **दूसरी bottom लाइन (पूर्व/बचत पोते) lal + bold** | done | Inline `{ color: C.expense, fontWeight: '900' }` |
| 8 | Fund head se **cash hatana** | done | `SchemeDrillModal` rows, `MonthlyScreen` scheme chips, bank-line scheme tags, `FundsScreen` sab me `fund !== 'cash'` filter; `openEdit` me legacy `'cash'` fallback; `EntryScreen` ki `schemeFunds` pehle se filtered |
| 9 | **Category screen tree** jaisa presentation — har branch par add/edit/delete | done | `CategoriesScreen` me recursive `renderNode` (L1→L2→L3), expand/collapse chevron, har node par `+` / `✎` / `🗑`, add-child / rename / archive modals; `archiveCategory` ab **poori subtree** ko archive karta hai (5-pass descendant collection) |
| 10 | Monthly check dropdown popup ka niche box | done | `useModalBodyMax` (item 2 wala fix) |
| 11 | गोशवारा Excel-jaisi **footer lines dono taraf** | done | `goswaraHtml` footer bands left + right |
| 12 | Ledger **Excel-jaisa table har format** me; ZP/PS ka **"प्रथम किस्त" hatana**; ledger **per work** | done | `tblBox/tblHead/tblRow/tblCell/tblTot` sab ledger/CC tables me; `ledgerHtml`/`buildLedger` me koi "प्रथम किस्त" nahi; ledger work choose karke |
| 13 | Ledger home par **dropdowns (scheme / work / month)** | done | `LedgersScreen` ke teen filters |
| 14 | Share ki Excel/PDF file ke naam me **format ka naam + date** | done | `stampedName(title)` = `safeName(title) + ' - YYYY-MM-DD'`, `sharePdf`/`shareExcel`/`shareWorkbook` me |
| 15 | Format Center me **dropdown + share se pehle layout preview** | done | `fmtKey`/`fmtList` + `SelectField`, orientation/filename box, "पूर्व-दृश्य" → `previewDoc` (expo-print), "Share — PDF / Excel" → `askAndShare` |
| 16 | Bank statement par **karya (work) chunne ka popup** | done | `WorkPicker` modal |
| 17 | Sirf ankon wali fields par **numeric keyboard** (dates bhi) | done | Har numeric `Field` par `keyboardType="numeric"` (audit: 0 missing); **dates** ab `dateDigit(setter)` se — sirf अंक type karo, `-` apne-aap (`YYYY-MM-DD`); purane `DD-MM-YYYY` text ko chhunta nahi |
| 18 | Masters ki input fields **bahut patli** thi; **alag man-days calculation page** (bina koi kaam jode) | done | `Field` ko `minHeight:46` + `grow` + `bg: C.input` (BSR Unit/Rate, Item name); **Home tile "मान-दिवस गणना (स्वतंत्र)"** → `go('manday','')` → `MandayScreen` standalone mode (`workId=''`): header alag, MB-component limit 0, **sirf हिसाब save** (koi Muster Roll nahi banta), alert me bhi yahi bataya jata hai |
| 19 | **Holiday ka option hatana**; 26 Jan / 15 Aug / 02 Oct har MR me default chhuttiyan; pakhwada default **12 man-days** | done | `FIXED_HOLIDAYS` + `pakhwadaWorkingDays` (Sunday + teen fixed; Sunday jeet jata hai); `DEFAULT_PAKHWADA_DAYS=12`; `MastersScreen` ka **Holiday tab puri tarah hataya** (uski jagah hamesha-dikhne wala "छुट्टियाँ (निश्चित — कोई विकल्प नहीं)" card); Home tile label `Masters (BSR/Items/मान-दिवस)` |
| 20 | **Work add hone ke baad edit** ka option | done | `WorkAddForm` me `edit`/`onDone` props (sare field prefilled) + `updateWork`; `WorkDetailScreen` par "✎ कार्य सुधारें" modal |
| 21 | MB entry ke liye **सामग्री और श्रम alag-alag pages**; सामग्री page par karigar → material ya labour; **default = karigar in labour amount** | done | `MbScreen` me do bade tabs: **सामग्री (Material) · N** / **श्रम (Labour) · N**; ek hi waqt sirf us page ka form + us page ka group card (doosre ka sirf yog). सामग्री page par naya chooser **"यह किस पक्ष में गिनें?"** → `सामग्री` / `कारीगर → श्रम राशि`; `isKarigarName()` (कारीगर/मिस्त्री/श्रमिक/मजदूर/labour/karigar…) match hote hi **default labour**, `kind:'artisan'` + `karigarIn:'labour'`. श्रम page par purana karigar-toggle **hataya** |
| 22 | Nearest-amount ka **vistaar se hisaab** (e.g. "19 labour × 12 days + 1 labour × 2 days @ ₹260/day → ₹59,800 near ₹60,000") | done | `MandayOpt` me `full`/`rem`; `mandayOptions(desired, rate, days)` ab `floor(desired/rate)` man-days ko `full × days + 1 × rem` me baant-ta hai; `dayChoices = [12,13]` jab `days===12`; `optDetail(o, desired, who)` → `"19 श्रमिक × 12 दिन + 1 श्रमिक × 2 दिन @ ₹260/दिन → ₹59,800 · चाहिए ₹60,000 · अंतर ₹200"`; **`optList(..., desired)`** call sites par `parseFloat(desiredLab/Kar)` pass hota hai |
| 23 | Karigar ke liye **wahi detail** | done | `optKar` wale `optList` par bhi `desiredKar`; per-MR line dono hisso ki dikhati hai |
| 24 | Labour/karigar **13 man-days se zyada nahi**; default 12; 13 sirf tab jab 12 se bada fark bache | done | `MAX_PAKHWADA_DAYS=13`; days field ab `onChangeText={onDays}` (clamp 1..13); `rollDays = max(selLab.days, selKar.days) \|\| D` → MR/period/saving sab usi se; **`saveCalc` me do guards** (`D>13` aur `rollDays>13` par rok); option lists me 13 sirf nearest-amount candidate ke roop me |
| 25 | Bills par **vendor chunne ka popup** | done | Vendor chooser modal (`WorkPicker` jaisa) |
| 26 | Bills → **works ki list + "Other Expenses"**; cashbook ke vouchers apne-automatically apne work ke niche; voucher tap → detail + edit/correct/delete | done | `OTHER_WORK_ID='other-expenses'` sentinel + `WorkPicker.includeOther`; `BillsScreen` ka voucher section → detail modal → "✎ सुधारें" (`setEditTxnId` → EntryScreen) aur "🗑 रद्द करें" (`CancelModal`); `Shell` `setEditTxnId` pass karta hai |
| 27 | CC → **wahi works list**; work ka CC data print/Excel layout me; wahin se edit/correct | done | पृष्ठ 1 / 3 / 4 sab `tblBox` Excel tables; `ccBody()` nikala — `share` aur naya `preview` dono use karte hain; "✎ कार्य सुधारें" → `WorkAddForm edit={w}` |
| 28 | Works screen: **upar list → detail; bottom-right `+` FAB** se add form | done | `WorksScreen` FAB + modal; `Empty` steps update |
| 29 | Layout audit — **koi box doosre ko cover na kare**; font/bg colour same nahi hone chahiye | done | Header title ab `minWidth:0/flexShrink:1` (lamba title action/badge ko cover nahi karta); action/badge ko `flexShrink:0` wrapper; `Field` ka bg `C.card`→`C.input` (modal ke andar invisible box tha); sabhi chip selected par **white text on `C.primary`**; table header `#1d2b23` on `#e8f2ec` (contrast); CC पृष्ठ 3 + Excel/CSV se **"मेट" कॉलम hataya** (header + rows + totals + note), naam कारीगर/श्रमिक; lambe modal sab `useModalBodyMax` par |
| 30 | Web research → sujhav poocho → confusion confirm → **feedback ke baad implement** | done | Research: eGramSwaraj / Meri Panchayat (geo-tag, audit trail, offline), GIGW + Bharat fintech/rural UX (offline-first, vernacular, duplicate prevention, trust/lock). User ne chuna: **(A) App Lock, (B) Auto-backup reminder, (C) Duplicate entry warning** — teeno implement |

### G.3 — v10 me nayi 3 cheezein (user ke feedback ke baad)

**(A) App Lock — PIN + अंगुली/चेहरा + auto-relock**
- `types/models.ts` `AppSettings` me naya: `lastBackupAt?`, `autoLockSec?` (`biometricEnabled` pehle se tha, ab use hota hai).
- `app/index.tsx` module-level helpers `bioAvailable()` (`hasHardwareAsync && isEnrolledAsync`) aur `bioAuth()` (`LocalAuthentication.authenticateAsync`) — dono try/catch, kisi bhi error par `false` (app kabhi nahi atakta).
- **LoginScreen:** agar sensor hai to "अंगुली / चेहरा से खोलें" (chalu) ya "अंगुली से खोलना चालू करें" (bund) button; success → seedha app. PIN field hamesha maujood (fallback).
- **AppSettingsScreen → Security (App lock):** अंगुली ON/OFF toggle + "ऐप background जाने पर कितनी देर बाद lock" chips: `तुरंत / 30 सेकंड / 2 मिनट / 10 मिनट` (default **30 सेकंड** — chhote app-switch par adhura form na ude).
- **Shell** me `AppState` listener: `background`/`inactive` → timer, `active` → timer cancel; timer fire hone par `stackRef = ['login']` + `setStage('login')`.

**(B) Auto-backup reminder**
- `BackupScreen` — `saveBackup()` aur `shareBackupFile()` safal hote hi `updateApp({ lastBackupAt: now })`.
- `HomeScreen` — `lastBackupAt` missing ho ya **≥ 2 din** purana ho to sabse upar hamesha **काम का card**: "⬇ बैकअप लेने का समय हो गया" + aakhri backup ki tareekh + tap → `go('backup')`.

**(C) Duplicate entry warning**
- `EntryScreen.save` — do check: (a) wahi `reference` (purana wala), aur **(b) naya**: wahi `date` + wahi `type` + `|amount − n| < 0.5` + (party khali na ho to wahi party, case-insensitive). Dono me se koi mila to confirm dialog: "संभावित दोहरी entry" + kaaran + wahi entry ki details + "वापस / हाँ, सहेजें".

**Verification:** `tsc -p tsconfig.json --noEmit` EXIT=0 · `expo export --platform android` EXIT=0 (4.9 MB `.hbc` bundle).
**Zip:** `Gram-Panchayat-Cashbook-FULL-v10.zip` — approx **2.11 MB**, **44 entries** (34 files + 10 dir entries), sab forward-slash, sab `cashbook-mobile/` prefix, `node_modules` bahar.
