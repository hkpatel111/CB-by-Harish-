/** PROJECT_MASTER — core domain types (Phase 1) */

export type Id = string;

/** Cashbook page (Excel-register style manual pagination) */
export type CashbookPage = {
  id: Id;
  fyId: Id;
  pageNo: number;
  label: string;
  createdAt: string;
  /**
   * instruction #15(b) — हर महीने की last day वाला पन्ना automatic.
   * 'YYYY-MM' — page month-end date par judta hai, chahe us din koi entry ho ya na ho.
   */
  month?: string;
  /**
   * instruction v9 #3 — **एक पृष्ठ = एक ही दिनांक** (सारे entries उसी दिनांक के)।
   * 'YYYY-MM-DD'. auto month-end page की date = उस महीने की आख़िरी तारीख़।
   */
  date?: string;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
};

/** पाक्षिक मस्टरोल — labour mandays + wage rate (CC page 3) */
export type PakhwadaRoll = {
  id: Id;
  workId: Id;
  fyId: Id;
  fromDate: string;
  toDate: string;
  rollNo: string;
  mateCount: number;
  skilledCount: number;
  unskilledCount: number;
  days: number;
  wageMate: number;
  wageUnskilled: number;
  wageSkilled: number;
  /**
   * v9 #10 — यह MR किस मन-डे स्वीकृति से बना है (MandayScreen → CC page 3 auto-fill)।
   * उस स्वीकृति को delete करने पर ये MR भी हट जाते हैं।
   */
  sourceId?: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
};

export type Fund = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  name: string;
  shortName: string;
  openingBalance: number;
  enabled: boolean;
  openingSource: 'carry-forward' | 'manual';
  sortOrder: number;
};

export type CategoryKind = 'income' | 'expense';

export type CategoryNode = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  kind: CategoryKind;
  name: string;
  parentId: Id | null;
  level: 1 | 2 | 3;
  archived: boolean;
};

export type Panchayat = {
  id: Id;
  name: string;
  block: string;
  district: string;
};

export type FinancialYear = {
  id: Id;
  label: string;
  start: string;
  end: string;
  locked: boolean;
  /**
   * Per-FY fund openings (D17 / K.3): हर FY का apna opening snapshot.
   * Absent = legacy data → fund.openingBalance use hota hai.
   */
  openings?: Record<string, number>;
  /** Is FY me archived (disabled) funds — delete = "this FY only" (K.3) */
  disabledFunds?: string[];
};

/** 'transfer' = नकद→बैंक जमा (Part G: cash−, bank+; NOT income/expense) */
export type TxType = 'income' | 'expense' | 'transfer';

export type Transaction = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  fyId: Id;
  type: TxType;
  date: string;
  pageId: Id | null;
  reference: string;
  /** L.F. — ledger folio number (ledger cross-verification ke liye, old doc §3.1) */
  ledgerFolio: string;
  party: string;
  detail: string;
  note: string;
  /** परिसंपत्ति रजिस्टर पृष्ठ संख्या (Part C.3.2 — expense side column 6) */
  assetPage?: string;
  /** रद्द करने का कारण (D4 — reason required, audit me rehta hai) */
  cancelReason?: string;
  schemeId: Id;
  amounts: Record<string, number>;
  categoryId: Id | null;
  subcategoryId: Id | null;
  subSubcategoryId: Id | null;
  workId: Id | null;
  expenseKind: 'work' | 'other' | null;
  /**
   * v10 #5 — **योजना चुनने के बाद यह पूछा जाता है कि लेन-देन नकद हुआ या बैंक से।**
   * यह बस *माध्यम* है (cash = तिजोरी, bank = चेक/NEFT/ATM) — योजना (schemeId) से अलग।
   * `null`/अनुपस्थित = legacy entry → ऐसे में app पुरानी entry को "नकद" मानता है।
   */
  medium?: 'cash' | 'bank' | null;
  status: 'active' | 'cancelled';
  createdAt: string;
  updatedAt: string;
};

/** instruction #19 — कार्य की वित्त पोषण एजेंसी (dropdown + add/edit/delete) */
export type FundingAgency = {
  id: Id;
  name: string;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
};

export type Work = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  fyId: Id;
  name: string;
  schemeId: Id;
  ward: string;
  sanctionRef: string;
  /** instruction #19 — वित्त पोषण एजेंसी (Panchayat / Samiti / Jila Parishad / MP / MLA / TAD …) */
  fundingAgency?: string;
  /** FS — वित्तीय स्वीकृति राशि (प्रपत्र-1 + CC min() rule) */
  fsAmount?: number;
  materialPrior: number;
  labourPrior: number;
  status: 'ongoing' | 'completed';
  /* ── Part H / user instruction #8: sanction + MB details ── */
  /** A.S. — प्रशासनिक स्वीकृति क्रमांक / दिनांक */
  asNo?: string;
  asDate?: string;
  /** T.S. — तकनीकी स्वीकृति क्रमांक / दिनांक */
  tsNo?: string;
  tsDate?: string;
  /** F.S. — वित्तीय स्वीकृति क्रमांक / दिनांक */
  fsNo?: string;
  fsDate?: string;
  startDate?: string;
  completeDate?: string;
  mbStatus?: 'pending' | 'complete';
  /** MB details — mbStatus 'complete' होने पर पूछे जाते हैं */
  mbNo?: string;
  mbPage?: string;
  mbValuation?: number;
  mbLabourAmount?: number;
  mbMaterialAmount?: number;
};

/** Vendor / party master (PART N) — Bills व dropdown entries ke liye */
export type Vendor = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  name: string;
  phone?: string;
  address?: string;
  /** 'material' = सामग्री विक्रेता, 'labour' = ठेकेदार/श्रम, 'other' */
  kind: 'material' | 'labour' | 'other';
  archived: boolean;
};

/** L.3 audit trail: user, time, entity, action, field, old/new, reason */
export type AuditLog = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  fyId: Id;
  time: string;
  entity: 'transaction' | 'fy' | 'fund' | 'panchayat';
  entityId: Id;
  action: 'create' | 'update' | 'cancel' | 'lock' | 'archive';
  field?: string;
  oldV?: string;
  newV?: string;
  reason?: string;
};

export type MbLine = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  workId: Id;
  itemName: string;
  qty: number;
  rate: number;
  /** material = सामग्री पक्ष; labour = श्रम पक्ष (कारीगर default yahin) */
  kind: 'material' | 'labour' | 'artisan';
  /**
   * Instruction #3: कारीगर toggle — 'labour' (default, श्रम पक्ष में) या
   * 'material' (सामग्री पक्ष में). Line ka group isi se decide hota hai.
   */
  karigarIn?: 'labour' | 'material';
  note?: string;
};

export type Bill = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  workId: Id;
  fyId: Id;
  billDate: string;
  paymentDate: string;
  pageRef: string;
  vendor: string;
  amount: number;
  note: string;
};

export type BankAccount = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  name: string;
  accountNo: string;
  bankName: string;
};

export type BankLine = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  accountId: Id;
  fyId: Id;
  statementMonth: string;
  date: string;
  narration: string;
  amount: number;
  side: 'credit' | 'debit';
  instrument: string;
  schemeId: Id | null;
  workId: Id | null;
  /* instruction #13 — statement tagging: योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी */
  vendorId?: Id | null;
  categoryId?: Id | null;
  note?: string;
  ignored: boolean;
  postedTxnId: Id | null;
};

export type FySettings = {
  lineCount: number;
  /**
   * हर entry के बाद छोड़ी जाने वाली खाली पंक्तियाँ = `blankLineGap − 1` (0–3).
   * instruction #11 — यह अब सिर्फ़ Entry page से बदलता है (FY setting se hataya).
   * legacy values 1/2 pehle jaisi hi rehti hain (0 aur 1 blank line).
   */
  blankLineGap: number;
  allowSchemeNegative: boolean;
  pageBackground: string;
  entryFontColor: string;
  shriPoteColor: string;
  summaryFontColor: string;
  /**
   * instruction #10 — entry par tap → सुधार (edit). बंद हो तो entry
   * सिर्फ़ read-only खुलेगी (koi edit/radd nahi).
   */
  allowBackDateEdit: boolean;
};

export type AppSettings = {
  pin: string | null;
  /** v10 #30-A — अंगुली/चेहरे से unlock (fingerprint / face) */
  biometricEnabled: boolean;
  setupComplete: boolean;
  adminName: string;
  themeId: string;
  /** 8 finance logos me se chosen (old doc §16.1) — Feather icon name */
  logoId: string;
  language: 'hi' | 'en' | 'hinglish';
  showScreenBadge: boolean;
  /** v10 #30-B — आख़िरी बैकअप कब लिया गया (auto-backup reminder) */
  lastBackupAt?: string;
  /**
   * v10 #30-A — ऐप background गई तो कितने सेकंड बाद फिर से lock।
   * 0/undefined = background होते ही lock (default)।
   */
  autoLockSec?: number;
};

/** BSR Master — वार्षिक दर सूची (old master B §5) */
export type BsrRate = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  year: string; // e.g. '2026-27'
  itemName: string;
  unit: string;
  rate: number;
};

/** Item Master — qty flags (old master B §8.3) */
export type ItemMaster = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  name: string;
  wholeNumberOnly: boolean; // cement/brick = poorn sankhya only
  lastBillOnly: boolean; // पानी/टेंकर/मशीनरी… sirf last bill
  basicItem: boolean; // cement/रेत/गिट्टी front-load suggestion
};

/** Holiday Master — साल-वार छुट्टियाँ (old master B §7.1) */
export type HolidayEntry = {
  id: Id;
  year: string;
  date: string;
  name: string;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
};

/** Worker Master — कारीगर/लेबर year-wise rates (old master B §6) */
export type WorkerRate = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  role: 'karigar' | 'labour' | 'mate';
  name: string;
  year: string;
  dailyRate: number;
};

/** Man-days calculation audit (old master B §7.3.5) */
export type MandayCalc = {
  id: Id;
  /** v10 #1 — किस पंचायत का data है (हर पंचायत का अलग database) */
  panchayatId?: Id;
  workId: Id;
  role: 'karigar' | 'labour' | 'mate';
  workers: number;
  days: number;
  rate: number;
  bsrYear: string;
  amount: number;
  mbComponentAmount: number;
  createdAt: string;
  /**
   * instruction #26 — Muster Roll की संरचना (user-friendly wizard):
   * एक MR में `size` लोग, उनमें से `karigar` कारीगर + (size − karigar) श्रमिक;
   * `count` = इस pakhwada में जारी कितने MR; `note` = स्वतः बना विवरण।
   *
   * v9 #10 + #14 — अब दोनों भूमिकाएँ एक साथ और हर MR का विभाजन **custom**:
   *  • `mrs` — हर MR में कितने कारीगर और कितने श्रमिक (बाक़ी श्रमिक)
   *  • `lab` / `kar` — दोनों पक्षों की अपनी-अपनी दर, मान-दिवस व राशि
   *  • `rolls` — बनाए गए Muster Roll की id (CC पृष्ठ 3 में वही विवरण)
   */
  muster?: {
    size: number;
    karigar: number;
    count: number;
    note: string;
    mrs?: { karigar: number; labour: number }[];
    lab?: { workers: number; days: number; rate: number; amount: number };
    kar?: { workers: number; days: number; rate: number; amount: number };
    rolls?: Id[];
  };
};

export type RootData = {
  version: 5;
  app: AppSettings;
  fySettings: FySettings;
  panchayats: Panchayat[];
  activePanchayatId: Id;
  financialYears: FinancialYear[];
  activeFinancialYearId: Id;
  funds: Fund[];
  categories: CategoryNode[];
  transactions: Transaction[];
  works: Work[];
  /** instruction #19 — वित्त पोषण एजेंसी master (dropdown) */
  fundingAgencies: FundingAgency[];
  mbLines: MbLine[];
  bills: Bill[];
  bankAccounts: BankAccount[];
  bankLines: BankLine[];
  pages: CashbookPage[];
  workerRolls: PakhwadaRoll[];
  bsrRates: BsrRate[];
  itemMasters: ItemMaster[];
  vendors: Vendor[];
  holidays: HolidayEntry[];
  workerRates: WorkerRate[];
  mandayCalcs: MandayCalc[];
  auditLogs: AuditLog[];
};
