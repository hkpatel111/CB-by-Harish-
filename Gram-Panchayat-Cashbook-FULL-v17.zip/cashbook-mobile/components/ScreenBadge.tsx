/**
 * ScreenBadge — G-03 हर screen का corner badge (S-xx).
 *
 * v14 / L1-19 (rule **G-32**) — badge अब **दबाने योग्य (Pressable)** है:
 * tap → Feedback window → Submit → backup फ़ोल्डर में `Feedback.txt` में
 * एक पंक्ति **append** (UTF-8, append-only):
 *   `timestamp | badge | screen/stage | FY | panchayat | version | category | text`
 * App Settings (S-60) भी इसी तरह काम करता है — G-03/C-16 का अपवाद नहीं।
 */
import Constants from 'expo-constants';
import React, { useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useStore } from '@/context/AppStore';
import colors from '@/constants/colors';
import { appendFeedback } from '@/services/backupFolder';
/* v17 / C-11 — feedback भेजते व़क़्त उस पन्ने का ज़रूरी data भी साथ जाए (L-11) */
import { getScreenCtx, screenCtxLine } from '@/services/screenContext';

/* theme वही संदर्भ जो app/index.tsx में `C` — applyTheme इसी object को बदलता है */
const C = colors.light;

const CATS: { key: string; label: string }[] = [
  { key: 'bug', label: 'बग (bug)' },
  { key: 'suggestion', label: 'सुझाव' },
  { key: 'question', label: 'सवाल' },
  { key: 'other', label: 'अन्य' },
];

export function ScreenBadge({ label, screen }: { label: string; screen?: string }) {
  const {
    app,
    activeFy,
    activePanchayat,
    /* v17 / C-11 — feedback के साथ पन्ने का data भेजने के लिए सामान्य snapshot */
    fyTransactions,
    works,
    activeFunds,
    fundOpening,
    totalOpening,
    totalIncome,
    totalExpense,
    currentBalance,
    mbLines,
    bills,
    workerRolls,
    mandayCalcs,
    bsrRates,
    fyPages,
  } = useStore();
  const [open, setOpen] = useState(false);
  const [cat, setCat] = useState('bug');
  const [txt, setTxt] = useState('');
  const [msg, setMsg] = useState('');
  /* v17 / C-11 — feedback L-11: इस पन्ने का ज़रूरी data भी जुड़े (डिफ़ॉल्ट ON) */
  const [attach, setAttach] = useState(true);

  /* hooks पहले, check बाद में (rules-of-hooks) */
  if (!app?.showScreenBadge) return null;

  const act = fyTransactions.filter((t) => t.status === 'active');
  const bank = activeFunds.filter((f) => f.id !== 'cash').reduce((s, f) => s + fundOpening(f), 0);
  const cash = activeFunds.filter((f) => f.id === 'cash').reduce((s, f) => s + fundOpening(f), 0);
  /* store का सामान्य snapshot — कोई screen अपना ctx न दे तब भी कुछ तो जाए */
  const snap: { k: string; v: string }[] = [
    ...getScreenCtx(),
    { k: 'वर्ष', v: activeFy?.label || '-' },
    { k: 'पंचायत', v: activePanchayat?.name || '-' },
    { k: 'पन्ने', v: String(fyPages.length) },
    { k: 'entries', v: `${act.length} +${fyTransactions.length - act.length} रद्द` },
    { k: 'आय', v: String(Math.round(totalIncome)) },
    { k: 'व्यय', v: String(Math.round(totalExpense)) },
    { k: 'शेष', v: String(Math.round(currentBalance)) },
    { k: 'खोलने', v: `कुल ${Math.round(totalOpening)} = बैंक ${Math.round(bank)} + नकद ${Math.round(cash)}` },
    { k: 'कार्य', v: String(works.length) },
    { k: 'MR', v: String(workerRolls.length) },
    { k: 'MB', v: String(mbLines.length) },
    { k: 'बिल', v: String(bills.length) },
    { k: 'मन-डे', v: String(mandayCalcs.length) },
    { k: 'BSR', v: String(bsrRates.length) },
  ];
  const snapLine = snap.map((r) => `${r.k}=${r.v}`).join(' · ');

  const line = () =>
    [
      new Date().toISOString(),
      label,
      screen || label,
      activeFy?.label || '-',
      activePanchayat?.name || '-',
      String(Constants.expoConfig?.version ?? '1.0.0'),
      cat,
      txt.replace(/\s+/g, ' ').trim() || '(empty)',
      /* v17 / C-11 — feedback L-11: पन्ने का data उसी line के साथ */
      attach && snapLine ? `DATA: ${snapLine}` : '',
    ]
      .filter(Boolean)
      .join(' | ');

  const submit = async () => {
    try {
      const uri = await appendFeedback(line());
      setMsg(`✓ Feedback.txt में सहेज दिया — ${uri.split('/').pop() || 'Feedback.txt'}`);
      setTxt('');
    } catch (e) {
      setMsg(`✗ नहीं लिखा जा सका — ${e instanceof Error ? e.message : String(e)}`);
    }
  };

  return (
    <>
      <Pressable
        onPress={() => {
          setMsg('');
          setOpen(true);
        }}
        accessibilityLabel={`Feedback — ${label}`}
        style={styles.badge}
      >
        <Text style={styles.text}>{label}</Text>
      </Pressable>

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.backdrop} onPress={() => setOpen(false)}>
          <Pressable style={styles.card} onPress={() => undefined}>
            <Text style={styles.title}>Feedback — {label}</Text>
            <Text style={styles.meta}>{screen || label} · FY {activeFy?.label || '-'} · {activePanchayat?.name || '-'}</Text>

            <Text style={styles.lbl}>श्रेणी (category)</Text>
            <View style={styles.chips}>
              {CATS.map((c) => (
                <Pressable
                  key={c.key}
                  onPress={() => setCat(c.key)}
                  style={[
                    styles.chip,
                    {
                      backgroundColor: cat === c.key ? C.primary : C.primarySoft,
                      borderColor: cat === c.key ? C.primary : C.border,
                    },
                  ]}
                >
                  <Text style={{ color: cat === c.key ? '#fff' : C.foreground, fontSize: 12, fontWeight: '800' }}>
                    {c.label}
                  </Text>
                </Pressable>
              ))}
            </View>

            <Text style={styles.lbl}>आपकी बात (text)</Text>
            <TextInput
              value={txt}
              onChangeText={setTxt}
              multiline
              placeholder="क्या गलत लगा / क्या जोड़ना चाहेंगे?"
              placeholderTextColor={C.mutedForeground}
              style={styles.input}
            />

            {msg ? <Text style={[styles.meta, { marginTop: 6 }]}>{msg}</Text> : null}

            {/* v17 / C-11 — feedback L-11: इस पन्ने का ज़रूरी data साथ भेजें */}
            <Pressable onPress={() => setAttach((a) => !a)} style={styles.attach}>
              <View style={[styles.tick, attach ? { backgroundColor: C.primary, borderColor: C.primary } : null]}>
                {attach ? <Text style={{ color: '#fff', fontSize: 11, fontWeight: '900' }}>✓</Text> : null}
              </View>
              <Text style={{ flex: 1, fontSize: 12, fontWeight: '800', color: C.foreground }}>
                इस पन्ने का सारा ज़रूरी data भी Feedback.txt में जोड़ें
              </Text>
            </Pressable>
            {attach && snapLine ? (
              <Text numberOfLines={6} style={styles.snap}>
                {snapLine}
              </Text>
            ) : null}

            <View style={styles.row}>
              <Pressable
                onPress={async () => {
                  await submit();
                }}
                style={[styles.btn, { backgroundColor: C.primary }]}
              >
                <Text style={{ color: '#fff', fontWeight: '900', fontSize: 13 }}>Submit</Text>
              </Pressable>
              <Pressable onPress={() => setOpen(false)} style={[styles.btn, { backgroundColor: C.primarySoft }]}>
                <Text style={{ color: C.primary, fontWeight: '900', fontSize: 13 }}>बंद करें</Text>
              </Pressable>
            </View>
            <Text style={styles.meta}>
              फ़ाइल: बैकअप फ़ोल्डर / Feedback.txt — append-only, नंबर {label} के साथ।
            </Text>
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
}

/* Alert.alert सीमा (≤3 buttons) की चिंता नहीं — यहाँ अपना ही Modal है। */
const styles = StyleSheet.create({
  badge: { backgroundColor: 'rgba(0,0,0,0.2)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  text: { color: '#fff', fontSize: 10, fontWeight: '800' },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', alignItems: 'center', justifyContent: 'center', padding: 16 },
  card: { width: '100%', maxWidth: 460, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 16, padding: 14 },
  title: { fontSize: 16, fontWeight: '900', color: C.foreground },
  meta: { fontSize: 11, color: C.mutedForeground, marginTop: 3 },
  lbl: { fontSize: 12, fontWeight: '800', color: C.foreground, marginTop: 10, marginBottom: 4 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10, borderWidth: 1 },
  input: {
    minHeight: 78,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 10,
    padding: 10,
    fontSize: 13,
    color: C.foreground,
    backgroundColor: C.background,
    textAlignVertical: 'top',
  },
  row: { flexDirection: 'row', gap: 8, marginTop: 12 },
  btn: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 10 },
  /* v17 / C-11 — data attach विकल्प */
  attach: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 10 },
  tick: {
    width: 20,
    height: 20,
    borderRadius: 6,
    borderWidth: 1.5,
    borderColor: C.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  snap: {
    fontSize: 10,
    color: C.mutedForeground,
    backgroundColor: C.background,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 8,
    padding: 8,
    marginTop: 6,
    lineHeight: 15,
  },
});
