/**
 * screenContext.ts — v17 / C-11 (feedback L-11)
 *
 * Feedback window से जुड़ा एक छोटा registry: हर screen अपने **ज़रूरी data** को यहाँ
 * लिख देती है, और ScreenBadge उसे Feedback.txt की line के साथ जोड़कर भेज देता है —
 * ताकि PC पर बैठकर bug सुधारते व़क़्त उसी पन्ने का असली आँकड़ा सामने हो।
 *
 * यह सिर्फ़ **session भर** के लिए रहता है (koi data persist nahi hota)। कोई screen
 * न लिखे तो ScreenBadge सिर्फ़ store का सामान्य snapshot भेजता है।
 *
 *   `setScreenCtx([{ k: 'पृष्ठ', v: '3 · 2024-04' }, { k: 'आय', v: '₹12,000' }])`
 */
export type CtxRow = { k: string; v: string };

let rows: CtxRow[] = [];

/** अपनी screen का snapshot (रेंडर के व़क़्त कॉल करें — कोई state नहीं, सिर्फ़ module var) */
export function setScreenCtx(r: CtxRow[]): void {
  rows = r;
}

/** ScreenBadge पढ़ता है */
export function getScreenCtx(): CtxRow[] {
  return rows;
}

/** Feedback.txt में जाने वाली लंबी line: `k=v · k=v · …` (खाली हो तो '') */
export function screenCtxLine(): string {
  return rows.filter((r) => r && r.k).map((r) => `${r.k}=${r.v}`).join(' · ');
}
