/**
 * fixLog.ts — v17 / **Feedback tracking file (फ़ीडबैक सुधार-सूची)**
 *
 * Ye file app ke andar hi bundled hai (services/fixLog.ts). Iska maksad:
 *   • Naya app install karte hi pata chal jaye ki Feedback.txt ke kaun-se
 *     बिंदु pehle hi theek ho chuke hain (status = done) — unhe Feedback.txt
 *     se hata diya ja sake.
 *   • Kaun-se अभी नहीं हुए (status = deferred) — wo Feedback.txt me rehne chahiye.
 *
 * App me isko dekhne ka tarika:
 *   App Settings (S-60) → "Feedback status (ठीक किए गए बिंदु)" →
 *   Poori list screen par, ya "शेयर करें" se Feedback-Fixed-Points-vN.txt file.
 *
 * Har naye build round me:
 *   1. nayi group / naye point is list me jodo (ver = us build ka naam), aur
 *   2. FIX_LOG_VERSION + FIX_LOG_DATE badal do.
 */

export type FixStatus = 'done' | 'deferred';

export type FixPoint = {
  /** Feedback.txt wala code (CC-30, S-06, K-11 …) */
  id: string;
  /** Kis screen/section par lagu hua (badge / naam) */
  where: string;
  /** Kya theek hua — ek line me */
  title: string;
  /** Kis build me hua (v14 / v15 / v16 …) */
  ver: string;
  status: FixStatus;
};

export type FixGroup = { key: string; label: string; points: FixPoint[] };

/** Is list wale build ka naam — har round me badlo */
export const FIX_LOG_VERSION = 'v17';
export const FIX_LOG_DATE = '2026-10-10';

export const FIX_LOG: FixGroup[] = [
  {
    key: 'v17-round',
    label: 'v17 — Feedback.txt के 27 बिंदु (CC · MB · मन-डे · Bill Register · BSR · गोशवारा · Cashbook)',
    points: [
      { id: 'V17-01', where: 'CC export पृष्ठ 4', title: 'PDF/Excel से "बिल विवरण" व "तुलनात्मक विवरण" तालिकाएँ हटाईं; सामग्री तालिका अब न्यूनतम 12 पंक्तियाँ (10–12 मद हाथ से लिखने की ख़ाली जगह)', ver: 'v17', status: 'done' },
      { id: 'V17-02', where: 'Entry सुधारें (S-09)', title: 'vendor में MR चुनते ही वाउचर राशि उस MR की कुल राशि से auto भर जाती है (MR का पूरा भुगतान होता है)', ver: 'v17', status: 'done' },
      { id: 'V17-03', where: 'Cashbook + (S-07)', title: 'नई एन्ट्री की तिथि सीधे उसी महीने व वर्ष पर खुलती है (वर्ष default, महीना/वर्ष बदलने के chips)', ver: 'v17', status: 'done' },
      { id: 'V17-04', where: 'Home (S-06)', title: 'graph की legend chips — रंग-बिंदु के साथ योजना का नाम (कौन-सी लाइन किस योजना की)', ver: 'v17', status: 'done' },
      { id: 'V17-05', where: 'Home (S-06)', title: 'Opening balance — नकद फ़ंड अलग "नकद", बाक़ी सारी योजनाएँ "बैंक" में (अलग-अलग कार्ड)', ver: 'v17', status: 'done' },
      { id: 'V17-06', where: 'गोशवारा (S-55)', title: 'opening/closing बैंक व नकद विभाजन — ऊपर की तालिका और नीचे footer दोनों में', ver: 'v17', status: 'done' },
      { id: 'V17-07', where: 'Works (S-18)', title: 'कार्य अपने-आप उसकी FS तिथि के वित्त-वर्ष में दिखता है', ver: 'v17', status: 'done' },
      { id: 'V17-08', where: 'मन-डे स्वीकृति (S-22)', title: 'सूची की "सुधार" अब वही गणना-इंजन भरा हुआ खोलती है + सुधार मोड पट्टा; save करने पर पुरानी स्वीकृति उसी की जगह बदलती है (दोहराव नहीं)', ver: 'v17', status: 'done' },
      { id: 'V17-09', where: 'Cashbook (S-07)', title: 'कहीं और जाकर back लौटने पर वही पन्ना खुला मिलेगा', ver: 'v17', status: 'done' },
      { id: 'V17-10', where: 'हर स्क्रीन — Feedback window', title: 'टॉगल: इस पन्ने का सारा ज़रूरी data संलग्न करें → Feedback.txt में DATA: लाइन जुड़ जाती है', ver: 'v17', status: 'done' },
      { id: 'V17-11', where: 'CC पृष्ठ 4 (S-26)', title: '"सामग्री मद जोड़ें" में उसी वर्ष की BSR सूची का dropdown — मद चुनते ही नाम व दर अपने-आप भर जाते हैं', ver: 'v17', status: 'done' },
      { id: 'V17-12', where: 'Bill Register (S-59)', title: 'कैशबुक व्यय-वाउचर का पूरा item-wise संपादन — नाम/मात्रा/दर जोड़ें-हटाएँ, योग व वाउचर राशि का अंतर लाइव, MB से तुरंत मद जोड़ें', ver: 'v17', status: 'done' },
      { id: 'V17-13', where: 'Masters (S-36)', title: 'BSR दरों का स्वतः बैकअप — `Cashbook-BSR-Rates.json` backup-फ़ोल्डर + mirror में लिखा जाता है; नया app install होते ही अपने-आप वापस आ जाती हैं', ver: 'v17', status: 'done' },
      { id: 'V17-14', where: 'Cashbook export (S-07)', title: 'PDF/Excel में आय व व्यय दोनों पक्ष एक ही पृष्ठ पर (दोहरा पन्ना ख़त्म)', ver: 'v17', status: 'done' },
      { id: 'V17-15', where: 'Cashbook export (S-07)', title: 'आय/व्यय योग, श्री/बचत पोते व महायोग के सामने जहाँ मान 0 है वहाँ भी 0 छपे', ver: 'v17', status: 'done' },
      { id: 'V17-16', where: 'Cashbook export (S-07)', title: 'आय पक्ष की पहली लाइन में "श्री पोते राशि" हर पृष्ठ पर', ver: 'v17', status: 'done' },
      { id: 'V17-17', where: 'Cashbook प्रिंट (S-07)', title: '"प्रिंट लेआउट देखें" — system print dialog में A4/Legal/Letter व portrait/landscape; एक पृष्ठ = एक कैशबुक पन्ना', ver: 'v17', status: 'done' },
      { id: 'V17-18', where: 'Cashbook ⚙ (S-07)', title: 'PDF/Excel के font colour व background अलग-अलग सेट करने के विकल्प', ver: 'v17', status: 'done' },
      { id: 'V17-19', where: 'Entry सुधारें (S-48)', title: '"किसको भुगतान" का vendor dropdown व बाक़ी सब विकल्प बिल्कुल नई एन्ट्री जैसे (pre-filled)', ver: 'v17', status: 'done' },
      { id: 'V17-20', where: 'Entry सुधारें (S-48)', title: 'कार्य एन्ट्री का नाम दिखता है व बदलकर सामान्य/किसी और कार्य में डाला जा सकता है', ver: 'v17', status: 'done' },
      { id: 'V17-21', where: 'गोशवारा (S-55)', title: 'तीनों formats (दो-पक्षीय विवरण / नाम-मद वार / निचोड़) अलग-अलग share बटन', ver: 'v17', status: 'done' },
      { id: 'V17-22', where: 'Ledger export (S-28)', title: '"चल शेष" कॉलम हटाया (चल शेष सिर्फ़ बैंक स्टेटमेंट में)', ver: 'v17', status: 'done' },
      { id: 'V17-23', where: 'मन-डे स्वीकृति (S-22)', title: 'कार्य नाम के ठीक नीचे MB सीमाएँ — श्रमिक, कारीगर, सामग्री, मूल्यांकन + अब तक स्वीकृत राशि व शेष', ver: 'v17', status: 'done' },
      { id: 'V17-24', where: 'MB — माप पुस्तिका (S-21)', title: 'दो अलग पृष्ठ — A · श्रम (S-21a) व B · सामग्री (S-21b), अलग-अलग badge; दोनों पर कार्य नाम के नीचे MB सीमाएँ', ver: 'v17', status: 'done' },
      { id: 'V17-25', where: 'CC (S-26) · मन-डे (S-22)', title: 'real-time योग — सामग्री जोड़ते/सुधारते ही qty × दर, नया कुल योग व MB शेष; मन-डे में भी "अभी का कुल हिसाब"', ver: 'v17', status: 'done' },
      { id: 'V17-26', where: 'CC (S-26)', title: 'सातों पन्ने अलग-अलग chips + हर पन्ने का अपना badge (S-26.1 … S-26.7 / S-26.All); Share में मौजूदा पन्ना · पन्ना श्रेणी · सभी पन्ने', ver: 'v17', status: 'done' },
      { id: 'V17-27', where: 'CC पृष्ठ 4 (S-26)', title: 'सामग्री पृष्ठ के ऊपर सारे आँकड़े (CC श्रम, FS, कुल व सामग्री मूल्यांकन, अभी का सामग्री योग, अंतर); नया योग MB सामग्री सीमा से बाहर गया तो रोक लगती है', ver: 'v17', status: 'done' },
    ],
  },
  {
    key: 'v16-cc',
    label: 'v16 — मन-डे / CC श्रम राशि (S-21 · S-22 · S-26)',
    points: [
      {
        id: 'V16-01',
        where: 'मन-डे स्वीकृति · CC पृष्ठ 3',
        title:
          'CC की श्रम राशि अब हमेशा स्वीकृति बराबर — मस्टरोल में कारीगर व श्रमिक के दिन अलग-अलग भरे जाते हैं (पहले सब पर max(दिन) चढ़ जाता था, जैसे ₹99,750 की जगह ₹1,03,440)',
        ver: 'v16',
        status: 'done',
      },
      {
        id: 'V16-02',
        where: 'हर स्क्रीन',
        title:
          'फ़ोन का back बटन / gesture हमेशा काम करे — app का back handler सबसे पहले चलता है (किसी भी पन्ने या print preview से)',
        ver: 'v16',
        status: 'done',
      },
      {
        id: 'V16-03',
        where: 'प्रिंट / शेयर',
        title:
          'system print-preview या share-sheet खुले रहने तक app auto-lock नहीं होता (पहले वापस आने पर Login पर फेंक देता था)',
        ver: 'v16',
        status: 'done',
      },
      {
        id: 'V16-04',
        where: 'Login / auto-lock',
        title: 'auto-lock के बाद PIN डालते ही वही पन्ना खुलेगा जहाँ आप थे (फिर से पंचायत-सेटअप नहीं)',
        ver: 'v16',
        status: 'done',
      },
      {
        id: 'V16-05',
        where: 'App Settings (S-60)',
        title: 'यही Feedback tracking फ़ाइल — ऐप के अंदर देखें व शेयर करें कि कौन-से बिंदु ठीक हो चुके हैं',
        ver: 'v16',
        status: 'done',
      },
      {
        id: 'V16-06',
        where: 'MR Register (S-58)',
        title: 'MR संपादन में अब "कारीगर दिन" व "श्रमिक दिन" अलग-अलग भरे जा सकते हैं',
        ver: 'v16',
        status: 'done',
      },
    ],
  },
  {
    key: 'v15-cc',
    label: 'v15 — CC / पूर्णता प्रमाण पत्र (S-26)',
    points: [
      { id: 'CC-30', where: 'CC (S-26)', title: 'व्यय लेखे अनुसार = पृष्ठ 3 श्रम योग + पृष्ठ 4 सामग्री योग (cashbook की भुगतान-राशि नहीं)', ver: 'v15', status: 'done' },
      { id: 'CC-31', where: 'CC पृष्ठ 1 (S-26)', title: 'व्यय की row में पहले दोनों उप-विवरण (अ. श्रम, ब. सामग्री) फिर उनका योग', ver: 'v15', status: 'done' },
      { id: 'CC-32', where: 'CC पृष्ठ 1 (S-26)', title: 'मूल्यांकन = MB श्रम + MB सामग्री', ver: 'v15', status: 'done' },
      { id: 'CC-33', where: 'CC (S-26)', title: 'कुल अनुमत = min(FS, MB मूल्यांकन, व्यय लेखे) + realtime लाइन', ver: 'v15', status: 'done' },
      { id: 'CC-34', where: 'CC (S-26)', title: 'CC > मूल्यांकन = सिर्फ़ ऊपर लाल चेतावनी, कोई रोक नहीं — preview/share हमेशा चलते हैं', ver: 'v15', status: 'done' },
      { id: 'CC-35', where: 'CC (S-26)', title: 'पृष्ठ dropdown 1..7 + "All pages"', ver: 'v15', status: 'done' },
      { id: 'CC-36', where: 'CC पृष्ठ 3 (S-26)', title: 'MR sanction राशि जैसी भरी गई वैसी ही — दोबारा गणना नहीं', ver: 'v15', status: 'done' },
      { id: 'CC-37', where: 'CC पृष्ठ 3 (S-26)', title: 'पृष्ठ 3 से "alternate fill" विकल्प हटाया — अब सिर्फ़ संपादन (edit-only)', ver: 'v15', status: 'done' },
      { id: 'CC-38', where: 'CC पृष्ठ 4 (S-26)', title: 'सामग्री सीधे यहीं सुधारें — मात्रा ≤ MB (ज़्यादा पर लाल चेतावनी), MB में न हो तो भी जोड़ें, BSR + निविदा दर, योग → पृष्ठ 1', ver: 'v15', status: 'done' },
      { id: 'CC-39', where: 'CC (S-26)', title: 'क्रॉस-लिंक: पृष्ठ 1 की राशि / पृष्ठ 3 पर tap = उसे भरने वाला पन्ना, back से CC पर वापसी', ver: 'v15', status: 'done' },
      { id: 'CC-40', where: 'CC export (S-26)', title: 'Excel/PDF में कोई भी app-संबंधी note / version tag नहीं', ver: 'v15', status: 'done' },
      { id: 'CC-41', where: 'CC (S-26)', title: '"बिल सुधारें" बटन CC से हटाया', ver: 'v15', status: 'done' },
      { id: 'CC-42', where: 'CC पृष्ठ 1/3/4 (S-26)', title: 'स्क्रीन की table = ठीक वैसी जैसी print/Excel की table (स्तंभ, क्रम, योग-पंक्तियाँ समान)', ver: 'v15', status: 'done' },
      { id: 'CC-43', where: 'CC Excel (S-26)', title: 'स्तंभ अपलोड की गई Excel के ठीक वैसे — पृष्ठ 3 = 10 स्तंभ (merged header), पृष्ठ 4 = 9 स्तंभ', ver: 'v15', status: 'done' },
    ],
  },
  {
    key: 'v15-mb',
    label: 'v15 — MB (S-21) व मन-डे स्वीकृति (S-22)',
    points: [
      { id: 'MB-13', where: 'MB (S-21)', title: 'MB generate होने के बाद fix — पन्ने पर नया "अंतर (diff)" card (पंक्तियाँ, श्रम, सामग्री तीनों)', ver: 'v15', status: 'done' },
      { id: 'MB-14', where: 'MB (S-21)', title: 'MB पन्ने पर सिर्फ़ MB सामग्री — "कौन-सा पृष्ठ" विकल्प व "+ MB line" वाले कार्ड हटाए', ver: 'v15', status: 'done' },
      { id: 'MB-15', where: 'MB (S-21)', title: 'कारीगर ⇄ सामग्री toggle MB से हटाया (अब सिर्फ़ CC पृष्ठ 4 पर)', ver: 'v15', status: 'done' },
      { id: 'MD-18', where: 'मन-डे स्वीकृति (S-22)', title: '"कारीगर — कहाँ गिनें?" कार्ड हटाया — वहाँ सिर्फ़ भूमिका (श्रमिक/कारीगर)', ver: 'v15', status: 'done' },
    ],
  },
  {
    key: 'v15-screens',
    label: 'v15 — बाक़ी स्क्रीन',
    points: [
      { id: 'S-06', where: 'होम', title: 'एक common graph (इस साल का running balance + सभी योजनाएँ) · टाइल grid 2-2 · MR/Bill/MB टाइल Settings में · back पर scroll वहीं', ver: 'v15', status: 'done' },
      { id: 'S-09', where: 'Entry', title: 'पुरानी तारीख़ भरते ही उस पन्ने का श्री पोते का आरंभिक शेष दिखता है', ver: 'v15', status: 'done' },
      { id: 'S-13', where: 'बैंक', title: 'बैंक विवरण में running-balance (शेष) स्तंभ', ver: 'v15', status: 'done' },
      { id: 'S-58', where: 'MR Register', title: 'सिर्फ़ काम से जुड़े MR दिखें · tap = देखें / सुधारें / "काम के साथ जोड़ें" (multi-link)', ver: 'v15', status: 'done' },
      { id: 'S-59', where: 'Bill Register', title: 'cashbook के सभी व्यय-भुगतान · बिल सुधारें (items सहित) / काम ↔ सामान्य में ले जाएँ', ver: 'v15', status: 'done' },
      { id: 'S-28', where: 'खातावही', title: 'LF स्तंभ हटा — एक ही CB पृष्ठ स्तंभ + एक ही दो-पक्षी table', ver: 'v15', status: 'done' },
      { id: 'S-55', where: 'गोशवारा', title: '"नाम मदवार" दो-पक्षी table + हर format पर ऊपर-दाएँ share बटन', ver: 'v15', status: 'done' },
      { id: 'S-07', where: 'रोकड़ बही', title: 'स्थायी नीचे nav बार + ⚙ settings (ऊपर/नीचे, वर्तमान वर्ष) · श्री पोते से पहले "अपना कोष (NAGAD | BANK | YOJANA | KUL)" · pinch zoom सुगम', ver: 'v15', status: 'done' },
      { id: 'S-50', where: 'शेयर', title: 'पन्नों का क्रम — सबसे पुरानी तारीख़ = क्रम 1', ver: 'v15', status: 'done' },
      { id: 'S-02', where: 'पंचायत', title: 'पृष्ठ badge के बगल में (i) बटन → उस पन्ने के सभी नियम · नया logo', ver: 'v15', status: 'done' },
      { id: 'S-60', where: 'App Settings', title: 'App Settings का टाइल होम पर नहीं, Settings में', ver: 'v15', status: 'done' },
    ],
  },
  {
    key: 'deferred',
    label: 'अभी नहीं हुआ (Feedback.txt में रखें)',
    points: [
      { id: 'K-11', where: 'बैंक', title: 'बैंक PDF से Excel — कोई PDF-पाठ लाइब्रेरी नहीं है, इसलिए यह बिंदु स्थगित है', ver: 'v14', status: 'deferred' },
    ],
  },
];

/** कुल बिंदु (status के अनुसार) */
export function fixLogCount(status: FixStatus = 'done'): number {
  return FIX_LOG.reduce((s, g) => s + g.points.filter((p) => p.status === status).length, 0);
}

/**
 * पूरी सूची के लिए सादा text — इसी से `Feedback-Fixed-Points-vN.txt` बनती है
 * (App Settings → Feedback status → शेयर करें)।
 */
export function fixLogText(): string {
  const L: string[] = [];
  L.push('ग्राम पंचायत कैशबुक (Gram Panchayat Cashbook) — ठीक किए गए बिंदु / Fix log');
  L.push(`build ${FIX_LOG_VERSION} · ${FIX_LOG_DATE} · कुल done = ${fixLogCount('done')} · deferred = ${fixLogCount('deferred')}`);
  L.push('='.repeat(78));
  L.push('नियम: नया app लगाते ही Feedback.txt से "✓ done" वाले बिंदु हटा दें।');
  L.push('       "… deferred" वाले बिंदु Feedback.txt में रहने चाहिए।');
  L.push('');
  for (const g of FIX_LOG) {
    L.push(`-- ${g.label}`);
    L.push('-'.repeat(78));
    for (const p of g.points) {
      L.push(`${p.status === 'done' ? '[✓ done]' : '[… pending]'} ${p.id}  (${p.where})`);
      L.push(`      ${p.title}  [${p.ver}]`);
    }
    L.push('');
  }
  return L.join('\n');
}
