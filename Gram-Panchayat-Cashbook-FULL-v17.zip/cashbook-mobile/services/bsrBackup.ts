/**
 * bsrBackup.ts — v17 / C-14 (feedback L-14)
 *
 * **BSR दरों का अपना-आप बैकअप** — ताकि app अनइंस्टॉल करके दोबारा install करने पर भी
 * दरें वापस आ जाएँ (App Data मिट जाता है, इसलिए बैकअप **बाहरी फ़ोल्डर** में जाता है)।
 *
 * दो जगह लिखा जाता है:
 *   1. `Cashbook-BSR-Rates.json` — backup फ़ोल्डर (SAF) में → **uninstall के बाद भी बचा**।
 *   2. AsyncStorage mirror → फ़ोल्डर न मिले तब भी तेज़ी से वापसी हो सके।
 *
 * दोनों जगह से पढ़ा जाता है; folder वाली फ़ाइल को प्राथमिकता (वही uninstall-सुरक्षित है)।
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getBackupDirUri, listBackups, readBackup, saveBackup } from '@/services/backupFolder';
import type { BsrRate } from '@/types/models';

export const BSR_BACKUP_FILE = 'Cashbook-BSR-Rates.json';
const MIRROR_KEY = 'gpc-cashbook-bsr-mirror';

export type BsrBackupDoc = {
  v: 1;
  savedAt: string;
  rates: BsrRate[];
};

/** bsrRates बदलते ही (throttled) फ़ोल्डर + mirror दोनों में लिखो */
let writing = false;
export async function writeBsrBackup(rates: BsrRate[]): Promise<boolean> {
  if (writing || !rates.length) return false;
  writing = true;
  try {
    const doc: BsrBackupDoc = { v: 1, savedAt: new Date().toISOString(), rates };
    const json = JSON.stringify(doc, null, 2);
    try {
      await AsyncStorage.setItem(MIRROR_KEY, json);
    } catch {
      /* mirror न बने तो folder वाला रास्ता फिर भी चलेगा */
    }
    const uri = await getBackupDirUri();
    if (!uri) return false;
    await saveBackup(BSR_BACKUP_FILE, json);
    return true;
  } catch {
    return false;
  } finally {
    writing = false;
  }
}

/** पहले फ़ोल्डर वाली फ़ाइल, फिर mirror — जो मिले उसकी दरें */
export async function readBsrBackup(): Promise<BsrRate[]> {
  try {
    const entries = await listBackups();
    const hit = entries.find((e) => e.name === BSR_BACKUP_FILE);
    if (hit) {
      const rates = parseDoc(await readBackup(hit.uri));
      if (rates.length) return rates;
    }
  } catch {
    /* फ़ोल्डर नहीं मिला → mirror आज़माते हैं */
  }
  try {
    const mirror = await AsyncStorage.getItem(MIRROR_KEY);
    const rates = parseDoc(mirror);
    if (rates.length) return rates;
  } catch {
    /* कुछ नहीं */
  }
  return [];
}

/** backup file में कितनी दरें हैं + कब लिखी गई थीं (UI में दिखाने के लिए) */
export async function bsrBackupInfo(): Promise<{ ok: boolean; count: number; savedAt: string | null }> {
  try {
    const entries = await listBackups();
    const hit = entries.find((e) => e.name === BSR_BACKUP_FILE);
    if (hit) {
      const doc = parseDocWithTime(await readBackup(hit.uri));
      if (doc) return { ok: true, count: doc.rates.length, savedAt: doc.savedAt };
    }
  } catch {
    /* fall through */
  }
  try {
    const mirror = await AsyncStorage.getItem(MIRROR_KEY);
    const doc = parseDocWithTime(mirror);
    if (doc) return { ok: true, count: doc.rates.length, savedAt: doc.savedAt };
  } catch {
    /* ख़ाली */
  }
  return { ok: false, count: 0, savedAt: null };
}

function parseDocWithTime(text: string | null): BsrBackupDoc | null {
  if (!text) return null;
  try {
    const p = JSON.parse(text);
    if (p && Array.isArray(p.rates) && p.rates.length) {
      return { v: 1, savedAt: String(p.savedAt || ''), rates: p.rates as BsrRate[] };
    }
    /* पुराना/अलग आकार: सिर्फ़ array हो तब भी चलाओ */
    if (Array.isArray(p) && p.length) return { v: 1, savedAt: '', rates: p as BsrRate[] };
  } catch {
    return null;
  }
  return null;
}

function parseDoc(text: string | null): BsrRate[] {
  return parseDocWithTime(text)?.rates || [];
}
