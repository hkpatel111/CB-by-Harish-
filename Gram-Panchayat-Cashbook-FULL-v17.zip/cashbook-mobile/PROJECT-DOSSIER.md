# PROJECT DOSSIER — Gram Panchayat Cashbook

> **Ye ek hi file padho, purani files mat kholo.**
> Isme project ki poori detail hai: data model, store API, screens, export pipeline,
> build/verify/zip procedure, purane rounds ke faisle, aur naya round karne ka checklist.
> Agar kisi cheez ka naam/line dhundhna ho to bhi **sirf yahi file** + grep se kaam ho jayega.
>
> **lastUpdated = v17 · 2026-10-10**
> **NOTE:** line-numbers neeche *v17 ke banate waqt* ke hain. Kuch bhi edit karo to
> line badal jaati hai — isliye hamesha **naam se grep karo**, line sirf hint hai.

---

## 0. Ye project kya hai (2 लाइन में)

Gram Panchayat (ग्राम पंचायत) का cashbook ऐप — Android APK (Expo/React Native).
पंचायत का रोकड़ बही (cashbook), कार्य (works), माप पुस्तिका (MB), मन-डे स्वीकृति,
मस्टरोल, बिल, CC (पूर्णता प्रमाण पत्र), गोशवारा, खाता बही, बैंक विवरण — सब ऐप में।
सारा data offline (AsyncStorage + user-chosen SAF backup folder), कोई server नहीं।
User Hinglish बोलता है — replies भी Hinglish में।

---

## 1. पहचान और delivery pipeline

| चीज़ | value |
|---|---|
| Working dir | `F:\Android app\cashbook\extracted\cashbook-mobile` |
| Parent folder | `F:\Android app\` |
| Repo root (deliverables) | `F:\Android app\cashbook` |
| GitHub repo | `CB-by-Harish-` |
| Android package | `com.grampanchayat.cashbook` |
| app.json | `version` / `versionCode` — हर round में बढ़ाओ (v17 = 1.0.5 / 6) |
| Icon | `assets/images/cashbook-icon.png` + `cashbook-icon-foreground.png` (1024×1024 PNG) — fixed, कभी मत बदलो |
| Source zip | `F:\Android app\cashbook\Gram-Panchayat-Cashbook-FULL-vN.zip` |
| Workflow | `F:\Android app\cashbook\.github\workflows\build-apk.yml` — name/comment में `Build APK (Gram Panchayat Cashbook vN)` |
| User build करता है | Actions → *workflow name* → **Run workflow** |
| ZIP glob | `Gram-Panchayat-Cashbook-FULL-*.zip` + `sort -V | tail -1` (workflow में hardcode नहीं — सिर्फ़ नई zip डालो) |

**Docs (root ↔ extracted byte-identical रखने हैं):**
- `PROJECT_MASTER_NEW.md` — लंबा master spec (SECTION A…N)
- `CASHBOOK-RULES-INDEX.txt` — rule index (PART 1…30)
- **`PROJECT-DOSSIER.md`** — यही फ़ाइल (compact reference)
हर नए round में तीनों में section जोड़ो (Section N+1 / Part 30+1) और byte-identity assert करो।

---

## 2. File map (source only — node_modules कभी zip में नहीं)

| file | lines | क्या है |
|---|---|---|
| `app/index.tsx` | ~13,400 | **सारा UI एक ही फ़ाइल में** — 30 स्क्रीन + `Shell` (nav) + `makeStyles` |
| `app/_layout.tsx` | 29 | `GestureHandlerRootView` + `Slot` |
| `context/AppStore.tsx` | ~1,720 | सारा state, actions, migrations |
| `types/models.ts` | ~553 | सारे data types |
| `services/pageEngine.ts` | ~200 | शुद्ध गणना: `formatINR`, `schemeBalance`, `pageOpenings`, `dayMahayog`, roll helpers |
| `services/formats.ts` | ~599 | document data-builders: `ccBuild`, `buildLedger`, `buildGoswara`, `buildPrapt1/4` |
| `services/exportHtml.ts` | ~1,044 | HTML builders: CC 7 pages, गोशवारा, खाता बही, प्रपत्र-1/2/4, बैंक विवरण |
| `services/exportDoc.ts` | ~269 | `DOC_CSS`, `docHtml`, `sharePdf`, `shareExcel`, `askAndShare`, `previewDoc`, `shareRawFile`, `shareZipBundle` |
| `services/xlsx.ts` | ~383 | raw xlsx writer (`sheetFromHtml` = HTML→grid; **no styles/widths**) |
| `services/mandays.ts` | ~143 | `DEFAULT_PAKHWADA_DAYS`, `MAX_PAKHWADA_DAYS`, `FIXED_HOLIDAYS`, `pakhwadaWorkingDays` |
| `services/fixLog.ts` | ~167 | **Feedback tracking file** — हर ठीक किया बिंदु यहाँ |
| `services/backupFolder.ts` | ~184 | SAF folder + `appendFeedback()` |
| `services/backupCodec.ts`, `zipread.ts`, `xlsxread.ts` | — | backup/zip/xlsx पढ़ना |
| `components/ScreenBadge.tsx` | ~158 | badge → **Feedback window** (suggestion लिखकर Feedback.txt में append) |
| `constants/colors.ts` | ~222 | themes + `applyTheme`; default palette `colors.light` |
| `components/ErrorBoundary.tsx`, `ErrorFallback.tsx`, `KeyboardAwareScrollViewCompat.tsx` | — | plumbing |

**कोई PDF library नहीं है** (K-11 = forever deferred: bank PDF → Excel कभी मत करो)।
**`react-native-svg`** available (graph), **`jimp-compact`** available, **`expo-print`** = PDF.
**Reanimated worklets में plain JS closure मत बुलाओ।**

---

## 3. Data model (`types/models.ts`)

`RootData` (models ~519) में सब कुछ:

```
version: 5
app: AppSettings          fySettings: FySettings
panchayats[]  activePanchayatId
financialYears[]  activeFinancialYearId
funds[]  categories[]  transactions[]  works[]  fundingAgencies[]
mbLines[]  bills[]  bankAccounts[]  bankLines[]  pages[]
workerRolls[]  bsrRates[]  itemMasters[]  vendors[]  holidays[]
workerRates[]  mandayCalcs[]  auditLogs[]  auditOverrides?
```

### प्रमुख entities

**`Transaction`** (~115): `id, fyId, type:'income'|'expense'|'transfer', date, pageId, reference,
ledgerFolio, party, detail, note, assetPage?, cancelReason?, schemeId, **amounts: Record<fundId, number>**,
categoryId, subcategoryId, subSubcategoryId, workId, rollId?, expenseKind:'work'|'other'|null,
**medium?: 'cash'|'bank'|null**, status:'active'|'cancelled', createdAt, updatedAt`

**`Work`** (~166): `id, fyId, name, schemeId, ward, sanctionRef, fundingAgency?, fsAmount?,
materialPrior, labourPrior, status:'ongoing'|'completed', asNo?/asDate?, tsNo?/tsDate?,
fsNo?/fsDate?, startDate?, completeDate?, mbStatus?, mbNo?, mbPage?, assetCreatedDate?,
lfRegisterNo?, **mbValuation?**, mbLabourAmount?, mbMaterialAmount?, contingencyAmount?,
tenderRatePct?, **ccMaterial?: CcMaterialItem[]`**

**`CcMaterialItem`** (~231): `{ id, mbLineId?, itemName, qty, rate, unit? }` — CC पृष्ठ 4 की सामग्री

**`MbLine`** (~270): `{ id, workId, itemName, qty, rate, kind:'material'|'labour'|'artisan',
karigarIn?:'labour'|'material', note? }` — **fyId नहीं**, workId से scoped

**`Bill`** (~288): `{ id, workId, fyId, billDate, paymentDate, pageRef, vendor, amount, note,
crossCheck?, billType?:'starting'|'during'|'final', items?: {itemName, qty, rate, kind?}[] }`

**`PakhwadaRoll` (MR)** (~27): `{ id, workId, fyId, fromDate, toDate, rollNo, mateCount,
skilledCount, unskilledCount, days, **skilledDays?**, **unskilledDays?**,
wageMate, wageUnskilled, wageSkilled, sourceId? (→MandayCalc), linkedWorkIds?, panchayatId? }`
> **v16 rule:** कारीगर व श्रमिक के दिन **अलग-अलग** (`skilledDays`/`unskilledDays`)। undefined → `days`।
> हर जगह `rollWage()/rollMandays()/rollSkilledMd()/rollUnskilledMd()` (pageEngine) से गिनो।

**`MandayCalc`** (~484): `{ id, workId, role, workers, days, rate, bsrYear, amount,
mbComponentAmount, createdAt, muster?: { size, karigar, count, note, mrs?, lab?{workers,days,rate,amount}, kar?{...}, rolls? } }`

**`Fund`** (~65): `{ id, name, shortName, openingBalance, enabled, openingSource:'carry-forward'|'manual', sortOrder }`
> **कोई `kind` field नहीं है।** Cash vs bank = **literal id `'cash'`**। बाक़ी सब funds बैंक हेड हैं।
> `activeFunds.filter(f => f.id !== 'cash')` = बैंक heads।

**`FinancialYear`** (~97): `{ id, label, start, end, locked, openings?: Record<fundId, number>, disabledFunds?: string[] }`

**`CashbookPage`** (~6): `{ id, fyId, pageNo, label, createdAt, month?: 'YYYY-MM', date?: 'YYYY-MM-DD' }`

**`BsrRate`** (~441): `{ id, year, itemName, unit, rate }` · **`ItemMaster`** (~452): `{ id, name, wholeNumberOnly, lastBillOnly, basicItem }`
**`FySettings`** (~357): `{ lineCount, blankLineGap, allowSchemeNegative, pageBackground, entryFontColor, shriPoteColor, summaryFontColor, allowBackDateEdit }`

**`AppSettings`** (~377): `pin, biometricEnabled, setupComplete, themeId, language, showScreenBadge,
lastBackupAt?, autoBackup?, backupHour?, autoLockSec?, reminder*, userName?, lang?,
cbBarTop?: string[], cbBarBottom?: string[]`

---

## 4. Store API (`context/AppStore.tsx`)

`useStore()` = RootData fields + `hydrated` + actions. प्रमुख:

| action / selector | क्या |
|---|---|
| `hydrated` | hydration पूरी हुई या नहीं |
| `activePanchayat`, `activeFy`, `activeFunds` | current scope; `activeFunds` = enabled ∖ disabledFunds, sortOrder पर |
| `fyTransactions` | **strict** `t.fyId === activeFy.id` |
| `fundOpening(f)` | `activeFy.openings[f.id] ?? f.openingBalance` |
| `totalOpening`, `totalIncome`, `totalExpense`, `currentBalance` | FY totals (सब funds मिलाकर) |
| `fyPages` | FY pages, date→pageNo sort, **renumbered 1..n** |
| `ensurePageForDate(date)`, `pageOptionsForDate(date)`, `addPage`, `insertPageAfter`, `deletePage`, `assignTxnToPage` | page ops |
| `addTransaction(t)` / `updateTransaction(id, patch)` / `cancelTransaction(id, reason)` / `purgeTransactions(ids)` | txn CRUD (addTransaction `fyId` ख़ुद stamp करता है) |
| `undoCashbookPage(pageId)` / `redoCashbookPage(pageId)` / `undoCount` / `redoCount` | per-page undo |
| `addWork(w)` (id लौटाता है, `fyId` caller देता है) / `updateWork(id, patch)` / `deleteWorkCascade(id)` | works |
| `addMbLine` / `updateMbLine` / `deleteMbLine` · `addBill` / `updateBill` / `deleteBill` | MB + bills |
| `addVendor` / `updateVendor` / `deleteVendor` · `addBankLine` / `updateBankLine` / `postBankLineToCashbook` | vendors + bank |
| `addWorkerRoll` / `updateWorkerRoll` · `addMandayCalc` / `updateMandayCalc` / `deleteMandayCalc` | MR + sanction |
| `addBsrRate` / `updateBsrRate` / `deleteBsrRate` · `addItemMaster`… · `addHoliday` · `addWorkerRate` | masters |
| `addFinancialYear` / `closeFinancialYearCarryForward` | FY (closing → carry-forward) |
| `addFund` / `updateFundOpening(id, opening, source)` / `deleteFundFy(id)` | funds |
| `addCategory` / `archiveCategory` / `renameCategory` | categories |
| `addTransferCashToBank(date, amount, bankFundId, note?)` | transfer txn |
| `exportBackupJson()` / `importBackupJson(json)` / `exportCsvForFy()` | backup |

**Migrations (AppStore top):** `mergeRaw` → `seedBsrItems` → `withOpeningsSnapshot` → `withPageDates`
→ `fixRollDays` → `migratePages` → `stripSchemeCats` → `withPanchayatScope`।
Hydration (~615) और `importBackupJson` (~1059) **दोनों** इसी chain से गुज़रते हैं।
> नई field जोड़नी हो तो migration यहीं लिखो — backup-restore पर भी चलेगी।

**Storage key:** `gpc-cashbook-v5` (AsyncStorage) · backup folder key: `gpc-cashbook-backup-dir` (SAF)

---

## 5. Navigation — Stage ↔ screen ↔ badge

`Stage` union (index.tsx ~115):
`login, panchayat, appSettings, fy, fySettings, home, cashbook, entry, funds, categories,
monthly, goswara, reports, ledgers, backup, bank, works, workDetail, mb, manday, bills, cc,
formats, masters, closing, settings, search, mrRegister, billRegister`

`Shell()` (~12993) में `stackRef` (nav history) + `back()` + big `switch(stage)` (~13139)।
नया screen जोड़ना = ① `Stage` में string ② switch में case ③ screen component।

| stage | component | badge | पर्पस |
|---|---|---|---|
| `login` | `LoginScreen` | S-01 | PIN/biometric |
| `panchayat` | `PanchayatScreen` | S-02 | पंचायत चुनें |
| `appSettings` | `AppSettingsScreen` | S-60 | theme/lang/lock/reminder + **Feedback status (fixLog)** |
| `fy` | `FYScreen` | S-05 | FY चुनें |
| `fySettings` | `FYSettingsScreen` | S-49 | page style / lines / colours |
| `home` | `HomeScreen` | S-06 | tiles + BalanceGraph + drill modals |
| `cashbook` | `CashbookScreen` | S-07 (share modal S-50) | **रोकड़ बही** — main screen |
| `entry` | `EntryScreen` | S-08 income / S-09 expense | नई/सुधार entry (poora form) |
| `funds` | `FundsScreen` | S-35 | कोष heads |
| `categories` | `CategoriesScreen` | S-46 | श्रेणियाँ |
| `monthly` | `MonthlyScreen` | S-47 (+ inline edit modal S-48) | monthly check + entry edit modal |
| `goswara` | `GoswaraScreen` | S-55 | गोशवारा |
| `reports` | `ReportsScreen` | S-34 | exports hub |
| `ledgers` | `LedgersScreen` | S-28 | खाता बही |
| `bank` | `BankScreen` | S-13 | बैंक विवरण |
| `works` | `WorksScreen` | S-18 | कार्य सूची |
| `workDetail` | `WorkDetailScreen` | S-19 (empty S-51) | कार्य विवरण |
| `mb` | `MbScreen` | S-21 | माप पुस्तिका |
| `manday` | `MandayScreen` | S-22 | मन-डे स्वीकृति wizard |
| `bills` | `BillsScreen` | S-25 | बिल |
| `cc` | `CcScreen` | S-26 | CC 7 pages |
| `formats` | `FormatsScreen` | S-56 | प्रपत्र centre |
| `masters` | `MastersScreen` | S-36 | BSR + item master |
| `closing` | `ClosingScreen` | S-45 | FY समापन |
| `settings` | `SettingsScreen` | S-57 | व्यवस्था hub |
| `search` | `GlobalSearchScreen` | S-43 | खोजें |
| `mrRegister` | `MrRegisterScreen` | S-58 | MR register |
| `billRegister` | `BillRegisterScreen` | S-59 | Bill register |

Fallback screens: `WorkPicker` badge **S-52** (MB), **S-53** (बिल), **S-54** (CC) — जब कोई work न चुना हो।

**Reusable UI components (index.tsx ऊपर):** `Btn` (~155, variants `primary|outline|soft|danger`),
`IconBtn` (~195, Feather names), `Header` (~385, props `title/eyebrow/onBack/badge/action/screen`),
`Field` (~911), `DateField` (~681, 3-step y→m→d calendar), `YearField` (~666), `SelectField` (~1075),
`ModalBody` (~1033, props `title/hint/onClose/closeLabel/backdropClose/children`),
`Empty` (~1149), `PinModal` (~1164), `CancelModal` (~1208), `Stat` (~1852), `ColorSwatchField` (~973),
`SchemeDrillModal` (~1677), `BalanceGraph` (~2113), `WorkAddForm` (~6924), `BsrYearSheet` (~9125),
`BankLineEditor` (~6813), `CatLevelList` (~4838)।

**Theme/colors:** `const C = colors.light` (module level, ~106) — `C.primary, C.background, C.foreground,
C.border, C.mutedForeground, C.expense, C.income, C.chip…`। Styles `makeStyles()` (~13278) से बनते हैं,
theme बदलने पर `applyThemeAndStyles()` rebuild करता है। इस्तेमाल होने वाले keys:
`page, dark, pad, row, section, hint, meta, card, cardOn, cardTitle, stat*, tblBox, tblHead,
tblHeadCell, tblRow, tblCell, tblTot, chips, chip, chipOn, empty*, modalBg, modalCard, modalTitle,
fieldWrap, fieldLabel, field, err, btn, btnText, sumLine, gosHead, homeRow, homeIcon`।
> ⚠️ `styles` परिवर्तनशील है (theme पर rebuild) — inline style object बनाकर `styles` के ऊपर मत भरो।

---

## 6. Export / print pipeline

```
कोई screen  →  builder (HTML string)  →  askAndShare(title, body, landscape?, excelBody?)
                                            ├─ "PDF (A4)"  → chooseOrientationThenShare → sharePdf → Print.printToFileAsync → share sheet
                                            └─ "Excel (.xlsx)" → sheetFromHtml(excelBody ?? body) → buildXlsx → share sheet
`previewDoc(title, body, landscape?)` = सीधा Print.printAsync (print preview खोलता है)
`shareRawFile(fileName, content, mime)` = कच्ची file share (txt/csv)
`shareZipBundle(title, files[])` = .zip
```

**PDF page control:** `docHtml()` (exportDoc ~66) `@page { size: A4 portrait|landscape; margin }` लगाता है।
`.pg { page-break-before: always; }` (DOC_CSS ~30) — HTML में `<div class="pg">` लगाओगे तो नया PDF page।

**Cashbook के exports अलग हैं — `exportHtml.ts` में नहीं, `CashbookScreen` में:**
- `sideTableHtml(pageIdx, side, ops, pageTx)` — एक side का `<table>` (HTML/PDF)
- `pageBlockHtml(pageIdx)` — page का block (head + income table + expense table + stamp)
- `pageXlsHtml(pageIdx)` — Excel के लिए **एक ही combined dual-grid table**
- `shareBody()` / `shareXlsBody()` — चुने हुए pages का जोड़
- Footer lines: आय/व्यय योग, पूर्व/बचत पोते, महायोग।

**xlsx.ts:** `SheetDef = { name, rows: SheetCell[][] }` — सिर्फ़ grid। **styles/colour/width सपोर्ट नहीं।**
`htmlToRows()` colspan/rowspan समझता है। number-like strings numeric बन जाती हैं।

**CC:** `formats.ccBuild(input)` → `CcData` (~510-556 return fields)। `exportHtml.ccPagesHtml(a)` → 7 pages HTML।
CC data keys: `expenseLabour, expenseMaterial, expenseLekhya, mbValuationLabour, mbValuationMaterial,
mbValuation, mulyaankan, allowable, material, materialBsr, tenderPct, tenderRateOf, fsAmount,
asAmount, paid, actualExpense, lekhyaCap, lekhyaOver, mbOver, sanctionedMaterial, materialOver,
contingency, contingencyCap, contingencyOver, residualMaterial, mandays{mate,skilled,unskilled,wage}`
CC pages: 1 = CC (16 col table), 2 = UC, 3 = श्रम (10 col, rolls), 4 = सामग्री (9 col),
5 = तकनीकी निरीक्षण, 6 = फोटो, 7 = फोटो (2 col)। `CC_PAGE_LABELS` (index ~2544)।

---

## 7. अटल नियम (invariants — कभी मत तोड़ो)

1. **कोई network call नहीं**, कोई PDF library नहीं, कोई server नहीं।
2. **Devanagari सिर्फ़ utf8 `fs.*FileSync(...,'utf8')` से** (docs में)। source files ठीक हैं।
3. **root ↔ extracted docs byte-identical** — हर round में assert करो।
4. **Zip में `node_modules` कभी नहीं**, forward slashes, prefix `cashbook-mobile/`, dir entries `…/`।
5. **CC = v15 वाला मापदंड:** व्यय लेखे = पृष्ठ 3 श्रम + पृष्ठ 4 सामग्री; मूल्यांकन = MB श्रम + MB सामग्री;
   कुल अनुमत = min(FS, मूल्यांकन, व्यय); कोई hard block नहीं, सिर्फ़ `ccWarn`।
6. **MR की राशि = स्वीकृति बराबर** — `rollWage()` से, भूमिका-वार दिन (`skilledDays`/`unskilledDays`)।
7. **एक नक़द कोष = id `'cash'`**; बाक़ी सब बैंक। Opening/closing cash-bank split इसी पर।
8. **`Alert.alert` में max 3 buttons।**
9. **Har `<Modal>` पर `onRequestClose`** (Android back)।
10. **`share` sequence:** सबसे पुरानी तारीख़ = क्रम 1।
11. **Screens पर badge (S-xx) + (i) rules modal** — नया screen बनाओ तो `SCREEN_INFO` (~218) में जोड़ो।
12. **App Settings का टाइल home पर नहीं**, Settings में। नीचे permanent nav bar + ⚙ settings।
13. **बिल सुधारें CC से नहीं** — बिल screen से।
14. **Excel export में कोई app-note/version-tag नहीं।**
15. **`fixRollDays` migration** नई field के साथ ही जोड़ी जाती है।
16. **`nativeUiBusy()`** — system print/share खुला हो तो auto-lock नहीं।
17. **Work की `fyId`** — FS date के अनुसार FY में जाती है (v17)।

---

## 8. Coding conventions

- Language: **TypeScript**, React 18, RN 0.7x, Expo Router (single `app/index.tsx`)।
- Comments Hinglish में, code identifiers English। टिप्पणी में version/tag लिखो (जैसे `/* v17 / C-3 ... */`)।
- Hindi strings inline रखते हैं (UI हिंदी में है); `t(lang,'key','हिंदी')` से EN/HI translation।
- `formatINR(n)` = Indian grouping (pageEngine)। `esc(s)` = HTML escape।
- Validation हमेशा `Alert.alert('...')` से, स्पष्ट Hinglish मैसेज के साथ।
- पुरानी field कभी मत हटाओ — optional बनाकर fallback दो (backup compatibility)।
- Har user-visible बदलाव `services/fixLog.ts` में point जोड़कर document करो।

---

## 9. Build / verify / deliver (हर round में यही sequence)

```powershell
# 1) Typecheck
Set-Location "F:\Android app\cashbook\extracted\cashbook-mobile"
& "C:\Program Files\nodejs\node.exe" node_modules\typescript\bin\tsc -p tsconfig.json --noEmit
# EXIT=0 चाहिए

# 2) Bundle check
$out = "$env:TEMP\cbexpNN"; Remove-Item $out -Recurse -Force -EA 0
& "C:\Program Files\nodejs\node.exe" node_modules\expo\bin\cli export --platform android --output-dir $out
# EXIT=0 चाहिए

# 3) Zip  (script: C:\Users\Administrator\AppData\Local\Temp\opencode\mkzipN.ps1)
#    prune = node_modules,.git,.expo,android,ios,dist,.idea,.vs,.out,.cache
#    dir entries = "cashbook-mobile/<rel>/" (zero length), files via CreateEntryFromFile
#    names .Replace('\','/'), prefix cashbook-mobile/
# output: F:\Android app\cashbook\Gram-Panchayat-Cashbook-FULL-vN.zip

# 4) Docs sync — root + extracted में identical append, फिर assert
node -e "const fs=require('fs');if(!fs.readFileSync(a,'utf8').includes(x))fs.appendFileSync(a,t,'utf8')"
# पढ़कर compare: readFileSync(root,'utf8') === readFileSync(extracted,'utf8')

# 5) app.json version/versionCode बढ़ाओ, workflow name/comment → vN
```

**Node path:** `C:\Program Files\nodejs\node.exe`। PowerShell console Devanagari mojibake दिखाता है —
file ठीक होती है, इसलिए जाँच node से `readFileSync(...,'utf8').includes('...')` से करो।

---

## 10. पुराने rounds — फ़ैसले (सिर्फ़ वो जो आगे भी लागू हैं)

| round | क्या मिला |
|---|---|
| v14 (Section K) | system mode, page badges, S-43/S-58/S-59/S-60 screens, MR register, bill register, pincode |
| v15 (Section M) | 43 feedback points — CC 14 (S-26: व्यय लेखे/मूल्यांकन/कुल अनुमत/पृष्ठ dropdown/स्तंभ), MB 4 (diff card, MB-only material, karigar toggle हटाया), मन-डे 1, बाक़ी स्क्रीन 11 (S-06 graph, S-09 श्री पोते, S-13 balance, S-58/S-59 registers, S-28 single ledger table, S-55 two-sided goshwara, S-07 nav bar + अपना कोष, S-50 page order, S-02 (i) rules, S-60 settings) |
| v16 (Section N) | 3 बिंदु — (1) CC श्रम 1,03,440 → 99,750: `skilledDays`/`unskilledDays` + `rollWage()` helpers + `fixRollDays` migration; (2) phone back हमेशा: handler re-subscribe `[back, stage, hydrated]` = LIFO में सबसे नया, `isNativeUiBusy()` से print/share पर lock नहीं, `lockedStackRef` से lock के बाद वही पन्ना; (3) `services/fixLog.ts` feedback tracking + App Settings में "Feedback status" |
| v17 (Section O) | **Feedback.txt के 27/27 बिंदु** — CC (p4 से बिल+तुलना tables, सामग्री तालिका ≥12 पंक्तियाँ, BSR dropdown, real-time योग, 7 अलग pages + S-26.x badges, share = मौजूदा/श्रेणी/सभी, p4 सीमा-कार्ड + MB-रोक), MB (2 पृष्ठ A/S-21a · B/S-21b + सीमाएँ), मन-डे (सुधार = वही इंजन `loadCalc`, MB सीमाएँ, real-time कुल हिसाब), Bill Register (`Transaction.items?` item-wise संपादन), Masters (`services/bsrBackup.ts` स्वतः बैकअप+restore), गोशवारा (3 share + बैंक/नकद विभाजन), Ledger (चल शेष कॉलम हटाया), Entry (MR auto-राशि + date default + S-48 vendor/कार्य), Home (legend + opening विभाजन), Works (FS-FY `fixWorkFy`), Cashbook (एक पन्ना = एक PDF पन्ना, 0 दिखे, श्री पोते, प्रिंट लेआउट, रंग), Feedback (`services/screenContext.ts` `DATA:`) |

**Deferred forever:** K-11 (bank PDF → Excel, कोई PDF text-lib नहीं)।

---

## 11. नया round करने का checklist

1. `C:\Users\Administrator\Documents\Feedback.txt` पढ़ो। हर लाइन = एक बिंदु (pipe format:
   `ISOts | S-xx | screen | FY | panchayat | version | bug|suggestion|question|other | text`)।
2. **इसी dossier से शुरू करो।** जिस screen की बात है, §5 से उसका component ढूँढो, फिर उसका नाम grep करो।
3. हर बिंदु पर: root cause ढूँढो → छोटा fix → tsc → अगला।
4. जो बिंदु पूरा न हो पाए तो `services/fixLog.ts` में `status: 'deferred'` लिखो, झूठ मत लिखो।
5. सारे fixes के बाद `services/fixLog.ts` में नया group जोड़ो (`FIX_LOG_VERSION = 'vN'` + date)।
6. तीनों docs में section जोड़ो (SECTION O+ / PART 31+) — root ↔ extracted byte-identical।
7. `app.json` version/versionCode बढ़ाओ। tsc + export जाँचो। zip बनाओ (`mkzipN.ps1`)।
8. workflow name/comment → vN।
9. User को Hinglish में report: क्या ठीक हुआ, क्या deferred, build कैसे करना है।

---

## 12. जल्दी ढूँढने के लिए grep-anchors

| ढूँढना है | grep |
|---|---|
| Cashbook export HTML | `sideTableHtml` · `pageBlockHtml` · `pageXlsHtml` · `shareBody` · `shareXlsBody` |
| Cashbook UI state | `cashbookUI` (module-scope `{page, zoom, gotoDate, openPage}`) |
| Entry form | `EntryScreen` · `rollsForWork` · `setRollId` · `vendorOptions` · `paidRollIds` |
| Entry edit (S-48) | `MonthlyScreen` · `editId` · `openEdit` · `saveEdit` |
| Date picker | `DateField` · `MONTH_HI` · `askPageForDate` |
| Home tiles / graph | `HomeScreen` · `BalanceGraph` · `GRAPH_SERIES_COLORS` · `SchemeDrillModal` |
| गोशवारा | `GoswaraScreen` · `buildGoswara` · `goswaraHtml` · `prarambhikBank` |
| Works | `WorksScreen` · `WorkAddForm` · `addWork` · `fsDate` |
| मन-डे | `MandayScreen` · `mandayOptions` · `saveCalc` · `loadCalc` · `editCalcId` · `optDetail` |
| MB | `MbScreen` · `mbTab` · `mbLines` · `karigarIn` |
| CC | `CcScreen` · `ccBuild` · `ccPagesHtml` · `ccSlice` · `ccRangeOpen` · `CC_PAGE_LABELS` · `p4Edit` · `ccMaterial` |
| खाता बही | `LedgersScreen` · `buildLedger` · `ledgerHtml` · `ledgerCsv` |
| BSR | `BsrYearSheet` · `addBsrRate` · `BSR_TEMPLATE` · `seedBsrItems` · `services/bsrBackup.ts` · `BSR_BACKUP_FILE` |
| Bill register | `BillRegisterScreen` · `BillsScreen` · `billEdit` · `allocateBillItems` · `vItems` · `updateTransaction` |
| Feedback window | `components/ScreenBadge.tsx` · `services/screenContext.ts` · `setScreenCtx` · `appendFeedback` (services/backupFolder) |
| ठीक किए बिंदु | `services/fixLog.ts` · `FIX_LOG` · `fixLogText` |
| Back/lock | `BackHandler` · `isNativeUiBusy` · `lockedStackRef` · `autoLockSec` |
| Theme | `colors.light` · `applyThemeAndStyles` · `makeStyles` |

---

## 13. v17 round record (Feedback.txt के 27 बिंदु)

**Source:** `C:\Users\Administrator\Documents\Feedback.txt` — 27 लाइनें (08-10-2026 13:51 → 09-10-2026 17:19),
स्क्रीन: S-06 · S-07 · S-09 · S-18 · S-21 · S-22 · S-26 · S-28 · S-36 · S-48 · S-55 · S-59।
**Status:** `tsc --noEmit` → EXIT=0 · `expo export --platform android` → EXIT=0 ·
zip `Gram-Panchayat-Cashbook-FULL-v17.zip` · workflow **Build APK (Gram Panchayat Cashbook v17)** ·
`app.json` 1.0.5 / versionCode **6** · `fixLog.ts` `FIX_LOG_VERSION='v17'` group **`v17-round`** (27 बिंदु)।

| # | Screen | Fix |
|---|---|---|
| 1 | CC p4 export | PDF/Excel से **बिल-विवरण + तुलनात्मक** tables हटाईं; सामग्री तालिका **≥12 पंक्तियाँ** (ख़ाली = हाथ से लिखने को) |
| 2 | S-09 Entry | MR चुनते ही **वाउचर राशि = MR की कुल राशि** (auto) |
| 3 | S-07 Cashbook + | तिथि **सीधे उसी महीने/वर्ष पर**, वर्ष default, महीना/साल chips |
| 4 | S-06 Home | graph **legend chips** (रंग-बिंदु + योजना) |
| 5 | S-06 Home | opening = **नकद फ़ंड अलग, बाक़ी सब बैंक** |
| 6 | S-55 गोशवारा | opening/closing **बैंक/नकद विभाजन** — ऊपर व footer दोनों |
| 7 | S-18 Works | कार्य **FS तिथि के वित्त-वर्ष** में (`fixWorkFy` migration) |
| 8 | S-22 मन-डे | सूची की **सुधार = वही गणना-इंजन** (`loadCalc` + `editCalcId`, पुरानी numeric popup हटाई) |
| 9 | S-07 Cashbook | back से लौटने पर **वही पन्ना** |
| 10 | हर स्क्रीन | Feedback window **`DATA:` toggle** (`screenContext.ts`) |
| 11 | CC p4 | **उसी वर्ष की BSR dropdown** — नाम+दर auto |
| 12 | S-59 Bill Register | वाउचर का **पूरा item-wise संपादन** (`Transaction.items?`, योग vs राशि LIVE) |
| 13 | S-36 Masters | **BSR स्वतः बैकअप** (`bsrBackup.ts` — folder + mirror, uninstall के बाद भी वापस) |
| 14 | S-07 export | आय+व्यय **एक ही पृष्ठ** (`.cb`) |
| 15 | S-07 export | **0 भी छपे** (योग / श्री-बचत पोते / महायोग) |
| 16 | S-07 export | आय पक्ष पहली लाइन **"श्री पोते राशि"** |
| 17 | S-07 print | **"प्रिंट लेआउट देखें"** — A4/Legal/Letter × portrait/landscape, 1 पृष्ठ = 1 कैशबुक पन्ना |
| 18 | S-07 ⚙ | **PDF/Excel रंग** (`pdfFontColor`/`pdfBgColor` + `setDocTheme`) |
| 19 | S-48 Entry | **vendor dropdown** + सब विकल्प नई एन्ट्री जैसे (pre-filled) |
| 20 | S-48 Entry | **कार्य का नाम** दिखे व बदले |
| 21 | S-55 गोशवारा | **तीनों formats अलग share** (`gosEntries`/`gosShare`) |
| 22 | S-28 Ledger | **चल शेष कॉलम हटाया** (`ledgerHtml`) |
| 23 | S-22 मन-डे | नाम के नीचे **MB सीमाएँ** (श्रमिक/कारीगर/सामग्री/मूल्यांकन + शेष) |
| 24 | S-21 MB | **दो पृष्ठ** A · श्रम (**S-21a**) / B · सामग्री (**S-21b**), दोनों पर सीमाएँ |
| 25 | S-26 + S-22 | **real-time योग** (qty × दर, नया कुल, MB शेष; मन-डे "अभी का कुल हिसाब") |
| 26 | S-26 CC | **7 अलग chips + badge** (S-26.1…7 / S-26.All); **share = मौजूदा · श्रेणी · सभी** |
| 27 | CC p4 | **ऊपर सारे आँकड़े + अंतर**; नया योग MB सीमा से बाहर = **रोक** |

### नई/बदली फ़ाइलें (v17)

- `services/screenContext.ts` — `setScreenCtx` / `getScreenCtx` / `screenCtxLine`
- `services/bsrBackup.ts` — `writeBsrBackup` / `readBsrBackup` / `bsrBackupInfo` / `BSR_BACKUP_FILE`
- `types/models.ts` — `Transaction.items?: { itemName, qty, rate }[]`
- `context/AppStore.tsx` — bsr-restore + bsr-write effects (`raw.bsrRates` पर 700 ms debounce)
- `services/exportHtml.ts` — `pg4` से `billRows` + तुलना table हटाए, `MAT_MIN_ROWS = 12`
- `app/index.tsx` — `loadCalc`/`editCalcId` (मन-डे), `mbTab` (MB), `ccRangeOpen`/`ccSlice` (CC),
  `vItems` (Bill Register), `p4BsrYear` (CC p4), `SCREEN_INFO` base-badge fallback
- `services/fixLog.ts` — `FIX_LOG_VERSION='v17'`, group `v17-round` (27 बिंदु)

**Deferred forever:** K-11 (bank PDF → Excel) — जैसा कि हमेशा।
