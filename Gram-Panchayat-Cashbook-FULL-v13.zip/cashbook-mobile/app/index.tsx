/**
 * Gram Panchayat Cashbook — Phase 1 full UI
 * PROJECT_MASTER.md (20-09-2026 FINAL)
 */
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  Alert,
  AppState,
  BackHandler,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { File } from 'expo-file-system';
/* v10 #30-A — अंगुली / चेहरे से app lock (fingerprint / face unlock) */
import * as LocalAuthentication from 'expo-local-authentication';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
/* v12 #28 — S-06 पर "शेयरबाज़ार जैसा" running-balance ग्राफ़ */
import Svg, { Circle, Line as SvgLine, Polyline } from 'react-native-svg';
import colors, { applyTheme, THEMES } from '@/constants/colors';
import { formatINR, useStore, BSR_TEMPLATE } from '@/context/AppStore';
import { ScreenBadge } from '@/components/ScreenBadge';
import {
  categoryPathLabel,
  fmtDate,
  isValidIsoDate,
  isPathIncomplete,
  GENERAL_CAT_ID,
  GENERAL_CAT_LABEL,
  monthLastDay,
  pageOpenings,
  schemeBalance,
  sumAmounts,
  toIsoLocal,
  transactionLineCount,
} from '@/services/pageEngine';
import { findBsr, pakhwadaWorkingDays, rateCheck, referenceRate, suggestCombos, FIXED_HOLIDAYS, DEFAULT_PAKHWADA_DAYS, MAX_PAKHWADA_DAYS } from '@/services/mandays';
import {
  clearBackupDir,
  deleteBackup,
  getBackupDirUri,
  listBackups,
  pickBackupDir,
  readBackupBytes,
  saveBackup,
  type BackupEntry,
} from '@/services/backupFolder';
/* instruction #17/#18/#19 — backup har format me (json / csv / xlsx / zip) + wahi restore */
import { backupToCsv, backupToXlsx, backupToZip, csvToXlsx, mimeForExt, parseBackupBytes, parseBackupText, parseCsv } from '@/services/backupCodec';
/* instruction #15 — असली bank-statement .xlsx अपलोड करके parse करो */
import { parseXlsx, parseXlsxFirstSheet } from '@/services/xlsxread';
import { bytesToText } from '@/services/zipread';
import {
  allocateBillItems,
  buildFolioMap,
  buildGoswara,
  buildLedger,
  buildPrapt1,
  buildPrapt4,
  ccBuild,
  CC_INSTRUCTIONS,
  folioFromMap,
  madKeyOf,
  type FmtHeader,
} from '@/services/formats';
/* instruction #6/#11/#12/#13 — share me PDF ya Excel (askAndShare) + Excel-type HTML formats */
import { askAndShare, previewDoc, shareRawFile, shareWorkbook, shareZipBundle } from '@/services/exportDoc';
import {
  bankStatementHtml,
  ccPagesHtml,
  goswaraHtml,
  ledgerHtml,
  pattaHtml,
  prapt1Html,
  prapt2Html,
  prapt4Html,
} from '@/services/exportHtml';
import type { AppSettings, BankLine, Bill, MandayCalc, MbLine, Transaction, Work } from '@/types/models';

const C = colors.light;

/**
 * instruction #2 — app logo chooser hata diya (LOGO_CHOICES nahi chahiye).
 * Panchayat ka asli `cashbook logo.jpg` hi app ka chinn hai — login header,
 * app icon, splash aur adaptive icon sab yahi use karte hain.
 */
const LOGO_SRC = require('@/assets/images/cashbook-logo.png');

type Stage =
  | 'login'
  | 'panchayat'
  | 'appSettings'
  | 'fy'
  | 'fySettings'
  | 'home'
  | 'cashbook'
  | 'entry'
  | 'funds'
  | 'categories'
  | 'monthly'
  | 'goswara'
  | 'reports'
  | 'ledgers'
  | 'backup'
  | 'bank'
  | 'works'
  | 'workDetail'
  | 'mb'
  | 'manday'
  | 'bills'
  | 'cc'
  | 'formats'
  | 'masters'
  | 'closing'
  /* v13 #14a — S-06 की "व्यवस्था (Settings)" अब एक अपना पन्ना (Stage), Modal नहीं */
  | 'settings';

/**
 * v10 #26 — Bills / व्यय में "अन्य व्यय (Other Expenses)" भी एक प्रविष्टि है,
 * ताकि कार्य-रहित ख़र्च (वेतन, रखरखाव, यात्रा …) भी उसी सूची में दिखें।
 * यह कोई `Work` record नहीं है — बस UI की sentinel id।
 */
const OTHER_WORK_ID = 'other-expenses';

function Btn({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'soft' | 'outline' | 'danger';
  icon?: keyof typeof Feather.glyphMap;
  disabled?: boolean;
}) {
  const bg =
    variant === 'primary' ? C.primary : variant === 'danger' ? C.expenseSoft : variant === 'soft' ? C.primarySoft : 'transparent';
  const fg = variant === 'primary' ? '#fff' : variant === 'danger' ? C.expense : C.primary;
  return (
    <Pressable
      disabled={disabled}
      onPress={() => {
        Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.btn,
        { backgroundColor: bg, borderColor: variant === 'outline' ? C.border : bg, opacity: disabled ? 0.4 : pressed ? 0.85 : 1 },
      ]}
    >
      {icon ? <Feather name={icon} size={16} color={fg} /> : null}
      <Text style={[styles.btnText, { color: fg }]}>{label}</Text>
    </Pressable>
  );
}

/**
 * v12 #29 + #32 — IconBtn पहले हर जगह सफ़ेद icon + सफ़ेद 15% background पर था,
 * इसलिए **सफ़ेद card पर दिखता ही नहीं** था (श्रेणी/बिल/agency rows में ✎ 🗑 ग़ायब)।
 * अब primarySoft background + primary icon — गहरे header पर भी दिखता है,
 * सफ़ेद card पर भी दिखता है, और हर theme में अपने-आप मिलता है।
 */
function IconBtn({ name, onPress }: { name: keyof typeof Feather.glyphMap; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.iconBtn,
        {
          backgroundColor: C.primarySoft,
          borderColor: C.primary,
          borderWidth: 1,
          opacity: pressed ? 0.7 : 1,
        },
      ]}
    >
      <Feather name={name} size={18} color={C.primary} />
    </Pressable>
  );
}

function Header({
  title,
  eyebrow,
  onBack,
  badge,
  action,
}: {
  title: string;
  eyebrow?: string;
  onBack?: () => void;
  badge?: string;
  action?: React.ReactNode;
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? 40 : insets.top) + 6 }]}>
      <View style={styles.headerRow}>
        {onBack ? <IconBtn name="arrow-left" onPress={onBack} /> : <View style={styles.mark}><Feather name="book-open" size={16} color="#fff" /></View>}
        {/* v10 #29 — title ko shrink hona chahiye, warna lamba title action/badge ko cover kar deta tha */}
        <View style={{ flex: 1, minWidth: 0, flexShrink: 1 }}>
          {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
          <Text style={styles.hTitle}>{title}</Text>
        </View>
        {action ? <View style={{ flexShrink: 0 }}>{action}</View> : null}
        {badge ? <View style={{ flexShrink: 0 }}><ScreenBadge label={badge} /></View> : null}
      </View>
    </View>
  );
}

/**
 * v10 #17 — दिनांक फ़ील्ड: सिर्फ़ अंक टाइप करें और हर2 अंक के बाद '-' अपने-आप
 * लग जाए (YYYY-MM-DD)। जो टेक्स्ट पहले से किसी और ढाँचे में है (जैसे DD-MM-YYYY)
 * उसे छूते नहीं — सिर्फ़ YYYY-MM-DD की बढ़ती हुई प्रविष्टि को ही फ़ॉर्मैट करते हैं।
 */
const dateDigit = (set: (v: string) => void) => (t: string) => {
  if (!/^\d{0,4}(-\d{0,2}){0,2}$/.test(t)) {
    set(t);
    return;
  }
  const d = t.replace(/[^0-9]/g, '').slice(0, 8);
  let out = d.slice(0, 4);
  if (d.length > 4) out += '-' + d.slice(4, 6);
  if (d.length > 6) out += '-' + d.slice(6, 8);
  set(out);
};

/* ——— v10 #30-A — App Lock: अंगुली / चेहरा (fingerprint / face) ——— */
async function bioAvailable(): Promise<boolean> {
  try {
    const [hw, enrolled] = await Promise.all([
      LocalAuthentication.hasHardwareAsync(),
      LocalAuthentication.isEnrolledAsync(),
    ]);
    return !!hw && !!enrolled;
  } catch {
    return false;
  }
}

async function bioAuth(): Promise<boolean> {
  try {
    const r = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Gram Panchayat Cashbook खोलें',
      cancelLabel: 'PIN से खोलें',
      disableDeviceFallback: false,
    });
    return !!r.success;
  } catch {
    return false;
  }
}

/* ——— v11 #7 / #14 — कैलेंडर (month popup) से तारीख़ ——— */
const MONTH_HI = [
  'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
  'जुलाई', 'अगस्त', 'सितम्बर', 'अक्टूबर', 'नवम्बर', 'दिसम्बर',
];
const WEEK_HI = ['रवि', 'सो', 'मं', 'बु', 'गु', 'शु', 'श'];

/**
 * v11 #19 / #20 — BSR के वर्ष: सारे वित्तीय वर्ष + जिन वर्षों की दरें पहले से दर्ज हैं।
 * इसी सूची से हर जगह (Masters, Manday, Bills) वर्ष चुना जाता है।
 */
function bsrYearList(fys: { label: string }[], rates: { year: string }[]): string[] {
  const s = new Set<string>();
  for (const f of fys) if (f.label) s.add(f.label);
  for (const r of rates) if (r.year) s.add(r.year);
  return [...s].sort((a, b) => b.localeCompare(a));
}

/**
 * v11 #25 + v12 #21 — दिन-समय के अनुसार अभिवादन (Login + Home दोनों में),
 * आख़िर में **उपयोगकर्ता का नाम** (App Settings → आपका नाम) —
 * जैसे "सुप्रभात, हरिश 🌞" / "शुभ संध्या, हरिश 🌇"
 */
function greetOf(d: Date = new Date(), userName?: string, lang: Lang = 'hinglish'): string {
  const h = d.getHours();
  const who = (userName || '').trim();
  if (lang === 'english') {
    const g = h < 12 ? 'Good morning 🌞' : h < 17 ? 'Hello 🙏' : h < 21 ? 'Good evening 🌇' : 'Good night 🌙';
    return who ? `${g}, ${who}` : g;
  }
  const g = h < 12 ? 'सुप्रभात 🌞' : h < 17 ? 'नमस्कार 🙏' : h < 21 ? 'शुभ संध्या 🌇' : 'शुभ रात्रि 🌙';
  return who ? `${g.split(' ')[0]}, ${who} ${g.split(' ')[1] ?? ''}`.trim() : g;
}

/**
 * v11 #24 — क्या आज reminder दिखाना है?
 *  • हर माह 9 व 18 (या चुनी हुई तारीख़ें)
 *  • और/या कस्टम अंतराल (हर N दिन)
 *  • चालू/बंद स्विच + एक दिन में सिर्फ़ एक बार
 */
function reminderDue(a: AppSettings, today: string = toIsoLocal(new Date())): boolean {
  if (a.reminderEnabled === false) return false;
  if (a.reminderLastSeen === today) return false;
  const day = Number(today.slice(8, 10));
  const days = a.reminderDays && a.reminderDays.length ? a.reminderDays : [9, 18];
  if (days.includes(day)) return true;
  const iv = a.reminderIntervalDays || 0;
  if (iv > 0) {
    const t = Date.parse(`${today}T00:00:00Z`);
    const epoch = Date.UTC(2026, 0, 1);
    if (!Number.isNaN(t) && Math.floor((t - epoch) / 86400000) >= 0 && Math.floor((t - epoch) / 86400000) % iv === 0)
      return true;
  }
  return false;
}

/* ═════════════════════════ v12 #27 — भाषा चुनाव ═════════════════════════
   तीन विकल्प: Hinglish (डिफ़ॉल्ट) · English · हिन्दी।

   दायरा: भाषा सिर्फ़ **ऐप का इंटरफ़ेस** (मेन्यू, tile, बटन, अभिवादन) बदलती है।
   आधिकारिक प्रपत्र — रोकड़ बही, गोशवारा, प्रपत्र-1/2/4, खाता बही, बैंक विवरण,
   CC के सात पृष्ठ — हमेशा हिन्दी में ही रहते हैं ताकि सरकारी अभिलेख ज्यों का त्यों
   छपें। इसीलिए dictionary सिर्फ़ chrome (navigation + actions) की है, जिसमें कोई
   key छूट जाए तो मौजूदा (Hinglish) टेक्स्ट ही दिखता है — टूटा हुआ label कभी नहीं। */
export type Lang = 'hinglish' | 'english' | 'hindi';

export const LANGS: { key: Lang; label: string; sub: string }[] = [
  { key: 'hinglish', label: 'Hinglish (default)', sub: 'रोमन में हिन्दी — जैसा अभी है' },
  { key: 'english', label: 'English', sub: 'English menus, tiles & buttons' },
  { key: 'hindi', label: 'हिन्दी (देवनागरी)', sub: 'पूरा इंटरफ़ेस देवनागरी में' },
];

type Dict = Record<string, string>;

const EN: Dict = {
  'login.title': 'Login',
  'login.setPin': 'Create PIN',
  'login.sub': 'Sign in with your PIN',
  'login.save': 'Save & continue',
  'login.pinBtn': 'Login with PIN',
  'login.bio': 'Open with fingerprint / face',
  'login.bioOn': 'Turn fingerprint unlock on',
  'login.bioHintOn': 'Or type the PIN above',
  'login.bioHintOff': 'Next time it opens with fingerprint only (PIN always stays valid)',
  'tile.cashbook': 'Cashbook',
  'tile.monthly': 'Monthly check',
  'tile.goswara': 'Goswara (income & expenditure)',
  'tile.ledgers': 'Ledgers',
  'tile.bank': 'Bank statement',
  'tile.works': 'Works — list',
  'tile.mb': 'MB (measurement book)',
  'tile.bills': 'Bills',
  'tile.cc': 'CC (completion certificate)',
  'tile.manday': 'Man-day calculation',
  'home.settings': 'Settings',
  'home.settingsSub': 'Masters · Formats · FY closing · Backup · Reports · Categories · Fund heads',
  'set.masters': 'Masters (BSR / items / man-days)',
  'set.formats': 'Formats Centre',
  'set.closing': 'Financial-year closing wizard',
  'set.backup': 'Backup / Export',
  'set.reports': 'Reports hub',
  'set.categories': 'Categories (3 levels)',
  'set.funds': 'Fund heads',
  'set.language': 'App language',
  'greet.start': 'Start',
  'greet.hint':
    'Cashbook, new entry, goswara, ledger, works, formats centre and backup — everything opens from here.',
  'greet.note': 'The greeting changes with the time of day (morning / afternoon / evening / night).',
  back: 'Go back',
  'lang.label': 'App language',
  'lang.hint': 'Only menus, tiles and buttons change. Official forms stay in Hindi.',
};

const HI: Dict = {
  'login.title': 'लॉगिन',
  'login.setPin': 'PIN सेट करें',
  'login.sub': 'PIN से लॉगिन करें',
  'login.save': 'सहेजें और आगे बढ़ें',
  'login.pinBtn': 'PIN से लॉगिन करें',
  'login.bio': 'अंगुली / चेहरा से खोलें',
  'login.bioOn': 'अंगुली से खोलना चालू करें',
  'login.bioHintOn': 'या ऊपर PIN भरकर भी खोल सकते हैं',
  'login.bioHintOff': 'चालू करते ही अगली बार सिर्फ़ अंगुली से खुलेगा (PIN हमेशा वैध रहेगा)',
  'tile.cashbook': 'रोकड़ बही',
  'tile.monthly': 'मासिक जाँच',
  'tile.goswara': 'गोशवारा (आय-व्यय)',
  'tile.ledgers': 'खाता बही',
  'tile.bank': 'बैंक विवरण',
  'tile.works': 'कार्य — सूची',
  'tile.mb': 'माप पुस्तिका (MB)',
  'tile.bills': 'बिल',
  'tile.cc': 'पूर्णता प्रमाण पत्र (CC)',
  'tile.manday': 'मान-दिवस गणना',
  'home.settings': 'व्यवस्था',
  'home.settingsSub': 'स्वामी · प्रपत्र · FY समापन · बैकअप · रिपोर्ट · श्रेणी · कोष शीर्ष',
  'set.masters': 'स्वामी (BSR / मद / मान-दिवस)',
  'set.formats': 'प्रपत्र केंद्र',
  'set.closing': 'वित्तीय वर्ष समापन विज़ार्ड',
  'set.backup': 'बैकअप / निर्यात',
  'set.reports': 'रिपोर्ट केंद्र',
  'set.categories': 'श्रेणियाँ (3 स्तर)',
  'set.funds': 'कोष शीर्ष',
  'set.language': 'ऐप की भाषा',
  'greet.start': 'शुरू करें',
  'greet.hint': 'रोकड़ बही, नई एंट्री, गोशवारा, खाता बही, कार्य, प्रपत्र केंद्र और बैकअप — सब यहीं से खुलता है।',
  'greet.note': 'अभिवादन दिन के समय के अनुसार बदलता रहेगा (सुबह / दोपहर / शाम / रात)।',
  back: 'वापस जाएँ',
  'lang.label': 'ऐप की भाषा',
  'lang.hint': 'सिर्फ़ मेन्यू, tile और बटन बदलते हैं — आधिकारिक प्रपत्र हिन्दी में ही रहते हैं।',
};

/** चालू भाषा (default = hinglish) */
function useLang(): Lang {
  const { app } = useStore();
  return (app?.lang as Lang) || 'hinglish';
}

/**
 * key → अनुवाद। `hinglish` में fallback (मौजूदा टेक्स्ट) ही लौटता है,
 * इसलिए कोई भी key छूट जाए तो पुराना label ही दिखता है।
 */
const t = (lang: Lang, key: string, fallback: string): string =>
  lang === 'english' ? EN[key] ?? fallback : lang === 'hindi' ? HI[key] ?? fallback : fallback;

/** v11 #19/#20 — वर्ष चुनने की chips (dropdown की तरह, पर एक tap में) */
function YearField({ label, value, years, onChange }: { label: string; value: string; years: string[]; onChange: (y: string) => void }) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ flexDirection: 'row', gap: 6 }}>
        {years.map((y) => (
          <Pressable key={y} onPress={() => onChange(y)} style={[styles.chip, value === y && styles.chipOn]}>
            <Text style={{ color: value === y ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>{y}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

function DateField({
  label,
  value,
  onChange,
  onBlur,
  placeholder = 'YYYY-MM-DD',
  grow,
  bg,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  onBlur?: () => void;
  placeholder?: string;
  grow?: boolean;
  bg?: string;
}) {
  const [open, setOpen] = useState(false);
  const valid = isValidIsoDate(value);
  const isoToday = toIsoLocal(new Date());
  const [ym, setYm] = useState<string>(valid ? value.slice(0, 7) : isoToday.slice(0, 7));
  React.useEffect(() => {
    if (open) setYm(valid ? value.slice(0, 7) : isoToday.slice(0, 7));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const [yy, mm] = ym.split('-').map(Number);
  const lead = new Date(Date.UTC(yy, mm - 1, 1)).getUTCDay();
  const dim = new Date(Date.UTC(yy, mm, 0)).getUTCDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < lead; i++) cells.push(null);
  for (let d = 1; d <= dim; d++) cells.push(d);
  while (cells.length % 7) cells.push(null);
  const isoOf = (d: number) => `${ym}-${String(d).padStart(2, '0')}`;
  const shift = (n: number) => {
    const dt = new Date(Date.UTC(yy, mm - 1 + n, 1));
    setYm(`${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}`);
  };
  const pick = (d: number) => {
    onChange(isoOf(d));
    setOpen(false);
    onBlur?.();
  };

  return (
    <View style={[styles.fieldWrap, grow ? { flex: 1 } : null]}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <Pressable
        onPress={() => setOpen(true)}
        style={[
          styles.field,
          { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
          grow ? { flex: 1 } : null,
          bg ? { backgroundColor: bg } : null,
        ]}
      >
        <Text
          style={{ color: valid ? C.foreground : C.mutedForeground, flex: 1, fontWeight: '700' }}
          numberOfLines={1}
        >
          {valid ? fmtDate(value) : placeholder}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          {valid ? (
            <Pressable
              onPress={() => {
                onChange(isoToday);
                onBlur?.();
              }}
              style={{ paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, backgroundColor: C.primarySoft }}
            >
              <Text style={{ fontSize: 11, fontWeight: '800', color: C.primary }}>आज</Text>
            </Pressable>
          ) : null}
          <Feather name="calendar" size={16} color={C.mutedForeground} />
        </View>
      </Pressable>

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        {/* v12 #6 + #12 — calendar का नीचे का हिस्सा कटे नहीं (scroll) + हमेशा Back बटन */}
        <ModalBody title={label} onClose={() => setOpen(false)}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Pressable onPress={() => shift(-1)} style={[styles.chip, { paddingHorizontal: 12 }]}>
                <Text style={{ fontSize: 16, fontWeight: '900', color: C.foreground }}>‹</Text>
              </Pressable>
              <Text style={{ flex: 1, textAlign: 'center', fontWeight: '900', fontSize: 15, color: C.foreground }}>
                {MONTH_HI[mm - 1]} {yy}
              </Text>
              <Pressable onPress={() => shift(1)} style={[styles.chip, { paddingHorizontal: 12 }]}>
                <Text style={{ fontSize: 16, fontWeight: '900', color: C.foreground }}>›</Text>
              </Pressable>
            </View>
            <View style={{ flexDirection: 'row', marginTop: 4 }}>
              {WEEK_HI.map((w) => (
                <Text
                  key={w}
                  style={{ width: '14.28%', textAlign: 'center', fontSize: 11, fontWeight: '800', color: C.mutedForeground }}
                >
                  {w}
                </Text>
              ))}
            </View>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
              {cells.map((d, i) => {
                if (!d) return <View key={`e${i}`} style={{ width: '14.28%', height: 40 }} />;
                const iso = isoOf(d);
                const on = value === iso;
                const isToday = isoToday === iso;
                return (
                  <Pressable
                    key={iso}
                    onPress={() => pick(d)}
                    style={{
                      width: '14.28%',
                      height: 40,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <View
                      style={{
                        width: 34,
                        height: 34,
                        borderRadius: 17,
                        alignItems: 'center',
                        justifyContent: 'center',
                        backgroundColor: on ? C.primary : isToday ? C.primarySoft : 'transparent',
                        borderWidth: isToday && !on ? 1.5 : 0,
                        borderColor: C.primary,
                      }}
                    >
                      <Text
                        style={{
                          fontSize: 13,
                          fontWeight: on ? '900' : '700',
                          color: on ? '#fff' : C.foreground,
                        }}
                      >
                        {d}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
            <View style={{ marginTop: 8 }}>
              {/* v12 #12 — Back अब ModalBody में (हमेशा दिखता है) — यहाँ सिर्फ़ "आज" */}
              <Btn
                label="आज (आज की तिथि)"
                variant="soft"
                onPress={() => {
                  onChange(isoToday);
                  setOpen(false);
                  onBlur?.();
                }}
              />
            </View>
        </ModalBody>
      </Modal>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  keyboardType = 'default',
  secureTextEntry,
  multiline,
  placeholder,
  bg,
  onBlur,
  grow,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  keyboardType?: 'default' | 'numeric';
  secureTextEntry?: boolean;
  multiline?: boolean;
  placeholder?: string;
  /** instruction #30 — modal me card = field ka background hota tha → boxes invisible */
  bg?: string;
  /** v9 #3 — तारीख़ भरते ही (blur) पन्ने का विकल्प पूछना हो */
  onBlur?: () => void;
  /**
   * v9 #12 — row में side-by-side fields (जैसे MB की Qty / Rate) बहुत पतली रह जाती
   * थीं। `grow` = जितनी जगह मिले उतनी ले लो (लंबाई में नहीं — row की चौड़ाई में)।
   */
  grow?: boolean;
}) {
  return (
    <View style={[styles.fieldWrap, grow ? { flex: 1, minWidth: 0 } : null]}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        multiline={multiline}
        placeholder={placeholder}
        placeholderTextColor={C.mutedForeground}
        onBlur={onBlur}
        style={[
          styles.field,
          bg ? { backgroundColor: bg } : null,
          multiline && { minHeight: 70, textAlignVertical: 'top' },
        ]}
      />
    </View>
  );
}

/**
 * instruction #6 — colour setting ab normal selection window hai (swatch grid).
 * Pehle hex code type karna padta tha; ab sirf dot par tap.
 */
const COLOR_SWATCHES: string[] = [
  '#1565C0', '#0D47A1', '#1B5E20', '#2E7D32', '#00695C', '#E65100',
  '#B71C1C', '#4A148C', '#212121', '#37474F', '#6A1B9A', '#AD1457',
  '#F9A825', '#FF6F00', '#1A237E', '#006064', '#33691E', '#827717',
  '#00838F', '#5D4037', '#3E2723', '#263238',
];

function ColorSwatchField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const cur = (value || '').toUpperCase();
  return (
    <View style={{ marginBottom: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 }}>
        <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: value || '#000', borderWidth: 1, borderColor: C.border }} />
        <Text style={styles.fieldLabel}>{label}</Text>
        <Text style={[styles.meta, { marginLeft: 'auto' }]}>{value}</Text>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
        {COLOR_SWATCHES.map((hex) => {
          const on = cur === hex.toUpperCase();
          return (
            <Pressable
              key={hex}
              onPress={() => onChange(hex)}
              style={{
                width: 34,
                height: 34,
                borderRadius: 17,
                backgroundColor: hex,
                borderWidth: on ? 3 : 1,
                borderColor: on ? C.foreground : 'rgba(0,0,0,0.25)',
                transform: [{ scale: on ? 1 : 0.9 }],
              }}
            >
              {on ? <Text style={{ color: '#fff', fontWeight: '900', textAlign: 'center', lineHeight: 32 }}>✓</Text> : null}
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

/**
 * Dropdown select (instructions #5, #7, #9, #10): tap karo → modal me list;
 * addNewLabel/onAddNew ho to list me hi "नया जोड़ें" ka option (jaise vendor/work add).
 */
/**
 * v10 #2 / #4 / #10 / #16 / #25 — **modal ke bottom wala dibba gayab ho jaata tha.**
 * modalCard par `maxHeight: '78%'` tha, par andar ka ScrollView fixed (340/420/460px)
 * tha. RN me box clip nahi hota — content card ki height se bahar nikal kar screen
 * ke neeche chala jaata tha, isliye footer button / total / input dikhna band.
 *
 * Ab body ki height window ke hisaab se calculate hoti hai, isliye card kabhi
 * overflow nahi karta aur footer hamesha screen par rehta hai.
 */
function useModalBodyMax(pct = 0.86, reserve = 250) {
  const { height } = useWindowDimensions();
  /* modalBg = flex:1 + padding 22 (44 vertical) → % usi content-box par lagta hai */
  return Math.max(150, Math.round((height - 44) * pct) - reserve);
}

/**
 * v12 #6 / #10 / #12 / #32 — **सारे data-fill popup का एक ढाँचा**:
 *  • पूरा content एक `ScrollView` में → नीचे का कोई box/बटन कटता नहीं, font+colour हमेशा दिखता है
 *  • सबसे नीचे **हमेशा "वापस जाएँ (Back)"** बटन → parent path पर वापस जाता है
 *  • backdrop (बाहर काली जगह) tap करने पर भी वही Back
 */
function ModalBody({
  title,
  hint,
  onClose,
  closeLabel,
  backdropClose = true,
  children,
}: {
  title: string;
  hint?: string;
  onClose: () => void;
  /** v12 #27 — दिया न जाए तो भाषा के अनुसार Back label अपने-आप */
  closeLabel?: string;
  /** भरा हुआ form अनजाने में बंद न हो — false रखें (Back बटन फिर भी रहता है) */
  backdropClose?: boolean;
  children: React.ReactNode;
}) {
  const bodyMax = useModalBodyMax(0.9, 140);
  const lang = useLang();
  const backLbl = closeLabel || t(lang, 'back', 'वापस जाएँ (Back)');
  return (
    <Pressable style={styles.modalBg} onPress={backdropClose ? onClose : undefined}>
      <Pressable style={[styles.modalCard, { maxHeight: '92%' }]} onPress={() => undefined}>
        <Text style={styles.modalTitle}>{title}</Text>
        {hint ? <Text style={styles.meta}>{hint}</Text> : null}
        <ScrollView
          style={{ maxHeight: bodyMax }}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ flexGrow: 0, paddingBottom: 6 }}
        >
          {children}
        </ScrollView>
        <Btn label={backLbl} variant="outline" onPress={onClose} />
      </Pressable>
    </Pressable>
  );
}

function SelectField({
  label,
  value,
  placeholder = 'चुनें',
  options,
  onSelect,
  addNewLabel,
  onAddNew,
  hint,
}: {
  label: string;
  value: string;
  placeholder?: string;
  options: { key: string; label: string; sub?: string }[];
  onSelect: (key: string) => void;
  addNewLabel?: string;
  onAddNew?: () => void;
  hint?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <Pressable
        onPress={() => setOpen(true)}
        style={[styles.field, { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }]}
      >
        <Text style={{ color: value ? C.foreground : C.mutedForeground, flex: 1, fontWeight: '700' }} numberOfLines={1}>
          {value || placeholder}
        </Text>
        <Feather name="chevron-down" size={16} color={C.mutedForeground} />
      </Pressable>
      {hint ? <Text style={styles.meta}>{hint}</Text> : null}
      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        {/* v12 #6 + #10 — नीचे का layout न कटे, फ़ॉन्ट/कलर साफ़ दिखे + हमेशा Back बटन */}
        <ModalBody
          title={label}
          hint={hint}
          onClose={() => setOpen(false)}
          closeLabel="वापस जाएँ (Back)"
        >
          {options.map((o) => (
            <Pressable
              key={o.key}
              onPress={() => {
                setOpen(false);
                onSelect(o.key);
              }}
              style={[styles.field, { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }]}
            >
              <Text style={{ color: C.foreground, fontWeight: '700', flex: 1 }} numberOfLines={2}>
                {o.label}
              </Text>
              {o.sub ? <Text style={{ color: C.mutedForeground, fontSize: 11 }}>{o.sub}</Text> : null}
            </Pressable>
          ))}
          {options.length === 0 ? <Text style={styles.meta}>कोई विकल्प नहीं — नीचे से जोड़ें</Text> : null}
          {onAddNew ? (
            <Btn
              label={addNewLabel || '+ नया जोड़ें'}
              icon="plus"
              variant="soft"
              onPress={() => {
                setOpen(false);
                onAddNew();
              }}
            />
          ) : null}
        </ModalBody>
      </Modal>
    </View>
  );
}

function Empty({ title, why, steps }: { title: string; why: string; steps: string[] }) {
  return (
    <View style={styles.empty}>
      <Feather name="info" size={20} color={C.primary} />
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyWhy}>{why}</Text>
      {steps.map((s, i) => (
        <Text key={i} style={styles.emptyStep}>
          {i + 1}. {s}
        </Text>
      ))}
    </View>
  );
}

function PinModal({
  open,
  title,
  onCancel,
  onOk,
}: {
  open: boolean;
  title: string;
  onCancel: () => void;
  onOk: () => void;
}) {
  const { verifyPin } = useStore();
  const [pin, setPin] = useState('');
  // bug fix: cancel hone par pin field reset (warna purana PIN dikhta rehta tha)
  React.useEffect(() => {
    if (!open) setPin('');
  }, [open]);
  return (
    <Modal visible={open} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={styles.modalBg}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>{title}</Text>
          <Field label="Admin PIN" value={pin} onChangeText={setPin} secureTextEntry keyboardType="numeric" />
          <View style={styles.row}>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={onCancel} />
            <Btn
              label="Confirm"
              onPress={() => {
                if (!verifyPin(pin)) {
                  Alert.alert('गलत PIN');
                  return;
                }
                setPin('');
                onOk();
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* D4: रद्द करने का कारण अनिवार्य — यहीं माँगा जाता है */
function CancelModal({
  txn,
  onCancel,
  onConfirm,
}: {
  txn: Transaction;
  onCancel: () => void;
  onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState('');
  return (
    <Modal visible transparent animationType="fade" onRequestClose={onCancel}>
      <View style={styles.modalBg}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>शुद्धि — कारण आवश्यक</Text>
          <Text style={styles.meta}>
            {txn.date} · {txn.party} · {formatINR(sumAmounts(txn.amounts))}
          </Text>
          <Field label="रद्द करने का कारण *" value={reason} onChangeText={setReason} multiline />
          <Text style={styles.meta}>
            Entry audit में रहेगी, totals से बाहर होगी, print में लाल strike-through दिखेगा (D4)।
          </Text>
          <View style={styles.row}>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={onCancel} />
            <Btn label="रद्द करें" variant="danger" disabled={!reason.trim()} onPress={() => onConfirm(reason)} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* ——— LOGIN ——— */
function LoginScreen({ onDone }: { onDone: () => void }) {
  const { app, setPin, verifyPin, updateApp } = useStore();
  /* v12 #27 — भाषा */
  const lang = useLang();
  const [pin, setPinLocal] = useState('');
  const [confirm, setConfirm] = useState('');
  const [err, setErr] = useState('');
  /* v10 #30-A — फ़ोन में अंगुली/चेहरा सेट है या नहीं */
  const [bioOk, setBioOk] = useState(false);

  React.useEffect(() => {
    let alive = true;
    (async () => {
      const ok = await bioAvailable();
      if (alive) setBioOk(ok);
    })();
    return () => {
      alive = false;
    };
  }, []);

  const submit = async () => {
    if (!app.setupComplete || !app.pin) {
      if (pin.length < 4) return setErr('PIN ≥ 4');
      if (pin !== confirm) return setErr('PIN match नहीं');
      await setPin(pin);
      onDone();
      return;
    }
    if (!verifyPin(pin)) return setErr('गलत PIN');
    onDone();
  };

  /* v10 #30-A — अंगुली/चेहरे से खोलें (PIN नहीं भरना पड़ता) */
  const tryBio = async (enable: boolean) => {
    if (enable && !app.biometricEnabled) await updateApp({ biometricEnabled: true });
    const ok = await bioAuth();
    if (ok) {
      setErr('');
      onDone();
    } else {
      setErr('अंगुली/चेहरा मैच नहीं हुआ — PIN भरें');
    }
  };

  return (
    <View style={styles.dark}>
      <StatusBar style="light" />
      {/* bug fix: screen fixed-height thi (ScrollView nahi) — logo chooser ya keyboard
          khulte hi Login button niche chala jata tha / gayab ho jata tha. */}
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', paddingBottom: 32, paddingHorizontal: 2 }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.loginPad}>
            {/* instruction #2 — panchayat ka asli cashbook logo (login par hamesha) */}
            <View style={styles.loginLogoWrap}>
              <Image source={LOGO_SRC} style={styles.loginLogo} resizeMode="cover" />
            </View>
            <Text style={styles.brand}>GRAM PANCHAYAT CASHBOOK</Text>
            {/* v12 #2 + #21 — login पर अभिवादन: सिर्फ़ दिन-समय + उपयोगकर्ता का नाम (पंचायत का नाम नहीं) */}
            <Text style={[styles.loginSub, { fontWeight: '900', color: C.accent, fontSize: 15 }]}>
              {greetOf(new Date(), app.userName, lang)}
            </Text>
            <Text style={styles.loginHi}>
              {app.pin ? t(lang, 'login.title', 'Login') : t(lang, 'login.setPin', 'PIN सेट करें')}
            </Text>
            <Text style={styles.loginSub}>{t(lang, 'login.sub', 'PIN से लॉगिन करें')}</Text>
            <Field label="PIN" value={pin} onChangeText={setPinLocal} secureTextEntry keyboardType="numeric" />
            {!app.pin ? <Field label="Confirm PIN" value={confirm} onChangeText={setConfirm} secureTextEntry keyboardType="numeric" /> : null}
            {err ? <Text style={styles.err}>{err}</Text> : null}
            <View style={{ height: 8 }} />
            <Btn
              label={!app.pin ? t(lang, 'login.save', 'Save & Continue') : t(lang, 'login.pinBtn', 'Login with PIN')}
              icon="log-in"
              onPress={submit}
            />
            {/* v10 #30-A — अंगुली/चेहरे से खोलें */}
            {bioOk && app.pin ? (
              <>
                <View style={{ height: 8 }} />
                {app.biometricEnabled ? (
                  <Btn
                    label={t(lang, 'login.bio', 'अंगुली / चेहरा से खोलें')}
                    icon="check"
                    variant="soft"
                    onPress={() => tryBio(false)}
                  />
                ) : (
                  <Btn
                    label={t(lang, 'login.bioOn', 'अंगुली से खोलना चालू करें')}
                    icon="check"
                    variant="outline"
                    onPress={() => tryBio(true)}
                  />
                )}
                <Text style={styles.loginSub}>
                  {app.biometricEnabled
                    ? t(lang, 'login.bioHintOn', 'या ऊपर PIN भरकर भी खोल सकते हैं')
                    : t(lang, 'login.bioHintOff', 'चालू करते ही अगली बार सिर्फ़ अंगुली से खुलेगा (PIN हमेशा वैध रहेगा)')}
                </Text>
              </>
            ) : null}
            <ScreenBadge label="S-01" />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

function PanchayatScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { panchayats, activePanchayatId, setActivePanchayatId, activePanchayat } = useStore();
  return (
    <View style={styles.page}>
      <Header title="Panchayat" eyebrow="Select" onBack={onBack} badge="S-02" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>⚙ App Settings — PIN, पंचायत CRUD</Text>
        {panchayats.map((p) => (
          <Pressable key={p.id} onPress={() => setActivePanchayatId(p.id)} style={[styles.card, activePanchayatId === p.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <Text style={styles.meta}>{p.block} · {p.district}</Text>
          </Pressable>
        ))}
        <Btn label="Continue" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Active: {activePanchayat.name}</Text>
      </ScrollView>
    </View>
  );
}

function AppSettingsScreen({ onBack }: { onBack: () => void }) {
  const { app, updateApp, setPin, panchayats, addPanchayat, deletePanchayat, updatePanchayat } = useStore();
  /* v12 #27 — भाषा */
  const lang = useLang();
  const [name, setName] = useState('');
  const [block, setBlock] = useState('');
  const [dist, setDist] = useState('');
  const [newPin, setNewPin] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  const [pending, setPending] = useState<null | (() => void)>(null);
  /* v10 #30-A — फ़ोन में अंगुली/चेहरा है या नहीं */
  const [bioOk, setBioOk] = useState(false);
  React.useEffect(() => {
    let alive = true;
    (async () => {
      const ok = await bioAvailable();
      if (alive) setBioOk(ok);
    })();
    return () => {
      alive = false;
    };
  }, []);
  const lockSec = app.autoLockSec ?? 0;

  return (
    <View style={styles.page}>
      <Header title="App Settings" onBack={onBack} badge="S-01" />
      <ScrollView contentContainerStyle={styles.pad}>
        {/* v12 #21 — greeting में दिखने वाला उपयोगकर्ता का नाम */}
        <Text style={styles.section}>आपका नाम (greeting के लिए)</Text>
        <Field
          label="नाम"
          value={app.userName || ''}
          onChangeText={(t) => updateApp({ userName: t })}
          placeholder="जैसे: हरिश"
        />
        <Text style={styles.meta}>
          अभिवादन इसी नाम से दिखेगा — {greetOf(new Date(), app.userName, lang)}। ख़ाली रहने पर सिर्फ़ अभिवादन (बिना नाम)।
        </Text>

        {/* ═══════════ v12 #27 — भाषा चुनाव ═══════════ */}
        <Text style={styles.section}>{t(lang, 'lang.label', 'ऐप की भाषा (App language)')}</Text>
        <SelectField
          label={t(lang, 'lang.label', 'भाषा')}
          value={LANGS.find((l) => l.key === (app.lang || 'hinglish'))?.label || 'Hinglish (default)'}
          options={LANGS.map((l) => ({ key: l.key, label: l.label, sub: l.sub }))}
          onSelect={(k) => updateApp({ lang: k as Lang })}
          hint={t(
            lang,
            'lang.hint',
            'सिर्फ़ मेन्यू, tile और बटन बदलते हैं — आधिकारिक प्रपत्र (रोकड़ बही, गोशवारा, प्रपत्र-1/2/4, CC) हिन्दी में ही रहते हैं।'
          )}
        />

        <Text style={styles.section}>Security (App lock)</Text>
        <Field label="Change PIN (new)" value={newPin} onChangeText={setNewPin} secureTextEntry keyboardType="numeric" />
        <Btn
          label="Update PIN"
          onPress={() => {
            if (newPin.length < 4) return Alert.alert('PIN ≥ 4');
            setPending(() => async () => {
              await setPin(newPin);
              setNewPin('');
              Alert.alert('PIN updated');
            });
            setPinOpen(true);
          }}
        />
        {/* v10 #30-A — अंगुली / चेहरा से unlock */}
        {bioOk ? (
          <>
            <Btn
              label={`अंगुली / चेहरा से खोलें: ${app.biometricEnabled ? 'चालू' : 'बंद'}`}
              variant={app.biometricEnabled ? 'soft' : 'outline'}
              onPress={() => updateApp({ biometricEnabled: !app.biometricEnabled })}
            />
            <Text style={styles.meta}>
              चालू होने पर Login screen पर अंगुली/चेहरे का बटन दिखेगा। PIN हमेशा वैध रहता है (वैकल्पिक रास्ता)।
            </Text>
          </>
        ) : (
          <Text style={styles.meta}>इस फ़ोन में अंगुली/चेहरा सेंसर नहीं मिला — सिर्फ़ PIN लॉक रहेगा।</Text>
        )}
        {/* v10 #30-A — background जाते ही फिर से lock */}
        <Text style={styles.meta}>ऐप background जाने पर कितनी देर बाद फिर से lock हो:</Text>
        <View style={styles.chips}>
          {[
            { s: 0, l: 'तुरंत' },
            { s: 30, l: '30 सेकंड' },
            { s: 120, l: '2 मिनट' },
            { s: 600, l: '10 मिनट' },
          ].map((o) => (
            <Pressable
              key={o.s}
              onPress={() => updateApp({ autoLockSec: o.s })}
              style={[styles.chip, lockSec === o.s && styles.chipOn]}
            >
              <Text style={{ color: lockSec === o.s ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>{o.l}</Text>
            </Pressable>
          ))}
        </View>

        {/* ═══ v11 #24 — reminder (reminders): 9 व 18 तारीख़ + कस्टम अंतराल + चालू/बंद ═══ */}
        <Text style={styles.section}>Reminders</Text>
        <Btn
          label={`Reminders: ${app.reminderEnabled === false ? 'बंद' : 'चालू'}`}
          variant={app.reminderEnabled === false ? 'outline' : 'soft'}
          icon="clock"
          onPress={() => updateApp({ reminderEnabled: app.reminderEnabled === false ? true : false })}
        />
        <Text style={styles.meta}>हर माह इन तारीख़ों को reminder दिखेगा (tap करके जोड़ें/हटाएँ):</Text>
        <View style={styles.chips}>
          {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => {
            const on = (app.reminderDays && app.reminderDays.length ? app.reminderDays : [9, 18]).includes(d);
            return (
              <Pressable
                key={d}
                onPress={() => {
                  const cur = app.reminderDays && app.reminderDays.length ? app.reminderDays : [9, 18];
                  const next = on ? cur.filter((x) => x !== d) : [...cur, d].sort((a, b) => a - b);
                  updateApp({ reminderDays: next });
                }}
                style={[styles.chip, on && styles.chipOn]}
              >
                <Text style={{ color: on ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>{d}</Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={styles.meta}>और/या कस्टम अंतराल — हर कितने दिन बाद (दिनों में):</Text>
        <View style={styles.chips}>
          {[
            { v: 0, l: 'बंद' },
            { v: 3, l: 'हर 3 दिन' },
            { v: 7, l: 'हर सप्ताह' },
            { v: 15, l: 'हर पक्ष' },
            { v: 30, l: 'हर माह' },
          ].map((o) => (
            <Pressable
              key={o.v}
              onPress={() => updateApp({ reminderIntervalDays: o.v })}
              style={[styles.chip, (app.reminderIntervalDays || 0) === o.v && styles.chipOn]}
            >
              <Text style={{ color: (app.reminderIntervalDays || 0) === o.v ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>
                {o.l}
              </Text>
            </Pressable>
          ))}
        </View>
        <Field
          label="या अपना अंतराल (दिन — 1 से 90)"
          value={String(app.reminderIntervalDays || 0)}
          keyboardType="numeric"
          onChangeText={(t) => {
            const n = parseInt(t.replace(/[^0-9]/g, '') || '0', 10);
            updateApp({ reminderIntervalDays: Math.max(0, Math.min(90, n)) });
          }}
        />
        <Text style={styles.meta}>
          चालू होने पर ऐप खोलते ही उस दिन reminder दिखेगा (एक दिन में एक बार)। यहाँ बंद करते ही बिलकुल नहीं दिखेगा।
        </Text>
        <Btn
          label={`Screen badges: ${app.showScreenBadge ? 'ON' : 'OFF'}`}
          variant="outline"
          onPress={() => updateApp({ showScreenBadge: !app.showScreenBadge })}
        />

        <Text style={styles.section}>Theme colour (6 रंग)</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {(Object.keys(THEMES) as (keyof typeof THEMES)[]).map((id) => {
            const t = THEMES[id];
            const on = (app.themeId || 'green') === id;
            return (
              <Pressable
                key={id}
                onPress={() => updateApp({ themeId: id })}
                style={{
                  alignItems: 'center',
                  gap: 4,
                  padding: 6,
                  borderRadius: 12,
                  borderWidth: 2,
                  borderColor: on ? t.swatch : 'transparent',
                  backgroundColor: on ? C.secondary : 'transparent',
                }}
              >
                <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: t.swatch, borderWidth: 2, borderColor: 'rgba(0,0,0,0.15)' }} />
                <Text style={{ fontSize: 11, color: on ? t.swatch : C.mutedForeground, fontWeight: on ? '800' : '600' }}>
                  {t.hindi}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={styles.meta}>चुनते ही पूरी ऐप का रंग बदल जाएगा (फिर से खोलने पर भी यही रहेगा)।</Text>

        <Text style={styles.section}>App logo</Text>
        {/* instruction #2 — logo chooser options hata diye; panchayat ka cashbook logo hi laga hai */}
        <View style={[styles.card, { alignItems: 'center', paddingVertical: 18 }]}>
          <Image source={LOGO_SRC} style={{ width: 96, height: 96, borderRadius: 20 }} resizeMode="cover" />
          <Text style={[styles.meta, { marginTop: 8, textAlign: 'center' }]}>
            Gram Panchayat Cashbook — logo badalne ki zarurat nahi (fixed)
          </Text>
        </View>

        <Text style={styles.section}>Panchayat master</Text>
        <Field label="Name" value={name} onChangeText={setName} />
        <Field label="Block" value={block} onChangeText={setBlock} />
        <Field label="District" value={dist} onChangeText={setDist} />
        <Btn label="Add panchayat" icon="plus" onPress={() => name.trim() && addPanchayat({ name: name.trim(), block: block || '—', district: dist || '—' })} />
        {panchayats.map((p) => (
          <View key={p.id} style={styles.card}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <View style={styles.row}>
              <Btn
                label="Delete"
                variant="danger"
                onPress={() => {
                  setPending(() => async () => {
                    const r = await deletePanchayat(p.id);
                    if (!r.ok) Alert.alert(r.error || 'Error');
                  });
                  setPinOpen(true);
                }}
              />
            </View>
          </View>
        ))}
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm Admin PIN" onCancel={() => setPinOpen(false)} onOk={() => { setPinOpen(false); pending?.(); setPending(null); }} />
    </View>
  );
}

/**
 * items #3 / #4 / #5 / #8 — FY screen aur Home ke tile par tap karo to
 * real-time scheme-wise विवरण:
 *   Opening → हर योजना का उस FY का opening + edit (PIN confirm)
 *   Income / Expense / Balance → योजना वार राशि
 *   Entries → योजना वार कितने transaction + कुल राशि
 */
type DrillKind = 'opening' | 'income' | 'expense' | 'balance' | 'txns' | 'cancelled';

const DRILL_TITLE: Record<DrillKind, string> = {
  opening: 'Opening balance — योजना वार',
  income: 'आय — योजना वार (real time)',
  expense: 'व्यय — योजना वार (real time)',
  balance: 'शेष — योजना वार (real time)',
  txns: 'लेन-देन — योजना वार',
  cancelled: 'रद्द entries — योजना वार',
};

type DrillRow = { id: string; name: string; short: string; amount: number; count: number; txnAmount: number; opening: number };

function SchemeDrillModal({ kind, onClose }: { kind: DrillKind | null; onClose: () => void }) {
  const { activeFunds, activeFy, fyTransactions, fundOpening, updateFundOpening } = useStore();
  const [editId, setEditId] = useState<string | null>(null);
  const [bal, setBal] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  const [pendingSave, setPendingSave] = useState<null | (() => void)>(null);
  /* v10 #2 — tile popup ka bottom total/dibba ab overflow nahi karega */
  const bodyMax = useModalBodyMax(0.86, 300);

  const rows: DrillRow[] = useMemo(() => {
    if (!kind) return [];
    const act = fyTransactions.filter((t) => t.status === 'active');
    /* v10 #8 — cash कोई योजना/fund head नहीं, सिर्फ़ माध्यम → drill me मत दिखाओ */
    return activeFunds.filter((f) => f.id !== 'cash').map((f) => {
      const open = fundOpening(f);
      let inc = 0;
      let exp = 0;
      let count = 0;
      let txnAmount = 0;
      for (const t of act) {
        const a = Number(t.amounts[f.id]) || 0;
        if (t.type === 'income') inc += a;
        else if (t.type === 'expense') exp += a;
        else if (t.type === 'transfer') inc += a;
        if (a !== 0 || t.schemeId === f.id) {
          if (t.schemeId === f.id) {
            count += 1;
            txnAmount += Number(t.amounts[f.id]) || 0;
          }
        }
      }
      let amount = open;
      if (kind === 'income') amount = inc;
      else if (kind === 'expense') amount = exp;
      else if (kind === 'balance') amount = open + inc - exp;
      else if (kind === 'txns') amount = txnAmount;
      if (kind === 'cancelled') {
        let cCount = 0;
        let cAmt = 0;
        for (const t of fyTransactions) {
          if (t.status !== 'cancelled' || t.schemeId !== f.id) continue;
          cCount += 1;
          cAmt += Number(t.amounts[f.id]) || 0;
        }
        count = cCount;
        amount = cAmt;
      }
      return { id: f.id, name: f.name, short: f.shortName, amount, count, txnAmount, opening: open };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, fyTransactions, activeFunds, fundOpening]);

  const total = rows.reduce((s, r) => s + (kind === 'txns' ? r.count : r.amount), 0);

  return (
    <Modal visible={!!kind} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalBg}>
        <View style={[styles.modalCard, { maxHeight: '86%' }]}>
          <Text style={styles.modalTitle}>{kind ? DRILL_TITLE[kind] : ''}</Text>
          <Text style={styles.meta}>वर्ष {activeFy.label} · सभी मान हर entry के साथ अपडेट</Text>
          <ScrollView style={{ maxHeight: bodyMax }} contentContainerStyle={{ gap: 8, paddingTop: 8 }}>
            {rows.map((r) => (
              <View key={r.id} style={[styles.card, { padding: 10 }]}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.cardTitle}>{r.name}</Text>
                    <Text style={styles.meta}>
                      {kind === 'txns'
                        ? `${r.count} transaction · ${formatINR(r.txnAmount)}`
                        : kind === 'cancelled'
                          ? `${r.count} रद्द entry · ${formatINR(r.amount)}`
                          : `योजना कोड ${r.short}`}
                    </Text>
                  </View>
                  <Text style={[styles.cardTitle, { color: r.amount < 0 ? C.destructive : C.foreground }]}>
                    {kind === 'txns' ? String(r.count) : formatINR(r.amount)}
                  </Text>
                  {kind === 'opening' ? (
                    <Btn
                      label="✎"
                      variant="outline"
                      onPress={() => {
                        setEditId(r.id);
                        setBal(String(r.opening));
                      }}
                    />
                  ) : null}
                </View>
                {kind === 'opening' && editId === r.id ? (
                  <View style={{ marginTop: 6 }}>
                    <Field label={`Opening — ${r.name}`} value={bal} onChangeText={setBal} keyboardType="numeric" />
                    <Btn
                      label="सहेजें (PIN confirm)"
                      onPress={() => {
                        setPendingSave(() => () => {
                          updateFundOpening(r.id, parseFloat(bal) || 0, 'manual');
                          setEditId(null);
                        });
                        setPinOpen(true);
                      }}
                    />
                  </View>
                ) : null}
              </View>
            ))}
          </ScrollView>
          <View style={[styles.card, { backgroundColor: C.primarySoft, marginTop: 4 }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.meta}>कुल {kind === 'txns' ? 'entries' : 'राशि'}</Text>
                <Text style={[styles.cardTitle, { fontSize: 16 }]}>{kind === 'txns' ? String(total) : formatINR(total)}</Text>
              </View>
            </View>
          </View>
          <Btn label="वापस जाएँ (Back)" variant="outline" onPress={onClose} />
        </View>
      </View>
      <PinModal
        open={pinOpen}
        title="Opening सुधार — PIN"
        onCancel={() => {
          setPinOpen(false);
          setPendingSave(null);
        }}
        onOk={() => {
          setPinOpen(false);
          const fn = pendingSave;
          setPendingSave(null);
          fn?.();
        }}
      />
    </Modal>
  );
}

function FYScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { financialYears, activeFinancialYearId, setActiveFinancialYearId, activeFy, activePanchayat, totalOpening, totalIncome, totalExpense, currentBalance, fyTransactions } = useStore();
  /* items #3/#4/#5/#8 — tile tap → scheme-wise विवरण */
  const [drill, setDrill] = useState<DrillKind | null>(null);
  return (
    <View style={styles.page}>
      <Header title="वित्तीय वर्ष" eyebrow={activePanchayat.name} onBack={onBack} badge="S-05" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>Entries are FY-scoped. Only balances carry to next year — not old entries.</Text>
        {financialYears.map((fy) => (
          <Pressable key={fy.id} onPress={() => setActiveFinancialYearId(fy.id)} style={[styles.card, activeFinancialYearId === fy.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{fy.label} {fy.locked ? '🔒' : ''}</Text>
            <Text style={styles.meta}>{fmtDate(fy.start)} → {fmtDate(fy.end)}</Text>
          </Pressable>
        ))}
        <View style={styles.stats}>
          <Stat label="Opening" v={formatINR(totalOpening)} onPress={() => setDrill('opening')} />
          <Stat label="Income" v={formatINR(totalIncome)} onPress={() => setDrill('income')} />
          <Stat label="Expense" v={formatINR(totalExpense)} onPress={() => setDrill('expense')} />
          <Stat label="Balance" v={formatINR(currentBalance)} onPress={() => setDrill('balance')} />
          <Stat label="Txns (this FY)" v={String(fyTransactions.length)} onPress={() => setDrill('txns')} />
          <Stat
            label="रद्द entries"
            v={String(fyTransactions.filter((t) => t.status === 'cancelled').length)}
            onPress={() => setDrill('cancelled')}
          />
        </View>
        <Btn label="FY Home" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Selected {activeFy.label}</Text>
      </ScrollView>
      <SchemeDrillModal kind={drill} onClose={() => setDrill(null)} />
    </View>
  );
}

/**
 * instruction #2 — FY main + FY Home ke सारे tile ek hi 2-column grid में.
 * Style wrapper (Pressable) पर ही लगानी ज़रूरी है, वरना width % inner View के
 * circular reference में बिगड़ जाती थी (tile टूटकर alag-alag row me aa jate the).
 */
function Stat({ label, v, onPress }: { label: string; v: string; onPress?: () => void }) {
  const content = (
    <>
      <Text style={styles.statLabel} numberOfLines={1}>
        {label}
      </Text>
      <Text style={styles.statValue} numberOfLines={1} adjustsFontSizeToFit>
        {v}
      </Text>
      <Text style={styles.statHint} numberOfLines={1}>
        {onPress ? 'विवरण ›' : '\u00A0'}
      </Text>
    </>
  );
  if (!onPress) return <View style={styles.stat}>{content}</View>;
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.07)' }}
      style={({ pressed }) => [styles.stat, pressed && styles.statPressed]}
    >
      {content}
    </Pressable>
  );
}

/**
 * instruction #18 — "Share FY CSV" अब असली **file** देता है (text message नहीं)।
 * user चुने .csv या .xlsx — दोनों mobile पर खुल जाती हैं।
 */
async function shareFyCsv(baseName: string, csv: string): Promise<void> {
  const run = async (ext: 'csv' | 'xlsx') => {
    try {
      const content = ext === 'csv' ? csv : csvToXlsx(csv, 'FY');
      await shareRawFile(`${baseName}.${ext}`, content, mimeForExt(ext));
    } catch (e) {
      Alert.alert('Share fail', String((e as Error)?.message || e));
    }
  };
  Alert.alert('FY CSV', 'किस format में file भेजें?', [
    { text: '.csv (Excel / Sheets)', onPress: () => run('csv') },
    { text: '.xlsx (असली Excel)', onPress: () => run('xlsx') },
    { text: 'रद्द', style: 'cancel' },
  ]);
}

/** Next FY derive — hardcoded '2027–28' bug fix (FY hamesha current FY ke baad) */
function nextFyParts(fy: { end: string }): { label: string; start: string; end: string } {
  const endYear = parseInt(fy.end.slice(0, 4), 10) || new Date().getFullYear();
  const startY = endYear;
  const start = `${startY}-04-01`;
  const end = `${startY + 1}-03-31`;
  const label = `${startY}–${String((startY + 1) % 100).padStart(2, '0')}`;
  return { label, start, end };
}

function FYSettingsScreen({ onBack }: { onBack: () => void }) {
  const {
    fySettings,
    updateFySettings,
    activeFunds,
    addFund,
    updateFundOpening,
    deleteFundFy,
    addFinancialYear,
    closeFinancialYearCarryForward,
    activeFy,
    fundOpening,
    fyTransactions,
    purgeFinancialYearEntries,
  } = useStore();
  const [fn, setFn] = useState('');
  const [fo, setFo] = useState('0');
  const [editId, setEditId] = useState<string | null>(null);
  const [bal, setBal] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  // pending ko deliberately loose rakha hai: kuch actions Promise<void>, kuch
  // Promise<{ok,error}> return karte hain — dono chalayein
  const [pending, setPending] = useState<null | (() => unknown)>(null);
  // bug fix: controlled Field store value se render hota tha — range check reject hote hi
  // field reset ho jati thi, isliye user kabhi naya number type hi nahi kar pata tha
  const [lineInput, setLineInput] = useState(String(fySettings.lineCount));
  const lineNum = parseInt(lineInput, 10);
  const lineValid = Number.isFinite(lineNum) && lineNum >= 16 && lineNum <= 40;
  const nx = nextFyParts(activeFy);

  const runPending = async () => {
    setPinOpen(false);
    const fnToDo = pending;
    setPending(null);
    if (!fnToDo) return;
    const r: unknown = await fnToDo();
    if (r && typeof r === 'object' && 'ok' in r && !(r as { ok: boolean }).ok) {
      Alert.alert('नहीं हुआ', String((r as { error?: string }).error || '—'));
    }
  };

  return (
    <View style={styles.page}>
      <Header title="FY / Cashbook Settings" onBack={onBack} badge="S-49" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.section}>Lines (txn = L−4)</Text>
        <Field
          label="Total lines (16–40, default 25)"
          value={lineInput}
          onChangeText={(v) => {
            setLineInput(v);
            const n = parseInt(v, 10);
            if (Number.isFinite(n) && n >= 16 && n <= 40) updateFySettings({ lineCount: n });
          }}
          keyboardType="numeric"
        />
        {!lineValid ? <Text style={styles.err}>16–40 के बीच डालें — मान तभी लागू होगा</Text> : null}
        <Text style={styles.meta}>Transaction lines now: {transactionLineCount(lineValid ? lineNum : fySettings.lineCount)}</Text>
        {/* instruction #11 — blank-line-gap ab sirf Entry page par (yahan se hata diya) */}
        <Btn
          label={fySettings.allowSchemeNegative ? 'Scheme minus: ON' : 'Scheme minus: OFF'}
          variant="soft"
          onPress={() => updateFySettings({ allowSchemeNegative: !fySettings.allowSchemeNegative })}
        />
        {/* instruction #10 — entry tap → सुधार या सिर्फ़ विवरण */}
        <Btn
          label={
            fySettings.allowBackDateEdit
              ? 'Back-date editing: ON — entry tap = सुधार'
              : 'Back-date editing: OFF — entry tap = सिर्फ़ विवरण'
          }
          variant={fySettings.allowBackDateEdit ? 'primary' : 'danger'}
          onPress={() => updateFySettings({ allowBackDateEdit: !fySettings.allowBackDateEdit })}
        />
        <Text style={styles.meta}>
          बंद होने पर cashbook में किसी भी entry पर tap करने पर सिर्फ़ पढ़ने के लिए विवरण खुलेगा — सुधार/रद्द नहीं होगा।
        </Text>
        {/* instruction #6 — colour ab normal swatch selection se (koi digit/code input nahi) */}
        <Text style={styles.section}>रंग (colour)</Text>
        <ColorSwatchField label="Entry font colour" value={fySettings.entryFontColor} onChange={(v) => updateFySettings({ entryFontColor: v })} />
        <ColorSwatchField label="श्री पोते / सारांश line colour" value={fySettings.summaryFontColor} onChange={(v) => updateFySettings({ summaryFontColor: v })} />
        <ColorSwatchField label="श्री पोते colour" value={fySettings.shriPoteColor} onChange={(v) => updateFySettings({ shriPoteColor: v })} />
        <ColorSwatchField label="Page background" value={fySettings.pageBackground} onChange={(v) => updateFySettings({ pageBackground: v })} />

        <Text style={styles.section}>Schemes (this device book)</Text>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>
              {formatINR(fundOpening(f))} · {f.openingSource === 'carry-forward' ? '↩ CF' : '✎ Manual'} · इस FY का opening
            </Text>
            <View style={styles.row}>
              <Btn
                label="Edit opening"
                variant="outline"
                onPress={() => {
                  setEditId(f.id);
                  setBal(String(fundOpening(f)));
                }}
              />
              <Btn
                label="Delete (इस FY से)"
                variant="danger"
                onPress={() => {
                  setPending(() => () => deleteFundFy(f.id));
                  setPinOpen(true);
                }}
              />
            </View>
            {editId === f.id ? (
              <>
                <Field label="Opening balance" value={bal} onChangeText={setBal} keyboardType="numeric" />
                <Btn
                  label="Save"
                  onPress={() => {
                    updateFundOpening(f.id, parseFloat(bal) || 0, 'manual');
                    setEditId(null);
                  }}
                />
              </>
            ) : null}
          </View>
        ))}
        <Field label="New scheme" value={fn} onChangeText={setFn} />
        <Field label="Opening" value={fo} onChangeText={setFo} keyboardType="numeric" />
        <Btn label="Add scheme" icon="plus" onPress={() => { addFund(fn, parseFloat(fo) || 0, 'manual'); setFn(''); setFo('0'); }} />

        <Text style={styles.section}>New FY (empty entries)</Text>
        <Text style={styles.meta}>
          अगला FY: {nx.label} ({nx.start} → {nx.end}) — current FY {activeFy.label} से derive
        </Text>
        {/* C11 decision: FY add/lock par bhi PIN re-confirm compulsory */}
        <Btn
          label={`Add FY ${nx.label} (empty) — PIN confirm`}
          onPress={() => {
            setPending(() => () => addFinancialYear(nx.label, nx.start, nx.end));
            setPinOpen(true);
          }}
        />
        <Btn
          label={`Close current FY → carry balances only to ${nx.label} — PIN confirm`}
          variant="soft"
          onPress={() => {
            setPending(() => () => closeFinancialYearCarryForward(activeFy.id, nx.label, nx.start, nx.end));
            setPinOpen(true);
          }}
        />

        {/* ═══ v12 #4 — इस वित्तीय वर्ष का सारा data एक साथ मिटाना ═══ */}
        <Text style={styles.section}>इस वित्तीय वर्ष का data मिटाएँ (DANGER)</Text>
        <Text style={styles.meta}>
          नीचे बटन दबाने पर {activeFy.label} की **सारी entries** (आय + व्यय) एक साथ मिट जाएँगी। इसके बाद वे entries ऐप में
          कहीं भी, **audit trail सहित**, नहीं दिखेंगी। सिर्फ़ PIN कन्फर्म के बाद ही मिटेंगी — पन्ने, schemes, masters और
          बाक़ी settings अपने-आप बने रहेंगे।
        </Text>
        <Btn
          label={`erase this financial year data (${activeFy.label}) — PIN`}
          variant="danger"
          icon="trash-2"
          onPress={() => {
            const n = fyTransactions.filter((t) => t.fyId === activeFy.id).length;
            if (!n) {
              Alert.alert('कुछ मिटाने को नहीं', `${activeFy.label} में कोई entry नहीं है।`);
              return;
            }
            Alert.alert(
              `${activeFy.label} की ${n} entries मिटाएँ?`,
              'यह काम स्थायी (irreversible) है। अगले स्टेप में PIN माँगा जाएगा — उसके बाद ये entries audit trail में भी नहीं रहेंगी।',
              [
                { text: 'रहने दें', style: 'cancel' },
                {
                  text: 'आगे बढ़ें (PIN)',
                  style: 'destructive',
                  onPress: () => {
                    setPending(() => async () => {
                      const done = purgeFinancialYearEntries(activeFy.id);
                      Alert.alert('मिटा दिया', `${done} entries स्थायी रूप से मिटा दी गईं (audit trail सहित)।`);
                      return { ok: true };
                    });
                    setPinOpen(true);
                  },
                },
              ]
            );
          }}
        />
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm" onCancel={() => { setPinOpen(false); setPending(null); }} onOk={runPending} />
    </View>
  );
}

/**
 * v12 #28 — S-06 (greeting के नीचे) "शेयरबाज़ार जैसा" running-balance ग्राफ़:
 * 01 अप्रैल से आज तक हर पन्ने/तारीख़ के बाद का शेष — ऊपर-नीचे होता हुआ।
 * बिंदु पर tap करने से उस दिन का शेष दिखता है।
 */
function BalanceGraph({ points, height = 150 }: { points: { label: string; v: number }[]; height?: number }) {
  const { width } = useWindowDimensions();
  const [sel, setSel] = useState<number | null>(null);
  if (!points || points.length < 2) return null;
  const W = Math.max(180, width - 60);
  const H = height;
  const vals = points.map((p) => p.v);
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const span = max - min || 1;
  const pad = 14;
  const X = (i: number) => (i / Math.max(1, points.length - 1)) * (W - 8) + 4;
  const Y = (v: number) => pad + (1 - (v - min) / span) * (H - pad * 2);
  const poly = points.map((p, i) => `${X(i).toFixed(1)},${Y(p.v).toFixed(1)}`).join(' ');
  const idx = Math.min(sel == null ? points.length - 1 : sel, points.length - 1);
  const cur = points[idx];
  const col = cur.v >= points[0].v ? C.income : C.expense;
  const touchW = W / points.length;
  return (
    <View style={[styles.card, { padding: 8 }]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Text style={styles.cardTitle}>📈 Running balance (page-wise)</Text>
        <Text style={{ color: col, fontWeight: '900', fontSize: 14 }}>{formatINR(cur.v)}</Text>
      </View>
      <Text style={styles.meta}>
        {cur.label} · न्यूनतम {formatINR(min)} · अधिकतम {formatINR(max)} · ग्राफ़ पर tap करके तारीख़ देखें
      </Text>
      <View style={{ marginTop: 6 }}>
        <Svg width={W} height={H}>
          <SvgLine x1={4} y1={Y(max)} x2={W - 4} y2={Y(max)} stroke={C.border} strokeWidth={1} strokeDasharray="4 4" />
          <SvgLine x1={4} y1={Y(min)} x2={W - 4} y2={Y(min)} stroke={C.border} strokeWidth={1} strokeDasharray="4 4" />
          <SvgLine x1={4} y1={Y(points[0].v)} x2={W - 4} y2={Y(points[0].v)} stroke={C.mutedForeground} strokeWidth={1} />
          <Polyline points={poly} fill="none" stroke={col} strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />
          <SvgLine x1={X(idx)} y1={2} x2={X(idx)} y2={H - 2} stroke={C.primary} strokeWidth={1} strokeDasharray="3 3" opacity={0.7} />
          <Circle cx={X(idx)} cy={Y(cur.v)} r={4.5} fill={col} stroke="#fff" strokeWidth={1.5} />
        </Svg>
        <View style={{ position: 'absolute', top: 0, left: 0, width: W, height: H, flexDirection: 'row' }}>
          {points.map((p, i) => (
            <Pressable key={`${p.label}-${i}`} onPress={() => setSel(i)} style={{ width: touchW, height: H }} />
          ))}
        </View>
      </View>
      <Text style={styles.meta}>
        शुरुआत {points[0].label} ({formatINR(points[0].v)}) → अंत {points[points.length - 1].label} (
        {formatINR(points[points.length - 1].v)})
      </Text>
    </View>
  );
}

function HomeScreen({ go, back }: { go: (s: Stage, wid?: string) => void; back: () => void }) {
  const {
    activeFy, activePanchayat, currentBalance, totalIncome, totalExpense, fyTransactions,
    totalOpening, categories, bankLines, app, updateApp, fyPages,
  } = useStore();
  /* v12 #27 — भाषा (मेन्यू / tile / बटन) */
  const lang = useLang();
  /* items #3/#4/#5/#8 — FY Home ke tile par tap → scheme-wise विवरण */
  const [drill, setDrill] = useState<DrillKind | null>(null);
  /* v12 #19 — एक ही Settings tile के अंदर masters/formats/समापन/बैकअप/reports/categories/fund heads */
  /* v13 #14a — `settingsOpen` हटाया: व्यवस्था अब `settings` Stage (अलग पन्ना) में खुलती है */
  /* ═══ v11 #25 — खोलते ही अभिवादन (पहली बार पूरा पॉपअप, बाद में पतली पट्टी) ═══ */
  const todayStr = toIsoLocal(new Date());
  const [greetOpen, setGreetOpen] = useState(!app?.greetingShown);
  const closeGreet = () => {
    setGreetOpen(false);
    updateApp({ greetingShown: true });
  };
  /* ═══ v11 #24 — reminder: 9 व 18 तारीख़ या चुना हुआ कस्टम अंतराल ═══ */
  const [remOpen, setRemOpen] = useState(() => (app ? reminderDue(app, toIsoLocal(new Date())) : false));
  React.useEffect(() => {
    if (remOpen && app && app.reminderLastSeen !== todayStr) updateApp({ reminderLastSeen: todayStr });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remOpen]);
  // J.1 — dashboard flags: incomplete category paths + untagged/open bank lines
  const incompleteCount = fyTransactions.filter(
    (t) => t.status === 'active' && (!t.schemeId || isPathIncomplete(t, categories))
  ).length;
  const openBankLines = bankLines.filter((l) => l.fyId === activeFy.id && !l.postedTxnId && !l.ignored).length;
  /* v10 #30-B — बैकअप reminder: अभी तक कोई बैकअप नहीं, या 2 दिन से पुराना */
  const lastBkMs = app?.lastBackupAt ? new Date(app.lastBackupAt).getTime() : 0;
  const bkDays = lastBkMs ? Math.floor((Date.now() - lastBkMs) / 86400000) : -1;
  const needBackup = bkDays < 0 || bkDays >= 2;

  /* ═══ v12 #28 — 01 अप्रैल से आज तक का page-wise running balance (शेयरबाज़ार जैसा) ═══ */
  const runPoints = useMemo(() => {
    const today = toIsoLocal(new Date());
    const last = today < activeFy.start ? activeFy.start : today > activeFy.end ? activeFy.end : today;
    const act = fyTransactions.filter((t) => t.status === 'active');
    const bal = (d: string) =>
      totalOpening +
      act.reduce((s, t) => {
        if (t.date > d) return s;
        const v = sumAmounts(t.amounts);
        if (t.type === 'income') return s + v;
        if (t.type === 'expense') return s - v;
        return s; // transfer (नकद→बैंक) = आय/व्यय नहीं
      }, 0);
    const stamps = new Set<string>([activeFy.start]);
    for (const p of fyPages) {
      const d = p.date || (p.month ? monthLastDay(p.month) : '');
      if (d && d >= activeFy.start && d <= last) stamps.add(d);
    }
    /* पन्ने कम हों तो उन entries की तारीख़ें भी — ग्राफ़ ख़ाली न लगे */
    if (stamps.size < 3) for (const t of act) if (t.date >= activeFy.start && t.date <= last) stamps.add(t.date);
    stamps.add(last);
    const arr = [...stamps].sort();
    /* बहुत ज़्यादा बिंदु हों तो हर Nवाँ चुनकर भी अंतिम बिंदु हमेशा रखें */
    const step = Math.max(1, Math.ceil(arr.length / 120));
    const kept = arr.filter((_, i) => i % step === 0);
    if (kept[kept.length - 1] !== arr[arr.length - 1]) kept.push(arr[arr.length - 1]);
    return kept.map((d) => ({ label: fmtDate(d), v: bal(d) }));
  }, [fyTransactions, fyPages, totalOpening, activeFy.start, activeFy.end]);
  return (
    <View style={styles.page}>
      <Header title={`FY ${activeFy.label}`} eyebrow={activePanchayat.name} onBack={back} badge="S-06" />
      <ScrollView contentContainerStyle={styles.pad}>
        {/* v12 #28 — ग्राम पंचायत कैशबुक का page-wise running-balance ग्राफ़ */}
        <BalanceGraph points={runPoints} />
        {/* v11 #25 — खोलते ही अभिवादन (दिन/समय के अनुसार) */}
        <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5, backgroundColor: C.primarySoft }]}>
          <Text style={styles.cardTitle}>{greetOf(new Date(), app.userName)}</Text>
          <Text style={styles.meta}>
            {activePanchayat.name} · FY {activeFy.label} · आज {fmtDate(todayStr)}
          </Text>
        </View>
        {/* v11 #24 — आज reminder दिन है (tap करके बंद; App Settings में चालू/बंद) */}
        {remOpen ? (
          <Pressable onPress={() => setRemOpen(false)} style={[styles.card, { borderColor: C.accent, borderWidth: 1.5 }]}>
            <Text style={styles.cardTitle}>⏰ आज reminder का दिन है</Text>
            <Text style={styles.meta}>
              तारीख़ {fmtDate(todayStr)} — आज का हिसाब, एंट्री व बैकअप निपटाएँ।
            </Text>
            <Text style={styles.meta}>
              तारीख़/अंतराल/चालू-बंद — App Settings → reminder में बदलें। (आज के लिए बंद — tap करें)
            </Text>
          </Pressable>
        ) : null}
        {/* v10 #30-B — auto-backup reminder */}
        {needBackup ? (
          <Pressable onPress={() => go('backup')} style={[styles.card, { borderColor: C.accent, borderWidth: 1.5 }]}>
            <Text style={styles.cardTitle}>⬇ बैकअप लेने का समय हो गया</Text>
            <Text style={styles.meta}>
              {bkDays < 0
                ? 'अभी तक एक भी बैकअप नहीं लिया गया।'
                : `आख़िरी बैकअप ${fmtDate((app?.lastBackupAt || '').slice(0, 10))} — ${bkDays} दिन पहले।`}
            </Text>
            <Text style={styles.meta}>
              एक टैप में .json / .csv / .xlsx / .zip बैकअप — फ़ोन खोने या खराब होने पर पूरा data वापस आ सकता है। टैप करें →
            </Text>
          </Pressable>
        ) : null}
        <View style={styles.stats}>
          <Stat label="Opening" v={formatINR(totalOpening)} onPress={() => setDrill('opening')} />
          <Stat label="Balance" v={formatINR(currentBalance)} onPress={() => setDrill('balance')} />
          <Stat label="Income" v={formatINR(totalIncome)} onPress={() => setDrill('income')} />
          <Stat label="Expense" v={formatINR(totalExpense)} onPress={() => setDrill('expense')} />
          <Stat label="Entries" v={String(fyTransactions.filter((t) => t.status === 'active').length)} onPress={() => setDrill('txns')} />
          <Stat
            label="रद्द entries"
            v={String(fyTransactions.filter((t) => t.status === 'cancelled').length)}
            onPress={() => setDrill('cancelled')}
          />
        </View>
        {incompleteCount > 0 ? (
          <Text style={[styles.err, { marginBottom: 6 }]}>
            ⚠ {incompleteCount} entries incomplete (scheme/category path missing) — Monthly check → Incomplete
          </Text>
        ) : null}
        {openBankLines > 0 ? (
          <Text style={[styles.meta, { marginBottom: 6 }]}>⚠ {openBankLines} bank lines pending tag/post</Text>
        ) : null}
        {/* ═══ v12 #18 — "Add Income / Expense" tile हटाया (अब cashbook page के नीचे
            works page जैसा floating + बटन से एंट्री बनती है) ═══
            ═══ v12 #19 — Masters / Formats / FY समापन / Backup / Reports / Categories /
            Fund heads अब नीचे "व्यवस्था (Settings)" tile के अंदर ═══ */}
        {[
          ['cashbook', 'book', 'Cashbook', '25-line Option A · dual grid'],
          ['monthly', 'check-circle', 'Monthly check', 'All txns + fix missing'],
          ['goswara', 'pie-chart', 'गोशवारा', 'Till-date auto'],
          ['ledgers', 'list', 'Ledgers', 'Auto from entries'],
          ['bank', 'credit-card', 'Bank statement', 'Tag + post'],
          /* instruction #23 — कार्य / MB / बिल / CC अलग-अलग tiles */
          ['works', 'briefcase', 'कार्य (Works) — सूची', 'सूची → AS/TS/FS + तिथि, स्वीकृति, शुरू/पूर्ण, भुगतान बिल'],
          ['mb', 'clipboard', 'MB (माप पुस्तिका)', 'कार्य चुनें → सामग्री / श्रम मूल्यांकन'],
          ['bills', 'file-text', 'बिल (Bills)', 'कार्य → भुगतान बिल व विवरण'],
          ['cc', 'grid', 'CC (पूर्णता प्रमाण)', 'कार्य → 7 पृष्ठ Excel जैसा layout'],
          /* v10 #18-2 — बिना कार्य जोड़े सिर्फ़ मान-दिवस/राशि का हिसाब */
          ['manday', 'clock', 'मान-दिवस गणना (स्वतंत्र)', 'कोई कार्य न चुनें — सीधे लोग × दिन × दर = राशि'],
        ].map(([id, icon, title, sub]) => (
          /* v13 #20 — MB / बिल / CC tile हमेशा **कार्य-सूची** से खुलें (पिछला चुना हुआ
             कार्य अपने-आप न खुल जाए); फिर चुने हुए कार्य का MB / बिल / CC। */
          <Pressable
            key={id}
            style={styles.homeRow}
            onPress={() => go(id as Stage, id === 'mb' || id === 'bills' || id === 'cc' || id === 'manday' ? '' : undefined)}
          >
            <View style={styles.homeIcon}><Feather name={icon as any} size={18} color={C.primary} /></View>
            <View style={{ flex: 1 }}>
              {/* v12 #27 — tile का शीर्षक चुनी हुई भाषा में */}
              <Text style={styles.cardTitle}>{t(lang, `tile.${id}`, title)}</Text>
              <Text style={styles.meta}>{sub}</Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}

        {/* v12 #19 — एक ही Settings tile के अंदर masters, formats, समापन, बैकअप, report, categories, fund heads */}
        <Pressable style={[styles.homeRow, { backgroundColor: C.primarySoft, borderColor: C.primary }]} onPress={() => go('settings')}>
          <View style={styles.homeIcon}><Feather name="settings" size={18} color={C.primary} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardTitle}>{t(lang, 'home.settings', 'व्यवस्था (Settings)')}</Text>
            <Text style={styles.meta}>{t(lang, 'home.settingsSub', 'Masters · प्रपत्र · FY समापन · बैकअप · Reports · Categories · Fund heads')}</Text>
          </View>
          <Feather name="chevron-right" size={18} color={C.mutedForeground} />
        </Pressable>
      </ScrollView>
      <SchemeDrillModal kind={drill} onClose={() => setDrill(null)} />
      {/* v13 #14a — अब "व्यवस्था (Settings)" एक अलग पन्ना है (`settings` Stage) — उसी में खुलता है */}
      {/* v11 #25 — पहली बार खोलने पर पूरा अभिवादन पॉपअप (सिर्फ़ एक बार) */}
      <Modal visible={greetOpen} transparent animationType="fade" onRequestClose={closeGreet}>
        <Pressable style={styles.modalBg} onPress={closeGreet}>
          <Pressable style={styles.modalCard} onPress={() => undefined}>
            <Text style={styles.modalTitle}>{greetOf(new Date(), app.userName, lang)}</Text>
            <Text style={styles.sumLine}>{activePanchayat.name}</Text>
            <Text style={styles.meta}>
              FY {activeFy.label} · आज {fmtDate(todayStr)} · शेष {formatINR(currentBalance)}
            </Text>
            <Text style={styles.hint}>
              {t(
                lang,
                'greet.hint',
                'यहाँ से Cashbook, नई एंट्री, गोशवारा, लेजर, कार्य (Works), प्रपत्र/Formats Centre, बैकअप — सब एक ही जगह से खुलता है।'
              )}
            </Text>
            <Btn label={t(lang, 'greet.start', 'शुरू करें')} icon="log-in" onPress={closeGreet} />
            <Text style={styles.meta}>
              {t(lang, 'greet.note', 'अभिवादन दिन के समय के हिसाब से बदलता रहेगा (सुबह / दोपहर / शाम / रात)।')}
            </Text>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

/* Instruction #15 — entry se wapas aane par usi page + usi zoom par rehna chahiye */
/* v13 #10 — `openPage >= 0` = अगली बार कैशबुक सीधा इसी पन्ने पर खुले (ledger से आने पर) */
const cashbookUI = { page: 0, zoom: 1, gotoDate: '', openPage: -1 };

function CashbookScreen({ back, go, onEdit, onNewEntry }: { back: () => void; go: (s: Stage) => void; onEdit: (txnId: string) => void; onNewEntry: () => void }) {
  const {
    fyTransactions, activeFunds, fySettings, activePanchayat, activeFy, cancelTransaction,
    exportCsvForFy, fyPages, addPage, insertPageAfter, deletePage, fundOpening, syncMonthlyPages,
    ensurePageForDate, purgeTransactions,
  } = useStore();
  /* v13 #10 — ledger से सीधा किसी ख़ास पन्ने पर आने की स्थिति यहीं से लो */
  const bootOpen = cashbookUI.openPage;
  cashbookUI.openPage = -1;
  const [pageIdx, setPageIdx] = useState(bootOpen >= 0 ? bootOpen : cashbookUI.page);
  /* instruction #10 + #15 — ek side phone par fit + pinch/± zoom */
  const [zoom, setZoom] = useState(cashbookUI.zoom);
  const [cancelTxn, setCancelTxn] = useState<Transaction | null>(null);
  /* instruction #4 — share: पहले page range चुनो, फिर PDF (A4) / .xlsx — text नहीं */
  const [shareOpen, setShareOpen] = useState(false);
  const [rangeFrom, setRangeFrom] = useState('1');
  const [rangeTo, setRangeTo] = useState('1');
  /* v12 #5 — इस page की सारी entries एक साथ मिटाना (PIN के बाद; audit में भी नहीं रहेंगी) */
  const [eraseOpen, setEraseOpen] = useState(false);
  /* v12 #5 — "+ Page" का मेन्यू अब Modal (Android Alert में 5 बटन नहीं दिखते थे) */
  const [pageMenuOpen, setPageMenuOpen] = useState(false);

  /**
   * v9 #3 — month-end page **सिर्फ़** उन महीनों के जिनकी आख़िरी तारीख़ निकल चुकी है;
   * फिर आज की तारीख़ वाला पन्ना बनाकर उसी पर खोलो।
   */
  React.useEffect(() => {
    syncMonthlyPages();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeFy.id]);

  const pageDateOfIdx = (i: number) => {
    const p = fyPages[i];
    if (!p) return '';
    return p.date || (p.month ? monthLastDay(p.month) : '');
  };
  const todayInFy = () => {
    const t = toIsoLocal(new Date());
    if (t < activeFy.start) return activeFy.start;
    if (t > activeFy.end) return activeFy.end;
    return t;
  };

  React.useEffect(() => {
    ensurePageForDate(todayInFy());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeFy.id, ensurePageForDate]);

  /**
   * v11 #2 + #3 — **कैशबुक खोलते ही आज का पन्ना** (या entry की तारीख़ का पन्ना,
   * अगर उस entry से वापस आ रहे हैं)। `wantDate` पन्ना न मिले तो बना देता है।
   * एक बार jump के बाद user ◀/▶ से जहाँ चाहे जा सकता है — वापस खींचता नहीं।
   */
  const [wantDate, setWantDate] = useState<string>(() => {
    /* v13 #10 — ledger से आए हैं तो सीधा उसी पन्ने पर रहो, तारीख़ मत खींचो */
    if (bootOpen >= 0) return '';
    const g = cashbookUI.gotoDate;
    cashbookUI.gotoDate = '';
    return g || todayInFy();
  });
  React.useEffect(() => {
    if (!wantDate) return;
    const i = fyPages.findIndex((_, idx) => pageDateOfIdx(idx) === wantDate);
    if (i >= 0) {
      setPageIdx(i);
      setWantDate('');
      return;
    }
    ensurePageForDate(wantDate);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wantDate, fyPages]);

  const L = fySettings.lineCount;
  const txnMax = transactionLineCount(L);
  /* instruction #11 — blankLineGap − 1 = हर entry के बाद खाली लाइनें (0–3) */
  const blankLines = Math.max(0, Math.min(3, (fySettings.blankLineGap || 1) - 1));

  const safeIdx = Math.min(pageIdx, Math.max(0, fyPages.length - 1));
  const curPage = fyPages[safeIdx] || null;
  const isLastPage = safeIdx >= fyPages.length - 1;

  /**
   * v12 #5 — इस page पर दिखने वाली **सारी entries** (assigned + आख़िरी page पर
   * बिना page वाली legacy entries) — erase के लिए इन्हीं की ids चाहिए।
   */
  const pageTxnIds = (): string[] =>
    fyTransactions.filter((t) => (t.pageId ? t.pageId === curPage?.id : isLastPage)).map((t) => t.id);

  // instruction #15: page/zoom persist (entry → back = wahin par)
  React.useEffect(() => {
    cashbookUI.page = safeIdx;
  }, [safeIdx]);
  React.useEffect(() => {
    cashbookUI.zoom = zoom;
  }, [zoom]);

  const sortTx = (a: Transaction, b: Transaction) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt);
  const sideOfTx = (t: Transaction) => (t.type === 'transfer' ? 'expense' : t.type);
  /**
   * v13 #9 — **screen और export एक ही filter.** पहले export सिर्फ़
   * `t.pageId === page.id` लेता था, जबकि screen `zoneFor` बिना page वाली
   * (legacy) entries को आख़िरी पन्ने पर दिखाती थी → Excel/PDF में entries गायब
   * रह जाती थीं। अब दोनों जगह यही helper।
   */
  const txnsOfPageIdx = (idx: number): Transaction[] => {
    const p = fyPages[idx];
    if (!p) return [];
    const isLast = idx === fyPages.length - 1;
    return fyTransactions.filter((t) => (t.pageId ? t.pageId === p.id : isLast)).sort(sortTx);
  };

  /* ═══ v13 #10 — प्रति-मद L.F. + दो-तरफ़ा कड़ियाँ ═══ */
  const folioMap = React.useMemo(() => buildFolioMap(fyTransactions), [fyTransactions]);
  const folioOf = (t: Transaction): string => folioFromMap(folioMap, t);
  /** L.F. / ledger की कोई भी पंक्ति दबाने पर उसी मद का खाता बही खुले */
  const openLedgerOf = (t: Transaction) => {
    const k = madKeyOf(t);
    Object.keys(ledgerJump).forEach((x) => delete (ledgerJump as Record<string, string>)[x]);
    if (k.startsWith('work:')) ledgerJump.workId = k.slice(5);
    else if (k.startsWith('cat:')) ledgerJump.catId = k.slice(4);
    else if (k.startsWith('scheme:')) ledgerJump.fundId = k.slice(7);
    go('ledgers');
  };

  /**
   * C.3/C.7 — इस page के दोनों zones:
   * assigned txn अपने page पर; unassigned last page पर (legacy fallback).
   * Cancelled txns भी line घेरते हैं (print पर लाल strike) — totals से बाहर रहते हैं.
   * D1/C.8 — blankLineGap 2 = हर entry के बाद 1 खाली line.
   */
  const zoneFor = (side: 'income' | 'expense'): (Transaction | null)[] => {
    const list = fyTransactions
      .filter((t) => {
        if (sideOfTx(t) !== side) return false;
        if (t.pageId) return t.pageId === curPage?.id;
        return isLastPage;
      })
      .sort(sortTx);
    const zone: (Transaction | null)[] = [];
    for (const t of list) {
      if (zone.length >= txnMax) break;
      zone.push(t);
      for (let b = 0; b < blankLines && zone.length < txnMax; b++) zone.push(null);
    }
    while (zone.length < txnMax) zone.push(null);
    return zone;
  };

  const zoneInc = zoneFor('income');
  const zoneExp = zoneFor('expense');
  const activeInc = zoneInc.filter((t): t is Transaction => !!t && t.status === 'active');
  const activeExp = zoneExp.filter((t): t is Transaction => !!t && t.status === 'active');

  const fundIds = activeFunds.map((f) => f.id);

  // C.6 — इस page का श्री पोते = पिछले page की बचत पोते (page 1 = FY opening) + D17 CF/Manual
  const openingByFund = pageOpenings(
    activeFunds.map((f) => ({ id: f.id, openingBalance: fundOpening(f) })),
    fyPages,
    fyTransactions,
    safeIdx
  );
  const prevLastDate =
    safeIdx <= 0
      ? activeFy.start
      : (() => {
          const prev = fyPages[safeIdx - 1];
          const tx = fyTransactions.filter((t) => t.pageId === prev.id && t.status === 'active').sort(sortTx);
          return tx.length ? tx[tx.length - 1].date : '';
        })();
  const cfLabel =
    safeIdx > 0
      ? 'Carry-forward — पिछले पृष्ठ की बचत पोते'
      : activeFunds.some((f) => f.openingSource === 'carry-forward')
        ? 'Carry-forward — पिछले FY की समापन शेष'
        : 'Manual — हाथ से भरा';

  // C.5 — हर amount column के लिए नीचे के 3 row
  const aay: Record<string, number> = {};
  const vyay: Record<string, number> = {};
  for (const f of fundIds) {
    aay[f] = activeInc.reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
    vyay[f] = activeExp.reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
  }
  const shriOf = (f: string) => openingByFund[f] || 0;
  const aayOf = (f: string) => aay[f] || 0;
  const vyayOf = (f: string) => vyay[f] || 0;
  const mahayogLOf = (f: string) => shriOf(f) + aayOf(f);
  const bachatOf = (f: string) => mahayogLOf(f) - vyayOf(f);
  const mahayogROf = (f: string) => vyayOf(f) + bachatOf(f);

  /* ── C.3 column layout — fixed text columns + रकम group (dynamic funds + कुल) ── */
  type Col = { key: string; label: string; w: number };
  /**
   * instruction #7 — नकद (Cash) कोई योजना नहीं, सिर्फ़ लेन-देन का माध्यम है.
   * इसलिए Own Fund को 2 column में दिखाओ: नगद (cash) + बैंक (own).
   */
  /**
   * v10 #6 — **अपना कोष (own fund) के 2 column — नगद + बैंक — सबसे पहले**,
   * फिर सारी योजनाएँ। नकद (Cash) कोई योजना नहीं, सिर्फ़ लेन-देन का माध्यम है,
   * इसलिए उसे यहाँ अलग column में दिखाकर अलग जोड़ा/गिना जा सकता है।
   */
  const ownCols: Col[] = [
    { key: 'cash', label: 'नगद', w: 46 },
    { key: 'own', label: 'बैंक', w: 46 },
  ];
  const schemeCols: Col[] = activeFunds
    .filter((f) => f.id !== 'cash' && f.id !== 'own')
    .map((f) => ({ key: f.id, label: f.shortName, w: 46 }));
  /* instruction #10 — पतला layout (चौड़ाई घटाई ताकि एक side phone पर बैठे; बाक़ी zoom ± से) */
  const amtCols: Col[] = [...ownCols, ...schemeCols, { key: '_tot', label: 'कुल', w: 52 }];
  const ownKeys = new Set(ownCols.map((c) => c.key));
  const schemeW = amtCols.filter((c) => c.key !== '_tot' && !ownKeys.has(c.key)).reduce((s, c) => s + c.w, 0);
  const ownW = ownCols.reduce((s, c) => s + c.w, 0);
  const totW = amtCols.find((c) => c.key === '_tot')?.w || 52;
  const leftCols: Col[] = [
    { key: 'date', label: 'दिनांक', w: 44 },
    { key: 'ref', label: 'चेक, DD, इन्वॉइस न. व दिनांक', w: 58 },
    { key: 'party', label: 'किस से प्राप्त किया', w: 72 },
    { key: 'detail', label: 'विवरण', w: 66 },
    { key: 'lf', label: 'L.F.', w: 18 },
  ];
  /* instruction #9 — व्यय side से 'परि. रजि. पृ.' column हटा दिया (ज़रूरत नहीं) */
  const rightCols: Col[] = [
    { key: 'date', label: 'दिनांक', w: 44 },
    { key: 'ref', label: 'वाउचर नं. व दिनांक', w: 58 },
    { key: 'party', label: 'भुगतान किसको किया गया', w: 74 },
    { key: 'detail', label: 'किस कार्य पेटे भुगतान', w: 70 },
    { key: 'lf', label: 'L.F.', w: 18 },
  ];
  /* v10 #3 — zoom-scaled चौड़ाई (cell() भी यही formula लगाता है) */
  const cw = (w: number) => Math.max(6, Math.round(w * zoom));
  const textSum = (cols: Col[]) => cols.reduce((s, c) => s + cw(c.w), 0);
  const amtSum = amtCols.reduce((s, c) => s + cw(c.w), 0);
  const LrowW = cw(16) + textSum(leftCols) + amtSum;
  const RrowW = cw(16) + textSum(rightCols) + amtSum;
  const DIV = 2;
  /* instruction #10 + #15 — दोनों sides = एक table; zoom se chaudii scale hoti hai */
  const tableW = LrowW + RrowW + DIV + 24;

  /** C.5 — नीचे के 3 row (दोनों पक्षों के लिए) */
  type FRow = { line: number; kind: RowKind; label: string; get: (f: string) => number };
  const footersFor = (side: 'L' | 'R'): FRow[] =>
    side === 'L'
      ? [
          { line: L - 2, kind: 'aayYog', label: 'आय योग', get: aayOf },
          { line: L - 1, kind: 'poorvPote', label: 'पूर्व पोते', get: shriOf },
          { line: L, kind: 'mahayogL', label: 'महायोग', get: mahayogLOf },
        ]
      : [
          { line: L - 2, kind: 'vyayYog', label: 'व्यय योग', get: vyayOf },
          { line: L - 1, kind: 'bachat', label: 'बचत पोते', get: bachatOf },
          { line: L, kind: 'mahayogR', label: 'महायोग', get: mahayogROf },
        ];

  type RowKind = 'shri' | 'txn' | 'aayYog' | 'poorvPote' | 'mahayogL' | 'vyayYog' | 'bachat' | 'mahayogR';

  const kindBg = (kind: string) =>
    kind === 'shri'
      ? 'rgba(198,40,40,0.06)'
      : ['aayYog', 'poorvPote', 'mahayogL', 'vyayYog', 'bachat', 'mahayogR'].includes(kind)
        ? 'rgba(27,94,32,0.08)'
        : undefined;
  const kindColor = (kind: string) => {
    /* v10 #7 — नीचे की दूसरी line (पूर्व पोते / बचत पोते): font = लाल + bold */
    if (kind === 'poorvPote' || kind === 'bachat') return '#C62828';
    if (kind === 'shri') return fySettings.shriPoteColor;
    if (['aayYog', 'vyayYog', 'mahayogL', 'mahayogR'].includes(kind)) return fySettings.summaryFontColor;
    if (kind === 'txn') return fySettings.entryFontColor;
    return C.mutedForeground;
  };

  const cell = (
    k: string,
    w: number,
    text: string,
    o: { bold?: boolean; right?: boolean; color?: string; bg?: string; strike?: boolean; lines?: number; sub?: string; px?: number } = {}
  ) => (
    <View
      key={k}
      style={{
        // instruction #10/#15 — zoom se cell ki चौड़ाई + font दोनों scale (एक side fit)
        width: o.px != null ? o.px : cw(w),
        borderRightWidth: StyleSheet.hairlineWidth,
        borderRightColor: '#a9c6b2',
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: '#a9c6b2',
        paddingHorizontal: Math.max(1, Math.round(3 * zoom)),
        paddingVertical: 2,
        justifyContent: 'center',
        backgroundColor: o.bg,
      }}
    >
      <Text
        numberOfLines={o.lines ?? 1}
        style={{
          fontSize: Math.max(6, Math.round(9 * zoom)),
          fontWeight: o.bold ? '800' : '600',
          color: o.color || C.foreground,
          textAlign: o.right ? 'right' : 'left',
          textDecorationLine: o.strike ? 'line-through' : undefined,
        }}
      >
        {text}
      </Text>
      {o.sub ? (
        <Text
          numberOfLines={1}
          style={{
            fontSize: Math.max(5, Math.round(8 * zoom)),
            color: o.color || C.mutedForeground,
            textDecorationLine: o.strike ? 'line-through' : undefined,
          }}
        >
          {o.sub}
        </Text>
      ) : null}
    </View>
  );

  const amtCells = (k: string, get: (f: string) => number, kind: string, showZero: boolean) => {
    const wOf = (id: string) => (amtCols.find((c) => c.key === id) || { w: 70 }).w;
    const mk = (id: string) => {
      /* v10 #6 — कुल = हर column (नगद + बैंक + सारी योजनाएँ) का जोड़ */
      const v = id === '_tot' ? amtCols.filter((c) => c.key !== '_tot').reduce((s, c) => s + get(c.key), 0) : get(id);
      const txt = v === 0 && !showZero ? '' : formatINR(v);
      return cell(`${k}-${id}`, wOf(id), txt, {
        right: true,
        bold: kind !== 'txn',
        color: kind === 'txn' ? fySettings.entryFontColor : kindColor(kind),
        bg: kindBg(kind),
      });
    };
    return amtCols.map((c) => mk(c.key));
  };

  const txnTextCell = (c: Col, t: Transaction, i: number, pre = '') => {
    const cancelled = t.status === 'cancelled';
    const val =
      c.key === 'date'
        ? fmtDate(t.date)
        : c.key === 'ref'
          ? t.reference || ''
          : c.key === 'party'
            ? t.type === 'transfer'
              ? `⇄ ${t.party}`
              : t.party
            : c.key === 'detail'
              ? t.detail || ''
              : c.key === 'lf'
                ? folioOf(t)
                : c.key === 'asset'
                  ? t.assetPage || ''
                  : '';
    /* v13 #10 — L.F. cell अलग से दबाया जा सके → उसी मद का ledger खुले */
    if (c.key === 'lf') {
      return (
        <Pressable
          key={`${pre}t${i}-lf`}
          onPress={() => openLedgerOf(t)}
          style={{ backgroundColor: val ? C.primarySoft : undefined, borderRadius: 4 }}
        >
          {cell(`${pre}t${i}-${c.key}`, c.w, val ? `${val} ›` : '', {
            color: cancelled ? C.expense : C.primary,
            bold: true,
            bg: kindBg('txn'),
          })}
        </Pressable>
      );
    }
    return cell(`${pre}t${i}-${c.key}`, c.w, val, {
      color: cancelled ? C.expense : fySettings.entryFontColor,
      strike: cancelled,
      sub: cancelled ? `रद्द: ${t.cancelReason || '—'}` : undefined,
    });
  };

  const onTxnAction = (t: Transaction) => {
    if (t.status === 'cancelled') {
      Alert.alert(
        'रद्द शुद्धि',
        `${fmtDate(t.date)} · ${t.party}\n${formatINR(sumAmounts(t.amounts))}\nकारण: ${t.cancelReason || '—'}`,
        [{ text: 'ठीक है' }]
      );
      return;
    }
    /* instruction #10 — FY setting: back-date editing बंद तो सिर्फ़ विवरण */
    if (!fySettings.allowBackDateEdit) {
      Alert.alert(
        'विवरण (सुधार बंद)',
        `${fmtDate(t.date)}\nकिससे प्राप्त/भुगतान: ${t.party || '—'}\nविवरण: ${t.detail || '—'}\nराशि: ${formatINR(sumAmounts(t.amounts))}`,
        [{ text: 'बंद' }]
      );
      return;
    }
    Alert.alert('शुद्धि', `${fmtDate(t.date)} · ${t.party}\n${formatINR(sumAmounts(t.amounts))}`, [
      { text: 'बंद', style: 'cancel' },
      { text: 'सुधारें (Edit)', onPress: () => onEdit(t.id) },
      { text: 'रद्द करें…', style: 'destructive', onPress: () => setCancelTxn(t) },
    ]);
  };

  /**
   * instruction #10 — entry par tap → सुधार के लिए खुले;
   * FY setting बंद हो तो सिर्फ़ read-only विवरण.
   */
  const onTxnPress = (t: Transaction) => {
    if (t.status === 'cancelled' || !fySettings.allowBackDateEdit) {
      onTxnAction(t);
      return;
    }
    onEdit(t.id);
  };

  /** C.3/C.7 — Excel-register style table: line# + text cols + रकम group */
  /**
   * v10 #3 — **आय और व्यय की हर line आपस में समानांतर (parallel).**
   * पहले दोनों पक्ष अलग-अलग column थे इसलिए एक की line 15 दूसरी की line 15 के
   * साथ नहीं मिलती थी। अब एक ही row में दोनों पक्ष बैठते हैं → ऊँचाई अपने-आप
   * बराबर, और बीच में हरी विभाजक रेख़ा।
   */
  const zOwnKey = new Set(ownKeys);
  const zOf = (pred: (c: Col) => boolean) => amtCols.filter(pred).reduce((s, c) => s + cw(c.w), 0);
  const zScheme = zOf((c) => c.key !== '_tot' && !zOwnKey.has(c.key));
  const zOwn = zOf((c) => zOwnKey.has(c.key));
  const zTot = cw(totW);

  const renderTable = () => {
    const divider = <View key="div" style={{ width: DIV, backgroundColor: '#1e6048' }} />;
    const mkRow = (
      key: string,
      l: React.ReactNode,
      r: React.ReactNode,
      opt: { lOn?: () => void; rOn?: () => void; lLong?: () => void; rLong?: () => void; lBg?: string; rBg?: string } = {}
    ) => (
      <View key={key} style={{ flexDirection: 'row' }}>
        <View style={{ width: LrowW }}>
          <Pressable
            disabled={!opt.lOn}
            onPress={opt.lOn || (() => undefined)}
            onLongPress={opt.lLong}
            style={[{ flexDirection: 'row', flexGrow: 1 }, opt.lBg ? { backgroundColor: opt.lBg } : null]}
          >
            {l}
          </Pressable>
        </View>
        {divider}
        <View style={{ width: RrowW }}>
          <Pressable
            disabled={!opt.rOn}
            onPress={opt.rOn || (() => undefined)}
            onLongPress={opt.rLong}
            style={[{ flexDirection: 'row', flexGrow: 1 }, opt.rBg ? { backgroundColor: opt.rBg } : null]}
          >
            {r}
          </Pressable>
        </View>
      </View>
    );

    const colsOf = (side: 'L' | 'R') => (side === 'L' ? leftCols : rightCols);
    const zoneOf = (side: 'L' | 'R') => (side === 'L' ? zoneInc : zoneExp);
    const textBase = (cols: Col[]) => cols.reduce((s, c) => s + c.w, 0);

    const band = (w: number, color: string, text: string) => (
      <View style={{ width: w, backgroundColor: color, paddingVertical: 5, paddingHorizontal: 4 }}>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 11, textAlign: 'center' }}>{text}</Text>
      </View>
    );

    const head1 = (side: 'L' | 'R') => [
      cell(`${side}-h1-a`, 0, '', { bold: true, bg: '#dceee4', px: cw(16) + textSum(colsOf(side)) }),
      zScheme > 0 ? cell(`${side}-h1-b`, 0, 'योजना (₹)', { bold: true, right: true, bg: '#dceee4', px: zScheme }) : null,
      zOwn > 0 ? cell(`${side}-h1-c`, 0, 'अपना कोष (₹)', { bold: true, right: true, bg: '#dceee4', px: zOwn }) : null,
      cell(`${side}-h1-d`, 0, 'कुल (₹)', { bold: true, right: true, bg: '#dceee4', px: zTot }),
    ];

    const head2 = (side: 'L' | 'R') => [
      cell(`${side}-h2-line`, 16, '#', { bold: true, lines: 2, bg: '#eaf5ec' }),
      ...colsOf(side).map((c) => cell(`${side}-h2-${c.key}`, c.w, c.label, { bold: true, lines: 3, bg: '#eaf5ec' })),
      ...amtCols.map((c) =>
        cell(`${side}-h2a-${c.key}`, c.w, c.label, { bold: true, right: true, lines: 2, bg: '#eaf5ec' })
      ),
    ];

    /* line 1 — श्री पोते राशि (प्राप्ति) / उसके समानांतर व्यय की खाली line */
    const shriCells = (side: 'L' | 'R') => {
      const isL = side === 'L';
      const cols = colsOf(side);
      return [
        cell(`${side}-sline`, 16, '1', { bold: true, color: '#78909c', bg: kindBg('shri') }),
        ...cols.map((c) =>
          isL && c.key === 'party'
            ? cell(`${side}-sparty`, c.w, 'श्री पोते राशि', {
                bold: true,
                color: fySettings.shriPoteColor,
                bg: kindBg('shri'),
                sub: cfLabel,
                lines: 2,
              })
            : cell(`${side}-s-${c.key}`, c.w, isL && c.key === 'date' ? fmtDate(prevLastDate) : '', {
                bg: kindBg('shri'),
              })
        ),
        ...(isL
          ? amtCells(`${side}-s`, shriOf, 'shri', true)
          : amtCells(`${side}-s`, () => 0, 'txn', false)),
      ];
    };

    const bodyCells = (side: 'L' | 'R', i: number) => {
      const cols = colsOf(side);
      const t = zoneOf(side)[i];
      const lineNo = i + 2;
      if (!t) {
        return [
          cell(`${side}-bl`, 16, String(lineNo), { color: '#78909c' }),
          ...cols.map((c) => cell(`${side}-bt-${c.key}`, c.w, '')),
          ...amtCells(`${side}-ba`, () => 0, 'txn', false),
        ];
      }
      return [
        cell(`${side}-tl`, 16, String(lineNo), { color: '#78909c' }),
        ...cols.map((c) => txnTextCell(c, t, i, `${side}-`)),
        ...amtCells(`${side}-t${i}`, (f: string) => Number(t.amounts[f]) || 0, 'txn', false),
      ];
    };

    const footCells = (side: 'L' | 'R', fr: FRow) => {
      const cols = colsOf(side);
      const fc = kindColor(fr.kind);
      const bg = kindBg(fr.kind);
      return [
        cell(`${side}-fl-${fr.kind}`, 16, String(fr.line), { bold: true, color: fc, bg }),
        ...cols.map((c) =>
          c.key === 'party'
            ? cell(`${side}-fp-${fr.kind}`, c.w, fr.label, { bold: true, color: fc, bg, lines: 2 })
            : cell(`${side}-ft-${fr.kind}-${c.key}`, c.w, '', { bg, color: fc })
        ),
        ...amtCells(`${side}-f${fr.kind}`, fr.get, fr.kind, true),
      ];
    };

    const fL = footersFor('L');
    const fR = footersFor('R');

    return (
      <View>
        {mkRow('band', band(LrowW, '#1e6048', 'प्राप्ति (आय)'), band(RrowW, '#3d5a4a', 'भुगतान (व्यय)'))}
        {mkRow('gh', head1('L'), head1('R'))}
        {mkRow('ch', head2('L'), head2('R'))}
        {mkRow('shri', shriCells('L'), shriCells('R'))}
        {zoneInc.map((_, i) => {
          const a = zoneInc[i];
          const b = zoneExp[i];
          return mkRow(
            `z${i}`,
            bodyCells('L', i),
            bodyCells('R', i),
            {
              lOn: a ? () => onTxnPress(a) : onNewEntry,
              rOn: b ? () => onTxnPress(b) : onNewEntry,
              lLong: a ? () => onTxnAction(a) : undefined,
              rLong: b ? () => onTxnAction(b) : undefined,
              lBg: a && a.status === 'cancelled' ? 'rgba(163,78,70,0.07)' : undefined,
              rBg: b && b.status === 'cancelled' ? 'rgba(163,78,70,0.07)' : undefined,
            }
          );
        })}
        {fL.map((fr, i) => mkRow(`f${i}`, footCells('L', fr), footCells('R', fR[i])))}
      </View>
    );
  };

  /* ── instruction #4 — cashbook का HTML (PDF के लिए) और rows (Excel के लिए) ── */
  const H = (s: unknown) =>
    String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

  const sideTableHtml = (
    pageIdx: number,
    side: 'income' | 'expense',
    ops: Record<string, number>,
    pageTx: Transaction[]
  ): string => {
    const cols = side === 'income' ? leftCols : rightCols;
    const list = pageTx.filter((t) => sideOfTx(t) === side);
    const act = list.filter((t) => t.status === 'active');
    const opening = (f: string) => Number(ops[f]) || 0;
    const got = (f: string) => act.reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
    const mahayog = (f: string) => opening(f) + got(f);
    const bachat = (f: string) => mahayog(f) - got(f);
    const amt = (get: (f: string) => number): string[] =>
      amtCols.map((c) => {
        const v = c.key === '_tot' ? amtCols.filter((x) => x.key !== '_tot').reduce((s, x) => s + get(x.key), 0) : get(c.key);
        return v === 0 ? '' : formatINR(v);
      });
    const head =
      `<tr><th class="c">#</th>` +
      cols.map((c) => `<th>${H(c.label)}</th>`).join('') +
      amtCols.map((c) => `<th class="r">${H(c.label)}</th>`).join('') +
      `</tr>`;
    const line = (n: number, texts: Record<string, string>, a: string[], bold = false, strike = false) =>
      `<tr class="${bold ? 'b' : ''}"><td class="c">${n}</td>` +
      cols
        .map((c) => {
          const v = H(texts[c.key] || '');
          return `<td>${strike ? `<s>${v}</s>` : v}</td>`;
        })
        .join('') +
      a.map((v) => `<td class="r">${H(v)}</td>`).join('') +
      `</tr>`;

    const blank = { date: '', ref: '', party: '', detail: '', lf: '' };
    const rows: string[] = [line(1, blank, amt(opening), true)];
    let n = 2;
    for (const t of list) {
      if (n > L - 3) break;
      const cancelled = t.status === 'cancelled';
      const texts: Record<string, string> = {
        date: fmtDate(t.date),
        ref: t.reference || '',
        party: t.type === 'transfer' ? `⇄ ${t.party || ''}` : t.party || '',
        detail: t.detail ? (cancelled ? `${t.detail} · रद्द` : t.detail) : cancelled ? 'रद्द' : '',
        lf: folioOf(t),
      };
      rows.push(line(n, texts, amt((f) => Number(t.amounts[f]) || 0), false, cancelled));
      n += 1;
    }
    while (n <= L - 3) {
      rows.push(line(n, blank, amt(() => 0)));
      n += 1;
    }
    const footers =
      side === 'income'
        ? [
            { n: L - 2, label: 'आय योग', get: got },
            { n: L - 1, label: 'पूर्व पोते', get: opening },
            { n: L, label: 'महायोग', get: mahayog },
          ]
        : [
            { n: L - 2, label: 'व्यय योग', get: got },
            { n: L - 1, label: 'बचत पोते', get: bachat },
            { n: L, label: 'महायोग', get: (f: string) => got(f) + bachat(f) },
          ];
    for (const ft of footers) {
      rows.push(line(ft.n, { ...blank, party: ft.label }, amt(ft.get), true));
    }
    return `<table><thead>${head}</thead><tbody>${rows.join('')}</tbody></table>`;
  };

  const pageBlockHtml = (pageIdx: number): string => {
    const page = fyPages[pageIdx];
    if (!page) return '';
    const ops = pageOpenings(
      activeFunds.map((f) => ({ id: f.id, openingBalance: fundOpening(f) })),
      fyPages,
      fyTransactions,
      pageIdx
    );
    const pageTx = txnsOfPageIdx(pageIdx);
    return `<div class="pg"><div class="head"><h1>${H(activePanchayat.name)} — रोकड़ बही (Cashbook)</h1>
<div class="sm">${H(activePanchayat.block)} · ${H(activePanchayat.district)} · वित्तीय वर्ष ${H(activeFy.label)}</div>
<div class="sm"><b>पृष्ठ ${page.pageNo}</b> · ${H(page.label)}</div></div>
<div class="note"><b>आय पक्ष (प्राप्ति)</b></div>${sideTableHtml(pageIdx, 'income', ops, pageTx)}
<div class="note" style="margin-top:8px"><b>व्यय पक्ष (भुगतान)</b></div>${sideTableHtml(pageIdx, 'expense', ops, pageTx)}
<div class="note">पृष्ठ ${page.pageNo}/${fyPages.length} · बनाया गया ${new Date().toLocaleString('en-GB')}</div></div>`;
  };

  /**
   * v12 #20 — share से जो **Excel (.xlsx)** बनता है उसमें भी वही dual-grid रहे
   * जो cashbook page पर दिखता है: एक ही row में "आय पक्ष | व्यय पक्ष",
   * ऊपर वही header, नीचे वही 3 footer rows (आय योग/पूर्व पोते/महायोग + व्यय योग/बचत पोते/महायोग)।
   */
  const pageXlsHtml = (pageIdx: number): string => {
    const page = fyPages[pageIdx];
    if (!page) return '';
    const ops = pageOpenings(
      activeFunds.map((f) => ({ id: f.id, openingBalance: fundOpening(f) })),
      fyPages,
      fyTransactions,
      pageIdx
    );
    const pageTx = txnsOfPageIdx(pageIdx);
    const inc = pageTx.filter((t) => sideOfTx(t) === 'income');
    const exp = pageTx.filter((t) => sideOfTx(t) === 'expense');
    const shriOf = (f: string) => Number(ops[f]) || 0;
    const aayOf = (f: string) =>
      inc.filter((t) => t.status === 'active').reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
    const vyayOf = (f: string) =>
      exp.filter((t) => t.status === 'active').reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
    const mahayogLOf = (f: string) => shriOf(f) + aayOf(f);
    const bachatOf = (f: string) => mahayogLOf(f) - vyayOf(f);
    const mahayogROf = (f: string) => vyayOf(f) + bachatOf(f);

    const zoneOf = (side: 'income' | 'expense'): (Transaction | null)[] => {
      const lst = pageTx.filter((t) => sideOfTx(t) === side);
      const z: (Transaction | null)[] = [];
      for (const t of lst) {
        if (z.length >= txnMax) break;
        z.push(t);
        for (let b = 0; b < blankLines && z.length < txnMax; b++) z.push(null);
      }
      while (z.length < txnMax) z.push(null);
      return z;
    };
    const zi = zoneOf('income');
    const ze = zoneOf('expense');

    const colsOf = (side: 'income' | 'expense') => (side === 'income' ? leftCols : rightCols);
    const textOf = (t: Transaction | null, side: 'income' | 'expense'): string[] => {
      const cols = colsOf(side);
      if (!t) return cols.map(() => '');
      const cancelled = t.status === 'cancelled';
      const m: Record<string, string> = {
        date: fmtDate(t.date),
        ref: t.reference || '',
        party: t.type === 'transfer' ? `⇄ ${t.party || ''}` : t.party || '',
        detail: t.detail ? (cancelled ? `${t.detail} · रद्द` : t.detail) : cancelled ? 'रद्द' : '',
        lf: folioOf(t),
      };
      return cols.map((c) => m[c.key] || '');
    };
    const fmtAmt = (v: number) => (v === 0 ? '' : formatINR(v));
    const amtsOfGet = (get: (f: string) => number): string[] =>
      amtCols.map((c) => fmtAmt(c.key === '_tot' ? amtCols.filter((x) => x.key !== '_tot').reduce((s, x) => s + get(x.key), 0) : get(c.key)));
    const amtsOfTx = (t: Transaction | null): string[] =>
      amtsOfGet((f) => (t ? Number(t.amounts[f]) || 0 : 0));

    const nL = 1 + leftCols.length + amtCols.length;
    const nR = 1 + rightCols.length + amtCols.length;
    const nAll = nL + nR;
    const th = (v: string, span?: number) => `<th${span ? ` colspan="${span}"` : ''}>${H(v)}</th>`;
    const td = (v: string, cls?: string) => `<td${cls ? ` class="${cls}"` : ''}>${H(v)}</td>`;
    const tr = (cells: string[]) => `<tr>${cells.join('')}</tr>`;

    const rows: string[] = [];
    rows.push(tr([th(`कार्यालय ग्राम पंचायत — ${activePanchayat.name}`, nAll)]));
    rows.push(
      tr([
        th(
          `${activePanchayat.block || ''} · ${activePanchayat.district || ''} · वित्तीय वर्ष ${activeFy.label} · रोकड़ बही (Cashbook)`,
          nAll
        ),
      ])
    );
    rows.push(tr([th(`पृष्ठ ${page.pageNo}/${fyPages.length} · ${page.label}`, nAll)]));
    rows.push(tr([th('आय पक्ष (प्राप्ति)', nL), th('व्यय पक्ष (भुगतान)', nR)]));
    rows.push(
      tr([
        th('#'),
        ...colsOf('income').map((c) => th(c.label)),
        ...amtCols.map((c) => th(c.label)),
        th('#'),
        ...colsOf('expense').map((c) => th(c.label)),
        ...amtCols.map((c) => th(c.label)),
      ])
    );
    /* line 1 — दोनों ओर पूर्व पोते (opening) */
    rows.push(
      tr([
        td('1', 'c'),
        ...textOf(null, 'income'),
        ...amtsOfGet(shriOf),
        td('1', 'c'),
        ...textOf(null, 'expense'),
        ...amtsOfGet(shriOf),
      ])
    );
    for (let i = 0; i < txnMax; i++) {
      rows.push(
        tr([
          td(String(i + 2), 'c'),
          ...textOf(zi[i], 'income'),
          ...amtsOfTx(zi[i]),
          td(String(i + 2), 'c'),
          ...textOf(ze[i], 'expense'),
          ...amtsOfTx(ze[i]),
        ])
      );
    }
    const foot: { n: number; l: string; r: string; gl: (f: string) => number; gr: (f: string) => number }[] = [
      { n: L - 2, l: 'आय योग', r: 'व्यय योग', gl: aayOf, gr: vyayOf },
      { n: L - 1, l: 'पूर्व पोते', r: 'बचत पोते', gl: shriOf, gr: bachatOf },
      { n: L, l: 'महायोग', r: 'महायोग', gl: mahayogLOf, gr: mahayogROf },
    ];
    for (const ft of foot) {
      rows.push(
        tr([
          td(String(ft.n), 'c'),
          ...textOf(null, 'income'),
          ...amtsOfGet(ft.gl),
          td(String(ft.n), 'c'),
          ...textOf(null, 'expense'),
          ...amtsOfGet(ft.gr),
        ])
      );
    }
    return `<table><tbody>${rows.join('')}</tbody></table>`;
  };

  const rangeIdx = (): [number, number] => {
    const a = (parseInt(rangeFrom, 10) || 1) - 1;
    const b = (parseInt(rangeTo, 10) || 1) - 1;
    const from = Math.max(0, Math.min(fyPages.length - 1, Math.min(a, b)));
    const to = Math.max(0, Math.min(fyPages.length - 1, Math.max(a, b)));
    return [from, to];
  };
  const shareTitle = () => {
    const ix = selectedIdxs().filter((i) => fyPages[i]);
    if (!ix.length) return `Cashbook ${activeFy.label}`;
    const first = fyPages[ix[0]].pageNo;
    const last = fyPages[ix[ix.length - 1]].pageNo;
    return `Cashbook ${activeFy.label} — पृष्ठ ${first}${first === last ? '' : `–${last}`}`;
  };
  const shareBody = () => {
    const ix = selectedIdxs().filter((i) => fyPages[i]);
    if (!ix.length) return pageBlockHtml(rangeIdx()[0]);
    let out = '';
    for (const i of ix) out += pageBlockHtml(i);
    return out;
  };
  /* v12 #20 — Excel के लिए अलग body: वही dual-grid जो स्क्रीन पर दिखता है */
  const shareXlsBody = () => {
    const ix = selectedIdxs().filter((i) => fyPages[i]);
    if (!ix.length) return pageXlsHtml(rangeIdx()[0]);
    let out = '';
    for (const i of ix) out += pageXlsHtml(i);
    return out;
  };
  const pageOpts = fyPages.map((p, i) => ({ key: String(i + 1), label: `पृष्ठ ${p.pageNo} · ${p.label}` }));

  /* ═══ v12 #8 — share में page selection: पृष्ठ क्रम में भी, और मैन्युअल भी
       जैसे "1-3, 5, 7-9" — दोनों का चुनाव ═══ */
  const [manualRange, setManualRange] = useState('');
  /**
   * v13 #9 — **off-by-one ठीक.** मैन्युअल चुनाव user 1-based लिखता है ("1-3, 5"),
   * पर `selectedIdxs()` इसे 0-based index मानता था → पन्ना 1 कभी नहीं जुड़ता था और
   * आख़िरी पन्ना बाहर हो जाता था। अब parseManual 0-based index लौटाता है।
   */
  const parseManual = (s: string): number[] => {
    const n = fyPages.length;
    const out = new Set<number>();
    for (const raw of s.split(/[,;]+/)) {
      const t = raw.trim();
      if (!t) continue;
      const m = t.match(/^(\d+)\s*[-–]\s*(\d+)$/);
      if (m) {
        const a = parseInt(m[1], 10);
        const b = parseInt(m[2], 10);
        const lo = Math.max(1, Math.min(a, b));
        const hi = Math.min(n, Math.max(a, b));
        for (let i = lo; i <= hi; i++) out.add(i - 1);
      } else if (/^\d+$/.test(t)) {
        const v = parseInt(t, 10);
        if (v >= 1 && v <= n) out.add(v - 1);
      }
    }
    return [...out].sort((a, b) => a - b);
  };
  /** दिखाने के लिए 1-based */
  const manualLabel = (s: string): string => parseManual(s).map((i) => i + 1).join(', ');
  const selectedIdxs = (): number[] => {
    const m = manualRange.trim() ? parseManual(manualRange) : [];
    if (m.length) return m;
    const [a, b] = rangeIdx();
    const out: number[] = [];
    for (let i = a; i <= b; i++) out.push(i);
    return out;
  };


  return (
    <View style={[styles.page, { backgroundColor: fySettings.pageBackground }]}>
      {/* instruction #4 — share पर click → पहले page range, फिर PDF/Excel file */}
      {shareOpen ? (
        <Modal visible animationType="slide" onRequestClose={() => setShareOpen(false)}>
          <View style={[styles.page, { paddingTop: 50 }]}>
            <Header title="Cashbook share — पृष्ठ सीमा" onBack={() => setShareOpen(false)} badge="S-50" />
            <ScrollView contentContainerStyle={styles.pad}>
              <Text style={styles.hint}>
                {/* v11 #11 — RN me <b> tag nahi chalta (undefined component = crash) */}
                पहले पृष्ठ चुनें (page range), फिर format — यहाँ से असली{' '}
                <Text style={{ fontWeight: '900' }}>PDF</Text> या{' '}
                <Text style={{ fontWeight: '900' }}>.xlsx</Text> file जाएगी, text message नहीं।
              </Text>
              <SelectField
                label="पहला पृष्ठ (क्रम में)"
                value={pageOpts[rangeIdx()[0]]?.label || '—'}
                options={pageOpts}
                onSelect={(k) => {
                  setManualRange('');
                  setRangeFrom(k);
                }}
                hint="सारे पृष्ठ क्रम में ही दिखते हैं — पहला चुनें।"
              />
              <SelectField
                label="आख़िरी पृष्ठ (क्रम में)"
                value={pageOpts[rangeIdx()[1]]?.label || '—'}
                options={pageOpts}
                onSelect={(k) => {
                  setManualRange('');
                  setRangeTo(k);
                }}
              />
              {/* v12 #8 — मैन्युअल सीमा: 1-3, 5, 7-9 जैसा चुनाव भी */}
              <Text style={styles.section}>या मैन्युअल चुनाव (manual)</Text>
              <Field
                label="पृष्ठ संख्या — जैसे 1-3, 5, 7-9"
                value={manualRange}
                onChangeText={setManualRange}
                placeholder="1-3, 5, 7-9"
                bg="#ffffff"
              />
              <View style={styles.chips}>
                <Pressable style={styles.chip} onPress={() => setManualRange(`1-${fyPages.length}`)}>
                  <Text style={{ color: C.foreground, fontWeight: '700', fontSize: 12 }}>सब ({fyPages.length})</Text>
                </Pressable>
                <Pressable style={styles.chip} onPress={() => setManualRange(String(safeIdx + 1))}>
                  <Text style={{ color: C.foreground, fontWeight: '700', fontSize: 12 }}>सिर्फ़ यह पन्ना</Text>
                </Pressable>
                <Pressable style={styles.chip} onPress={() => setManualRange('')}>
                  <Text style={{ color: C.foreground, fontWeight: '700', fontSize: 12 }}>मैन्युअल हटाएँ</Text>
                </Pressable>
              </View>
              <Text style={styles.meta}>
                {manualRange.trim()
                  ? parseManual(manualRange).length
                    ? `मैन्युअल चुनाव लागू: ${manualLabel(manualRange)} — कुल ${parseManual(manualRange).length} पृष्ठ (ऊपर के dropdown अनदेखे)।`
                    : 'मैन्युअल में कोई मान्य पृष्ठ नहीं मिला — ऊपर का range लागू रहेगा।'
                  : `चुनी गई सीमा: पृष्ठ ${rangeIdx()[0] + 1} से ${rangeIdx()[1] + 1} (${rangeIdx()[1] - rangeIdx()[0] + 1} पृष्ठ)`}
              </Text>
              <Btn
                label="Share — PDF (A4) / Excel (.xlsx)"
                icon="share-2"
                onPress={async () => {
                  const t = shareTitle();
                  const b = shareBody();
                  /* v12 #20 — Excel में स्क्रीन जैसा dual-grid, PDF में A4 पन्ने */
                  const x = shareXlsBody();
                  setShareOpen(false);
                  await askAndShare(t, b, true, x);
                }}
              />
              <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setShareOpen(false)} />
            </ScrollView>
          </View>
        </Modal>
      ) : null}
      <Header
        title="Cashbook"
        /* v12 #9 — header में **कोई तारीख़ नहीं**; तारीख़ सिर्फ़ नीचे page-navigator में
           (एक ही जगह एक ही date दिखे — दो-दो date से उलझन होती थी) */
        eyebrow={`${activePanchayat.name} · ${activeFy.label} · पृष्ठ ${curPage ? curPage.pageNo : '—'}`}
        onBack={back}
        badge="S-07"
        action={
          <IconBtn
            name="share-2"
            onPress={() => {
              setRangeFrom(String(safeIdx + 1));
              setRangeTo(String(safeIdx + 1));
              setManualRange('');
              setShareOpen(true);
            }}
          />
        }
      />
      {/* Page navigator — Excel-style manual pagination (user request #1) */}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: '#0e3d2e' }}>
        <Pressable
          onPress={() => setPageIdx(Math.max(0, safeIdx - 1))}
          style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>◀</Text>
        </Pressable>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12, flex: 1, textAlign: 'center' }}>
          {curPage
            ? /* v12 #9 — नेविगेशन पट्टी पर **सिर्फ़ एक ही date** (label = DD-MM-YYYY) */
              `${curPage.label} · ${safeIdx + 1}/${fyPages.length}`
            : 'कोई page नहीं'}
        </Text>
        <Pressable
          onPress={() => setPageIdx(Math.min(fyPages.length - 1, safeIdx + 1))}
          style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>▶</Text>
        </Pressable>
        {/* instruction #15 — zoom: pinch nahi to ± se page chhota/bada */}
        <Pressable
          onPress={() => setZoom((z) => Math.max(0.5, Math.round((z - 0.1) * 10) / 10))}
          style={{ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>−</Text>
        </Pressable>
        <Pressable
          onPress={() => setZoom(1)}
          style={{ paddingHorizontal: 8, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.28)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 11 }}>{Math.round(zoom * 100)}%</Text>
        </Pressable>
        <Pressable
          onPress={() => setZoom((z) => Math.min(1.8, Math.round((z + 0.1) * 10) / 10))}
          style={{ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>+</Text>
        </Pressable>
        <Pressable
          /* v11 #3 — कहीं से भी "आज के पन्ने पर जाएँ" */
          onPress={() => setWantDate(todayInFy())}
          style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, backgroundColor: '#2f8f6b' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12 }}>आज</Text>
        </Pressable>
        <Pressable
          onPress={() => setPageMenuOpen(true)}
          style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, backgroundColor: '#f0b429' }}
        >
          <Text style={{ color: '#123b2c', fontWeight: '800', fontSize: 12 }}>+ Page</Text>
        </Pressable>
      </View>
      <ScrollView horizontal contentContainerStyle={{ minWidth: '100%' }}>
        <ScrollView contentContainerStyle={{ padding: 8, paddingBottom: 40, minWidth: tableW }}>
          <Text style={styles.hint}>
            {L} lines · txn lines {txnMax} · C.3 dual grid: दिनांक / चेक / विवरण / L.F. + नकद व बैंक columns · bottom-3 auto (C.5)
          </Text>
          <View style={styles.row}>
            <Btn label="+ Entry" icon="plus" onPress={() => go('entry')} />
          </View>

          {/* v11 #23 — यहाँ पहले scheme-wise balance (✎ pencil) दिखता था; अब असली
              Excel cashbook जैसी header-details: पंचायत का पूरा नाम + पृष्ठ क्रमांक + तिथि */}
          <View style={{ borderWidth: 1, borderColor: '#9db9a8', borderRadius: 8, backgroundColor: '#ffffff', paddingHorizontal: 10, paddingVertical: 8, marginBottom: 8, gap: 3 }}>
            <Text style={{ fontSize: 14, fontWeight: '900', color: '#123b2c', textAlign: 'center' }}>
              {/* v12 #31 — पूरा शीर्षक: कार्यालय ग्राम पंचायत … पंचायत समिति … (सिर्फ़ नाम नहीं) */}
              कार्यालय ग्राम पंचायत — {activePanchayat.name}
            </Text>
            <Text style={{ fontSize: 11, fontWeight: '700', color: '#2b4a3a', textAlign: 'center' }}>
              {activePanchayat.block ? `पंचायत समिति — ${activePanchayat.block}` : ''}
              {activePanchayat.block && activePanchayat.district ? ' · ' : ''}
              {activePanchayat.district ? `ज़िला — ${activePanchayat.district}` : ''}
            </Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 6, marginTop: 2 }}>
              <Text style={{ fontSize: 11, fontWeight: '800', color: '#123b2c' }}>
                रोकड़ बही (Cashbook)
              </Text>
              <Text style={{ fontSize: 11, fontWeight: '800', color: '#123b2c' }}>
                वित्तीय वर्ष {activeFy.label}
              </Text>
            </View>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 6 }}>
              <Text style={{ fontSize: 12, fontWeight: '900', color: '#C62828' }}>
                पृष्ठ क्रमांक {curPage ? curPage.pageNo : '—'} / {fyPages.length}
              </Text>
              <Text style={{ fontSize: 12, fontWeight: '900', color: '#C62828' }}>
                तिथि {pageDateOfIdx(safeIdx) ? fmtDate(pageDateOfIdx(safeIdx)) : '—'}
              </Text>
            </View>
            <Text style={{ fontSize: 10, color: '#5a6b62', textAlign: 'center' }}>
              {curPage ? curPage.label : ''} · रिकॉर्ड {L} लाइन प्रति पृष्ठ
            </Text>
          </View>

          {/* Dual page — side-by-side प्राप्ति | भुगतान grid (C.7) */}
          <View
            style={{
              backgroundColor: '#f3faf3',
              borderWidth: 2,
              borderColor: '#1e6048',
              minHeight: 400,
            }}
          >
            {renderTable()}
          </View>

          <Text style={[styles.meta, { marginTop: 8 }]}>
            Long-press = सुधार/रद्द · खाली cell tap = नई entry · Summary lines auto · Page {safeIdx + 1}/{fyPages.length} · + Page (Excel जैसा, बीच में भी insert)
          </Text>
        </ScrollView>
      </ScrollView>
      {/* ═══ v12 #18 — Works page (S-18) जैसा नीचे-दायीं तरफ़ floating "+" —
          यहीं से income / expenditure एंट्री जुड़ती है ═══ */}
      <Pressable
        onPress={onNewEntry}
        accessibilityLabel="नई एंट्री जोड़ें"
        style={({ pressed }) => ({
          position: 'absolute',
          right: 18,
          bottom: 26,
          width: 58,
          height: 58,
          borderRadius: 29,
          backgroundColor: pressed ? C.darkForest : C.primary,
          alignItems: 'center',
          justifyContent: 'center',
          elevation: 8,
          shadowColor: '#000',
          shadowOpacity: 0.3,
          shadowRadius: 6,
          shadowOffset: { width: 0, height: 3 },
          zIndex: 20,
        })}
      >
        <Feather name="plus" size={28} color={C.primaryForeground} />
      </Pressable>

      {/* ═══ v12 #5 — "+ Page" का मेन्यू: जोड़ें / insert / पन्ना हटाएँ / इस पन्ने की entries मिटाएँ ═══ */}
      <Modal visible={pageMenuOpen} transparent animationType="fade" onRequestClose={() => setPageMenuOpen(false)}>
        <ModalBody title="+ Page — क्या करना है?" onClose={() => setPageMenuOpen(false)}>
          <Btn label="अगला page जोड़ें" icon="plus" onPress={() => { setPageMenuOpen(false); addPage(); }} />
          <Btn
            label="इस page के बाद insert"
            icon="plus"
            variant="soft"
            onPress={() => {
              setPageMenuOpen(false);
              if (curPage) insertPageAfter(curPage.id);
            }}
          />
          <Btn
            label="इस page को हटाएँ (delete page)"
            icon="trash-2"
            variant="outline"
            onPress={() => {
              setPageMenuOpen(false);
              if (!curPage) return;
              Alert.alert(
                'पन्ना हटाएँ?',
                `पृष्ठ ${curPage.pageNo} हटेगा। उस पर की entries बिना पन्ने की (unassigned) हो जाएँगी — कोई data नष्ट नहीं होगा।`,
                [
                  { text: 'रहने दें', style: 'cancel' },
                  { text: 'हटाएँ', style: 'destructive', onPress: () => deletePage(curPage.id) },
                ]
              );
            }}
          />
          <Btn
            label="इस page की सारी entries मिटाएँ (erase)"
            icon="trash-2"
            variant="danger"
            onPress={() => {
              setPageMenuOpen(false);
              setEraseOpen(true);
            }}
          />
          <Text style={styles.meta}>
            erase = उस पन्ने की हर entry स्थायी रूप से मिट जाएगी और **audit trail में भी नहीं रहेगी** — PIN कन्फर्म के बाद
            ही चलेगा। पन्ना ख़ाली रहेगा (हटेगा नहीं)।
          </Text>
        </ModalBody>
      </Modal>

      <PinModal
        open={eraseOpen}
        title={`पृष्ठ ${curPage ? curPage.pageNo : ''} की entries मिटाएँ — PIN`}
        onCancel={() => setEraseOpen(false)}
        onOk={() => {
          setEraseOpen(false);
          const ids = pageTxnIds();
          if (!ids.length) {
            Alert.alert('कुछ मिटाने को नहीं', 'इस पन्ने पर कोई entry नहीं है।');
            return;
          }
          Alert.alert(
            `${ids.length} entries मिटाएँ?`,
            'यह पूरी तरह स्थायी है — ये entries आगे कहीं (audit समेत) नहीं दिखेंगी।',
            [
              { text: 'रहने दें', style: 'cancel' },
              {
                text: 'हाँ, मिटाएँ',
                style: 'destructive',
                onPress: () => {
                  const n = purgeTransactions(ids);
                  Alert.alert('मिटा दिया', `${n} entries स्थायी रूप से मिटा दी गईं।`);
                },
              },
            ]
          );
        }}
      />

      {cancelTxn ? (
        <CancelModal
          txn={cancelTxn}
          onCancel={() => setCancelTxn(null)}
          onConfirm={async (reason) => {
            const r = await cancelTransaction(cancelTxn.id, reason);
            setCancelTxn(null);
            if (!r.ok) Alert.alert(r.error || 'रद्द नहीं हुआ');
          }}
        />
      ) : null}
    </View>
  );
}

function EntryScreen({ back, editTxnId, onClearEdit }: { back: () => void; editTxnId?: string | null; onClearEdit?: () => void }) {
  const {
    activeFunds, addTransaction, updateTransaction, categories, fyTransactions, addTransferCashToBank,
    activeFy, getTransaction, works, addCategory, renameCategory, archiveCategory,
    fySettings, updateFySettings, pageOptionsForDate, ensurePageForDate,
    /* v11 #8 — vendor dropdown + उसी पन्ने से नया vendor जोड़ना */
    fundOpening, vendors, addVendor, workerRolls,
  } = useStore();
  const editTxn = editTxnId ? getTransaction(editTxnId) : null;
  /* v12 #30 — EntryScreen बंद होते ही edit id हमेशा साफ़ (Back बटन या फ़ोन का back — दोनों पर)।
     तभी जाकर cashbook की ख़ाली जगह tap करने पर "नई entry" खुलती है, पुरानी entry का सुधार नहीं। */
  // eslint-disable-next-line react-hooks/exhaustive-deps
  React.useEffect(() => () => onClearEdit?.(), []);
  const [type, setType] = useState<'income' | 'expense'>(editTxn ? (editTxn.type === 'expense' ? 'expense' : 'income') : 'income');
  const [date, setDate] = useState(editTxn?.date || toIsoLocal(new Date()));
  /* v9 #3 — तारीख़ भरते ही पूछो: इसी तारीख़ का कैशबुक पन्ना या अगला उपलब्ध पन्ना
     (अगली तारीख़ suggestion में)। एक पन्ने पर सारी तारीख़ एक जैसी रहती हैं। */
  const [pagePick, setPagePick] = useState<{ mode: 'own' } | { mode: 'next'; pageId: string }>({ mode: 'own' });
  const [promptedOn, setPromptedOn] = useState<string>(editTxn ? editTxn.date : '');

  const askPageForDate = (d: string) => {
    if (editTxnId) return; // सुधार में पन्ना वही रहता है (तारीख़ बदली तो save पर उस तारीख़ का पन्ना बनेगा)
    if (!isValidIsoDate(d) || promptedOn === d) return;
    setPromptedOn(d);
    setPagePick({ mode: 'own' });
    const nxt = pageOptionsForDate(d).next;
    if (!nxt) return; // अगला पन्ना नहीं है → सिर्फ़ इसी तारीख़ का पन्ना
    Alert.alert(
      'किस कैशबुक पन्ने पर डालें?',
      `${fmtDate(d)} की entry के लिए चुनें।\n\nएक पन्ने पर सिर्फ़ एक ही तारीख़ रहती है — इसलिए दूसरी तारीख़ चुनने पर उस तारीख़ का नया पन्ना बन जाएगा।`,
      [
        {
          text: `सुझाव: अगला पन्ना — ${fmtDate(nxt.date)} (${nxt.label})`,
          onPress: () => {
            setPagePick({ mode: 'next', pageId: nxt.pageId });
            setDate(nxt.date);
            setPromptedOn(nxt.date);
          },
        },
        { text: `${fmtDate(d)} का नया पन्ना बनाएँ`, onPress: () => setPagePick({ mode: 'own' }) },
        { text: 'बाद में', style: 'cancel' },
      ]
    );
  };
  const [party, setParty] = useState(editTxn?.party || '');
  /* instruction #9 — सिर्फ़ date, किससे प्राप्त, राशि, योजना, श्रेणी; एक entry में एक ही scheme */
  const schemeFunds = activeFunds.filter((f) => f.id !== 'cash');
  const [schemeId, setSchemeId] = useState(
    editTxn?.schemeId || (activeFunds.some((f) => f.id === 'own') ? 'own' : schemeFunds[0]?.id || activeFunds[0]?.id || 'sfc')
  );
  /* v10 #5 — योजना चुनने के बाद: यह लेन-देन नकद हुआ या बैंक से (माध्यम, योजना नहीं) */
  const [medium, setMedium] = useState<'cash' | 'bank'>(editTxn?.medium === 'bank' ? 'bank' : 'cash');
  const [amount, setAmount] = useState(() => {
    if (!editTxn) return '';
    const keys = Object.keys(editTxn.amounts);
    const v = editTxn.amounts[editTxn.schemeId] ?? (keys.length ? editTxn.amounts[keys[0]] : 0);
    return v ? String(v) : '';
  });
  /* instruction #7 — expense: कार्य (works dropdown) | अन्य (श्रेणी tree) */
  const [expKind, setExpKind] = useState<'work' | 'other'>(editTxn?.expenseKind === 'work' ? 'work' : 'other');
  const [workId, setWorkId] = useState<string | null>(editTxn?.workId || null);
  const [workAddOpen, setWorkAddOpen] = useState(false);
  const [catMgrOpen, setCatMgrOpen] = useState(false);
  /* v10 #4 — modal body height window se (overflow → bottom dibba gayab) */
  const modalBodyMax = useModalBodyMax(0.88, 280);
  const [catAddOpen, setCatAddOpen] = useState<null | 'l1' | 'l2' | 'l3'>(null);
  const [catAddName, setCatAddName] = useState('');
  const [detail, setDetail] = useState(editTxn?.detail || '');
  const [note, setNote] = useState(editTxn?.note || '');
  const [cat1, setCat1] = useState<string | null>(editTxn?.categoryId || null);
  const [cat2, setCat2] = useState<string | null>(editTxn?.subcategoryId || null);
  const [cat3, setCat3] = useState<string | null>(editTxn?.subSubcategoryId || null);
  const [assetPage, setAssetPage] = useState(editTxn?.assetPage || '');
  const [ledgerFolio, setLedgerFolio] = useState(editTxn?.ledgerFolio || '');
  const [reference, setReference] = useState(editTxn?.reference || '');
  /* वैकल्पिक विवरण default बंद — main form सिर्फ़ ज़रूरी फ़ील्ड (instruction #9) */
  const [showMore, setShowMore] = useState(
    !!(editTxn && (editTxn.detail || editTxn.reference || editTxn.ledgerFolio || editTxn.note || editTxn.assetPage))
  );
  const [bankFundId, setBankFundId] = useState(() => {
    const first = activeFunds.find((f) => f.id !== 'cash');
    return first ? first.id : 'sfc';
  });
  const [err, setErr] = useState('');
  const categoryNames: Record<string, string> = {};
  for (const c of categories) categoryNames[c.id] = c.name;

  // switching type invalidates non-applicable path
  React.useEffect(() => {
    setCat2(null);
    setCat3(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  const workSel = fyWorks.find((w) => w.id === workId) || null;

  /* ═══ v11 #6 — "उपरोक्त में से कोई नहीं" = सामान्य अदायगी (general installment) ═══ */
  const isGeneral = (id: string | null) => id === GENERAL_CAT_ID;
  const effSchemeId = expKind === 'work' && workSel ? workSel.schemeId : schemeId;

  /* v11 #4 — SFC / FFC जैसी बैंक योजना चुनते ही माध्यम अपने-आप "बैंक" */
  React.useEffect(() => {
    if (effSchemeId === 'sfc' || effSchemeId === 'ffc') setMedium('bank');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effSchemeId]);

  /* v11 #9 — कार्य-पेटे भुगतान में माध्यम default बैंक (अन्य में नकद) */
  React.useEffect(() => {
    if (type === 'expense') setMedium(expKind === 'work' ? 'bank' : 'cash');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expKind, type]);

  /* v11 #9 — किसको भुगतान: सिर्फ़ vendor की सूची + उसी पन्ने से नया vendor जोड़ना */
  const [vendorAddOpen, setVendorAddOpen] = useState(false);
  const [vendorName, setVendorName] = useState('');
  const vendorOptions = vendors
    .filter((v) => !v.archived)
    .map((v) => ({ key: v.name, label: v.name, sub: v.kind === 'material' ? 'सामग्री' : v.kind === 'labour' ? 'श्रम' : '' }));
  /* v11 #22 — कार्य चुनने पर उसके सभी Muster Roll भी भुगतान-सूची में (नंबर + राशि) */
  const rollsForWork = workerRolls.filter((r) => r.workId === workId);
  /* v11 #22 — कार्य चुनने पर उसके सभी Muster Roll भी भुगतान-सूची में (नंबर + राशि) */
  if (type === 'expense' && expKind === 'work' && workId) {
    for (const r of rollsForWork) {
      const amt = (r.skilledCount * r.wageSkilled + r.unskilledCount * r.wageUnskilled) * r.days;
      vendorOptions.push({
        key: `${r.id}`,
        label: `${r.rollNo} — ${amt ? formatINR(amt) : 'श्रम भुगतान'}`,
        sub: `${fmtDate(r.fromDate)} → ${fmtDate(r.toDate)}`,
      });
    }
  }

  /* v11 #9 — शीर्ष पर **अभी** का कैशबुक शेष (नगद + बैंक) */
  const balOf = (id: string) => {
    const f = activeFunds.find((x) => x.id === id);
    if (!f) return 0;
    return schemeBalance(id, fundOpening(f), fyTransactions);
  };
  const cashBal = balOf('cash');
  const bankBal = activeFunds.filter((f) => f.id !== 'cash').reduce((s, f) => s + balOf(f.id), 0);

  /**
   * instruction #12 — कोई श्रेणी पहले से चुनी नहीं होती; L1/L2/L3 का उलझन हटाया.
   * यहाँ से सिर्फ़ एक flat सूची: full path दिखता है, चुनो / जोड़ो / हटाओ.
   */
  const parentOf = (id: string | null) => (id ? categories.find((c) => c.id === id) || null : null);
  const pathOfCat = (id: string): string => {
    /* v11 #6 — सामान्य अदायगी sentinel है, कोई श्रेणी-नोड नहीं */
    if (id === GENERAL_CAT_ID) return GENERAL_CAT_LABEL;
    const names: string[] = [];
    let cur = parentOf(id);
    let guard = 0;
    while (cur && guard++ < 5) {
      names.unshift(cur.name);
      cur = parentOf(cur.parentId);
    }
    return names.join(' › ');
  };
  const pathTrio = (id: string): [string | null, string | null, string | null] => {
    if (id === GENERAL_CAT_ID) return [GENERAL_CAT_ID, null, null];
    const ids: string[] = [];
    let cur = parentOf(id);
    let guard = 0;
    while (cur && guard++ < 5) {
      ids.unshift(cur.id);
      cur = parentOf(cur.parentId);
    }
    return [ids[0] || null, ids[1] || null, ids[2] || null];
  };
  const kindCats = categories.filter((c) => c.kind === type && !c.archived);
  const hasChild = (id: string) => kindCats.some((c) => c.parentId === id);
  const catOptions = [
    ...kindCats.filter((c) => !hasChild(c.id)).map((c) => ({ key: c.id, label: pathOfCat(c.id) })),
    /* v11 #6 — आख़िर में: उपरोक्त में से कोई नहीं = सामान्य अदायगी (general installment) */
    { key: GENERAL_CAT_ID, label: `${GENERAL_CAT_LABEL} — general installment` },
  ];

  /* instruction #14 — व्यय में "कार्य" भी एक श्रेणी है; उसी में सारे कार्य आते हैं */
  const workCatId =
    categories.find(
      (c) =>
        c.kind === 'expense' &&
        c.level === 1 &&
        !c.archived &&
        (c.id === 'exp-work' || /^\s*(कार्य|work)/i.test(c.name))
    )?.id || null;

  const save = async () => {
    setErr('');
    const n = Number(amount.trim());
    if (!Number.isFinite(n) || n <= 0) return setErr('राशि > 0 भरें (एक ही योजना के लिए)');
    if (type === 'expense' && expKind === 'work' && !workId) return setErr('कार्य चुनें (या dropdown में से नया जोड़ें)');
    if (type === 'expense' && expKind === 'other' && !cat1) return setErr('श्रेणी चुनें');
    /* v11 #8 — व्यय में भुगतान का पक्ष ज़रूरी: सिर्फ़ vendor सूची से चुनें */
    if (type === 'expense' && !party.trim()) return setErr('किसको भुगतान — vendor की सूची से चुनें (नहीं है तो नीचे से जोड़ें)');
    if (!isValidIsoDate(date)) return setErr('तारीख अमान्य — YYYY-MM-DD');
    /* एक entry = एक scheme (instruction #9) */
    /* कार्य चुनने पर उसी की योजना auto-select (instruction #8) */
    const effScheme = expKind === 'work' && workSel ? workSel.schemeId : schemeId;
    const am: Record<string, number> = { [effScheme]: n };

    /* v10 #30-C — दोहरी entry रोको: (a) वही वाउचर क्रमांक, या
       (b) वही तारीख़ + वही राशि + वही पक्ष (reference ख़ाली हो तब भी) */
    const totalOf = (t: Transaction) => Object.values(t.amounts).reduce((s, v) => s + v, 0);
    const dup =
      (reference.trim()
        ? fyTransactions.find(
            (t) => t.id !== editTxnId && t.status === 'active' && t.type === type && t.reference === reference.trim()
          )
        : undefined) ||
      fyTransactions.find(
        (t) =>
          t.id !== editTxnId &&
          t.status === 'active' &&
          t.type === type &&
          t.date === date &&
          Math.abs(totalOf(t) - n) < 0.5 &&
          (!party.trim() || t.party.trim().toLowerCase() === party.trim().toLowerCase())
      );
    const doSave = async () => {
      const payload = {
        type,
        date,
        reference: reference.trim(),
        ledgerFolio: ledgerFolio.trim(),
        party: party.trim(),
        detail: detail.trim(),
        note: note.trim(),
        schemeId: effScheme,
        amounts: am,
        /* instruction #14 — कार्य भी व्यय की एक श्रेणी; बाक़ी rules वही */
        categoryId: type === 'expense' && expKind === 'work' ? workCatId : cat1,
        subcategoryId: type === 'expense' && expKind === 'work' ? null : cat2,
        subSubcategoryId: type === 'expense' && expKind === 'work' ? null : cat3,
        assetPage: assetPage.trim(),
        workId: type === 'expense' && expKind === 'work' ? workId : null,
        expenseKind: type === 'expense' ? expKind : null,
        /* v10 #5 — योजना के बाद पूछा गया माध्यम: नकद / बैंक */
        medium,
      };
      if (editTxnId) {
        /* v9 #3 — तारीख़ बदली तो उस तारीख़ का पन्ना बनाकर entry उसी पर भेजो */
        const patch: Partial<Transaction> = { ...payload };
        if (date !== editTxn?.date) {
          const pid = ensurePageForDate(date);
          if (pid) patch.pageId = pid;
        }
        const r = await updateTransaction(editTxnId, patch);
        if (!r.ok) return setErr(r.error);
        onClearEdit?.();
        /* v11 #3 — जिस तारीख़ की entry हुई, वापस जाते ही उसी तारीख़ का पन्ना खुले */
        cashbookUI.gotoDate = date;
        return back();
      }
      /* v9 #3 — user ने अगला पन्ना चुना हो तो वही, वरना तारीख़ का पन्ना store खुद चुनेगा */
      const r = await addTransaction({ ...payload, pageId: pagePick.mode === 'next' ? pagePick.pageId : null });
      if (!r.ok) return setErr(r.error);
      cashbookUI.gotoDate = date;
      back();
    };

    if (dup) {
      const sameRef = !!reference.trim() && dup.reference === reference.trim();
      Alert.alert(
        'संभावित दोहरी entry',
        (sameRef
          ? `वाउचर/रसीद "${dup.reference}" पहले से मौजूद है:`
          : `इसी तारीख़ · राशि · पक्ष की entry पहले से मौजूद है:`) +
          `\n${dup.date} · ${dup.party} · ${formatINR(totalOf(dup))}` +
          `\n\nफिर भी सहेजना है?`,
        [
          { text: 'वापस', style: 'cancel' },
          { text: 'हाँ, सहेजें', onPress: doSave },
        ]
      );
      return;
    }
    await doSave();
  };

  const close = () => {
    onClearEdit?.();
    back();
  };

  return (
    <View style={styles.page}>
      <Header title={editTxn ? 'Entry — सुधार' : 'Add entry'} onBack={close} badge={type === 'income' ? 'S-08' : 'S-09'} />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="Income" variant={type === 'income' ? 'primary' : 'outline'} onPress={() => setType('income')} />
          <Btn label="Expense" variant={type === 'expense' ? 'danger' : 'outline'} onPress={() => setType('expense')} />
        </View>
        <Text style={styles.hint}>
          सिर्फ़ ज़रूरी फ़ील्ड — तारीख, किससे प्राप्त/किसको भुगतान, राशि, योजना, श्रेणी · एक entry = एक योजना · तारीख FY ({activeFy.start} → {activeFy.end}) के भीतर
        </Text>
        {/* instruction #13 — date हमेशा DD/MM/YYYY में दिखेगी (storage ISO) */}
        <DateField label="तारीख" value={date} onChange={setDate} onBlur={() => askPageForDate(date)} />
        {isValidIsoDate(date) ? (
          <Text style={styles.meta}>दिखेगा: {fmtDate(date)} (DD/MM/YYYY)</Text>
        ) : (
          <Text style={styles.err}>तारीख format अमान्य — जैसे 2026-09-24</Text>
        )}
        {/* v9 #3 — कौन से पन्ने पर जाएगी, यह साफ़ दिखे */}
        {!editTxnId && isValidIsoDate(date) ? (
          <Text style={styles.meta}>
            {pagePick.mode === 'next'
              ? `पन्ना: अगला चुना गया — तारीख़ अपने आप ${fmtDate(date)} हो गई`
              : `पन्ना: ${fmtDate(date)} का नया/मौजूदा पन्ना — सारी तारीख़ एक जैसी रखने के लिए अलग तारीख़ पर नया पन्ना बनेगा`}
          </Text>
        ) : null}
        {/* ═══ v11 #9 — व्यय (भुगतान) फ़ॉर्म का क्रम: शेष → राशि → प्रकार → कार्य/योजना → विवरण ═══ */}
        {type === 'expense' ? (
          <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5, backgroundColor: C.primarySoft }]}>
            <Text style={styles.cardTitle}>अभी (इसी समय) का कैशबुक शेष</Text>
            <Text style={styles.sumLine}>
              नगद {formatINR(cashBal)} · बैंक {formatINR(bankBal)} · कुल {formatINR(cashBal + bankBal)}
            </Text>
            <Text style={styles.meta}>
              FY {activeFy.label} · आज {fmtDate(toIsoLocal(new Date()))} तक — सभी योजनाओं का योग
            </Text>
          </View>
        ) : null}

        {type === 'income' ? (
          <Field label="किससे प्राप्त" value={party} onChangeText={setParty} />
        ) : null}
        {/* v11 #9 — शेष के बाद सीधे वाउचर राशि */}
        <Field
          label={type === 'income' ? 'राशि (₹)' : 'वाउचर राशि (₹) *'}
          value={amount}
          onChangeText={setAmount}
          keyboardType="numeric"
        />

        {type === 'expense' ? (
          <>
            <Text style={styles.section}>भुगतान का प्रकार *</Text>
            <View style={styles.row}>
              <Btn label="कार्य (Work)" variant={expKind === 'work' ? 'primary' : 'outline'} onPress={() => setExpKind('work')} />
              <Btn label="अन्य (Other)" variant={expKind === 'other' ? 'danger' : 'outline'} onPress={() => setExpKind('other')} />
            </View>
            {expKind === 'work' ? (
              <SelectField
                label="कार्य चुनें *"
                value={workSel ? workSel.name : ''}
                placeholder="works की सूची से चुनें"
                options={fyWorks.map((w) => ({
                  key: w.id,
                  label: w.name,
                  sub: activeFunds.find((f) => f.id === w.schemeId)?.shortName,
                }))}
                onSelect={(id) => {
                  setWorkId(id);
                  const w = fyWorks.find((x) => x.id === id);
                  if (w) setSchemeId(w.schemeId); // instruction #8: योजना auto-select
                }}
                onAddNew={() => setWorkAddOpen(true)}
                addNewLabel="+ नया कार्य जोड़ें (फ़ॉर्म खुलेगा)"
                hint="सूची में कार्य नहीं है? नीचे से जोड़ें — योजना/AS/TS/FS/MB सब भरा जाएगा।"
              />
            ) : null}
          </>
        ) : null}

        {/* v11 #9 — योजना **कभी दो बार नहीं**: कार्य चुनते ही उसकी योजना अपने-आप,
            इसलिए यह dropdown सिर्फ़ "अन्य / आय" में ही दिखेगा। */}
        {!(type === 'expense' && expKind === 'work') ? (
          <SelectField
            label="योजना / Scheme *"
            value={activeFunds.find((f) => f.id === schemeId)?.name || schemeId}
            options={schemeFunds.map((f) => ({ key: f.id, label: f.name, sub: f.shortName }))}
            onSelect={setSchemeId}
            hint="SFC/FFC चुनते ही माध्यम अपने-आप बैंक हो जाएगा।"
          />
        ) : (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>योजना — स्वतः चुनी गई (दोबारा नहीं पूछी जाती)</Text>
            <Text style={styles.sumLine}>
              {activeFunds.find((f) => f.id === (workSel?.schemeId || ''))?.name || '—'}
            </Text>
            <Text style={styles.meta}>
              कार्य: {workSel?.name}
              {workSel?.sanctionRef ? ` · स्वीकृति ${workSel.sanctionRef}` : ''}
              {workCatId ? ` · श्रेणी: ${categoryNames[workCatId] || 'कार्य'}` : ''}
            </Text>
          </View>
        )}

        {/* v10 #5 + v11 #4/#9 — माध्यम: कार्य व SFC/FFC पर बैंक default */}
        <Text style={styles.section}>लेन-देन का माध्यम *</Text>
        <View style={styles.row}>
          <Btn
            label={medium === 'cash' ? '✓ नकद (Cash)' : 'नकद (Cash)'}
            variant={medium === 'cash' ? 'primary' : 'outline'}
            onPress={() => setMedium('cash')}
          />
          <Btn
            label={medium === 'bank' ? '✓ बैंक (Bank)' : 'बैंक (Bank)'}
            variant={medium === 'bank' ? 'primary' : 'outline'}
            onPress={() => setMedium('bank')}
          />
        </View>
        <Text style={styles.meta}>
          {medium === 'cash'
            ? 'नकद — तिजोरी/ड्राइंग से नगद (रोकड़ बही की नकद पंक्ति)'
            : 'बैंक — चेक / NEFT / ATM / बैंक खाते से (बैंक बही की नाम पंक्ति)'}
          {expKind === 'work' && type === 'expense' ? ' · कार्य-पेटे भुगतान में बैंक default' : ''}
        </Text>

        {/* ═══ v11 #8 — किसको भुगतान: सिर्फ़ vendor dropdown + उसी पन्ने से नया vendor ═══ */}
        {type === 'expense' ? (
          <SelectField
            label="किसको भुगतान * (सिर्फ़ vendor / MR की सूची)"
            value={party}
            placeholder="नाम चुनें"
            options={vendorOptions}
            onSelect={(k) => {
              const r = rollsForWork.find((x) => x.id === k);
              if (r) {
                const amt = (r.skilledCount * r.wageSkilled + r.unskilledCount * r.wageUnskilled) * r.days;
                /* v11 #22 — MR चुनते ही नंबर + राशि अपने-आप (मज़दूरी voucher) */
                setParty(`${r.rollNo} — श्रम भुगतान${amt ? ` ${formatINR(amt)}` : ''}`);
                if (!amount.trim() && amt) setAmount(String(amt));
              } else setParty(k);
            }}
            onAddNew={() => setVendorAddOpen(true)}
            addNewLabel="+ नया vendor जोड़ें"
            hint="सूची में नाम नहीं है? नीचे से जोड़ें — जोड़ते ही यहीं dropdown में आ जाएगा।"
          />
        ) : null}

        {!(type === 'expense' && expKind === 'work') ? (
          <>
            {/* instruction #12 — कोई श्रेणी पहले से चयनित नहीं; L1/L2/L3 उलझन हटाई */}
            <SelectField
              label={type === 'expense' ? 'व्यय श्रेणी *' : 'आय श्रेणी *'}
              value={cat1 ? pathOfCat(cat1) : ''}
              placeholder="श्रेणी चुनें (पहले से कुछ चुना नहीं)"
              options={catOptions}
              onSelect={(id) => {
                const [a, b, c] = pathTrio(id);
                setCat1(a);
                setCat2(b);
                setCat3(c);
              }}
              onAddNew={() => setCatMgrOpen(true)}
              addNewLabel="श्रेणी जोड़ें / बदलें / हटाएँ"
              hint="कोई भी श्रेणी पहले से नहीं चुनी है — यहाँ से चुनें, या नीचे से जोड़ें/हटाएँ।"
            />
            <View style={styles.chips}>
              <Pressable onPress={() => { setCat1(null); setCat2(null); setCat3(null); }} style={[styles.chip, { borderStyle: 'dashed' }]}>
                <Text style={{ color: C.expense, fontSize: 12, fontWeight: '800' }}>चयन हटाएँ</Text>
              </Pressable>
              <Pressable
                /* v11 #6 — सामान्य अदायगी (general installment) — अलग से एक tap */
                onPress={() => { setCat1(GENERAL_CAT_ID); setCat2(null); setCat3(null); }}
                style={[styles.chip, isGeneral(cat1) && styles.chipOn]}
              >
                <Text style={{ color: isGeneral(cat1) ? '#fff' : C.primary, fontSize: 12, fontWeight: '800' }}>
                  सामान्य अदायगी
                </Text>
              </Pressable>
              <Pressable onPress={() => { setCatAddOpen('l1'); setCatAddName(''); }} style={[styles.chip, { borderStyle: 'dashed' }]}>
                <Text style={{ color: C.primary, fontSize: 12, fontWeight: '800' }}>+ नई श्रेणी</Text>
              </Pressable>
            </View>
            <Btn label="श्रेणी प्रबंधन (जोड़ें / बदलें / हटाएँ)" variant="outline" icon="folder" onPress={() => setCatMgrOpen(true)} />
            {cat1 ? (
              <Text style={styles.meta}>
                Path: {categoryPathLabel({ categoryId: cat1, subcategoryId: cat2, subSubcategoryId: cat3 }, categoryNames)}
                {isGeneral(cat1) ? ' · monthly check में इस entry का श्रेणी-error नहीं दिखेगा' : ''}
              </Text>
            ) : null}
          </>
        ) : null}

        <Btn
          label={showMore ? '▲ वैकल्पिक विवरण छिपाएँ' : '▼ और विवरण (वैकल्पिक) — वाउचर, L.F., नोट'}
          variant="soft"
          onPress={() => setShowMore((s) => !s)}
        />
        {showMore ? (
          <>
            <Field label="Detail" value={detail} onChangeText={setDetail} />
            <Field
              label={type === 'income' ? 'रसीद/चेक क्रमांक' : 'वाउचर/चेक क्रमांक'}
              value={reference}
              onChangeText={setReference}
            />
            <Field label="L.F. (Ledger Folio — ledger से cross-verify होगा)" value={ledgerFolio} onChangeText={setLedgerFolio} placeholder="जैसे 12" keyboardType="numeric" />
            <Field label="Note" value={note} onChangeText={setNote} multiline />
            {type === 'expense' ? (
              <Field label="परिसंपत्ति रजिस्टर पृष्ठ संख्या (C.3.2)" value={assetPage} onChangeText={setAssetPage} placeholder="जैसे 4" keyboardType="numeric" />
            ) : null}
            <Btn
              label="⧉ पिछली entry से copy (repeat template)"
              variant="soft"
              onPress={() => {
                const last = fyTransactions.filter((t) => t.type === type && t.status === 'active').slice(-1)[0];
                if (!last) return Alert.alert('कोई पिछली entry नहीं', 'पहले एक entry बनाएँ');
                setParty(last.party);
                setDetail(last.detail);
                setNote(last.note);
                setSchemeId(last.schemeId);
                const keys = Object.keys(last.amounts);
                setAmount(last.amounts[keys[0]] ? String(last.amounts[keys[0]]) : '');
                setCat1(last.categoryId);
                setCat2(last.subcategoryId);
                setCat3(last.subSubcategoryId);
                setReference('');
                Alert.alert('Copy हो गया', 'दिनांक/राशि जाँच कर Save करें');
              }}
            />
            <Btn
              label="⇄ नकद से बैंक जमा (transfer — आय/व्यय नहीं)"
              variant="outline"
              onPress={() => {
                const total = Number(amount.trim());
                const bankFund = activeFunds.find((f) => f.id === bankFundId);
                if (!Number.isFinite(total) || !(total > 0)) return Alert.alert('राशि डालें');
                if (!isValidIsoDate(date)) return Alert.alert('अमान्य दिनांक', 'YYYY-MM-DD जैसे 2026-09-24 भरें');
                if (!bankFund) return Alert.alert('कोई बैंक fund नहीं');
                Alert.alert('नकद → बैंक जमा', `₹${total} को ${bankFund.shortName} में जमा करें?\n(नकद घटेगा, बैंक बढ़ेगा — आय/व्यय नहीं)`, [
                  { text: 'नहीं', style: 'cancel' },
                  {
                    text: 'जमा करें',
                    onPress: async () => {
                      const r = await addTransferCashToBank(date, total, bankFund.id, note || detail);
                      if (r.ok) close();
                      else Alert.alert(r.error || 'Fail');
                    },
                  },
                ]);
              }}
            />
            <Text style={styles.section}>बैंक fund (transfer destination)</Text>
            <View style={styles.chips}>
              {activeFunds
                .filter((f) => f.id !== 'cash')
                .map((f) => (
                  <Pressable key={f.id} onPress={() => setBankFundId(f.id)} style={[styles.chip, bankFundId === f.id && styles.chipOn]}>
                    <Text style={{ color: bankFundId === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
                  </Pressable>
                ))}
            </View>
          </>
        ) : null}
        {/* instruction #11 — entry करते वक़्त ही तय करें ऊपर की last entry से कितनी खाली लाइन छोड़नी है */}
        <Text style={styles.section}>इस entry से पहले कितनी खाली लाइनें?</Text>
        <View style={styles.chips}>
          {[0, 1, 2, 3].map((n) => {
            const on = Math.max(0, Math.min(3, (fySettings.blankLineGap || 1) - 1)) === n;
            return (
              <Pressable
                key={n}
                onPress={() => updateFySettings({ blankLineGap: n + 1 })}
                style={[styles.chip, on && styles.chipOn]}
              >
                <Text style={{ color: on ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>
                  {n === 0 ? 'बगैर खाली' : `${n} खाली लाइन`}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={styles.meta}>
          इस पन्ने की पिछली entry के बाद {Math.max(0, Math.min(3, (fySettings.blankLineGap || 1) - 1))} खाली लाइन छोड़कर यह entry लगेगी (पूरे FY पर लागू)।
        </Text>
        {err ? <Text style={styles.err}>{err}</Text> : null}
        <Btn label={editTxn ? 'सुधार सहेजें' : 'Save'} icon="check" onPress={save} />
        {editTxn ? <Btn label="वापस जाएँ (Back)" variant="outline" onPress={close} /> : null}
      </ScrollView>

      {/* instruction #7 — dropdown list me hi naya kary (poora form) */}
      <Modal visible={workAddOpen} transparent animationType="slide" onRequestClose={() => setWorkAddOpen(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '92%' }]}>
            <Text style={styles.modalTitle}>नया कार्य जोड़ें</Text>
            <ScrollView keyboardShouldPersistTaps="handled" style={{ maxHeight: modalBodyMax }}>
              <WorkAddForm
                onAdded={(w) => {
                  setWorkId(w.id);
                  const nw = works.find((x) => x.id === w.id);
                  if (nw) setSchemeId(nw.schemeId); // योजना auto-select (instruction #8)
                  setWorkAddOpen(false);
                }}
              />
            </ScrollView>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setWorkAddOpen(false)} />
          </View>
        </View>
      </Modal>

      {/* instruction #7 — श्रेणी: जोड़ें / बदलें / हटाएँ (यहीं से) */}
      <Modal visible={!!catAddOpen} transparent animationType="fade" onRequestClose={() => setCatAddOpen(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>
              {catAddOpen === 'l1' ? 'नई श्रेणी' : catAddOpen === 'l2' ? 'नई उपश्रेणी' : 'नई उप-उपश्रेणी'}
            </Text>
            <Field label="नाम" value={catAddName} onChangeText={setCatAddName} />
            <Btn
              label="सहेजें"
              onPress={async () => {
                if (!catAddName.trim()) return Alert.alert('नाम चाहिए');
                const parentId = catAddOpen === 'l1' ? null : catAddOpen === 'l2' ? cat1 : cat2;
                await addCategory(type, catAddName.trim(), parentId);
                setCatAddName('');
                setCatAddOpen(null);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setCatAddOpen(null)} />
          </View>
        </View>
      </Modal>
      {/* v11 #8 — उसी पन्ने से नया vendor जोड़ें → dropdown में तुरंत */}
      <Modal visible={vendorAddOpen} transparent animationType="fade" onRequestClose={() => setVendorAddOpen(false)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>नया vendor जोड़ें</Text>
            <Field label="नाम *" value={vendorName} onChangeText={setVendorName} />
            <Btn
              label="जोड़ें"
              onPress={async () => {
                if (!vendorName.trim()) return Alert.alert('नाम चाहिए');
                await addVendor({ name: vendorName.trim(), kind: 'other' });
                setParty(vendorName.trim());
                setVendorName('');
                setVendorAddOpen(false);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setVendorAddOpen(false)} />
            <Text style={styles.meta}>जोड़ते ही ऊपर "किसको भुगतान" dropdown में यह नाम आ जाएगा।</Text>
          </View>
        </View>
      </Modal>
      <Modal visible={catMgrOpen} transparent animationType="slide" onRequestClose={() => setCatMgrOpen(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '88%' }]}>
            <Text style={styles.modalTitle}>श्रेणी प्रबंधन — {type === 'income' ? 'आय' : 'व्यय'}</Text>
            <ScrollView keyboardShouldPersistTaps="handled" style={{ maxHeight: modalBodyMax }}>
              <CatLevelList
                kind={type}
                parentId={null}
                title="स्तर 1 (मुख्य श्रेणी)"
                selectedId={cat1}
                onPick={(id) => { setCat1(id); setCat2(null); setCat3(null); }}
              />
              {cat1 ? (
                <CatLevelList kind={type} parentId={cat1} title="स्तर 2 (उपश्रेणी)" selectedId={cat2} onPick={(id) => { setCat2(id); setCat3(null); }} />
              ) : null}
              {cat2 ? (
                <CatLevelList kind={type} parentId={cat2} title="स्तर 3 (उप-उपश्रेणी)" selectedId={cat3} onPick={setCat3} />
              ) : null}
              <Text style={styles.meta}>टैप = उसे चुनें · ✎ = नाम बदलें · 🗑 = हटाएँ (archive — पुरानी entries सुरक्षित)</Text>
            </ScrollView>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setCatMgrOpen(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

/** श्रेणी स्तर की सूची — चुनना/जोड़ना/नाम बदलना/हटाना यहीं से (instruction #7) */
function CatLevelList({
  kind,
  parentId,
  title,
  selectedId,
  onPick,
}: {
  kind: 'income' | 'expense';
  parentId: string | null;
  title: string;
  selectedId: string | null;
  onPick: (id: string) => void;
}) {
  const { categories, addCategory, renameCategory, archiveCategory } = useStore();
  const [nm, setNm] = useState('');
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const list = categories.filter((c) => c.kind === kind && c.parentId === parentId && !c.archived);
  return (
    <View style={{ marginBottom: 6 }}>
      <Text style={styles.section}>{title}</Text>
      {list.map((c) => (
        <View key={c.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
          <Pressable style={{ flex: 1 }} onPress={() => onPick(c.id)}>
            <Text style={{ fontWeight: selectedId === c.id ? '800' : '600', color: selectedId === c.id ? C.primary : C.foreground }}>
              {selectedId === c.id ? '✓ ' : ''}
              {c.name}
            </Text>
          </Pressable>
          <IconBtn
            name="edit-3"
            onPress={() => {
              setEditId(c.id);
              setEditName(c.name);
            }}
          />
          <IconBtn name="trash-2" onPress={() => archiveCategory(c.id)} />
        </View>
      ))}
      <View style={styles.row}>
        <Field label="नई श्रेणी का नाम" value={nm} onChangeText={setNm} grow />
      </View>
      <Btn
        label="+ जोड़ें"
        variant="soft"
        onPress={async () => {
          if (!nm.trim()) return;
          await addCategory(kind, nm.trim(), parentId);
          setNm('');
        }}
      />
      <Modal visible={!!editId} transparent animationType="fade" onRequestClose={() => setEditId(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>नाम बदलें</Text>
            <Field label="नाम" value={editName} onChangeText={setEditName} />
            <Btn
              label="सहेजें"
              onPress={async () => {
                if (editId && editName.trim()) await renameCategory(editId, editName.trim());
                setEditId(null);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setEditId(null)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

function CategoriesScreen({ back }: { back: () => void }) {
  const { categories, addCategory, archiveCategory, renameCategory } = useStore();
  const [kind, setKind] = useState<'income' | 'expense'>('income');
  const [name, setName] = useState('');
  const list = categories.filter((c) => c.kind === kind && !c.archived);

  /* ═══ v10 #9 — श्रेणी अब वृक्ष (tree) की तरह: हर डाल पर अपना add / edit / delete ═══ */
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const isOpen = (id: string) => expanded[id] !== false;
  const toggle = (id: string) => setExpanded((e) => ({ ...e, [id]: e[id] === false }));
  const [addFor, setAddFor] = useState<string | null>(null); // null = बंद, '' = root
  const [addName, setAddName] = useState('');
  const [renFor, setRenFor] = useState<{ id: string; name: string } | null>(null);
  const [delFor, setDelFor] = useState<{ id: string; name: string } | null>(null);
  /* v11 #10 — long-press या ⋮ से एक ही मेन्यू: जोड़ें / बदलें / हटाएँ / खोलें-बंद करें */
  const [menuFor, setMenuFor] = useState<{ id: string; name: string; level: number; kids: number } | null>(null);
  const treeMax = useModalBodyMax(0.74, 270);

  const roots = list.filter((c) => !c.parentId);
  const kidsOf = (id: string) => list.filter((c) => c.parentId === id);

  /* v11 #10 — पूरा पेड़ एक साथ खोलें / बंद करें (ढूँढना आसान) */
  const setAll = (open: boolean) => {
    const next: Record<string, boolean> = {};
    for (const c of list) next[c.id] = open;
    setExpanded(next);
  };

  const renderNode = (c: (typeof list)[number]): React.ReactNode => {
    const kids = kidsOf(c.id);
    const open = isOpen(c.id);
    const openMenu = () => setMenuFor({ id: c.id, name: c.name, level: c.level, kids: kids.length });
    return (
      <View key={c.id}>
        <Pressable
          /* v11 #10 — लंबा दबाव = सारे विकल्प एक ही जगह */
          onLongPress={openMenu}
          delayLongPress={450}
          android_ripple={{ color: C.primarySoft }}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 4,
            borderWidth: 1,
            borderColor: C.border,
            borderLeftWidth: 3,
            borderLeftColor: c.level === 1 ? C.primary : c.level === 2 ? C.income : C.accent,
            borderRadius: 10,
            backgroundColor: C.card,
            paddingVertical: 6,
            paddingHorizontal: 8,
            marginBottom: 6,
            marginLeft: (c.level - 1) * 14,
          }}
        >
          <Pressable
            onPress={() => kids.length && toggle(c.id)}
            style={{ flexDirection: 'row', alignItems: 'center', flex: 1, minHeight: 34 }}
          >
            <Feather
              name={kids.length ? (open ? 'chevron-down' : 'chevron-right') : 'corner-down-right'}
              size={16}
              color={C.mutedForeground}
            />
            <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 6, flex: 1 }]} numberOfLines={2}>
              {c.name}
            </Text>
            <Text style={styles.meta}>L{c.level}{kids.length ? ` · ${kids.length}` : ''}</Text>
          </Pressable>
          {c.level < 3 ? (
            <IconBtn
              name="plus"
              onPress={() => {
                setAddName('');
                setAddFor(c.id);
              }}
            />
          ) : null}
          <IconBtn
            name="edit-3"
            onPress={() => {
              setRenFor({ id: c.id, name: c.name });
            }}
          />
          <IconBtn
            name="trash-2"
            onPress={() => setDelFor({ id: c.id, name: c.name })}
          />
          {/* v11 #10 — सारे विकल्प एक साथ (long-press से भी यही खुलता है) */}
          <IconBtn name="folder" onPress={openMenu} />
        </Pressable>
        {open ? kids.map(renderNode) : null}
      </View>
    );
  };

  return (
    <View style={styles.page}>
      <Header title="Categories" onBack={back} badge="S-46" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          श्रेणियाँ वृक्ष (tree) में। <Text style={{ fontWeight: '900' }}>किसी भी पंक्ति पर लंबा दबाव</Text> करें (या ↗ बटन) —
          नई उपश्रेणी, नाम बदलें, हटाएँ, खोलें/बंद करें सब एक ही मेन्यू में। अधिकतम 3 स्तर।
        </Text>
        <View style={styles.row}>
          <Btn label="Income tree" variant={kind === 'income' ? 'primary' : 'outline'} onPress={() => setKind('income')} />
          <Btn label="Expense tree" variant={kind === 'expense' ? 'danger' : 'outline'} onPress={() => setKind('expense')} />
        </View>
        <View style={styles.row}>
          <Btn label="सब खोलें" variant="soft" icon="chevron-down" onPress={() => setAll(true)} />
          <Btn label="सब बंद करें" variant="outline" icon="chevron-right" onPress={() => setAll(false)} />
        </View>

        {/* root add */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>+ नई श्रेणी (स्तर 1)</Text>
          <Field label="नाम" value={name} onChangeText={setName} />
          <Btn
            label="Add root"
            icon="plus"
            onPress={() => {
              if (!name.trim()) return;
              addCategory(kind, name.trim(), null);
              setName('');
            }}
          />
        </View>

        {roots.length === 0 ? (
          <Empty title="कोई श्रेणी नहीं" why="इस प्रकार (income/expense) की कोई श्रेणी नहीं" steps={['ऊपर से प्रकार चुनें', '“+ नई श्रेणी” से जोड़ें']} />
        ) : (
          roots.map(renderNode)
        )}
      </ScrollView>

      {/* v11 #10 — long-press / ↗ से खुलने वाला एक ही मेन्यू (सब विकल्प एक जगह) */}
      <Modal visible={!!menuFor} transparent animationType="fade" onRequestClose={() => setMenuFor(null)}>
        <Pressable style={styles.modalBg} onPress={() => setMenuFor(null)}>
          <Pressable style={styles.modalCard} onPress={() => undefined}>
            <Text style={styles.modalTitle} numberOfLines={2}>{menuFor?.name}</Text>
            <Text style={styles.meta}>
              स्तर {menuFor?.level} · {menuFor?.kids || 0} उप-श्रेणी
              {menuFor && menuFor.level < 3 ? ' · इसके नीचे नया स्तर जोड़ सकते हैं' : ' · यह अंतिम स्तर है'}
            </Text>
            {menuFor && menuFor.level < 3 ? (
              <Btn
                label="+ नई उपश्रेणी जोड़ें"
                icon="plus"
                onPress={() => {
                  setAddName('');
                  setAddFor(menuFor.id);
                  setMenuFor(null);
                }}
              />
            ) : null}
            <Btn
              label="✎ नाम बदलें / सुधारें"
              icon="edit-3"
              variant="soft"
              onPress={() => {
                setRenFor({ id: menuFor!.id, name: menuFor!.name });
                setMenuFor(null);
              }}
            />
            {menuFor && menuFor.kids > 0 ? (
              <Btn
                label={isOpen(menuFor.id) ? '▸ उप-श्रेणियाँ बंद करें' : '▾ उप-श्रेणियाँ खोलें'}
                variant="soft"
                onPress={() => {
                  toggle(menuFor.id);
                  setMenuFor(null);
                }}
              />
            ) : null}
            <Btn
              label="🗑 हटाएँ (archive)"
              variant="danger"
              icon="trash-2"
              onPress={() => {
                setDelFor({ id: menuFor!.id, name: menuFor!.name });
                setMenuFor(null);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setMenuFor(null)} />
          </Pressable>
        </Pressable>
      </Modal>

      {/* add child (tree branch पर से) */}
      <Modal visible={addFor !== null} transparent animationType="fade" onRequestClose={() => setAddFor(null)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '70%' }]}>
            <Text style={styles.modalTitle}>नई श्रेणी जोड़ें</Text>
            <Text style={styles.meta}>
              पैरेंट: {addFor ? list.find((c) => c.id === addFor)?.name || '—' : '— (root)'} · स्तर{' '}
              {addFor ? (list.find((c) => c.id === addFor)?.level || 1) + 1 : 1}
            </Text>
            <ScrollView style={{ maxHeight: treeMax }}>
              <Field label="नाम" value={addName} onChangeText={setAddName} bg={C.input} />
            </ScrollView>
            <View style={styles.row}>
              <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setAddFor(null)} />
              <Btn
                label="जोड़ें"
                onPress={() => {
                  if (addFor && addName.trim()) addCategory(kind, addName.trim(), addFor);
                  setAddFor(null);
                  setAddName('');
                }}
              />
            </View>
          </View>
        </View>
      </Modal>

      {/* rename */}
      <Modal visible={!!renFor} transparent animationType="fade" onRequestClose={() => setRenFor(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>नाम बदलें</Text>
            <Field label="नाम" value={renFor?.name || ''} onChangeText={(t) => setRenFor((r) => (r ? { ...r, name: t } : r))} bg={C.input} />
            <View style={styles.row}>
              <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setRenFor(null)} />
              <Btn
                label="सहेजें"
                onPress={async () => {
                  if (renFor && renFor.name.trim()) await renameCategory(renFor.id, renFor.name.trim());
                  setRenFor(null);
                }}
              />
            </View>
          </View>
        </View>
      </Modal>

      {/* delete / archive */}
      <Modal visible={!!delFor} transparent animationType="fade" onRequestClose={() => setDelFor(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>श्रेणी हटाएँ?</Text>
            <Text style={styles.meta}>{delFor?.name}</Text>
            <Text style={styles.meta}>
              यह श्रेणी archive होगी (दिखनी बंद) — पुरानी entries सुरक्षित रहती हैं। इसके नीचे की शाखाएँ भी हटेंगी।
            </Text>
            <View style={styles.row}>
              <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setDelFor(null)} />
              <Btn
                label="हटाएँ"
                variant="danger"
                onPress={async () => {
                  if (delFor) await archiveCategory(delFor.id);
                  setDelFor(null);
                }}
              />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function MastersScreen({ back }: { back: () => void }) {
  const { bsrRates, itemMasters, addBsrRate, updateBsrRate, deleteBsrRate, addItemMaster, activeFy, mandayCalcs, financialYears } = useStore();
  /* instruction #29 — workers ki roster/लिस्ट नहीं बनानी; सिर्फ़ counting और मान-दिवस गणना
     v10 #19 — Holiday का tab हटाया: छुट्टियाँ अब निश्चित (नीचे देखें) */
  const [tab, setTab] = useState<'bsr' | 'items' | 'manday'>('bsr');
  const [bItem, setBItem] = useState('');
  const [bUnit, setBUnit] = useState('');
  const [bRate, setBRate] = useState('');
  /* ═══ v11 #18/#19 — Masters में BSR: कई वर्ष अलग-अलग + पूरा add/edit/correct/delete ═══ */
  const [bsrYear, setBsrYear] = useState(activeFy.label);
  const bsrYears = React.useMemo(() => bsrYearList(financialYears, bsrRates), [financialYears, bsrRates]);
  const [bFind, setBFind] = useState('');
  const [bEdit, setBEdit] = useState<{ id: string; itemName: string; unit: string; rate: string } | null>(null);
  const [bDel, setBDel] = useState<{ id: string; itemName: string } | null>(null);
  const [newYearOpen, setNewYearOpen] = useState(false);
  const [newYear, setNewYear] = useState('');
  /* v12 #6 — BSR popup अब ModalBody (scroll + Back) से खुलते हैं */
  const yearRates = bsrRates
    .filter((b) => b.year === bsrYear && (!bFind.trim() || b.itemName.toLowerCase().includes(bFind.trim().toLowerCase())))
    .sort((a, b) => a.itemName.localeCompare(b.itemName, 'hi'));
  const allYears = [...new Set([...bsrYears, ...bsrRates.map((b) => b.year)])].filter(Boolean).sort((a, b) => b.localeCompare(a));
  const [iName, setIName] = useState('');
  const [iWhole, setIWhole] = useState(true);
  const [iLast, setILast] = useState(false);
  const [iBasic, setIBasic] = useState(false);
  const mdTotal = mandayCalcs.reduce((s, c) => s + c.workers * c.days, 0);
  const mdAmount = mandayCalcs.reduce((s, c) => s + c.amount, 0);
  const byRole = (role: 'labour' | 'karigar' | 'mate') =>
    mandayCalcs.filter((c) => c.role === role).reduce((s, c) => s + c.workers * c.days, 0);
  return (
    <View style={styles.page}>
      <Header title="Masters" onBack={back} badge="S-36" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="BSR" variant={tab === 'bsr' ? 'primary' : 'outline'} onPress={() => setTab('bsr')} />
          <Btn label="Items" variant={tab === 'items' ? 'primary' : 'outline'} onPress={() => setTab('items')} />
          <Btn label="मान-दिवस" variant={tab === 'manday' ? 'primary' : 'outline'} onPress={() => setTab('manday')} />
        </View>
        {/* v10 #19 — Holiday विकल्प हटाया; तीन निश्चित राष्ट्रीय छुट्टियाँ हर MR में अपने-आप */}
        <View style={[styles.card, { borderColor: C.accent, borderWidth: 1.5 }]}>
          <Text style={styles.cardTitle}>छुट्टियाँ (निश्चित — कोई विकल्प नहीं)</Text>
          <Text style={styles.meta}>
            Holiday का विकल्प हटा दिया गया (v10 #19)। हर पखवाड़े/MR में ये तीन राष्ट्रीय छुट्टियाँ अपने-आप घटती हैं:
          </Text>
          {FIXED_HOLIDAYS.map((h) => (
            <Text key={h.mmdd} style={styles.meta}>
              • {h.name}
            </Text>
          ))}
          <Text style={styles.meta}>+ हर रविवार · तो पखवाड़े में कुल कार्यदिवस ≈ 12 (default), अधिकतम 13।</Text>
        </View>
        {tab === 'bsr' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>BSR — वार्षिक दर सूची (वर्ष {bsrYear} · {yearRates.length} items)</Text>
            {/* v11 #19 — एक से अधिक वर्ष की BSR, एक-एक करके add / edit / correct / delete */}
            <YearField label="वर्ष चुनें (multi-year BSR)" value={bsrYear} years={allYears} onChange={setBsrYear} />
            <Btn label="+ नया वर्ष जोड़ें" variant="soft" icon="plus" onPress={() => { setNewYear(''); setNewYearOpen(true); }} />
            <Field label="खोजें (item का नाम)" value={bFind} onChangeText={setBFind} bg={C.input} />
            <Text style={styles.meta}>
              जोड़ें / सुधारें / हटाएँ — सब इसी वर्ष में। दर वृत्ति: BSR−10…−20% safe। यही दरें Manday / MB / Bills में इसी
              वर्ष चुनने पर दिखती हैं।
            </Text>
            {yearRates.length === 0 ? (
              <Empty
                title={`वर्ष ${bsrYear} की BSR खाली`}
                why="इस वर्ष का अभी कोई दर दर्ज नहीं"
                steps={['नीचे Item + Unit + Rate भरें', '“BSR दर जोड़ें” दबाएँ', 'बाद में ✎ से सुधार या 🗑 से हटाव']}
              />
            ) : (
              yearRates.map((b) => (
                <View key={b.id} style={[styles.card, { flexDirection: 'row', alignItems: 'center', gap: 8 }]}>
                  <Pressable
                    style={{ flex: 1 }}
                    onPress={() => setBEdit({ id: b.id, itemName: b.itemName, unit: b.unit, rate: String(b.rate) })}
                  >
                    <Text style={styles.cardTitle}>{b.itemName}</Text>
                    <Text style={styles.meta}>
                      {b.year} · {b.unit || '—'} · ₹{b.rate} <Text style={{ color: C.primary }}>· tap करके सुधारें</Text>
                    </Text>
                  </Pressable>
                  <IconBtn
                    name="edit-3"
                    onPress={() => setBEdit({ id: b.id, itemName: b.itemName, unit: b.unit, rate: String(b.rate) })}
                  />
                  <IconBtn name="trash-2" onPress={() => setBDel({ id: b.id, itemName: b.itemName })} />
                </View>
              ))
            )}
            <Text style={styles.section}>नई दर जोड़ें — {bsrYear}</Text>
            <Field label="Item" value={bItem} onChangeText={setBItem} bg={C.input} />
            {/* v10 #18 — input पतले नहीं: पूरी चौड़ाई (grow) + ऊँचाई */}
            <View style={styles.row}>
              <Field label="Unit" value={bUnit} onChangeText={setBUnit} grow bg={C.input} />
              <Field label="Rate (₹)" value={bRate} onChangeText={setBRate} keyboardType="numeric" grow bg={C.input} />
            </View>
            <Btn
              label={`BSR दर जोड़ें (${bsrYear})`}
              onPress={() => {
                if (!bItem.trim() || !(parseFloat(bRate) > 0)) return Alert.alert('Item + rate चाहिए');
                const yr = bsrYear;
                const same = bsrRates.find(
                  (b) => b.year === yr && b.itemName.trim().toLowerCase() === bItem.trim().toLowerCase()
                );
                if (same) {
                  updateBsrRate(same.id, { unit: bUnit.trim(), rate: parseFloat(bRate) });
                  Alert.alert('सुधार हो गया', `${bItem} की दर ${yr} में अपडेट की गई।`);
                } else {
                  addBsrRate({ year: yr, itemName: bItem.trim(), unit: bUnit.trim(), rate: parseFloat(bRate) });
                }
                setBItem('');
                setBUnit('');
                setBRate('');
              }}
            />
          </View>
        ) : null}
        {tab === 'items' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Item master ({itemMasters.length})</Text>
            {itemMasters.map((i) => (
              <Text key={i.id} style={styles.meta}>
                {i.name} · {i.wholeNumberOnly ? 'पूर्ण संख्या' : 'दशमलव'}{i.lastBillOnly ? ' · अंतिम-बिल' : ''}{i.basicItem ? ' · आधारभूत' : ''}
              </Text>
            ))}
            <Field label="Item name" value={iName} onChangeText={setIName} grow bg={C.input} />
            <View style={styles.row}>
              <Btn label={`पूर्ण: ${iWhole ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setIWhole(!iWhole)} />
              <Btn label={`अंतिम-बिल: ${iLast ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setILast(!iLast)} />
              <Btn label={`आधारभूत: ${iBasic ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setIBasic(!iBasic)} />
            </View>
            <Btn
              label="Item जोड़ें"
              onPress={() => {
                if (!iName.trim()) return Alert.alert('नाम चाहिए');
                addItemMaster({ name: iName.trim(), wholeNumberOnly: iWhole, lastBillOnly: iLast, basicItem: iBasic });
                setIName('');
              }}
            />
          </View>
        ) : null}
        {/* instruction #29 — कोई worker list नहीं: सिर्फ़ counting और मान-दिवस गणना */}
        {tab === 'manday' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>मान-दिवस गणना (कोई roster नहीं)</Text>
            <Text style={styles.meta}>स्वीकृतियों का कुल योग — काम के हिसाब से मात्रा, कर्मचारियों की लिस्ट नहीं।</Text>
            <Text style={styles.cardTitle}>कुल मान-दिवस: {mdTotal}</Text>
            <Text style={styles.meta}>श्रमिक {byRole('labour')} · कारीगर {byRole('karigar')} · मेट {byRole('mate')}</Text>
            <Text style={styles.meta}>योग्य राशि: {formatINR(mdAmount)} · स्वीकृतियाँ {mandayCalcs.length}</Text>
            <Text style={styles.hint}>
              मान-दिवस मन-डे पृष्ठ (Manday) में बनते हैं — यहाँ सिर्फ़ कुल counting दिखती है।
            </Text>
            {mandayCalcs.length === 0 ? (
              <Empty title="अभी कोई गणना नहीं" why="मान-दिवस यहाँ दिखने के लिए पहले Manday page से स्वीकृति बनाएँ" steps={['कार्य खोलें', 'मन-डे स्वीकृति खोलें', 'विकल्प चुनकर save करें']} />
            ) : null}
          </View>
        ) : null}
      </ScrollView>

      {/* v11 #18 + v12 #6/#32 — BSR दर सुधारने का popup (scroll + हमेशा Back) */}
      <Modal visible={!!bEdit} transparent animationType="fade" onRequestClose={() => setBEdit(null)}>
        <ModalBody title={`BSR दर सुधारें — ${bsrYear}`} onClose={() => setBEdit(null)} backdropClose={false}>
          <Field label="Item" value={bEdit?.itemName || ''} onChangeText={(t) => setBEdit((e) => (e ? { ...e, itemName: t } : e))} />
          <Field label="Unit" value={bEdit?.unit || ''} onChangeText={(t) => setBEdit((e) => (e ? { ...e, unit: t } : e))} />
          <Field
            label="Rate (₹)"
            value={bEdit?.rate || ''}
            keyboardType="numeric"
            onChangeText={(t) => setBEdit((e) => (e ? { ...e, rate: t } : e))}
          />
          <Text style={styles.meta}>यह बदलाव सिर्फ़ {bsrYear} की दर पर लागू होगा — दूसरे वर्ष अपरिवर्तित रहेंगे।</Text>
          <Btn
            label="सहेजें (save)"
            icon="check"
            onPress={() => {
              if (!bEdit) return;
              /* v13 #2 — 0 एक वैध दर है (ग़लत दर को 0 करके बंद किया जा सकता है) */
              const rv = parseFloat(bEdit.rate);
              if (!bEdit.itemName.trim() || !Number.isFinite(rv) || rv < 0)
                return Alert.alert('Item + rate चाहिए', 'दर 0 या उससे अधिक होनी चाहिए (0 = दर हटाई जा रही है)।');
              updateBsrRate(bEdit.id, {
                itemName: bEdit.itemName.trim(),
                unit: bEdit.unit.trim(),
                rate: parseFloat(bEdit.rate),
              });
              setBEdit(null);
            }}
          />
        </ModalBody>
      </Modal>

      {/* v11 #18 — BSR दर हटाने की पुष्टि */}
      <Modal visible={!!bDel} transparent animationType="fade" onRequestClose={() => setBDel(null)}>
        <ModalBody title="यह दर हटाएँ?" onClose={() => setBDel(null)}>
          <Text style={styles.sumLine}>{bDel?.itemName}</Text>
          <Text style={styles.meta}>वर्ष {bsrYear} की दर हटेगी — दूसरे वर्ष की दरें नहीं बदलेंगी।</Text>
          <Btn label="हाँ, हटाएँ" variant="danger" icon="trash-2" onPress={() => { if (bDel) deleteBsrRate(bDel.id); setBDel(null); }} />
        </ModalBody>
      </Modal>

      {/* v11 #19 — अपना नया वर्ष जोड़ें (किसी भी वित्तीय वर्ष की BSR अलग से) */}
      <Modal visible={newYearOpen} transparent animationType="fade" onRequestClose={() => setNewYearOpen(false)}>
        <ModalBody title="नया वर्ष (BSR)" onClose={() => setNewYearOpen(false)} backdropClose={false}>
          <Field label="वर्ष label" value={newYear} onChangeText={setNewYear} placeholder="जैसे 2024-25" />
          <Btn
            label="वर्ष जोड़ें"
            icon="plus"
            onPress={() => {
              const y = newYear.trim();
              if (!y) return Alert.alert('वर्ष label भरें');
              setBsrYear(y);
              setNewYearOpen(false);
              Alert.alert('वर्ष चुना गया', `अब ${y} की BSR items नीचे जोड़ें।`);
            }}
          />
        </ModalBody>
      </Modal>
    </View>
  );
}

/** instruction #15 — month filter dropdown (manual type नहीं करना) */
const HI_MONTHS = ['जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितम्बर', 'अक्टूबर', 'नवम्बर', 'दिसम्बर'];
function monthLabel(m: string): string {
  const [y, mo] = m.split('-').map(Number);
  if (!y || !mo) return m;
  return `${HI_MONTHS[(mo - 1) % 12]} ${y}`;
}

function MonthlyScreen({ back }: { back: () => void }) {
  const { fyTransactions, updateTransaction, cancelTransaction, activeFunds, categories, purgeTransactions } = useStore();
  const [filter, setFilter] = useState<'all' | 'incomplete' | 'cancelled'>('all');
  const [editId, setEditId] = useState<string | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Transaction | null>(null);
  const [editParty, setEditParty] = useState('');
  const [editDetail, setEditDetail] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editNote, setEditNote] = useState('');
  const [editScheme, setEditScheme] = useState('');
  const [editRef, setEditRef] = useState('');
  const [editAsset, setEditAsset] = useState('');
  const [editCat, setEditCat] = useState<string | null>(null);
  const [editCat2, setEditCat2] = useState<string | null>(null);
  const [editCat3, setEditCat3] = useState<string | null>(null);
  /* instruction #6 — एक ही राशि column (ऊपर scheme चुन ली जाती है) */
  const [editAmount, setEditAmount] = useState('');
  const [editFolio, setEditFolio] = useState('');
  const [editErr, setEditErr] = useState('');
  const [month, setMonth] = useState('');

  /* instruction #8 — फ़ोन का back button अब "Entry सुधारें" को बंद करता है
     (पहले Shell का BackHandler स्टेज pop करता था और modal खुला ही रह जाता था)। */
  React.useEffect(() => {
    if (!editId) return;
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      setEditId(null);
      return true;
    });
    return () => sub.remove();
  }, [editId]);

  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;

  const list = fyTransactions.filter((t) => {
    if (month && !t.date.startsWith(month)) return false;
    // J.2 — incomplete = scheme ya category path ka deepest level missing
    if (filter === 'incomplete')
      return t.status === 'active' && (!t.schemeId || isPathIncomplete(t, categories));
    if (filter === 'cancelled') return t.status === 'cancelled';
    return true;
  });

  /* instruction #7 — SFC/FFC हट चुकी हैं (श्रेणी नहीं, योजना हैं); stale id हो तो ख़ाली कर दो */
  const aliveCat = (id: string | null) => (id && categories.some((c) => c.id === id) ? id : null);

  const openEdit = (t: Transaction) => {
    setEditId(t.id);
    setEditErr('');
    setEditParty(t.party);
    setEditDetail(t.detail);
    setEditDate(t.date);
    setEditNote(t.note);
    /* v10 #8 — legacy entry जिसकी योजना 'cash' हो तो उसे चुनने-योग्य योजना में बदल दो */
    setEditScheme(t.schemeId === 'cash' ? activeFunds.find((f) => f.id !== 'cash')?.id || t.schemeId : t.schemeId);
    setEditCat(aliveCat(t.categoryId));
    setEditCat2(aliveCat(t.subcategoryId));
    setEditCat3(aliveCat(t.subSubcategoryId));
    setEditRef(t.reference || '');
    setEditAsset(t.assetPage || '');
    setEditFolio(t.ledgerFolio || '');
    /* instruction #6 — सिर्फ़ एक राशि: scheme के नीचे उसी scheme की राशि */
    const v = t.amounts[t.schemeId] ?? sumAmounts(t.amounts);
    setEditAmount(v ? String(v) : '');
  };

  const saveEdit = async () => {
    if (!editId) return;
    /* instruction #6 — एक ही amount column; scheme ऊपर चुनी जाती है */
    const am: Record<string, number> = {};
    const raw = editAmount.trim();
    if (!raw) return setEditErr('राशि भरें');
    const n = Number(raw);
    if (!Number.isFinite(n)) return setEditErr(`"${raw}" अमान्य राशि`);
    if (n < 0) return setEditErr('ऋणात्मक राशि अनुमति नहीं');
    if (n > 0) am[editScheme] = n;
    const r = await updateTransaction(editId, {
      party: editParty.trim(),
      detail: editDetail.trim(),
      date: editDate,
      note: editNote.trim(),
      reference: editRef.trim(),
      schemeId: editScheme,
      categoryId: editCat,
      subcategoryId: editCat2,
      subSubcategoryId: editCat3,
      ledgerFolio: editFolio.trim(),
      assetPage: editAsset.trim(),
      amounts: am,
    });
    // bug fix: pehle result check hi nahi hota tha — guard violation chup-chaap save ho jata tha
    if (!r.ok) return setEditErr(r.error || 'सहेजा नहीं जा सका');
    setEditId(null);
    Alert.alert('सुधार सहेज लिया', undefined, [{ text: 'OK' }]);
  };

  const editing = fyTransactions.find((t) => t.id === editId);
  const editRoots = editing ? categories.filter((c) => c.kind === editing.type && c.level === 1 && !c.archived) : [];
  const editL2 = categories.filter((c) => c.parentId === editCat && !c.archived);
  const editL3 = categories.filter((c) => c.parentId === editCat2 && !c.archived);

  return (
    <View style={styles.page}>
      <Header title="Monthly check" onBack={back} badge="S-47" />
      <ScrollView contentContainerStyle={styles.pad}>
        <SelectField
          label="महीना चुनें (dropdown)"
          value={month ? monthLabel(month) : ''}
          placeholder="सब — कोई filter नहीं"
          options={[
            { key: '', label: 'सब — कोई filter नहीं' },
            ...Array.from(new Set(fyTransactions.map((t) => t.date.slice(0, 7))))
              .sort()
              .reverse()
              .map((m) => ({ key: m, label: monthLabel(m) })),
          ]}
          onSelect={setMonth}
          hint="महीना manual भरने की ज़रूरत नहीं — जिन महीनों में entry हैं वही dropdown में दिखेंगे।"
        />
        <View style={styles.row}>
          <Btn label="All" variant={filter === 'all' ? 'primary' : 'outline'} onPress={() => setFilter('all')} />
          <Btn label="Incomplete" variant={filter === 'incomplete' ? 'primary' : 'outline'} onPress={() => setFilter('incomplete')} />
          <Btn label="Cancelled" variant={filter === 'cancelled' ? 'primary' : 'outline'} onPress={() => setFilter('cancelled')} />
        </View>
        {list.length === 0 ? (
          <Empty title="No rows" why="Is FY/filter me entries nahi" steps={['Add cashbook entry', 'Filter badlein']} />
        ) : null}
        {list.map((t) => (
          <View key={t.id} style={styles.card}>
            <Text
              style={[
                styles.cardTitle,
                t.status === 'cancelled' ? { textDecorationLine: 'line-through', color: C.expense } : null,
              ]}
            >
              {t.date} · {t.type} · {t.party || '(no party)'} {t.status === 'cancelled' ? '· रद्द' : ''}
            </Text>
            <Text style={styles.meta}>
              {formatINR(sumAmounts(t.amounts))} · scheme={t.schemeId || 'MISSING'} ·{' '}
              {categoryPathLabel(t, catNames) || 'cat=MISSING'}
            </Text>
            {t.status === 'cancelled' ? (
              <Text style={[styles.meta, { color: C.expense }]}>कारण: {t.cancelReason || '—'}</Text>
            ) : null}
            <View style={styles.row}>
              <Btn label="✏ Edit" onPress={() => openEdit(t)} />
              {t.status === 'active' ? (
                <Btn label="Cancel entry" variant="danger" onPress={() => setCancelTarget(t)} />
              ) : null}
              {/* v12 #11 — रद्द entries को यहीं से स्थायी मिटाव (audit trail से भी गायब) */}
              {t.status === 'cancelled' && filter === 'cancelled' ? (
                <Btn
                  label="मिटाएँ (delete permanently)"
                  variant="danger"
                  icon="trash-2"
                  onPress={() =>
                    Alert.alert(
                      'स्थायी रूप से मिटाएँ?',
                      `${t.date} · ${t.party || '(no party)'} — यह entry और उसकी audit-log दोनों हमेशा के लिए मिट जाएँगी।`,
                      [
                        { text: 'रहने दें', style: 'cancel' },
                        {
                          text: 'हाँ, मिटाएँ',
                          style: 'destructive',
                          onPress: () => {
                            const n = purgeTransactions([t.id]);
                            Alert.alert(n ? 'मिटा दिया' : 'कुछ नहीं मिटा', n ? 'Entry audit trail सहित मिटा दी गई।' : '—');
                          },
                        },
                      ]
                    )
                  }
                />
              ) : null}
            </View>
            {t.status === 'cancelled' && filter !== 'cancelled' ? (
              <Text style={styles.meta}>इस entry को स्थायी मिटाने के लिए ऊपर “Cancelled” filter खोलें → “मिटाएँ”।</Text>
            ) : null}
          </View>
        ))}
      </ScrollView>

      {cancelTarget ? (
        <CancelModal
          txn={cancelTarget}
          onCancel={() => setCancelTarget(null)}
          onConfirm={async (reason) => {
            const r = await cancelTransaction(cancelTarget.id, reason);
            setCancelTarget(null);
            if (!r.ok) Alert.alert(r.error || 'रद्द नहीं हुआ');
          }}
        />
      ) : null}

      {/* Full edit modal — har transaction par sudhaar */}
      <Modal visible={!!editId} animationType="slide" onRequestClose={() => setEditId(null)}>
        <View style={[styles.page, { paddingTop: 50 }]}>
          <Header title="Entry सुधारें" onBack={() => setEditId(null)} badge="S-48" />
          <ScrollView contentContainerStyle={styles.pad}>
            <DateField label="दिनांक" value={editDate} onChange={setEditDate} />
            {!isValidIsoDate(editDate) ? <Text style={styles.err}>तारीख format अमान्य — जैसे 2026-09-24</Text> : null}
            <Field label={editing?.type === 'income' ? 'किससे प्राप्त' : 'किसको भुगतान'} value={editParty} onChangeText={setEditParty} />
            <Field label="Detail" value={editDetail} onChangeText={setEditDetail} />
            <Field
              label={editing?.type === 'income' ? 'रसीद/चेक क्रमांक' : 'वाउचर/चेक क्रमांक'}
              value={editRef}
              onChangeText={setEditRef}
            />
            <Field label="L.F. (Ledger Folio)" value={editFolio} onChangeText={setEditFolio} keyboardType="numeric" />
            {editing?.type === 'expense' ? (
              <Field label="परिसंपत्ति रजिस्टर पृष्ठ" value={editAsset} onChangeText={setEditAsset} keyboardType="numeric" />
            ) : null}
            <Field label="Note" value={editNote} onChangeText={setEditNote} multiline />
            <Text style={styles.section}>Scheme *</Text>
            <View style={styles.chips}>
              {/* v10 #8 — cash माध्यम है, योजना नहीं → यहाँ न दिखे */}
              {activeFunds
                .filter((f) => f.id !== 'cash')
                .map((f) => (
                  <Pressable key={f.id} onPress={() => setEditScheme(f.id)} style={[styles.chip, editScheme === f.id && styles.chipOn]}>
                    <Text style={{ color: editScheme === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
                  </Pressable>
                ))}
            </View>
            {/* instruction #6 — एक ही राशि column; scheme ऊपर चुन ली जाती है */}
            <Text style={styles.section}>राशि (एक ही column)</Text>
            <Field
              label={`राशि (₹) — ${activeFunds.find((f) => f.id === editScheme)?.shortName || 'scheme'}`}
              value={editAmount}
              onChangeText={setEditAmount}
              keyboardType="numeric"
              bg="#ffffff"
            />
            <Text style={styles.meta}>
              Scheme ऊपर चुनी जाती है — इसलिए हर fund के लिए अलग-अलग amount भरने की ज़रूरत नहीं।
            </Text>
            <Text style={styles.section}>Category path (L1 → L2 → L3)</Text>
            <View style={styles.chips}>
              {editRoots.map((c) => (
                <Pressable key={c.id} onPress={() => { setEditCat(c.id); setEditCat2(null); setEditCat3(null); }} style={[styles.chip, editCat === c.id && styles.chipOn]}>
                  <Text style={{ color: editCat === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                </Pressable>
              ))}
            </View>
            {editL2.length ? (
              <View style={styles.chips}>
                {editL2.map((c) => (
                  <Pressable key={c.id} onPress={() => { setEditCat2(c.id); setEditCat3(null); }} style={[styles.chip, editCat2 === c.id && styles.chipOn]}>
                    <Text style={{ color: editCat2 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
            {editL3.length ? (
              <View style={styles.chips}>
                {editL3.map((c) => (
                  <Pressable key={c.id} onPress={() => setEditCat3(c.id)} style={[styles.chip, editCat3 === c.id && styles.chipOn]}>
                    <Text style={{ color: editCat3 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
            {editCat ? (
              <Text style={styles.meta}>
                Path: {categoryPathLabel({ categoryId: editCat, subcategoryId: editCat2, subSubcategoryId: editCat3 }, catNames)}
              </Text>
            ) : null}
            {editErr ? <Text style={styles.err}>{editErr}</Text> : null}
            <View style={styles.row}>
              <Btn label="Save" icon="check" onPress={saveEdit} />
              <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setEditId(null)} />
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

function GoswaraScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, activeFunds, totalOpening, categories, activePanchayat, activeFy, bankLines, works } = useStore();
  const active = fyTransactions.filter((t) => t.status === 'active');
  if (active.length === 0) {
    return (
      <View style={styles.page}>
        <Header title="गोशवारा" onBack={back} badge="S-27" />
        <View style={styles.pad}>
          <Empty title="गोशवारा खाली" why="Is FY me abhi koi entry nahi" steps={['Cashbook me income/expense add karein', 'Ledgers auto update ho jayenge']} />
        </View>
      </View>
    );
  }
  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;
  const workNames: Record<string, string> = {};
  for (const w of works) workNames[w.id] = w.name;
  const schemeNames: Record<string, string> = {};
  for (const f of activeFunds) schemeNames[f.id] = f.name;
  const g = buildGoswara(fyTransactions, catNames, totalOpening, workNames, schemeNames);
  /* instruction #11 — गोशवारा hamesha do-sided (upload ki Excel jaisa), share me PDF/Excel */
  const hdr: FmtHeader = {
    panchayat: activePanchayat.name,
    block: activePanchayat.block,
    district: activePanchayat.district,
    fy: activeFy.label,
    formName: 'वार्षिक आय - व्यय सामान्य रोकड़ बही (गोशवारा) — till date',
  };
  /**
   * v10 #11 — bottom footer lines (Excel जैसे) दोनों तरफ़:
   *  आय पक्ष : आय योग · प्रारंभिक बैंक शेष · प्रारंभिक नकद शेष · महायोग
   *  व्यय पक्ष: व्यय योग · अंतिम बैंक शेष · अंतिम नकद शेष · महायोग
   * बैंक शेष = statement lines का net (credit − debit); नकद = कुल शेष − बैंक,
   * ताकि spec का समीकरण (आय महायोग = व्यय महायोग) सही बैठे।
   */
  const fyBankLines0 = bankLines.filter((l) => l.fyId === activeFy.id && !l.ignored);
  const antimBank = Math.round(
    fyBankLines0.reduce((s, l) => s + (l.side === 'credit' ? l.amount : -l.amount), 0) * 100
  ) / 100;
  const prarambhikBank = 0;
  const prarambhikNagad = g.prarambhikNagad;
  const antimNagad = Math.round((g.antSheshNagad - antimBank) * 100) / 100;
  const aayMahayog = Math.round((g.aayYog + prarambhikBank + prarambhikNagad) * 100) / 100;
  const vyayMahayog = Math.round((g.vyayYog + antimBank + antimNagad) * 100) / 100;

  const share = async () => {
    const body = goswaraHtml({
      header: hdr,
      rows: g.rows,
      aayYog: g.aayYog,
      vyayYog: g.vyayYog,
      prarambhikNagad,
      prarambhikBank,
      antimNagad,
      antimBank,
    });
    await askAndShare('गोशवारा (रोकड़ बही)', body, true);
  };

  /* v13 #13 — किसी भी entry (दोनों पक्ष) पर tap → उस entry के मद का ledger खुले */
  const jumpTxnLedger = (t: Transaction) => {
    Object.keys(ledgerJump).forEach((k) => delete (ledgerJump as Record<string, string>)[k]);
    if (t.workId) ledgerJump.workId = t.workId;
    else if (t.categoryId) ledgerJump.catId = t.categoryId;
    else if (t.schemeId) ledgerJump.fundId = t.schemeId;
    go('ledgers');
  };

  /* v10 #11 — footer row: [लेबल, राशि, रंग] */
  const footRow = (label: string, amt: number, color: string, bold = false) => (
    <View style={[styles.tblTot, bold ? { backgroundColor: '#e6f2ea' } : null]}>
      <Text style={[styles.tblCell, { flex: 5, fontWeight: bold ? '900' : '700' }]}>{label}</Text>
      <Text
        style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: bold ? '900' : '800', color }]}
      >
        {formatINR(amt)}
      </Text>
    </View>
  );
  return (
    <View style={styles.page}>
      <Header title="गोशवारा till date" onBack={back} badge="S-55" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>वार्षिक आय-व्यय सामान्य रोकड़ बही (audit demo format) — हर entry पर auto-update</Text>
        {/* instruction #9 — गोशवारा अब Excel-जैसा table: header band + borders + striping (plain list नहीं) */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>दो-पक्षीय विवरण (Cashbook की तरह — Excel table)</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}>
              <View style={styles.tblBox}>
                <View style={styles.tblHead}>
                  <Text style={[styles.tblHeadCell, { flex: 2 }]}>दिनांक</Text>
                  <Text style={[styles.tblHeadCell, { flex: 3 }]}>किससे प्राप्त</Text>
                  <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>राशि (₹)</Text>
                </View>
                {active
                  .filter((t) => t.type === 'income')
                  .sort((a, b) => a.date.localeCompare(b.date))
                  .map((t, i) => (
                    /* v13 #13 — आय पक्ष की entry tap → उस मद का ledger */
                    <Pressable
                      key={t.id}
                      onPress={() => jumpTxnLedger(t)}
                      style={[styles.tblRow, i % 2 ? { backgroundColor: '#f7faf8' } : null]}
                    >
                      <Text numberOfLines={1} style={[styles.tblCell, { flex: 2, fontSize: 10 }]}>{fmtDate(t.date)}</Text>
                      <Text numberOfLines={2} style={[styles.tblCell, { flex: 3, fontSize: 10 }]}>{t.party || t.detail || '—'}</Text>
                      <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', color: C.primary, fontWeight: '800' }]}>
                        {formatINR(sumAmounts(t.amounts))} ›
                      </Text>
                    </Pressable>
                  ))}
                <View style={styles.tblTot}>
                  <Text style={[styles.tblCell, { flex: 5, fontWeight: '800' }]}>आय योग</Text>
                  <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900', color: C.primary }]}>
                    {formatINR(g.aayYog)}
                  </Text>
                </View>
                {/* v10 #11 — आय पक्ष की bottom footer lines (Excel style) */}
                {footRow('प्रारंभिक बैंक शेष', prarambhikBank, C.foreground)}
                {footRow('प्रारंभिक नकद शेष', prarambhikNagad, C.foreground)}
                {footRow('महायोग', aayMahayog, C.primary, true)}
              </View>
            </View>
            <View style={{ flex: 1 }}>
              <View style={styles.tblBox}>
                <View style={styles.tblHead}>
                  <Text style={[styles.tblHeadCell, { flex: 2 }]}>दिनांक</Text>
                  <Text style={[styles.tblHeadCell, { flex: 3 }]}>किसको भुगतान</Text>
                  <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>राशि (₹)</Text>
                </View>
                {active
                  .filter((t) => t.type === 'expense')
                  .sort((a, b) => a.date.localeCompare(b.date))
                  .map((t, i) => (
                    /* v13 #13 — व्यय पक्ष की entry tap → उस मद का ledger */
                    <Pressable
                      key={t.id}
                      onPress={() => jumpTxnLedger(t)}
                      style={[styles.tblRow, i % 2 ? { backgroundColor: '#f7faf8' } : null]}
                    >
                      <Text numberOfLines={1} style={[styles.tblCell, { flex: 2, fontSize: 10 }]}>{fmtDate(t.date)}</Text>
                      <Text numberOfLines={2} style={[styles.tblCell, { flex: 3, fontSize: 10 }]}>{t.party || t.detail || '—'}</Text>
                      <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', color: C.expense, fontWeight: '800' }]}>
                        {formatINR(sumAmounts(t.amounts))} ›
                      </Text>
                    </Pressable>
                  ))}
                <View style={styles.tblTot}>
                  <Text style={[styles.tblCell, { flex: 5, fontWeight: '800' }]}>व्यय योग</Text>
                  <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900', color: C.expense }]}>
                    {formatINR(g.vyayYog)}
                  </Text>
                </View>
                {/* v10 #11 — व्यय पक्ष की bottom footer lines (Excel style) */}
                {footRow('अंतिम बैंक शेष', antimBank, C.foreground)}
                {footRow('अंतिम नकद शेष', antimNagad, C.foreground)}
                {footRow('महायोग', vyayMahayog, C.expense, true)}
              </View>
            </View>
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>नाम-मद वार Excel table</Text>
          <View style={styles.tblBox}>
            <View style={styles.tblHead}>
              <Text style={[styles.tblHeadCell, { width: 30 }]}>#</Text>
              <Text style={[styles.tblHeadCell, { flex: 1 }]}>नाम मद</Text>
              <Text style={[styles.tblHeadCell, { flex: 1, textAlign: 'right' }]}>आय (₹)</Text>
              <Text style={[styles.tblHeadCell, { flex: 1, textAlign: 'right' }]}>व्यय (₹)</Text>
            </View>
            {g.rows.map((r, i) => (
              /* v11 #12 — किसी भी मद पर tap → उसी का ledger (cross-link) */
              <Pressable
                key={i}
                onPress={() => {
                  Object.keys(ledgerJump).forEach((k) => delete (ledgerJump as Record<string, string>)[k]);
                  if (r.key.startsWith('work:')) ledgerJump.workId = r.key.slice(5);
                  else if (r.key.startsWith('scheme:')) ledgerJump.fundId = r.key.slice(7);
                  else if (r.key.startsWith('cat:')) ledgerJump.catId = r.key.slice(4).split('/').pop() || '';
                  go('ledgers');
                }}
                style={[
                  styles.tblRow,
                  { flexDirection: 'row', alignItems: 'center' },
                  i % 2 ? { backgroundColor: '#f7faf8' } : null,
                ]}
              >
                <Text style={[styles.tblCell, { width: 30, color: C.mutedForeground }]}>{i + 1}</Text>
                <Text numberOfLines={2} style={[styles.tblCell, { flex: 1 }]}>{r.name}</Text>
                <Text style={[styles.tblCell, { flex: 1, textAlign: 'right', color: C.primary }]}>{r.inc ? formatINR(r.inc) : ''}</Text>
                <Text style={[styles.tblCell, { flex: 1, textAlign: 'right', color: C.expense }]}>{r.exp ? formatINR(r.exp) : ''}</Text>
              </Pressable>
            ))}
            <View style={[styles.tblRow, { backgroundColor: C.primarySoft }]}>
              <Text style={[styles.tblCell, { fontSize: 10, color: C.primary }]}>
                ↑ किसी भी मद / कार्य / योजना पर tap करें — उसका पूरा ledger खुलेगा (आय-व्यय दोनों)
              </Text>
            </View>
            <View style={styles.tblTot}>
              <Text style={[styles.tblCell, { width: 30 }]} />
              <Text style={[styles.tblCell, { flex: 1, fontWeight: '900' }]}>कुल योग</Text>
              <Text style={[styles.tblCell, { flex: 1, textAlign: 'right', fontWeight: '900', color: C.primary }]}>{formatINR(g.aayYog)}</Text>
              <Text style={[styles.tblCell, { flex: 1, textAlign: 'right', fontWeight: '900', color: C.expense }]}>{formatINR(g.vyayYog)}</Text>
            </View>
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>निचोड़ (footer) — दोनों पक्ष</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={[styles.tblBox, { flex: 1 }]}>
              <View style={styles.tblHead}>
                <Text style={[styles.tblHeadCell, { flex: 5 }]}>आय पक्ष</Text>
                <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>राशि (₹)</Text>
              </View>
              {footRow('आय योग', g.aayYog, C.primary)}
              {footRow('प्रारंभिक बैंक शेष', prarambhikBank, C.foreground)}
              {footRow('प्रारंभिक नकद शेष', prarambhikNagad, C.foreground)}
              {footRow('महायोग', aayMahayog, C.primary, true)}
            </View>
            <View style={[styles.tblBox, { flex: 1 }]}>
              <View style={styles.tblHead}>
                <Text style={[styles.tblHeadCell, { flex: 5 }]}>व्यय पक्ष</Text>
                <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>राशि (₹)</Text>
              </View>
              {footRow('व्यय योग', g.vyayYog, C.expense)}
              {footRow('अंतिम बैंक शेष', antimBank, C.foreground)}
              {footRow('अंतिम नकद शेष', antimNagad, C.foreground)}
              {footRow('महायोग', vyayMahayog, C.expense, true)}
            </View>
          </View>
          <Text style={[styles.meta, { marginTop: 8 }]}>
            {Math.abs(aayMahayog - vyayMahayog) < 0.01
              ? `समीकरण जाँच — आय महायोग = व्यय महायोग (${formatINR(aayMahayog)}) : बराबर ✓`
              : `समीकरण जाँच — आय महायोग ${formatINR(aayMahayog)} ≠ व्यय महायोग ${formatINR(vyayMahayog)} : बराबर नहीं, जाँच करें`}
          </Text>
        </View>
        <View style={styles.row}>
          <Btn label="Share — PDF / Excel" icon="share-2" onPress={share} />
          <Btn label="Formats Centre" variant="outline" onPress={() => go('formats')} />
        </View>
        <View style={styles.card}>
          <Text style={styles.meta}>हस्ताक्षर: ______ सरपंच        ______ ग्राम विकास अधिकारी</Text>
        </View>
      </ScrollView>
    </View>
  );
}

/* v11 #12 — गोशवारा की किसी भी पंक्ति पर tap → उसी मद/योजना/कार्य का ledger खुले */
const ledgerJump: { fundId?: string; workId?: string; catId?: string; month?: string } = {};
function takeLedgerJump() {
  const j = { ...ledgerJump };
  Object.keys(ledgerJump).forEach((k) => delete (ledgerJump as Record<string, string>)[k]);
  return j;
}

function LedgersScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, activeFunds, totalOpening, activePanchayat, activeFy, fundOpening, works, bills, categories, fyPages } = useStore();
  /* v13 #10 — ledger की किसी पंक्ति पर tap → उसी entry का कैशबुक पन्ना खुले */
  const jumpToCashbook = (r: { txnId?: string }) => {
    if (!r.txnId) return;
    const t = fyTransactions.find((x) => x.id === r.txnId);
    if (!t) return;
    const idx = fyPages.findIndex((p) => p.id === t.pageId);
    if (idx < 0) return Alert.alert('पन्ना नहीं मिला', 'यह entry किसी कैशबुक पन्ने पर असाइन नहीं है।');
    cashbookUI.page = idx;
    cashbookUI.gotoDate = '';
    cashbookUI.openPage = idx;
    go('cashbook');
  };
  /* v10 #13 — home page par 4 dropdown: योजना / कार्य / व्यय-श्रेणी / महीना */
  const jump = React.useMemo(takeLedgerJump, []);
  const [fundId, setFundId] = useState<string>(jump.fundId || '');
  const [workId, setWorkId] = useState<string>(jump.workId || '');
  const [catId, setCatId] = useState<string>(jump.catId || '');
  const [month, setMonth] = useState<string>(jump.month || '');
  const active = fyTransactions.filter((t) => t.status === 'active');
  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  const months = [...new Set(active.map((t) => t.date.slice(0, 7)))].sort();

  const amtOf = (t: Transaction) => (fundId ? Number(t.amounts[fundId]) || 0 : sumAmounts(t.amounts));
  const inCat = (t: Transaction) =>
    !catId || t.categoryId === catId || t.subcategoryId === catId || t.subSubcategoryId === catId;
  const scoped = active.filter(
    (t) => (!workId || t.workId === workId) && (!month || t.date.slice(0, 7) === month) && inCat(t)
  );
  const selFund = fundId ? activeFunds.find((x) => x.id === fundId) : undefined;
  const selWork = workId ? works.find((w) => w.id === workId) : undefined;
  /* v11 #12 — व्यय-श्रेणी dropdown (path label सहित) */
  const catName: Record<string, string> = {};
  for (const c of categories) catName[c.id] = c.name;
  const selCat = catId ? categories.find((c) => c.id === catId) : undefined;
  const pathOf = (id: string): string => {
    const names: string[] = [];
    let cur: typeof selCat | null = categories.find((c) => c.id === id) || null;
    let g = 0;
    while (cur && g++ < 5) {
      names.unshift(cur.name);
      cur = cur.parentId ? categories.find((c) => c.id === cur!.parentId) || null : null;
    }
    return names.join(' › ');
  };
  /* व्यय-श्रेणी dropdown: सिर्फ़ वे जिनकी कोई उपश्रेणी नहीं (leaf) — ताकि filter साफ़ रहे */
  const catLeafIds = categories.filter((c) => c.kind === 'expense' && !c.archived);
  const hasKid = (id: string) => catLeafIds.some((c) => c.parentId === id);
  const catOptions = [
    { key: '', label: 'सभी व्यय श्रेणियाँ' },
    ...catLeafIds.filter((c) => !hasKid(c.id)).map((c) => ({ key: c.id, label: pathOf(c.id) })),
  ];

  /**
   * v10 #12 — **कार्य-वार ledger**: जिस कार्य से रक़म मिली/ख़र्च हुई उसी कार्य का
   * ledger (श्री पोते = 0, सिर्फ़ उस कार्य का आदान-प्रदान)। महीना चुना हो तो
   * श्री पोते = उस महीने से पहले तक का शेष।
   */
  const opening = (() => {
    if (workId || catId) return 0; // कार्य/श्रेणी-वार ledger — शुरुआत 0 से
    const f = selFund;
    let op = f ? fundOpening(f) : totalOpening;
    if (month) {
      for (const t of active.filter((x) => x.date.slice(0, 7) < month)) {
        const a = amtOf(t);
        if (!a) continue;
        op += t.type === 'expense' ? -a : a;
      }
    }
    return op;
  })();

  const rows = buildLedger(opening, scoped, fundId || undefined);
  const ledgerTitle = [
    'खाता बही',
    selWork ? selWork.name : selFund ? selFund.name : 'सभी योजनाएँ',
    selCat ? pathOf(selCat.id) : '',
    month ? monthLabel(month) : '',
  ]
    .filter(Boolean)
    .join(' — ');
  /* instruction #11 — खाता बही hamesha do-sided (upload ledger.pdf jaisa), share me PDF/Excel */
  const share = async () => {
    const body = ledgerHtml({
      header: {
        panchayat: activePanchayat.name,
        block: activePanchayat.block,
        district: activePanchayat.district,
        fy: activeFy.label,
        formName: ledgerTitle,
      },
      rows,
    });
    await askAndShare(ledgerTitle, body, true);
  };
  const tblHeadRow = (cells: string[]) => (
    <View style={styles.tblHead}>
      {cells.map((c, i) => (
        <Text key={i} style={styles.tblHeadCell}>{c}</Text>
      ))}
    </View>
  );
  return (
    <View style={styles.page}>
      <Header title="Ledgers (खाता बही)" onBack={back} badge="S-28" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          v10 #13 — योजना / कार्य / महीना dropdown से कोई भी ledger खोलें · श्री पोते → जमा/नाम → शेष (auto-update)
        </Text>
        <SelectField
          label="योजना (Scheme)"
          value={selFund?.name || 'सभी योजनाएँ'}
          options={[
            { key: '', label: 'सभी योजनाएँ' },
            ...activeFunds.map((f) => ({ key: f.id, label: f.name, sub: f.shortName })),
          ]}
          onSelect={setFundId}
        />
        <SelectField
          label="कार्य (Work)"
          value={selWork?.name || 'सभी कार्य'}
          options={[
            { key: '', label: 'सभी कार्य' },
            ...fyWorks.map((w) => ({ key: w.id, label: w.name, sub: w.sanctionRef || w.ward })),
          ]}
          onSelect={setWorkId}
          hint="कार्य चुनने पर उसी कार्य का आदान-प्रदान ledger (ZP/PS किस्त की जगह)"
        />
        {/* v11 #12 — व्यय-श्रेणी भी अलग ledger (गोशवारा की मद पर tap करने से यही खुलता है) */}
        <SelectField
          label="व्यय श्रेणी (Expense head)"
          value={selCat ? pathOf(selCat.id) : 'सभी श्रेणियाँ'}
          options={catOptions}
          onSelect={setCatId}
          hint="किसी खर्च-श्रेणी का अलग ledger — इस मद में कितना आया और कितना गया"
        />
        <SelectField
          label="महीना (Month)"
          value={month ? monthLabel(month) : 'पूरा वित्तीय वर्ष'}
          options={[
            { key: '', label: 'पूरा वित्तीय वर्ष' },
            ...months.map((m) => ({ key: m, label: monthLabel(m) })),
          ]}
          onSelect={setMonth}
        />
        {/* v10 #12 — हर format की तरह यहाँ भी Excel-जैसी table (borders + header band) */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>{ledgerTitle}</Text>
          <View style={styles.tblBox}>
            <View style={styles.tblHead}>
              <Text style={[styles.tblHeadCell, { flex: 2 }]}>दिनांक</Text>
              <Text style={[styles.tblHeadCell, { flex: 1 }]}>L.F.</Text>
              <Text style={[styles.tblHeadCell, { flex: 4 }]}>किस से प्राप्त / किसको भुगतान</Text>
              <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>जमा (₹)</Text>
              <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>नाम (₹)</Text>
              <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>शेष (₹)</Text>
            </View>
            {rows.map((r, i) => (
              /* v13 #10 — इस पंक्ति पर tap → उस entry का कैशबुक पन्ना (cross-link) */
              <Pressable
                key={i}
                onPress={() => jumpToCashbook(r)}
                style={[styles.tblRow, i % 2 ? { backgroundColor: '#f7faf8' } : null]}
              >
                <Text numberOfLines={1} style={[styles.tblCell, { flex: 2, fontSize: 10 }]}>
                  {r.date ? fmtDate(r.date) : 'श्री पोते'}
                </Text>
                <Text style={[styles.tblCell, { flex: 1, fontSize: 10, color: r.txnId ? C.primary : C.foreground, fontWeight: '800' }]}>
                  {r.folio ? `${r.folio} ›` : '—'}
                </Text>
                <Text numberOfLines={2} style={[styles.tblCell, { flex: 4, fontSize: 10 }]}>
                  {r.date ? r.party : r.detail}
                </Text>
                <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', color: C.primary, fontWeight: '700' }]}>
                  {r.credit ? formatINR(r.credit) : ''}
                </Text>
                <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', color: C.expense, fontWeight: '700' }]}>
                  {r.debit ? formatINR(r.debit) : ''}
                </Text>
                <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900' }]}>
                  {formatINR(r.running)}
                </Text>
              </Pressable>
            ))}
            <View style={styles.tblTot}>
              <Text style={[styles.tblCell, { flex: 5, fontWeight: '900' }]}>कुल योग</Text>
              <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900', color: C.primary }]}>
                {formatINR(rows.reduce((s, r) => s + r.credit, 0))}
              </Text>
              <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900', color: C.expense }]}>
                {formatINR(rows.reduce((s, r) => s + r.debit, 0))}
              </Text>
              <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900' }]}>
                {formatINR(rows[rows.length - 1]?.running || 0)}
              </Text>
            </View>
          </View>
        </View>

        {/* v10 #12 — दो-पक्षीय खाता बही भी Excel table में */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>दो-पक्षीय खाता बही (Excel table)</Text>
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ flex: 1 }}>
              <View style={styles.tblBox}>
                <View style={styles.tblHead}>
                  <Text style={[styles.tblHeadCell, { flex: 2 }]}>दिनांक</Text>
                  <Text style={[styles.tblHeadCell, { flex: 3 }]}>किससे प्राप्त</Text>
                  <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>राशि (₹)</Text>
                </View>
                {scoped
                  .filter((t) => t.type === 'income')
                  .sort((a, b) => a.date.localeCompare(b.date))
                  .map((t, i) => {
                    const w = works.find((x) => x.id === t.workId);
                    return (
                      <View key={t.id} style={[styles.tblRow, i % 2 ? { backgroundColor: '#f7faf8' } : null]}>
                        <Text numberOfLines={1} style={[styles.tblCell, { flex: 2, fontSize: 10 }]}>{fmtDate(t.date)}</Text>
                        <View style={[styles.tblCell, { flex: 3 }]}>
                          <Text numberOfLines={2} style={{ fontSize: 10 }}>{t.party || t.detail || '—'}</Text>
                          {w ? (
                            <Text numberOfLines={2} style={{ fontSize: 9, color: C.mutedForeground }}>
                              कार्य {w.name} · A.S. {w.asNo || '—'} · F.S. {w.fsNo || '—'}
                            </Text>
                          ) : null}
                          {t.note ? (
                            <Text numberOfLines={1} style={{ fontSize: 9, color: C.mutedForeground }}>{t.note}</Text>
                          ) : null}
                        </View>
                        <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', color: C.primary, fontWeight: '800' }]}>
                          {formatINR(amtOf(t))}
                        </Text>
                      </View>
                    );
                  })}
                <View style={styles.tblTot}>
                  <Text style={[styles.tblCell, { flex: 5, fontWeight: '800' }]}>आय योग</Text>
                  <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900', color: C.primary }]}>
                    {formatINR(scoped.filter((t) => t.type === 'income').reduce((s, t) => s + amtOf(t), 0))}
                  </Text>
                </View>
              </View>
            </View>
            <View style={{ flex: 1 }}>
              <View style={styles.tblBox}>
                <View style={styles.tblHead}>
                  <Text style={[styles.tblHeadCell, { flex: 2 }]}>दिनांक</Text>
                  <Text style={[styles.tblHeadCell, { flex: 3 }]}>किसको भुगतान</Text>
                  <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>राशि (₹)</Text>
                </View>
                {scoped
                  .filter((t) => t.type === 'expense')
                  .sort((a, b) => a.date.localeCompare(b.date))
                  .map((t, i) => {
                    const w = works.find((x) => x.id === t.workId);
                    const bl = bills.find((b) => b.id === (t as { billId?: string }).billId) || bills.find((b) => b.vendor && b.vendor === t.party);
                    return (
                      <View key={t.id} style={[styles.tblRow, i % 2 ? { backgroundColor: '#f7faf8' } : null]}>
                        <Text numberOfLines={1} style={[styles.tblCell, { flex: 2, fontSize: 10 }]}>{fmtDate(t.date)}</Text>
                        <View style={[styles.tblCell, { flex: 3 }]}>
                          <Text numberOfLines={2} style={{ fontSize: 10 }}>{t.party || t.detail || '—'}</Text>
                          {w ? (
                            <Text numberOfLines={2} style={{ fontSize: 9, color: C.mutedForeground }}>
                              कार्य {w.name} · T.S. {w.tsNo || '—'} · F.S. {w.fsNo || '—'}
                            </Text>
                          ) : null}
                          {bl ? (
                            <Text numberOfLines={1} style={{ fontSize: 9, color: C.mutedForeground }}>
                              बिल {formatINR(bl.amount)} · {bl.pageRef || '—'}
                            </Text>
                          ) : null}
                        </View>
                        <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', color: C.expense, fontWeight: '800' }]}>
                          {formatINR(amtOf(t))}
                        </Text>
                      </View>
                    );
                  })}
                <View style={styles.tblTot}>
                  <Text style={[styles.tblCell, { flex: 5, fontWeight: '800' }]}>व्यय योग</Text>
                  <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontWeight: '900', color: C.expense }]}>
                    {formatINR(scoped.filter((t) => t.type === 'expense').reduce((s, t) => s + amtOf(t), 0))}
                  </Text>
                </View>
              </View>
            </View>
          </View>
          <Text style={[styles.meta, { marginTop: 8 }]}>
            {selWork
              ? 'कार्य-वार ledger — सिर्फ़ उस कार्य से मिली/ख़र्च हुई रक़म (v10 #12; ZP/PS "प्रथम किस्त" ledger हटाया गया)'
              : 'दोनों पक्ष Excel-जैसी table में — PDF/Excel share भी यही layout बनाता है'}
          </Text>
        </View>

      </ScrollView>
    </View>
  );
}

function ReportsScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { exportCsvForFy, fyTransactions, auditLogs, activeFy } = useStore();
  const fyLogs = auditLogs.filter((l) => l.fyId === activeFy.id).slice(0, 25);
  return (
    <View style={styles.page}>
      <Header title="Reports hub" onBack={back} badge="S-34" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>{fyTransactions.length} rows in FY · Share CSV (Excel-readable). PDF layout uses white background per spec.</Text>
        <Btn
          label="Share FY CSV (Excel / .csv file)"
          icon="share-2"
          onPress={async () => shareFyCsv(`Cashbook-FY-${activeFy.label}`, exportCsvForFy())}
        />
        <View style={styles.row}>
          <Btn label="गोशवारा" variant="outline" onPress={() => go('goswara')} />
          <Btn label="Ledger" variant="outline" onPress={() => go('ledgers')} />
        </View>
        <View style={styles.row}>
          <Btn label="प्रपत्र Centre" variant="outline" onPress={() => go('formats')} />
          <Btn label="Monthly check" variant="outline" onPress={() => go('monthly')} />
        </View>

        {/* L.3 audit trail — create / update / cancel sab record */}
        <Text style={styles.section}>Audit trail (L.3 — नवीनतम {fyLogs.length})</Text>
        {fyLogs.length === 0 ? (
          <Text style={styles.meta}>अभी कोई log नहीं — entry बनाने/सुधारने/रद्द करने पर यहाँ दिखेगा।</Text>
        ) : (
          fyLogs.map((l) => (
            <View key={l.id} style={styles.card}>
              <Text style={styles.cardTitle}>
                {l.time.slice(0, 16).replace('T', ' ')} · {l.entity} · {l.action}
              </Text>
              <Text style={styles.meta}>
                {l.field ? `${l.field}: ${l.oldV || '—'} → ${l.newV || '—'}` : l.newV || ''}
                {l.reason ? ` · कारण: ${l.reason}` : ''}
              </Text>
            </View>
          ))
        )}
        <Empty
          title="PDF print layout"
          why="Native PDF renderer hooks to same dataset; CSV share works offline now."
          steps={['Use Share FY CSV in Excel', 'Page PDF engine binds to Option A layout in print module']}
        />
      </ScrollView>
    </View>
  );
}

function BankScreen({ back }: { back: () => void }) {
  const {
    bankAccounts, bankLines, addBankLine, updateBankLine, postBankLineToCashbook,
    activeFunds, activeFy, activePanchayat, works, vendors, categories,
  } = useStore();
  const [narr, setNarr] = useState('');
  const [amt, setAmt] = useState('');
  const [instr, setInstr] = useState('');
  const [side, setSide] = useState<'credit' | 'debit'>('credit');
  const [date, setDate] = useState(toIsoLocal(new Date()));
  /* instruction #13 — statement tagging: योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी */
  const [tagWork, setTagWork] = useState('');
  const [tagVendor, setTagVendor] = useState('');
  const [tagHead, setTagHead] = useState('');
  const [tagNote, setTagNote] = useState('');
  const fyLines = bankLines.filter((l) => l.fyId === activeFy.id);
  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  const heads = categories.filter((c) => c.level === 1 && !c.archived);
  const nameOfWork = (id: string | null | undefined) => fyWorks.find((w) => w.id === id)?.name || '';
  const nameOfVendor = (id: string | null | undefined) => vendors.find((v) => v.id === id)?.name || '';
  const nameOfHead = (id: string | null | undefined) => heads.find((c) => c.id === id)?.name || '';
  /* v9 #15 — Excel/CSV statement import + line सुधार */
  const [importMsg, setImportMsg] = useState('');
  const [editLineId, setEditLineId] = useState<string | null>(null);

  /* instruction #22 — statement असली Excel sheet जैसा दिखे */
  const [sheetView, setSheetView] = useState(true);
  const cell = (txt: string, w: number, align: 'left' | 'right' | 'center' = 'left', color = '#111') => (
    <Text
      key={txt + w + align}
      style={{
        width: w,
        fontSize: 11,
        color,
        textAlign: align,
        paddingVertical: 4,
        paddingHorizontal: 4,
        borderRightWidth: 1,
        borderRightColor: '#c9d8d0',
      }}
      numberOfLines={1}
    >
      {txt}
    </Text>
  );

  /* running balance — statement पर चलता शेष (bank demo sheet जैसा) */
  const sorted = [...fyLines].sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
  const balanceOf = new Map<string, number>();
  {
    let bal = fyLines.length ? 0 : 0;
    for (const l of sorted) {
      if (!l.ignored) bal += l.side === 'credit' ? l.amount : -l.amount;
      balanceOf.set(l.id, bal);
    }
  }

  const addLine = () => {
    // Part G: जमा + नाम दोनों; invalid date / zero amount block
    if (!isValidIsoDate(date)) return Alert.alert('अमान्य दिनांक', 'YYYY-MM-DD जैसे 2026-09-24');
    const n = Number(amt.trim());
    if (!Number.isFinite(n) || !(n > 0)) return Alert.alert('राशि > 0 चाहिए');
    if (!narr.trim()) return Alert.alert('Narration भरें');
    addBankLine({
      accountId: bankAccounts[0]?.id || 'ba1',
      fyId: activeFy.id,
      statementMonth: date.slice(0, 7),
      date,
      narration: narr.trim(),
      amount: n,
      side,
      instrument: instr.trim(),
      schemeId: null,
      workId: tagWork || null,
      vendorId: tagVendor || null,
      categoryId: tagHead || null,
      note: tagNote.trim() || undefined,
      ignored: false,
      postedTxnId: null,
    });
    setNarr('');
    setAmt('');
    setInstr('');
    setTagNote('');
  };

  /* ───────── v9 #15 — Excel / CSV bank statement import ───────── */
  type XCell = string | number | boolean | null;
  const hnorm = (v: unknown) => String(v ?? '').trim().toLowerCase().replace(/\s+/g, ' ');

  /** तारीख़: Excel serial / YYYY-MM-DD / DD/MM/YYYY (या DD-MM-YY) → ISO */
  const parseBankDate = (v: unknown): string => {
    if (typeof v === 'number' && v > 20000 && v < 80000) {
      const d = new Date(Date.UTC(1899, 11, 30) + Math.round(v) * 86400000);
      return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
    }
    const s = String(v ?? '').trim();
    if (isValidIsoDate(s)) return s;
    let m = /^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/.exec(s);
    if (m) {
      const iso = `${m[1]}-${String(+m[2]).padStart(2, '0')}-${String(+m[3]).padStart(2, '0')}`;
      if (isValidIsoDate(iso)) return iso;
    }
    m = /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/.exec(s);
    if (m) {
      let y = +m[3];
      if (y < 100) y += 2000;
      const iso = `${y}-${String(+m[2]).padStart(2, '0')}-${String(+m[1]).padStart(2, '0')}`;
      if (isValidIsoDate(iso)) return iso;
    }
    return '';
  };

  /** राशि: ₹ / , / खाली / (negative) हटाकर |value| */
  const parseAmt = (v: unknown): number => {
    if (typeof v === 'number') return Math.abs(v);
    const s = String(v ?? '')
      .replace(/[₹,\s]/g, '')
      .replace(/^\((.*)\)$/, '$1');
    const n = Math.abs(parseFloat(s));
    return Number.isFinite(n) ? n : 0;
  };

  const parseStatement = (rows: XCell[][]) => {
    const hi = rows.findIndex((r, i) =>
      i < 30 && r.some((c) => { const t = hnorm(c); return t === 'date' || t === 'narration' || t.startsWith('withdrawal'); })
    );
    if (hi < 0) throw new Error('Header पंक्ति नहीं मिली — DATE / NARRATION / WITHDRAWAL (DR) वाली सिर लाइन चाहिए');
    const hdr = rows[hi].map(hnorm);
    const col = (...names: string[]) => hdr.findIndex((h) => names.some((n) => h === n || h.startsWith(n + ' ')));
    const cDate = col('date', 'txn date', 'transaction date', 'value date', 'val date', 'दिनांक');
    const cNarr = col('narration', 'description', 'details', 'विवरण');
    const cPart = col('particulars');
    const cOther = col('other', 'remarks', 'note', 'remark');
    const cWd = col('withdrawal (dr)', 'withdrawal', 'debit', 'dr', 'निकासी');
    const cDep = col('deposit (cr)', 'deposit', 'credit', 'cr', 'जमा');
    const cSch = col('scheme', 'yojna', 'fund', 'योजना');
    const cVen = col('vendor', 'party', 'payee', 'beneficiary');
    const cIns = col('instrument', 'cheque no', 'cheque', 'utr', 'ref no', 'reference');
    if (cDate < 0) throw new Error('DATE column नहीं मिला');
    if (cWd < 0 && cDep < 0) throw new Error('WITHDRAWAL (DR) / DEPOSIT (CR) columns नहीं मिले');

    const out: {
      date: string; narration: string; amount: number; side: 'credit' | 'debit';
      instrument: string; note?: string; schemeId: string | null;
    }[] = [];
    for (let i = hi + 1; i < rows.length; i++) {
      const r = rows[i] || [];
      const dr = cWd >= 0 ? parseAmt(r[cWd]) : 0;
      const cr = cDep >= 0 ? parseAmt(r[cDep]) : 0;
      if (!dr && !cr) continue;
      const iso = parseBankDate(r[cDate]);
      if (!iso) continue;
      const parts = [String(r[cNarr] ?? '').trim(), String(r[cPart] ?? '').trim()].filter(Boolean);
      const narration = (parts.join(' — ') || String(r[cOther] ?? '').trim() || 'Bank entry').slice(0, 120);
      const schemeName = String(r[cSch] ?? '').trim();
      const schemeId = schemeName
        ? activeFunds.find((f) => f.name.toLowerCase() === schemeName.toLowerCase() || f.shortName.toLowerCase() === schemeName.toLowerCase())?.id || null
        : null;
      out.push({
        date: iso,
        narration,
        amount: dr || cr,
        side: dr ? 'debit' : 'credit',
        instrument: cIns >= 0 ? String(r[cIns] ?? '').trim() : '',
        note: cOther >= 0 ? String(r[cOther] ?? '').trim() || undefined : undefined,
        schemeId,
      });
    }
    if (!out.length) throw new Error('कोई valid पंक्ति नहीं मिली (तारीख़ + राशि चाहिए)');
    return out;
  };

  /** instruction #15 — Excel (.xlsx) या CSV उठाओ → statement भर जाए, फिर edit कर लें */
  const importStatement = async () => {
    try {
      const res = await File.pickFileAsync({ mimeTypes: ['*/*'] });
      if (res.canceled || !res.result) return;
      const bytes = new Uint8Array(await res.result.arrayBuffer());
      const name = res.result.name || '';
      /* हर candidate sheet को कोशिश करो — statement पहली sheet में नहीं भी हो सकती */
      const candidates: XCell[][][][] = [];
      if (/\.csv$/i.test(name)) {
        candidates.push([parseCsv(bytesToText(bytes)) as XCell[][]]);
      } else {
        try {
          const sheets = parseXlsx(bytes);
          if (sheets.length) candidates.push(sheets.map((s) => s.rows as XCell[][]));
        } catch {
          /* नीचे CSV fallback */
        }
        candidates.push([parseXlsxFirstSheet(bytes) as XCell[][]]);
        candidates.push([parseCsv(bytesToText(bytes)) as XCell[][]]);
      }
      let lines: ReturnType<typeof parseStatement> | null = null;
      let lastErr = '';
      outer: for (const group of candidates) {
        for (const rows of group) {
          try {
            lines = parseStatement(rows);
            if (lines.length) break outer;
          } catch (e) {
            lastErr = String((e as Error)?.message || e);
          }
        }
      }
      if (!lines || !lines.length) throw new Error(lastErr || 'कोई valid statement नहीं मिली');
      const seen = new Set(
        fyLines.map((l) => `${l.date}|${l.side}|${l.amount}|${l.narration}`)
      );
      let added = 0;
      for (const l of lines) {
        const key = `${l.date}|${l.side}|${l.amount}|${l.narration}`;
        if (seen.has(key)) continue;
        seen.add(key);
        await addBankLine({
          accountId: bankAccounts[0]?.id || 'ba1',
          fyId: activeFy.id,
          statementMonth: l.date.slice(0, 7),
          date: l.date,
          narration: l.narration,
          amount: l.amount,
          side: l.side,
          instrument: l.instrument,
          schemeId: l.schemeId,
          workId: null,
          vendorId: null,
          categoryId: null,
          note: l.note,
          ignored: false,
          postedTxnId: null,
        });
        added += 1;
      }
      setImportMsg(`${name}: ${lines.length} पंक्तियाँ पढ़ीं, ${added} नई जुड़ीं (दोहराव छोड़ा गया)।`);
      Alert.alert('Statement import', `${lines.length} पंक्तियाँ मिलीं\n${added} नई जुड़ीं\n\nअब ऊपर/नीचे से edit करके या “सब Post” से cashbook में भेजें।`);
    } catch (e) {
      Alert.alert('Import नहीं हुआ', String((e as Error)?.message || e));
    }
  };

  /** जितनी भी open पंक्तियाँ — एक साथ cashbook में post */
  const bulkPost = async () => {
    const open = sorted.filter((l) => !l.postedTxnId && !l.ignored);
    if (!open.length) return Alert.alert('कुछ post नहीं होना है', 'सब पहले से posted/ignored हैं।');
    const errs: string[] = [];
    for (const l of open) {
      const r = await postBankLineToCashbook(l.id);
      if (!r.ok) errs.push(`${l.date} ${l.narration.slice(0, 24)} — ${r.error || 'fail'}`);
    }
    if (errs.length) Alert.alert(`${open.length - errs.length}/${open.length} post हुए`, errs.slice(0, 6).join('\n'));
    else Alert.alert('सब post हो गए', `${open.length} पंक्तियाँ cashbook में दर्ज।`);
  };

  /* instruction #13 — bank statement share: PDF ya Excel, fields upload Excel jaisa */
  const bankAccount = bankAccounts[0];
  const shareStatement = async () => {
    let bal = 0;
    const rows = sorted
      .filter((l) => !l.ignored)
      .map((l) => {
        bal += l.side === 'credit' ? l.amount : -l.amount;
        const w = works.find((x) => x.id === l.workId);
        const v = vendors.find((x) => x.id === l.vendorId);
        const h = categories.find((x) => x.id === l.categoryId);
        const s = activeFunds.find((x) => x.id === l.schemeId);
        return {
          date: l.date,
          narration: l.narration,
          instrument: l.instrument,
          deposit: l.side === 'credit' ? l.amount : 0,
          withdrawal: l.side === 'debit' ? l.amount : 0,
          balance: Math.round(bal * 100) / 100,
          scheme: s?.name,
          work: w?.name,
          vendor: v?.name,
          head: h?.name,
          note: l.note,
          posted: !!l.postedTxnId,
        };
      });
    const body = bankStatementHtml({
      header: {
        panchayat: activePanchayat.name,
        block: activePanchayat.block,
        district: activePanchayat.district,
        fy: activeFy.label,
        formName: 'बैंक विवरण (Bank statement)',
      },
      accountName: bankAccount?.name || '—',
      accountNo: bankAccount?.accountNo || '—',
      bankName: bankAccount?.bankName || '—',
      rows,
    });
    await askAndShare('बैंक विवरण', body, true);
  };

  return (
    <View style={styles.page}>
      <Header
        title="Bank statement"
        onBack={back}
        badge="S-13"
        action={<IconBtn name="share-2" onPress={shareStatement} />}
      />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          Line add करें → scheme tag → Post (D−1 rule debit पर). OCR/PDF import device build में (Part U).
        </Text>
        {/* v12 #26 — चलता शेष (running balance) सबसे ऊपर, statement में भी column है */}
        <View style={[styles.card, { backgroundColor: C.primarySoft, borderColor: C.primary }]}>
          <Text style={styles.cardTitle}>चलता शेष (Running balance)</Text>
          <Text style={{ fontSize: 20, fontWeight: '900', color: C.primary }}>
            {formatINR(balanceOf.get(sorted.filter((l) => !l.ignored).slice(-1)[0]?.id || '') || 0)}
          </Text>
          <Text style={styles.meta}>
            कुल जमा {formatINR(sorted.filter((l) => !l.ignored && l.side === 'credit').reduce((s, l) => s + l.amount, 0))} · कुल नाम{' '}
            {formatINR(sorted.filter((l) => !l.ignored && l.side === 'debit').reduce((s, l) => s + l.amount, 0))} · नीचे Excel
            sheet में **BALANCE** column और share किए गए विवरण में “शेष (Balance)” column अलग से आता है।
          </Text>
        </View>
        {bankAccounts.map((a) => (
          <Text key={a.id} style={styles.meta}>{a.name} · {a.bankName} · {a.accountNo}</Text>
        ))}
        <View style={styles.row}>
          <Btn label="जमा (credit)" variant={side === 'credit' ? 'primary' : 'outline'} onPress={() => setSide('credit')} />
          <Btn label="नाम (debit)" variant={side === 'debit' ? 'danger' : 'outline'} onPress={() => setSide('debit')} />
        </View>
        <Field label="Narration" value={narr} onChangeText={setNarr} />
        <Field label="Amount" value={amt} onChangeText={setAmt} keyboardType="numeric" />
        <Field label="Instrument (चेक/DD/IMPS no.)" value={instr} onChangeText={setInstr} />
        <DateField label="Date" value={date} onChange={setDate} />
        {/* instruction #13 — योजना | कार्य | vendor/party | लेखा शीर्ष | टिप्पणी */}
        <Text style={styles.section}>Tagging (निकासी/जमा का विवरण)</Text>
        <SelectField
          label="कार्य (Work)"
          value={nameOfWork(tagWork)}
          options={fyWorks.map((w) => ({ key: w.id, label: w.name }))}
          onSelect={setTagWork}
          hint="लागू न हो तो खाली छोड़ें"
        />
        <SelectField
          label="विक्रेता / पक्ष (Vendor / Party)"
          value={nameOfVendor(tagVendor)}
          options={vendors.filter((v) => !v.archived).map((v) => ({ key: v.id, label: v.name }))}
          onSelect={setTagVendor}
        />
        <SelectField
          label="लेखा शीर्ष (Account head)"
          value={nameOfHead(tagHead)}
          options={heads.map((c) => ({ key: c.id, label: c.name }))}
          onSelect={setTagHead}
        />
        <Field label="टिप्पणी (Note)" value={tagNote} onChangeText={setTagNote} />
        <Btn
          label={side === 'credit' ? 'Add credit line' : 'Add debit line'}
          icon="plus"
          onPress={addLine}
        />
        {/* v9 #15 — बैंक की Excel/CSV उठाकर statement खुद भरो, फिर सुधारो */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Excel / CSV से statement import</Text>
          <Text style={styles.meta}>
            बैंक की Excel फ़ाइल उठाएँ — DATE · NARRATION · Scheme · WITHDRAWAL (DR) · DEPOSIT (CR) · BALANCE · vendor ·
            Particulars · Other स्तंभ app खुद पढ़ लेता है और statement भर देता है; बाद में हर पंक्ति सुधार सकते हैं।
          </Text>
          <Btn label="⬇ Excel / CSV फ़ाइल से import" icon="download" onPress={importStatement} />
          {importMsg ? <Text style={styles.meta}>{importMsg}</Text> : null}
        </View>
        {sorted.some((l) => !l.postedTxnId && !l.ignored) ? (
          <Btn label="सबको cashbook में Post करें" variant="soft" icon="check" onPress={bulkPost} />
        ) : null}
        {/* instruction #22 — बैंक विवरण असली Excel sheet जैसा (A/B/C column + DR/CR + चलता शेष) */}
        <View style={styles.row}>
          <Btn label={sheetView ? 'Excel sheet दिख रही है' : 'Excel sheet देखें'} variant={sheetView ? 'primary' : 'outline'} onPress={() => setSheetView(!sheetView)} />
          <Btn label={sheetView ? 'पूरी सूची देखें' : 'सूची'} variant={sheetView ? 'outline' : 'primary'} onPress={() => setSheetView(!sheetView)} />
        </View>
        {sheetView && sorted.length > 0 ? (
          <View style={{ backgroundColor: '#ffffff', borderWidth: 1, borderColor: '#9db9a8', borderRadius: 4, overflow: 'hidden', marginBottom: 10 }}>
            {/* column letters — Excel जैसा header */}
            <View style={{ flexDirection: 'row', backgroundColor: '#dfe9e3' }}>
              {['', 'A', 'B', 'C', 'D', 'E', 'F'].map((cl) => (
                <Text
                  key={cl}
                  style={{
                    width: cl === 'B' ? 170 : cl === '' ? 34 : 92,
                    fontSize: 11,
                    fontWeight: '800',
                    color: '#33463c',
                    textAlign: 'center',
                    paddingVertical: 4,
                    borderRightWidth: 1,
                    borderRightColor: '#9db9a8',
                  }}
                >
                  {cl}
                </Text>
              ))}
            </View>
            <View style={{ flexDirection: 'row', backgroundColor: '#e8f2ec', borderTopWidth: 1, borderTopColor: '#9db9a8' }}>
              {['#', 'DATE', 'NARRATION', 'WITHDRAWAL (DR)', 'DEPOSIT (CR)', 'BALANCE'].map((h) => (
                <Text
                  key={h}
                  style={{
                    width: h === '#' ? 34 : h === 'NARRATION' ? 170 : h === '#' ? 34 : 92,
                    fontSize: 10,
                    fontWeight: '800',
                    color: '#1d2b23',
                    textAlign: 'center',
                    paddingVertical: 5,
                    borderRightWidth: 1,
                    borderRightColor: '#9db9a8',
                  }}
                >
                  {h}
                </Text>
              ))}
            </View>
            {sorted.map((l, i) => {
              if (l.ignored) return null;
              const b = balanceOf.get(l.id) || 0;
              return (
                <Pressable
                  key={l.id}
                  onPress={() => setEditLineId(l.id)}
                  style={{ flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#e2ece7', backgroundColor: i % 2 ? '#fafcfa' : '#ffffff' }}
                >
                  {cell(String(i + 1), 34, 'center', '#5a6b62')}
                  {cell(l.date, 92, 'center')}
                  {cell(l.narration, 170)}
                  {cell(l.side === 'debit' ? formatINR(l.amount) : '', 92, 'right', '#b3261e')}
                  {cell(l.side === 'credit' ? formatINR(l.amount) : '', 92, 'right', '#1b5e20')}
                  {cell(formatINR(b), 92, 'right', '#111')}
                </Pressable>
              );
            })}
            <View style={{ flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#9db9a8', backgroundColor: '#e8f2ec' }}>
              {cell('', 34, 'center')}
              {cell('TOTAL', 92, 'center', '#1d2b23')}
              {cell('', 170, 'left')}
              {cell(formatINR(sorted.filter((l) => !l.ignored && l.side === 'debit').reduce((s, l) => s + l.amount, 0)), 92, 'right', '#b3261e')}
              {cell(formatINR(sorted.filter((l) => !l.ignored && l.side === 'credit').reduce((s, l) => s + l.amount, 0)), 92, 'right', '#1b5e20')}
              {cell(formatINR(balanceOf.get(sorted.filter((l) => !l.ignored).slice(-1)[0]?.id || '') || 0), 92, 'right')}
            </View>
            <Text style={[styles.meta, { padding: 6, color: '#33463c' }]}>
              Excel जैसा पृष्ठ — ऊपर दिए button से PDF (.xlsx भी) में भेजें।
            </Text>
          </View>
        ) : null}

        {!sheetView ? sorted.map((l) => (
          <View key={l.id} style={styles.card}>
            {/* v13 #12 — नीचे की entries में आख़िरी column = चलता शेष (running balance) */}
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle}>{l.date} · {l.narration}</Text>
                <Text style={styles.meta}>
                  {l.side === 'credit' ? 'जमा' : 'नाम'} {formatINR(l.amount)}
                  {l.instrument ? ` · ${l.instrument}` : ''}
                  {' · '}{l.ignored ? 'IGNORED' : l.postedTxnId ? 'POSTED' : 'open'}
                </Text>
              </View>
              <View
                style={{
                  minWidth: 104,
                  alignItems: 'flex-end',
                  backgroundColor: C.primarySoft,
                  borderColor: C.primary,
                  borderWidth: 1,
                  borderRadius: 10,
                  paddingHorizontal: 8,
                  paddingVertical: 6,
                }}
              >
                <Text style={{ fontSize: 9, fontWeight: '800', color: C.primary }}>चलता शेष</Text>
                <Text style={{ fontSize: 14, fontWeight: '900', color: C.foreground }}>
                  {formatINR(balanceOf.get(l.id) || 0)}
                </Text>
              </View>
            </View>
            {l.workId || l.vendorId || l.categoryId || l.note ? (
              <Text style={styles.meta}>
                {[l.workId ? `कार्य: ${nameOfWork(l.workId)}` : '', l.vendorId ? `पक्ष: ${nameOfVendor(l.vendorId)}` : '',
                  l.categoryId ? `शीर्ष: ${nameOfHead(l.categoryId)}` : '', l.note || ''].filter(Boolean).join(' · ')}
              </Text>
            ) : null}
            <Text style={styles.meta}>scheme tag:</Text>
            <View style={styles.chips}>
              {/* v10 #8 — बैंक लाइन पर cash टैग बेमानी है (वह ख़ुद बैंक की लाइन है) */}
              {activeFunds
                .filter((f) => f.id !== 'cash')
                .map((f) => (
                  <Pressable
                    key={f.id}
                    style={[styles.chip, l.schemeId === f.id && styles.chipOn]}
                    onPress={() => updateBankLine(l.id, { schemeId: f.id })}
                  >
                    <Text style={{ color: l.schemeId === f.id ? '#fff' : C.foreground, fontSize: 11 }}>{f.shortName}</Text>
                  </Pressable>
                ))}
            </View>
            <View style={styles.row}>
              <Btn label="सुधारें" variant="soft" onPress={() => setEditLineId(l.id)} />
              {!l.postedTxnId && !l.ignored ? (
                <Btn
                  label="Post to cashbook"
                  onPress={async () => {
                    const r = await postBankLineToCashbook(l.id);
                    if (!r.ok) Alert.alert('Post नहीं हुआ', r.error || 'Fail');
                  }}
                />
              ) : null}
              {!l.postedTxnId && !l.ignored ? (
                <Btn label="Ignore" variant="outline" onPress={() => updateBankLine(l.id, { ignored: true })} />
              ) : null}
              {l.ignored ? (
                <Btn label="Un-ignore" variant="outline" onPress={() => updateBankLine(l.id, { ignored: false })} />
              ) : null}
            </View>
          </View>
        )) : null}
        {fyLines.length === 0 ? (
          <Empty title="कोई statement line नहीं" why="अभी कोई bank line add नहीं हुई" steps={['Excel फ़ाइल से import करें', 'या ऊपर narration/amount/date भरें']} />
        ) : null}
      </ScrollView>

      {/* v9 #15 — import के बाद हर पंक्ति सुधारने की window */}
      {editLineId && fyLines.find((l) => l.id === editLineId) ? (
        <BankLineEditor
          line={fyLines.find((l) => l.id === editLineId)!}
          works={fyWorks}
          vendors={vendors.filter((v) => !v.archived)}
          heads={heads}
          funds={activeFunds}
          onClose={() => setEditLineId(null)}
          onSave={(id, patch) => updateBankLine(id, patch)}
        />
      ) : null}
    </View>
  );
}

/**
 * v9 #15 — Excel/CSV import के बाद हर बैंक पंक्ति सुधारने की window
 * (दिनांक, विवरण, राशि, जमा/नाम, संदर्भ, योजना/कार्य/पक्ष/शीर्ष tag, टिप्पणी)।
 */
function BankLineEditor({
  line,
  works,
  vendors,
  heads,
  funds,
  onClose,
  onSave,
}: {
  line: BankLine;
  works: { id: string; name: string }[];
  vendors: { id: string; name: string }[];
  heads: { id: string; name: string }[];
  funds: { id: string; name: string; shortName: string }[];
  onClose: () => void;
  onSave: (id: string, patch: Partial<BankLine>) => void;
}) {
  const [date, setDate] = useState(line.date);
  const [narr, setNarr] = useState(line.narration);
  const [amt, setAmt] = useState(String(line.amount));
  const [side, setSide] = useState<'credit' | 'debit'>(line.side);
  const [instr, setInstr] = useState(line.instrument);
  const [note, setNote] = useState(line.note || '');
  const [schemeId, setSchemeId] = useState(line.schemeId || '');
  const [workId, setWorkId] = useState(line.workId || '');
  const [vendorId, setVendorId] = useState(line.vendorId || '');
  const [categoryId, setCategoryId] = useState(line.categoryId || '');
  /* v10 #16 — modal body height window se */
  const bodyMax = useModalBodyMax(0.92, 270);

  const commit = () => {
    if (!isValidIsoDate(date)) return Alert.alert('अमान्य दिनांक', 'YYYY-MM-DD जैसे 2026-09-24');
    const n = parseFloat(amt.replace(/[^0-9.\-]/g, '')) || 0;
    if (!(n > 0)) return Alert.alert('राशि > 0 चाहिए');
    if (!narr.trim()) return Alert.alert('विवरण (narration) भरें');
    onSave(line.id, {
      date,
      narration: narr.trim(),
      amount: Math.abs(n),
      side,
      instrument: instr.trim(),
      note: note.trim() || undefined,
      schemeId: schemeId || null,
      workId: workId || null,
      vendorId: vendorId || null,
      categoryId: categoryId || null,
      statementMonth: date.slice(0, 7),
    });
    onClose();
  };

  return (
    <Modal visible transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalBg}>
        <View style={[styles.modalCard, { maxHeight: '92%' }]}>
          <Text style={styles.modalTitle}>पंक्ति सुधारें</Text>
          <Text style={styles.meta}>
            {line.postedTxnId ? 'यह पंक्ति cashbook में दर्ज है' : 'अभी cashbook में नहीं गई'}
          </Text>
          <ScrollView style={{ maxHeight: bodyMax }} keyboardShouldPersistTaps="handled">
            <DateField label="दिनांक" value={date} onChange={setDate} />
            <Field label="विवरण (narration)" value={narr} onChangeText={setNarr} multiline />
            <View style={styles.row}>
              <Field label="राशि" value={amt} onChangeText={setAmt} keyboardType="numeric" grow />
              <View style={{ flex: 1 }}>
                <Text style={styles.fieldLabel}>पक्ष</Text>
                <View style={styles.row}>
                  <Btn label="जमा" variant={side === 'credit' ? 'primary' : 'outline'} onPress={() => setSide('credit')} />
                  <Btn label="नाम" variant={side === 'debit' ? 'danger' : 'outline'} onPress={() => setSide('debit')} />
                </View>
              </View>
            </View>
            <Field label="संदर्भ (चेक/DD/IMPS)" value={instr} onChangeText={setInstr} />
            <SelectField
              label="योजना (Scheme)"
              value={funds.find((f) => f.id === schemeId)?.name || ''}
              options={funds.map((f) => ({ key: f.id, label: f.name, sub: f.shortName }))}
              onSelect={setSchemeId}
            />
            <SelectField
              label="कार्य (Work)"
              value={works.find((w) => w.id === workId)?.name || ''}
              options={works.map((w) => ({ key: w.id, label: w.name }))}
              onSelect={setWorkId}
            />
            <SelectField
              label="विक्रेता / पक्ष"
              value={vendors.find((v) => v.id === vendorId)?.name || ''}
              options={vendors.map((v) => ({ key: v.id, label: v.name }))}
              onSelect={setVendorId}
            />
            <SelectField
              label="लेखा शीर्ष"
              value={heads.find((h) => h.id === categoryId)?.name || ''}
              options={heads.map((h) => ({ key: h.id, label: h.name }))}
              onSelect={setCategoryId}
            />
            <Field label="टिप्पणी (Other)" value={note} onChangeText={setNote} multiline />
          </ScrollView>
          <Btn label="सहेजें" icon="check" onPress={commit} />
          <Btn label="वापस जाएँ (Back)" variant="outline" onPress={onClose} />
        </View>
      </View>
    </Modal>
  );
}

/**
 * Instruction #8 — work add का पूरा फ़ॉर्म (Works screen + Entry की dropdown दोनों में)
 * योजना, A.S./T.S./F.S. क्रमांक+दिनांक, शुरू/पूर्ण तिथि, MB स्थिति + MB विवरण पूछे जाते हैं।
 */
function WorkAddForm({
  onAdded,
  edit,
  onDone,
}: {
  onAdded?: (w: { id: string; name: string }) => void;
  /** v10 #20 — यह फ़ॉर्म किसी मौजूदा कार्य को सुधारने के लिए खुला है (भरा हुआ + Update बटन) */
  edit?: Work | null;
  /** सुधार/जोड़ने के बाद (modal बंद करने के लिए) */
  onDone?: () => void;
}) {
  const {
    addWork, updateWork, activeFy, activeFunds,
    /* instruction #19 */
    fundingAgencies, addFundingAgency, renameFundingAgency, deleteFundingAgency,
  } = useStore();
  /* v10 #20 — जोड़ने के बाद भी work सुधारा जा सकता है: `edit` दिया तो फ़ॉर्म भरा हुआ खुलेगा */
  const [name, setName] = useState(edit?.name || '');
  const [ward, setWard] = useState(edit?.ward || '');
  const [sanction, setSanction] = useState(edit?.sanctionRef || '');
  const [fs, setFs] = useState(edit?.fsAmount ? String(edit.fsAmount) : '');
  /* v11 #21 — स्वीकृति राशि के दो हिस्से: श्रम (labour) + सामग्री (material) */
  const [labPart, setLabPart] = useState(edit?.labourPrior ? String(edit.labourPrior) : '');
  const [matPart, setMatPart] = useState(edit?.materialPrior ? String(edit.materialPrior) : '');
  const [schemeId, setSchemeId] = useState(
    edit?.schemeId || activeFunds.find((f) => f.id !== 'cash')?.id || activeFunds[0]?.id || 'sfc'
  );
  const [agency, setAgency] = useState(
    edit?.fundingAgency ? fundingAgencies.find((f) => f.name === edit.fundingAgency)?.id || '' : ''
  );
  const [agencyMgr, setAgencyMgr] = useState(false);
  /* v10 #29 — modal body height window se */
  const agencyBodyMax = useModalBodyMax(0.86, 270);
  const [newAgency, setNewAgency] = useState('');
  const [editAgency, setEditAgency] = useState<{ id: string; name: string } | null>(null);
  const [asNo, setAsNo] = useState(edit?.asNo || '');
  const [asDate, setAsDate] = useState(edit?.asDate || '');
  const [tsNo, setTsNo] = useState(edit?.tsNo || '');
  const [tsDate, setTsDate] = useState(edit?.tsDate || '');
  const [fsNo, setFsNo] = useState(edit?.fsNo || '');
  const [fsDate, setFsDate] = useState(edit?.fsDate || '');
  const [start, setStart] = useState(edit?.startDate || '');
  const [complete, setComplete] = useState(edit?.completeDate || '');
  const [mbStatus, setMbStatus] = useState<'pending' | 'complete'>(edit?.mbStatus === 'complete' ? 'complete' : 'pending');
  const [mbNo, setMbNo] = useState(edit?.mbNo || '');
  const [mbPage, setMbPage] = useState(edit?.mbPage || '');
  const [mbVal, setMbVal] = useState(edit?.mbValuation ? String(edit.mbValuation) : '');
  const [mbLab, setMbLab] = useState(edit?.mbLabourAmount ? String(edit.mbLabourAmount) : '');
  const [mbHdr, setMbHdr] = useState(edit?.mbMaterialAmount ? String(edit.mbMaterialAmount) : '');
  const reset = () => {
    setName('');
    setWard('');
    setSanction('');
    setFs('');
    setLabPart('');
    setMatPart('');
    setAsNo('');
    setAsDate('');
    setTsNo('');
    setTsDate('');
    setFsNo('');
    setFsDate('');
    setStart('');
    setComplete('');
    setMbStatus('pending');
    setMbNo('');
    setMbPage('');
    setMbVal('');
    setMbLab('');
    setMbHdr('');
    setAgency('');
  };
  const num = (s: string) => {
    const n = Number(s.trim());
    return Number.isFinite(n) && n > 0 ? n : undefined;
  };
  const date = (s: string) => (isValidIsoDate(s.trim()) ? s.trim() : undefined);
  return (
    <>
      <Text style={styles.hint}>Instruction #8 — योजना, AS/TS/FS क्रमांक व दिनांक, शुरू/पूर्ण तिथि, MB स्थिति सब पूछे जाते हैं।</Text>
      <Field label="Work name *" value={name} onChangeText={setName} />
      <Field label="Ward / location" value={ward} onChangeText={setWard} />
      <Field label="Sanction reference (स्वीकृति सं.)" value={sanction} onChangeText={setSanction} />

      <Text style={styles.section}>योजना / Scheme (expense entry में यही auto select होगी)</Text>
      <SelectField
        label="योजना चुनें *"
        value={activeFunds.find((f) => f.id === schemeId)?.name || schemeId}
        options={activeFunds
          .filter((f) => f.id !== 'cash')
          .map((f) => ({ key: f.id, label: f.name, sub: f.shortName }))}
        onSelect={setSchemeId}
        hint="नकद (Cash) योजना नहीं — सिर्फ़ लेन-देन का माध्यम है।"
      />

      {/* instruction #19 — वित्त पोषण एजेंसी dropdown + add / edit / delete */}
      <Text style={styles.section}>वित्त पोषण एजेंसी (Funding agency)</Text>
      <SelectField
        label="Funding agency चुनें"
        value={fundingAgencies.find((f) => f.id === agency)?.name || agency}
        placeholder="चुनें (Panchayat / Samiti / Jila Parishad / MP / MLA / TAD …)"
        options={fundingAgencies.map((f) => ({ key: f.id, label: f.name }))}
        onSelect={setAgency}
        onAddNew={() => setAgencyMgr(true)}
        addNewLabel="एजेंसी जोड़ें / बदलें / हटाएँ"
        hint="सूची में न हो तो नीचे से जोड़ें; जोड़ी हुई एजेंसी dropdown में तुरंत आ जाएगी।"
      />

      <Text style={styles.section}>स्वीकृतियाँ</Text>
      <View style={styles.row}>
        <Field label="A.S. क्रमांक (प्रशासनिक)" value={asNo} onChangeText={setAsNo} grow />
        <DateField label="A.S. दिनांक" value={asDate} onChange={setAsDate} grow />
      </View>
      <View style={styles.row}>
        <Field label="T.S. क्रमांक (तकनीकी)" value={tsNo} onChangeText={setTsNo} grow />
        <DateField label="T.S. दिनांक" value={tsDate} onChange={setTsDate} grow />
      </View>
      <View style={styles.row}>
        <Field label="F.S. क्रमांक (वित्तीय)" value={fsNo} onChangeText={setFsNo} grow />
        <DateField label="F.S. दिनांक" value={fsDate} onChange={setFsDate} grow />
      </View>
      <Field label="FS वित्तीय स्वीकृति राशि (₹) — प्रपत्र-1 + CC min() rule" value={fs} onChangeText={setFs} keyboardType="numeric" />

      {/* ═══ v11 #21 — कार्य जोड़ते समय स्वीकृति राशि के दो हिस्से ═══ */}
      <Text style={styles.section}>स्वीकृति राशि के दो हिस्से (sanction split)</Text>
      <View style={styles.row}>
        <Field label="श्रम हिस्सा (Labour part ₹)" value={labPart} onChangeText={setLabPart} keyboardType="numeric" grow />
        <Field label="सामग्री हिस्सा (Material part ₹)" value={matPart} onChangeText={setMatPart} keyboardType="numeric" grow />
      </View>
      <View style={styles.card}>
        <Text style={styles.sumLine}>
          श्रम {formatINR(num(labPart) || 0)} + सामग्री {formatINR(num(matPart) || 0)} = कुल{' '}
          {formatINR((num(labPart) || 0) + (num(matPart) || 0))}
        </Text>
        <Text style={styles.meta}>
          {fs.trim()
            ? `FS स्वीकृति ${formatINR(num(fs) || 0)} — दोनों हिस्सों का योग इसी से मिलाकर रखें (प्रपत्र-1 यहीं से भरा जाता है)।`
            : 'FS राशि ख़ाली है — इन दो हिस्सों का योग ही स्वीकृति राशि मान ली जाएगी।'}
          {' '}
          दोनों ख़ाली रहे तो श्रम/सामग्री हिस्सा 0 माना जाएगा।
        </Text>
      </View>

      <Text style={styles.section}>कार्य अवधि</Text>
      <View style={styles.row}>
        <DateField label="कार्य शुरू तिथि" value={start} onChange={setStart} grow />
        <DateField label="कार्य पूर्ण तिथि" value={complete} onChange={setComplete} grow />
      </View>

      <Text style={styles.section}>MB स्थिति (माप पुस्तिका)</Text>
      <View style={styles.row}>
        <Btn label="लंबित (Pending)" variant={mbStatus === 'pending' ? 'primary' : 'outline'} onPress={() => setMbStatus('pending')} />
        <Btn label="पूर्ण (Complete)" variant={mbStatus === 'complete' ? 'primary' : 'outline'} onPress={() => setMbStatus('complete')} />
      </View>
      {mbStatus === 'complete' ? (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>MB विवरण</Text>
          <View style={styles.row}>
            <Field label="MB संख्या" value={mbNo} onChangeText={setMbNo} grow />
            <Field label="MB पृष्ठ संख्या" value={mbPage} onChangeText={setMbPage} keyboardType="numeric" grow />
          </View>
          <Field label="कुल मूल्यांकन राशि (₹)" value={mbVal} onChangeText={setMbVal} keyboardType="numeric" />
          <View style={styles.row}>
            <Field label="श्रम राशि (₹)" value={mbLab} onChangeText={setMbLab} keyboardType="numeric" grow />
            <Field label="सामग्री राशि (₹)" value={mbHdr} onChangeText={setMbHdr} keyboardType="numeric" grow />
          </View>
          <Text style={styles.meta}>सुझाव: ये आँकड़े MB lines (माप पुस्तिका) से मिलाकर रखें — CC पृष्ठ 1 यहीं से भरा जाता है।</Text>
        </View>
      ) : null}

      <Btn
        label={edit ? '✓ सहेजें (कार्य अपडेट होगा)' : 'Add work'}
        icon={edit ? 'check' : 'plus'}
        onPress={async () => {
          if (!name.trim()) return Alert.alert('Work name अनिवार्य');
          const payload = {
            fyId: activeFy.id,
            name: name.trim(),
            schemeId,
            ward: ward.trim(),
            sanctionRef: sanction.trim(),
            /* instruction #19 */
            fundingAgency: agency ? fundingAgencies.find((f) => f.id === agency)?.name || undefined : undefined,
            /* v11 #21 — स्वीकृति के दो हिस्से; FS ख़ाली हो तो इनका योग = स्वीकृति राशि */
            fsAmount:
              num(fs) ||
              ((num(labPart) || 0) + (num(matPart) || 0) > 0 ? (num(labPart) || 0) + (num(matPart) || 0) : undefined),
            materialPrior: num(matPart) || 0,
            labourPrior: num(labPart) || 0,
            status: (complete.trim() ? 'completed' : 'ongoing') as Work['status'],
            asNo: asNo.trim() || undefined,
            asDate: date(asDate),
            tsNo: tsNo.trim() || undefined,
            tsDate: date(tsDate),
            fsNo: fsNo.trim() || undefined,
            fsDate: date(fsDate),
            startDate: date(start),
            completeDate: date(complete),
            mbStatus,
            mbNo: mbNo.trim() || undefined,
            mbPage: mbPage.trim() || undefined,
            mbValuation: num(mbVal),
            mbLabourAmount: num(mbLab),
            mbMaterialAmount: num(mbHdr),
          };
          /* v10 #20 — मौजूदा कार्य का अपडेट */
          if (edit) {
            await updateWork(edit.id, payload);
            onDone?.();
            return;
          }
          const id = await addWork(payload);
          const addedName = name.trim();
          reset();
          onAdded?.({ id, name: addedName });
          onDone?.();
        }}
      />

      {/* instruction #19 — एजेंसी add / edit / delete */}
      <Modal visible={agencyMgr} transparent animationType="slide" onRequestClose={() => setAgencyMgr(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '86%' }]}>
            <Text style={styles.modalTitle}>वित्त पोषण एजेंसी</Text>
            <Text style={styles.meta}>नई जोड़ें, नाम बदलें या हटाएँ — dropdown पर तुरंत असर।</Text>
            <ScrollView style={{ maxHeight: agencyBodyMax }}>
              {fundingAgencies.map((f) => (
                <View key={f.id} style={[styles.field, { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 }]}>
                  <Text style={{ flex: 1, color: C.foreground, fontWeight: '700' }}>{f.name}</Text>
                  <IconBtn name="edit-3" onPress={() => setEditAgency({ id: f.id, name: f.name })} />
                  <IconBtn
                    name="trash-2"
                    onPress={() =>
                      Alert.alert('एजेंसी हटाएँ?', f.name, [
                        { text: 'रहने दें', style: 'cancel' },
                        { text: 'हटाएँ', style: 'destructive', onPress: () => deleteFundingAgency(f.id) },
                      ])
                    }
                  />
                </View>
              ))}
              {fundingAgencies.length === 0 ? <Text style={styles.meta}>कोई एजेंसी नहीं — नीचे से जोड़ें।</Text> : null}
            </ScrollView>
            <Field label="नई एजेंसी का नाम" value={newAgency} onChangeText={setNewAgency} bg={C.input} />
            <Btn
              label="+ जोड़ें"
              variant="soft"
              onPress={async () => {
                if (!newAgency.trim()) return Alert.alert('नाम चाहिए');
                await addFundingAgency(newAgency);
                setNewAgency('');
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setAgencyMgr(false)} />
          </View>
        </View>
      </Modal>

      <Modal visible={!!editAgency} transparent animationType="fade" onRequestClose={() => setEditAgency(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>एजेंसी का नाम बदलें</Text>
            <Field label="नाम" value={editAgency?.name || ''} onChangeText={(t) => setEditAgency((e) => (e ? { ...e, name: t } : e))} bg={C.input} />
            <Btn
              label="सहेजें"
              onPress={() => {
                if (editAgency && editAgency.name.trim()) renameFundingAgency(editAgency.id, editAgency.name.trim());
                setEditAgency(null);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setEditAgency(null)} />
          </View>
        </View>
      </Modal>
    </>
  );
}

function WorksScreen({ back, go }: { back: () => void; go: (s: Stage, workId?: string) => void }) {
  const { works, activeFy, activeFunds, financialYears } = useStore();
  /* ═══════════ v12 #16 — कार्य सूची को वित्तीय वर्ष से filter करें ═══════════
     कार्य का "असली" वर्ष = F.S. (वित्तीय स्वीकृति) तिथि जिस वर्ष में पड़ती है;
     F.S. न भरा हो या वर्ष के बाहर हो तो कार्य का अपना fyId लागू।
     इसी आधार पर पुराने/नए वर्ष के कार्य अलग-अलग दिखते हैं (BSR वर्ष चुनाव की तरह)। */
  const fyIdOfWork = (w: (typeof works)[number]): string => {
    const d = w.fsDate;
    if (d && isValidIsoDate(d)) {
      const hit = financialYears.find((f) => d >= f.start && d <= f.end);
      if (hit) return hit.id;
    }
    return w.fyId;
  };
  const [fyFilter, setFyFilter] = useState<string>(activeFy.id);
  const fyOpts = [
    { key: 'all', label: 'सभी वित्तीय वर्ष (all)', sub: `${works.length} कार्य` },
    ...[...financialYears]
      .sort((a, b) => b.start.localeCompare(a.start))
      .map((f) => ({
        key: f.id,
        label: `वित्तीय वर्ष ${f.label}`,
        sub: `${works.filter((w) => fyIdOfWork(w) === f.id).length} कार्य${f.id === activeFy.id ? ' · चालू वर्ष' : ''}`,
      })),
  ];
  const fyWorks = works.filter((w) => (fyFilter === 'all' ? true : fyIdOfWork(w) === fyFilter));
  /* v10 #28 — नीचे दायीं तरफ़ का + : नया कार्य फ़ॉर्म खोलता है */
  const [addOpen, setAddOpen] = useState(false);
  /* v10 #29 — modal ka bottom kisi input ko dabaye na */
  const addBodyMax = useModalBodyMax(0.9, 270);
  return (
    <View style={styles.page}>
      <Header title="Works" onBack={back} badge="S-18" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          ऊपर सारे कार्य — किसी कार्य पर tap करने से उसका पूरा विवरण खुलेगा (वहीं से सुधार भी होगा, v10 #20)। नया कार्य जोड़ने के लिए
          नीचे दायीं तरफ़ का “+” दबाएँ (v10 #28)।
        </Text>
        {/* v12 #16 — वित्तीय वर्ष के अनुसार filter (कार्य का वर्ष F.S. तिथि से) */}
        <SelectField
          label="वित्तीय वर्ष (filter)"
          value={fyOpts.find((o) => o.key === fyFilter)?.label || '—'}
          options={fyOpts}
          onSelect={setFyFilter}
          hint="कार्य का वर्ष उसकी F.S. (वित्तीय स्वीकृति) तिथि से तय होता है; F.S. न हो तो कार्य जिस वर्ष जोड़ा गया उसमें।"
        />
        {fyWorks.map((w) => (
          <Pressable key={w.id} style={styles.homeRow} onPress={() => go('workDetail', w.id)}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{w.name}</Text>
              <Text style={styles.meta}>
                {w.status} · योजना {activeFunds.find((f) => f.id === w.schemeId)?.name || w.schemeId}
                {w.ward ? ` · ward ${w.ward}` : ''}
                {w.sanctionRef ? ` · ${w.sanctionRef}` : ''}
                {w.fsAmount ? ` · FS ${formatINR(w.fsAmount)}` : ''}
                {w.mbStatus === 'complete' ? ' · MB ✓' : ''}
              </Text>
              <Text style={styles.meta}>
                वर्ष {financialYears.find((f) => f.id === fyIdOfWork(w))?.label || '—'}
                {w.fsDate ? ` · F.S. ${fmtDate(w.fsDate)}` : ' · F.S. तिथि नहीं'}
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
        {fyWorks.length === 0 ? (
          <Empty
            title={fyFilter === 'all' ? 'No works' : 'इस वित्तीय वर्ष का कोई कार्य नहीं'}
            why={
              fyFilter === 'all'
                ? 'अभी कोई कार्य दर्ज नहीं'
                : 'इस वर्ष में F.S. तिथि/कार्य नहीं — ऊपर filter बदलकर दूसरा वर्ष देखें'
            }
            steps={['नीचे दायीं तरफ़ का + दबाएँ', 'नया कार्य जोड़ें', 'फिर MB / Bills / CC खोलें']}
          />
        ) : null}
        <View style={{ height: 76 }} />
      </ScrollView>

      {/* v10 #28 — bottom-right floating “+” → नया कार्य फ़ॉर्म (सभी fields के साथ) */}
      <Pressable
        onPress={() => setAddOpen(true)}
        accessibilityLabel="नया कार्य जोड़ें"
        style={({ pressed }) => ({
          position: 'absolute',
          right: 18,
          bottom: 26,
          width: 58,
          height: 58,
          borderRadius: 29,
          backgroundColor: pressed ? C.darkForest : C.primary,
          alignItems: 'center',
          justifyContent: 'center',
          elevation: 8,
          shadowColor: '#000',
          shadowOpacity: 0.3,
          shadowRadius: 6,
          shadowOffset: { width: 0, height: 3 },
          zIndex: 20,
        })}
      >
        <Feather name="plus" size={28} color={C.primaryForeground} />
      </Pressable>

      <Modal visible={addOpen} transparent animationType="slide" onRequestClose={() => setAddOpen(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '96%' }]}>
            <Text style={styles.modalTitle}>+ नया कार्य</Text>
            <Text style={styles.meta}>सारे fields — योजना, एजेंसी, A.S./T.S./F.S., अवधि, MB विवरण</Text>
            <ScrollView style={{ maxHeight: addBodyMax }} keyboardShouldPersistTaps="handled">
              <WorkAddForm onDone={() => setAddOpen(false)} />
            </ScrollView>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setAddOpen(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

function WorkDetailScreen({ back, workId, go }: { back: () => void; workId: string; go: (s: Stage, wid?: string) => void }) {
  const { works, mbLines, bills, activeFunds, mandayCalcs, deleteMandayCalc, activeFy, deleteWorkCascade, fyTransactions } = useStore();
  /* v10 #20 — कार्य जोड़ने के बाद भी सुधारा जा सकता है (hook early-return से पहले) */
  const [editOpen, setEditOpen] = useState(false);
  const editBodyMax = useModalBodyMax(0.9, 270);
  const w = works.find((x) => x.id === workId);
  if (!w) {
    // K.5: dead click nahi — empty state + steps
    return (
      <View style={styles.page}>
        <Header title="Work" onBack={back} badge="S-51" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="यह work delete/hide हो गया होगा" steps={['Works list पर वापस जाएँ', 'दूसरा work चुनें']} />
        </View>
      </View>
    );
  }
  const mb = mbLines.filter((m) => m.workId === workId);
  const bl = bills.filter((b) => b.workId === workId);
  /* v11 #16 — इसी कार्य की मन-डे स्वीकृतियाँ (अवधि के भीतर, नीचे दिखेंगी) */
  const workCalcs = mandayCalcs
    .filter((c) => c.workId === workId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const mbVal = mb.reduce((s, m) => s + m.qty * m.rate, 0);
  const matVal = mb
    .filter((m) => m.kind === 'material' || (m.kind === 'artisan' && m.karigarIn === 'material'))
    .reduce((s, m) => s + m.qty * m.rate, 0);
  const labVal = mbVal - matVal;
  const paid = bl.filter((b) => b.paymentDate).reduce((s, b) => s + b.amount, 0);
  /* v12 #24 — कार्य से जुड़ी कैशबुक entries (मिटाई नहीं जाएँगी, सिर्फ़ लिंक हटेगा) */
  const linkedTxns = fyTransactions.filter((t) => t.workId === workId);
  const d = (x?: string) => (x ? fmtDate(x) : '—');
  return (
    <View style={styles.page}>
      <Header title={w.name} onBack={back} badge="S-19" />
      <ScrollView contentContainerStyle={styles.pad}>
        {/* instruction #23 — work list → click → पूरा विवरण एक ही पेज पर */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>स्वीकृति व क्रमांक</Text>
          <Text style={styles.meta}>
            A.S. {w.asNo || '—'} · {d(w.asDate)} {'\n'}
            T.S. {w.tsNo || '—'} · {d(w.tsDate)} {'\n'}
            F.S. {w.fsNo || '—'} · {d(w.fsDate)}
          </Text>
          <Text style={styles.meta}>
            स्वीकृति सं. {w.sanctionRef || '—'} · FS राशि {w.fsAmount ? formatINR(w.fsAmount) : '—'}
          </Text>
          {/* v11 #21 — स्वीकृति राशि के दो हिस्से (श्रम + सामग्री) */}
          <Text style={styles.sumLine}>
            श्रम हिस्सा {formatINR(w.labourPrior || 0)} + सामग्री हिस्सा {formatINR(w.materialPrior || 0)} ={' '}
            {formatINR((w.labourPrior || 0) + (w.materialPrior || 0))}
          </Text>
          <Text style={styles.meta}>
            वित्त पोषण एजेंसी: {w.fundingAgency || '—'} · योजना{' '}
            {activeFunds.find((f) => f.id === w.schemeId)?.name || w.schemeId}
            {w.ward ? ` · ward ${w.ward}` : ''}
          </Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>कार्य अवधि</Text>
          <Text style={styles.meta}>शुरू {d(w.startDate)} → पूर्ण {d(w.completeDate)}</Text>
          <Text style={styles.meta}>स्थिति: {w.status === 'completed' ? 'पूर्ण' : 'लंबित'}</Text>
        </View>

        {/* ═══ v11 #16 — कार्य खोलते ही इसी अवधि की मन-डे स्वीकृतियाँ (MR) + सुधार/हटाव ═══ */}
        <Text style={styles.cardTitle}>मन-डे स्वीकृतियाँ (MR) — {workCalcs.length}</Text>
        <Text style={styles.meta}>
          ये वही final selected details हैं जो Manday page पर चुने गए थे — इन्हें यहीं से सुधारा या हटाया जा सकता है।
        </Text>
        {workCalcs.length === 0 ? (
          <Text style={styles.meta}>अभी कोई मन-डे स्वीकृति नहीं — नीचे “मन-डे स्वीकृति” बटन से बनाएँ।</Text>
        ) : (
          workCalcs.map((c) => (
            <View key={c.id} style={[styles.card, { borderColor: C.primarySoft, borderWidth: 1.5 }]}>
              <Text style={styles.cardTitle}>
                {c.role === 'karigar' ? 'कारीगर' : 'कारीगर + श्रमिक'} · {c.workers} × {c.days} दिन
              </Text>
              <Text style={styles.sumLine}>{formatINR(c.amount)} @ ₹{c.rate}/दिन</Text>
              <Text style={styles.meta}>
                {c.createdAt.slice(0, 10)} · BSR {c.bsrYear}
                {c.muster?.count ? ` · ${c.muster.count} MR` : ''}
              </Text>
              {c.muster?.mrs?.length ? (
                <Text style={styles.meta}>
                  {c.muster.mrs
                    .map((m, i) => `MR${i + 1}: ${m.karigar}कारीगर + ${m.labour}श्रमिक`)
                    .join(' · ')}
                </Text>
              ) : null}
              {c.muster?.note ? <Text style={styles.meta}>विवरण: {c.muster.note}</Text> : null}
              <View style={styles.row}>
                <Btn label="✎ सुधारें" icon="edit-3" variant="soft" onPress={() => go('manday', w.id)} />
                <Btn
                  label="🗑 हटाएँ"
                  variant="danger"
                  icon="trash-2"
                  onPress={() => {
                    Alert.alert(
                      'यह स्वीकृति हटाएँ?',
                      `${formatINR(c.amount)} की मन-डे स्वीकृति (व MR) हटेंगी।`,
                      [
                        { text: 'रहने दें', style: 'cancel' },
                        { text: 'हटाएँ', style: 'destructive', onPress: () => deleteMandayCalc(c.id) },
                      ]
                    );
                  }}
                />
              </View>
            </View>
          ))
        )}
        <Text style={styles.cardTitle}>MB valuation {formatINR(mbVal)} ({mb.length} lines)</Text>
        <Text style={styles.meta}>
          सामग्री {formatINR(matVal)} · श्रम/कारीगर {formatINR(labVal)}
          {w.mbNo ? ` · MB नं. ${w.mbNo}` : ''}{w.mbPage ? ` · पृष्ठ ${w.mbPage}` : ''}
        </Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>भुगतान बिल ({bl.length})</Text>
          {bl.map((b) => (
            <Text key={b.id} style={styles.meta}>
              {fmtDate(b.billDate)} · {b.vendor} · {formatINR(b.amount)}
              {b.paymentDate ? ` · भुगतान ${fmtDate(b.paymentDate)}` : ''}
            </Text>
          ))}
          {bl.length === 0 ? <Text style={styles.meta}>कोई बिल नहीं</Text> : null}
          <Text style={styles.cardTitle}>कुल भुगतान: {formatINR(paid)}</Text>
        </View>
        {/* v10 #20 — कार्य जोड़ने के बाद भी सुधार */}
        <Btn label="✎ कार्य सुधारें (Edit)" icon="edit-3" onPress={() => setEditOpen(true)} />
        <Btn label="मन-डे स्वीकृति (नई / सूची)" icon="clipboard" onPress={() => go('manday', w.id)} />
        <Btn label="MB entry" variant="soft" onPress={() => go('mb', w.id)} />
        <Btn label="Bills" variant="soft" onPress={() => go('bills', w.id)} />
        <Btn label="CC (7 pages summary)" variant="outline" onPress={() => go('cc', w.id)} />

        {/* ═══ v12 #24 — कार्य सूची से मिटाना: MB + MR + बिल साथ, cashbook वाउचर बचे ═══ */}
        <Text style={styles.section}>कार्य मिटाएँ (Delete work)</Text>
        <Text style={styles.meta}>
          इस कार्य की **MB ({mb.length} lines)**, **मन-डे स्वीकृतियाँ ({workCalcs.length})** और **बिल ({bl.length})** एक साथ मिट
          जाएँगे। कैशबुक की जो entries इस कार्य के साथ जोड़ी गई थीं वे **नहीं मिटेंगी** — उनमें vendor/party, राशि और तिथि
          ज्यों का त्यों रहेगा, सिर्फ़ कार्य-लिंक हट जाएगा और वे monthly check में फिर से दिखेंगी।
        </Text>
        <Btn
          label={`🗑 कार्य मिटाएँ — ${w.name}`}
          variant="danger"
          icon="trash-2"
          onPress={() =>
            Alert.alert(
              'कार्य मिटाएँ?',
              `${w.name}\n\n• MB lines: ${mb.length}\n• मन-डे स्वीकृतियाँ (MR): ${workCalcs.length}\n• बिल: ${bl.length}\n• कैशबुक entries (बची रहेंगी, कार्य-लिंक हटेगा): ${linkedTxns.length}\n\nयह कार्य सूची से हमेशा के लिए हट जाएगा।`,
              [
                { text: 'रहने दें', style: 'cancel' },
                {
                  text: 'हाँ, मिटाएँ',
                  style: 'destructive',
                  onPress: async () => {
                    const r = await deleteWorkCascade(workId);
                    Alert.alert(
                      'कार्य मिटा दिया',
                      `MB ${r.mb} · MR ${r.mr} · बिल ${r.bills} हटे।\nकैशबुक की ${r.txns} entries सुरक्षित रहीं (अब vendor के नाम से, बिना कार्य-लिंक) — मासिक जाँच में दिखेंगी।`
                    );
                    back();
                  },
                },
              ]
            )
          }
        />
      </ScrollView>

      {/* v10 #20 — सुधार का फ़ॉर्म (भरा हुआ) */}
      <Modal visible={editOpen} transparent animationType="slide" onRequestClose={() => setEditOpen(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '96%' }]}>
            <Text style={styles.modalTitle}>कार्य सुधारें</Text>
            <Text style={styles.meta}>{w.name}</Text>
            <ScrollView style={{ maxHeight: editBodyMax }} keyboardShouldPersistTaps="handled">
              <WorkAddForm edit={w} onDone={() => setEditOpen(false)} />
            </ScrollView>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setEditOpen(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

/**
 * instruction #23 — MB / बिल / CC के लिए अलग-अलग tile; इन्हें खोलते ही
 * पहले कार्य चुनना पड़ता है (workId मिले बिना page नहीं खुलता)।
 */
function WorkPicker({
  title,
  badge,
  back,
  go,
  stage,
  includeOther,
  onlyMb,
}: {
  title: string;
  badge: string;
  back: () => void;
  go: (s: Stage, wid?: string) => void;
  stage: Stage;
  /** v10 #26 — सूची में "अन्य व्यय (Other Expenses)" भी दिखे (कार्य-रहित ख़र्च) */
  includeOther?: boolean;
  /** v12 #23 — माप पुस्तिका सूची: सिर्फ़ MB पूर्ण (mbStatus='complete') वाले कार्य */
  onlyMb?: boolean;
}) {
  const { works, activeFy, activeFunds } = useStore();
  const fyWorks = works.filter(
    (w) => w.fyId === activeFy.id && (!onlyMb || w.mbStatus === 'complete')
  );
  return (
    <View style={styles.page}>
      <Header title={title} onBack={back} badge={badge} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          {onlyMb
            ? /* v12 #23 — सिर्फ़ MB पूर्ण कार्य ही माप पुस्तिका सूची में */
              'यहाँ सिर्फ़ उन्हीं कार्यों की माप पुस्तिका (MB) दिखती है जिनकी MB पूर्ण हो चुकी है। खोलने पर MB विवरण खुलेगा — वहीं से सुधारें या हटाएँ।'
            : `पहले कार्य चुनें — फिर उसी कार्य का ${title} खुलेगा।`}
        </Text>
        {fyWorks.map((w) => (
          <Pressable key={w.id} style={styles.homeRow} onPress={() => go(stage, w.id)}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{w.name}</Text>
              <Text style={styles.meta}>
                {activeFunds.find((f) => f.id === w.schemeId)?.name || ''}
                {w.status === 'completed' ? ' · पूर्ण' : ' · लंबित'}
                {w.mbStatus === 'complete' ? ' · MB ✓' : ''}
                {/* v12 #23 — MB का नं./पृष्ठ/मूल्यांकन सूची में ही दिखे */}
                {onlyMb && w.mbNo ? ` · MB नं. ${w.mbNo}` : ''}
                {onlyMb && w.mbPage ? ` · पृष्ठ ${w.mbPage}` : ''}
                {onlyMb && w.mbValuation ? ` · मूल्यांकन ${formatINR(w.mbValuation)}` : ''}
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
        {/* v10 #26 — कार्य-रहित ख़र्च भी यहीं से खुलें */}
        {includeOther ? (
          <Pressable style={styles.homeRow} onPress={() => go(stage, OTHER_WORK_ID)}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>अन्य व्यय (Other Expenses)</Text>
              <Text style={styles.meta}>
                वेतन · रखरखाव · यात्रा · अन्य — जो किसी कार्य से जुड़े नहीं हैं
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ) : null}
        {fyWorks.length === 0 && !includeOther ? (
          <Empty
            title={onlyMb ? 'MB पूर्ण कोई कार्य नहीं' : 'कोई कार्य नहीं'}
            why={
              onlyMb
                ? 'इस वित्तीय वर्ष में अभी किसी कार्य की माप पुस्तिका पूर्ण नहीं हुई'
                : 'पहले Works tile से कार्य जोड़ें'
            }
            steps={
              onlyMb
                ? ['कार्य खोलें', 'MB entry → जानकारी भरें', 'MB स्थिति “पूर्ण (Complete)” करें']
                : ['कार्य खोलें', '+ नया कार्य जोड़ें', 'फिर यहाँ लौटें']
            }
          />
        ) : null}
      </ScrollView>
    </View>
  );
}

function MbScreen({ back, workId, go }: { back: () => void; workId: string; go: (s: Stage, wid?: string) => void }) {
  const { addMbLine, mbLines, works, activeFunds, bsrRates, activeFy, itemMasters, workerRates, financialYears,
    addBsrRate, updateBsrRate, deleteBsrRate, addItemMaster, updateItemMaster, deleteItemMaster, updateWork, deleteMbLine, updateMbLine } = useStore();
  /* v11 #19/#20 — MB में भी BSR वर्ष चुनने का dropdown (उसी वर्ष की दर/मद दिखेंगे) */
  const [bsrYear, setBsrYear] = useState(activeFy.label);
  const bsrYears = React.useMemo(() => bsrYearList(financialYears, bsrRates), [financialYears, bsrRates]);
  const [bsrOpen, setBsrOpen] = useState(false);
  const work = works.find((x) => x.id === workId);
  const [item, setItem] = useState(''); // v9 #13 — सामग्री: dropdown का key ('new' = नया मद)
  const [newItem, setNewItem] = useState('');
  const [qty, setQty] = useState('1');
  const [rate, setRate] = useState('0');
  /* instruction #3: दो अलग पक्ष — सामग्री / श्रम (v10 #21 — अब दो अलग pages) */
  const [part, setPart] = useState<'material' | 'labour'>('labour');
  /* v9 #12 — 'मेट' हटाया: MB में अब सिर्फ़ श्रमिक / कारीगर */
  const [role, setRole] = useState<'labour' | 'karigar'>('labour');
  /* v10 #21 — सामग्री पृष्ठ पर ही तय होता है: मद सामग्री है या कारीगर;
     कारीगर का default = श्रम राशि (यही “default = karigar in labour amount”) */
  const [matSide, setMatSide] = useState<'material' | 'labour'>('material');
  /* v13 #16/#17 — MB की कोई भी पंक्ति इसी पन्ने से सुधारें / मिटाएँ */
  const [lineEdit, setLineEdit] = useState<MbLine | null>(null);
  const isKarigarName = (s: string) =>
    /कारीगर|करीगर|राजमिस्त्री|मिस्त्री|mistri|श्रमिक|मजदूर|मजदुर|भूमिस|labou?r|kari?\s?gar/i.test(s || '');
  const lines = mbLines.filter((m) => m.workId === workId);
  const inMaterial = (m: MbLine) => m.kind === 'material' || (m.kind === 'artisan' && m.karigarIn === 'material');
  const matLines = lines.filter(inMaterial);
  const labLines = lines.filter((m) => !inMaterial(m));
  const sum = (l: MbLine[]) => l.reduce((s, m) => s + m.qty * m.rate, 0);
  const roleLabel = (m: MbLine) =>
    m.kind === 'material' ? 'सामग्री' : m.kind === 'artisan' ? (m.karigarIn === 'material' ? 'कारीगर (सामग्री में)' : 'कारीगर') : 'श्रम';

  /**
   * v13 #16/#17 — MB की हर पंक्ति अब सीधे इसी पन्ने से **सुधारी व हटाई** जा सकती है:
   *   • सामग्री पक्ष = consumption (खपत) मात्रा यहीं ठीक करें → BSR दर से योग बदलता है
   *   • ग़लती से जुड़ी श्रम पंक्ति भी यहीं से हटाई जा सकती है
   */
  const lineRows = (list: MbLine[]) =>
    list.map((m) => (
      <View key={m.id} style={[styles.card, { backgroundColor: C.input, borderColor: C.border, padding: 8 }]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardTitle} numberOfLines={2}>
              {m.itemName}
            </Text>
            <Text style={styles.meta}>
              {m.qty} × {formatINR(m.rate)} = {formatINR(Math.round(m.qty * m.rate * 100) / 100)}
              {m.kind === 'material' ? ' · सामग्री' : ''}
              {m.kind === 'artisan' ? ` · ${roleLabel(m)} (श्रम राशि में)` : ''}
            </Text>
          </View>
          <IconBtn name="edit-3" onPress={() => setLineEdit({ ...m })} />
          <IconBtn
            name="trash-2"
            onPress={() =>
              Alert.alert('यह पंक्ति हटाएँ?', `${m.itemName}\n${m.qty} × ${formatINR(m.rate)} = ${formatINR(m.qty * m.rate)}`, [
                { text: 'रहने दें', style: 'cancel' },
                { text: 'हटाएँ', style: 'destructive', onPress: () => deleteMbLine(m.id) },
              ])
            }
          />
        </View>
      </View>
    ));

  /* v9 #13 — सामग्री का मद: BSR + Item-master सूची से dropdown, आख़िर में "नया item" */
  const itemOptions = React.useMemo(() => {
    const seen = new Map<string, { key: string; label: string; sub?: string }>();
    for (const b of bsrRates) {
      if (b.year !== bsrYear) continue;
      const k = b.itemName.trim().toLowerCase();
      if (!k || seen.has(k)) continue;
      seen.set(k, { key: 'b:' + k, label: b.itemName, sub: `${formatINR(b.rate)} / ${b.unit || 'इकाई'}` });
    }
    for (const im of itemMasters) {
      const k = im.name.trim().toLowerCase();
      if (!k || seen.has(k)) continue;
      seen.set(k, { key: 'i:' + k, label: im.name, sub: 'Item master' });
    }
    return Array.from(seen.values());
  }, [bsrRates, itemMasters, bsrYear]);

  const itemLabel =
    item === 'new' ? newItem.trim() : item ? itemOptions.find((o) => o.key === item)?.label.trim() || '' : '';
  /* instruction #24 — मद लिखते ही BSR दर (अगर उस साल master में है) */
  const bsrHit = part === 'material' && itemLabel ? findBsr(bsrRates, bsrYear, itemLabel) : null;
  const karigarVal = lines.filter((m) => m.kind === 'artisan').reduce((s, m) => s + m.qty * m.rate, 0);

  /* v9 #13 — श्रम पक्ष पर मद नहीं पूछा जाता; दर भूमिका की BSR/default दर से अपने-आप,
     और सामग्री पक्ष पर दर 0 (item चुनते ही BSR दर अपने-आप बैठ जाती है) */
  React.useEffect(() => {
    if (part === 'material') {
      setRate('0');
      setQty('1');
      return;
    }
    const r = referenceRate(bsrRates, workerRates, bsrYear, role);
    if (r.rate) setRate(String(r.rate));
    setQty('1');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [part, role]);

  /* v10 #21 — मद बदलते ही यह भी तय: सामग्री या कारीगर (कारीगर → श्रम राशि, default) */
  React.useEffect(() => {
    if (part !== 'material' || !itemLabel) return;
    setMatSide(isKarigarName(itemLabel) ? 'labour' : 'material');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemLabel, part]);

  if (!work) {
    /* instruction #23 + v12 #23 — MB tile से आए तो सिर्फ़ MB पूर्ण कार्यों की सूची */
    return <WorkPicker title="MB (माप पुस्तिका)" badge="S-52" back={back} go={go} stage="mb" onlyMb />;
  }
  const save = () => {
    const isMaterial = part === 'material';
    const name = isMaterial
      ? itemLabel
      : role === 'karigar'
        ? 'कारीगर'
        : 'श्रमिक';
    if (!name) return Alert.alert(item === 'new' ? 'नया item का नाम भरें' : 'मद चाहिए', item === 'new' ? '' : 'सूची से चुनें या "नया item…" चुनें');
    const q = parseFloat(qty) || 0;
    const r = parseFloat(rate) || 0;
    /* v10 #21 — सामग्री पृष्ठ पर चुना पक्ष ही तय करता है: सामग्री, या कारीगर → श्रम राशि */
    const kind: MbLine['kind'] = isMaterial
      ? matSide === 'labour'
        ? 'artisan'
        : 'material'
      : role === 'karigar'
        ? 'artisan'
        : 'labour';
    addMbLine({
      workId,
      itemName: name,
      qty: q,
      rate: r,
      kind: kind as MbLine['kind'],
      /* कारीगर हमेशा श्रम राशि में (default = karigar in labour amount) */
      ...(kind === 'artisan' ? { karigarIn: 'labour' as const } : {}),
    });
    if (isMaterial) {
      setItem('');
      setNewItem('');
      setRate('0');
      setMatSide('material');
    }
    setQty('1');
  };
  return (
    <View style={styles.page}>
      <Header title="MB — माप पुस्तिका" onBack={back} badge="S-21" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{work.name}</Text>

        {/* v9 #11 — A.S./T.S./F.S. क्रमांक व दिनांक MB entry में साफ़-साफ़ दिखें */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>कार्य विवरण (auto) — स्वीकृति व MB</Text>
          <Text style={styles.meta}>
            योजना: {activeFunds.find((f) => f.id === work.schemeId)?.name || work.schemeId}
            {work.sanctionRef ? ` · स्वीकृति सं. ${work.sanctionRef}` : ''}
            {work.fundingAgency ? ` · एजेंसी ${work.fundingAgency}` : ''}
          </Text>
          <Text style={styles.meta}>A.S. (प्रशासनिक): {work.asNo || '—'} · दिनांक {work.asDate ? fmtDate(work.asDate) : '—'}</Text>
          <Text style={styles.meta}>T.S. (तकनीकी): {work.tsNo || '—'} · दिनांक {work.tsDate ? fmtDate(work.tsDate) : '—'}</Text>
          <Text style={styles.meta}>F.S. (वित्तीय): {work.fsNo || '—'} · दिनांक {work.fsDate ? fmtDate(work.fsDate) : '—'}</Text>
          <Text style={styles.meta}>
            FS राशि {work.fsAmount ? formatINR(work.fsAmount) : '—'}
            {work.mbValuation ? ` · MB मूल्यांकन ${formatINR(work.mbValuation)}` : ''}
          </Text>
          <Text style={styles.meta}>
            शुरू {work.startDate ? fmtDate(work.startDate) : '—'} → पूर्ण {work.completeDate ? fmtDate(work.completeDate) : '—'}
            {work.mbNo ? ` · MB नं. ${work.mbNo}` : ''}
            {work.mbPage ? ` · पृष्ठ ${work.mbPage}` : ''}
          </Text>
        </View>

        {/* ═══ v12 #23 — माप पुस्तिका का विवरण + सुधार / सुधार / हटाव ═══ */}
        <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5 }]}>
          <Text style={styles.cardTitle}>माप पुस्तिका (MB) — विवरण</Text>
          <Text style={styles.sumLine}>
            {work.mbValuation ? `मूल्यांकन ${formatINR(work.mbValuation)}` : 'मूल्यांकन —'}
            {' · '}
            {work.mbLabourAmount ? `श्रम ${formatINR(work.mbLabourAmount)}` : ''}
            {work.mbMaterialAmount ? ` · सामग्री ${formatINR(work.mbMaterialAmount)}` : ''}
          </Text>
          <Text style={styles.meta}>
            MB क्रमांक {work.mbNo || '—'} · पृष्ठ {work.mbPage || '—'} · स्थिति{' '}
            {work.mbStatus === 'complete' ? 'पूर्ण ✓' : 'लंबित'}
          </Text>
          <Text style={styles.meta}>पंक्तियाँ: {lines.length} (सामग्री {matLines.length} · श्रम/कारीगर {labLines.length})</Text>
          <View style={styles.row}>
            <Btn
              label="✎ MB सुधारें (Correct)"
              icon="edit-3"
              variant="soft"
              onPress={() => go('workDetail', workId)}
            />
            <Btn
              label="🗑 MB हटाएँ"
              variant="danger"
              icon="trash-2"
              onPress={() =>
                Alert.alert(
                  'माप पुस्तिका हटाएँ?',
                  `${work.name} की MB स्थिति फिर “लंबित (pending)” हो जाएगी और ये ${lines.length} पंक्तियाँ हटेंगी। कार्य, बिल और कैशबुक entries अपरिवर्तित रहेंगी।`,
                  [
                    { text: 'रहने दें', style: 'cancel' },
                    {
                      text: 'हटाएँ',
                      style: 'destructive',
                      onPress: async () => {
                        for (const m of lines) deleteMbLine(m.id);
                        await updateWork(workId, {
                          mbStatus: 'pending',
                          mbNo: undefined,
                          mbPage: undefined,
                          mbValuation: undefined,
                          mbLabourAmount: undefined,
                          mbMaterialAmount: undefined,
                        });
                        Alert.alert('MB हटा दी', 'कार्य फिर से MB बनाने योग्य है।');
                      },
                    },
                  ]
                )
              }
            />
          </View>
        </View>

        {/* ═══ v10 #21 — सामग्री और श्रम अब दो अलग-अलग pages ═══ */}
        <Text style={styles.section}>कौन-सा पृष्ठ?</Text>
        <View style={styles.row}>
          <Btn
            label={`सामग्री (Material) · ${matLines.length}`}
            variant={part === 'material' ? 'primary' : 'outline'}
            onPress={() => setPart('material')}
          />
          <Btn
            label={`श्रम (Labour) · ${labLines.length}`}
            variant={part === 'labour' ? 'primary' : 'outline'}
            onPress={() => setPart('labour')}
          />
        </View>

        {part === 'material' ? (
          <>
            {/* ═══ v12 #13 — सामग्री पृष्ठ पर **सबसे पहले** BSR वर्ष चुनाव ═══
                वर्ष चुने बिना मद/दर चुनना बेमानी है, इसलिए वर्ष-चुनाव ही पहला कदम। */}
            <Text style={styles.section}>पहले वर्ष चुनें — फिर मद</Text>
            <YearField label="BSR वर्ष" value={bsrYear} years={bsrYears} onChange={setBsrYear} />
            <Btn label={`BSR items संपादित करें (${bsrYear})`} icon="sliders" variant="soft" onPress={() => setBsrOpen(true)} />
            <Text style={styles.hint}>
              सामग्री पृष्ठ — मद चुनें (BSR/Item-master), फिर यह भी बताएँ कि वह{' '}
              <Text style={{ fontWeight: '900' }}>सामग्री</Text> है या <Text style={{ fontWeight: '900' }}>कारीगर</Text>। कारीगर
              अपने-आप श्रम राशि में गिना जाता है (v10 #21)।
            </Text>
            <Text style={styles.section}>नई पंक्ति — सामग्री</Text>
            {/* v9 #13 — dropdown = BSR/Item-master सूची + आख़िर में "नया item" (एक ही dropdown में) */}
            <SelectField
              label="सामग्री का मद (सूची से चुनें)"
              value={itemLabel || ''}
              options={[...itemOptions, { key: 'new', label: '➕ नया item…', sub: 'सूची में नहीं है' }]}
              onSelect={(k) => {
                setItem(k);
                if (k === 'new') {
                  setRate('0');
                  setQty('1');
                  return;
                }
                const lab = itemOptions.find((o) => o.key === k)?.label || '';
                const b = findBsr(bsrRates, bsrYear, lab);
                if (b && b.rate > 0) setRate(String(b.rate));
                /* v10 #21 — कारीगर जैसा मद चुना तो default श्रम राशि */
                setMatSide(isKarigarName(lab) ? 'labour' : 'material');
              }}
              hint="BSR व Item-master के सारे मद एक ही सूची में — नया मद चाहिए तो सबसे नीचे “नया item…” चुनें।"
            />
            {item === 'new' ? <Field label="नया item का नाम" value={newItem} onChangeText={setNewItem} placeholder="जैसे: प्लास्टर मेसिन" /> : null}
            {bsrHit ? (
              <Text style={styles.meta}>
                BSR {bsrYear} दर: {formatINR(bsrHit.rate)} / {bsrHit.unit || 'इकाई'}
              </Text>
            ) : itemLabel ? (
              <Text style={styles.meta}>इस मद की BSR दर master में नहीं — Masters → BSR से जोड़ें।</Text>
            ) : null}

            {/* v10 #21 — सामग्री page पर ही कारीगर चुना → material या labour (default = श्रम राशि) */}
            <Text style={styles.section}>यह किस पक्ष में गिनें? *</Text>
            <View style={styles.row}>
              <Btn label="सामग्री" variant={matSide === 'material' ? 'primary' : 'outline'} onPress={() => setMatSide('material')} />
              <Btn
                label="कारीगर → श्रम राशि"
                variant={matSide === 'labour' ? 'primary' : 'outline'}
                onPress={() => setMatSide('labour')}
              />
            </View>
            <Text style={styles.meta}>
              {matSide === 'labour'
                ? 'यह मद श्रम पक्ष में जुड़ेगा (कारीगर की राशि — MB की श्रम घटक में गिना जाएगा)।'
                : 'यह मद सामग्री पक्ष की उप-योग में जुड़ेगा।'}
            </Text>

            <View style={styles.row}>
              <Field label="Qty (मात्रा)" value={qty} onChangeText={setQty} keyboardType="numeric" grow bg={C.input} />
              <Field label="Rate (दर ₹)" value={rate} onChangeText={setRate} keyboardType="numeric" grow bg={C.input} />
            </View>
            <Btn label="MB line जोड़ें (सामग्री)" icon="plus" onPress={save} />
          </>
        ) : (
          <>
            <Text style={styles.hint}>
              श्रम पृष्ठ — मद अलग से नहीं पूछा जाता; नाम अपने-आप “श्रमिक/कारीगर”, दर BSR/default दर से बैठती है।
            </Text>
            <Text style={styles.section}>नई पंक्ति — श्रम</Text>
            <View style={styles.row}>
              <Btn label="श्रमिक" variant={role === 'labour' ? 'primary' : 'outline'} onPress={() => setRole('labour')} />
              <Btn label="कारीगर" variant={role === 'karigar' ? 'primary' : 'outline'} onPress={() => setRole('karigar')} />
            </View>
            {/* v9 #13 — श्रम पक्ष पर मद नहीं पूछते; नाम अपने-आप श्रमिक/कारीगर */}
            <Text style={styles.meta}>
              मद अपने-आप: <Text style={{ fontWeight: '800' }}>{role === 'karigar' ? 'कारीगर' : 'श्रमिक'}</Text> — यहाँ अलग से item नहीं भरना पड़ता।
            </Text>
            <View style={styles.row}>
              <Field label="मान-दिवस (दिन)" value={qty} onChangeText={setQty} keyboardType="numeric" grow bg={C.input} />
              <Field label="दर (₹/दिन)" value={rate} onChangeText={setRate} keyboardType="numeric" grow bg={C.input} />
            </View>
            <Btn label="MB line जोड़ें (श्रम)" icon="plus" onPress={save} />
          </>
        )}

        {/* instruction #3 — दोनों parts की अलग-अलग grouping + उप-योग; सक्रिय page का पूरा, बाक़ी का सिर्फ़ योग */}
        {part === 'material' ? (
          <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5 }]}>
            <Text style={styles.cardTitle}>सामग्री पक्ष ({matLines.length} lines) · योग {formatINR(sum(matLines))}</Text>
            {matLines.length === 0 ? (
              <Text style={styles.meta}>कोई सामग्री पंक्ति नहीं — ऊपर सामग्री पृष्ठ से जोड़ें।</Text>
            ) : (
              <>
                <Text style={styles.meta}>✎ = सुधारें (मात्रा/दर/खपत) · 🗑 = हटाएँ — दोनों इसी पन्ने से।</Text>
                {lineRows(matLines)}
              </>
            )}
            <Text style={styles.meta}>श्रम पक्ष का योग: {formatINR(sum(labLines))}</Text>
          </View>
        ) : (
          <View style={[styles.card, { borderColor: C.income, borderWidth: 1.5 }]}>
            <Text style={styles.cardTitle}>श्रम पक्ष ({labLines.length} lines) · योग {formatINR(sum(labLines))}</Text>
            {labLines.length === 0 ? (
              <Text style={styles.meta}>कोई श्रम पंक्ति नहीं — ऊपर श्रम पृष्ठ से जोड़ें।</Text>
            ) : (
              <>
                <Text style={styles.meta}>✎ = सुधारें · 🗑 = ग़लती से जुड़ी पंक्ति हटाएँ — इसी पन्ने से।</Text>
                {lineRows(labLines)}
              </>
            )}
            <Text style={styles.meta}>सामग्री पक्ष का योग: {formatINR(sum(matLines))}</Text>
          </View>
        )}
        <View style={styles.summary}>
          <Text style={styles.sumLine}>MB मूल्यांकन = सामग्री {formatINR(sum(matLines))} + श्रम {formatINR(sum(labLines))} = {formatINR(sum(matLines) + sum(labLines))}</Text>
          {/* instruction #24 — श्रम व कारीगर का अलग-अलग मूल्यांकन */}
          <Text style={styles.sumLine}>
            कारीगर मूल्यांकन {formatINR(karigarVal)} · श्रमिक मूल्यांकन {formatINR(sum(labLines) - karigarVal)}
          </Text>
        </View>

        {/* ═══ v13 #16 — MB पूर्ण होने के बाद सामग्री-पक्ष की खपत जोड़ें →
            BSR दर से योग = MB मूल्यांकन (एक ही बटन से पूरा MB दर्ज) ═══ */}
        <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5, backgroundColor: C.primarySoft }]}>
          <Text style={styles.cardTitle}>MB मूल्यांकन सहेजें (सामग्री खपत × BSR दर)</Text>
          <Text style={styles.meta}>
            सामग्री पक्ष की हर मद की खपत (Qty) ऊपर ✎ से भरें — योग उसी BSR/निविदा दर से बनेगा, जो MB मूल्यांकन बनता है।
          </Text>
          <Text style={styles.sumLine}>
            सामग्री {formatINR(sum(matLines))} + श्रम {formatINR(sum(labLines))} = {formatINR(sum(matLines) + sum(labLines))}
          </Text>
          <Btn
            label="✓ सामग्री व श्रम MB मूल्यांकन में दर्ज करें"
            icon="check"
            onPress={async () => {
              const mat = Math.round(sum(matLines) * 100) / 100;
              const lab = Math.round(sum(labLines) * 100) / 100;
              await updateWork(workId, {
                mbMaterialAmount: mat,
                mbLabourAmount: lab,
                mbValuation: Math.round((mat + lab) * 100) / 100,
              });
              Alert.alert(
                'MB मूल्यांकन दर्ज हुआ',
                `सामग्री ${formatINR(mat)} + श्रम ${formatINR(lab)} = ${formatINR(mat + lab)}\n(CC की पृष्ठ 4 से यही राशि जाँची जाएगी)`
              );
            }}
          />
        </View>

        <Btn
          label="मन-डे स्वीकृति / गणना खोलें (अलग sanction)"
          variant="soft"
          icon="clipboard"
          onPress={() => go('manday', workId)}
        />
      </ScrollView>
      {/* ═══ v13 #16/#17 — MB की पंक्ति सुधारें / मिटाएँ (इसी पन्ने से, बार-बार) ═══ */}
      <Modal visible={!!lineEdit} transparent animationType="slide" onRequestClose={() => setLineEdit(null)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '92%' }]}>
            <Text style={styles.modalTitle}>MB पंक्ति सुधारें (correct / delete)</Text>
            <ScrollView style={{ maxHeight: 420 }} keyboardShouldPersistTaps="handled">
              <Field
                label="मद / विवरण"
                value={lineEdit?.itemName || ''}
                onChangeText={(t) => setLineEdit((c) => (c ? { ...c, itemName: t } : c))}
              />
              <View style={styles.row}>
                <Field
                  label="Qty (मात्रा / खपत)"
                  value={String(lineEdit?.qty ?? '')}
                  keyboardType="numeric"
                  grow
                  bg={C.input}
                  onChangeText={(t) => setLineEdit((c) => (c ? { ...c, qty: parseFloat(t) || 0 } : c))}
                />
                <Field
                  label="Rate (दर ₹)"
                  value={String(lineEdit?.rate ?? '')}
                  keyboardType="numeric"
                  grow
                  bg={C.input}
                  onChangeText={(t) => setLineEdit((c) => (c ? { ...c, rate: parseFloat(t) || 0 } : c))}
                />
              </View>
              <Text style={styles.sumLine}>
                राशि: {formatINR(Math.round(((lineEdit?.qty || 0) * (lineEdit?.rate || 0)) * 100) / 100)}
              </Text>
              <Text style={styles.fieldLabel}>यह मद किस पक्ष में?</Text>
              <View style={styles.row}>
                <Btn
                  label="सामग्री"
                  variant={lineEdit && inMaterial(lineEdit) ? 'primary' : 'outline'}
                  onPress={() =>
                    setLineEdit((c) => (c ? { ...c, kind: 'material', karigarIn: 'material' } : c))
                  }
                />
                <Btn
                  label="श्रम / कारीगर"
                  variant={lineEdit && !inMaterial(lineEdit) ? 'primary' : 'outline'}
                  onPress={() =>
                    setLineEdit((c) =>
                      c ? { ...c, kind: isKarigarName(c.itemName) ? 'artisan' : 'labour', karigarIn: 'labour' } : c
                    )
                  }
                />
              </View>
              <Text style={styles.hint}>
                सामग्री = MB की सामग्री योग में (CC पृष्ठ 4) · श्रम = श्रम योग में (CC पृष्ठ 3)।
              </Text>
              <Btn
                label="🗑 यह पंक्ति मिटाएँ"
                variant="danger"
                icon="trash-2"
                onPress={() =>
                  Alert.alert('यह पंक्ति मिटाएँ?', lineEdit?.itemName || '', [
                    { text: 'रहने दें', style: 'cancel' },
                    {
                      text: 'मिटाएँ',
                      style: 'destructive',
                      onPress: async () => {
                        if (lineEdit) await deleteMbLine(lineEdit.id);
                        setLineEdit(null);
                      },
                    },
                  ])
                }
              />
            </ScrollView>
            <Btn
              label="✓ पंक्ति सहेजें"
              icon="check"
              onPress={async () => {
                if (!lineEdit) return;
                const l = lineEdit;
                if (!l.itemName.trim()) return Alert.alert('मद का नाम चाहिए');
                if (!(l.qty > 0)) return Alert.alert('Qty (मात्रा) > 0 भरें');
                if (!(l.rate >= 0)) return Alert.alert('दर 0 या उससे अधिक होनी चाहिए');
                await updateMbLine(l.id, {
                  itemName: l.itemName.trim(),
                  qty: l.qty,
                  rate: l.rate,
                  kind: l.kind,
                  karigarIn: l.karigarIn,
                });
                setLineEdit(null);
                Alert.alert('पंक्ति सुधर गई', `${l.itemName}: ${l.qty} × ${formatINR(l.rate)} — सूची व MB मूल्यांकन नई राशि से अपडेट हो गया।`);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setLineEdit(null)} />
          </View>
        </View>
      </Modal>
      {/* v11 #19/#20 — MB से ही उसी वर्ष की BSR items: जोड़ें / सुधारें / हटाएँ */}
      <BsrYearSheet
        open={bsrOpen}
        onClose={() => setBsrOpen(false)}
        year={bsrYear}
        bsrRates={bsrRates}
        itemMasters={itemMasters}
        addBsrRate={addBsrRate}
        updateBsrRate={updateBsrRate}
        deleteBsrRate={deleteBsrRate}
        addItemMaster={addItemMaster}
        updateItemMaster={updateItemMaster}
        deleteItemMaster={deleteItemMaster}
      />
    </View>
  );
}

/** v9 #10 — मन-डे विकल्प (दिन fix, दर बदलकर सबसे नज़दीक राशि) */
type MandayOpt = {
  workers: number;
  days: number;
  rate: number;
  amount: number;
  remaining: number;
  totalMd: number;
  /** v10 #22 — जो लोग पूरे `days` दिन लगेंगे */
  full: number;
  /** v10 #22 — बचे हुए मान-दिवस (एक व्यक्ति × rem दिन) */
  rem: number;
};

/**
 * v9 #10 + **v10 #22/#23/#24** — निकटतम राशि की गणना अब *विस्तार से*:
 *   • desired राशि → कुल मान-दिवस = floor(desired / rate)
 *   • वे मान-दिवस इस तरह बाँटते हैं: `full × days` + `1 × rem`
 *     जैसे ₹60,000 पर ₹260/दिन → 230 मान-दिवस → **19 श्रमिक × 12 दिन + 1 श्रमिक × 2 दिन
 *     = ₹59,800 (₹60,000 के निकट)**
 *   • दर भी घटा-घटा कर (−5/−10/−15/−20/−10%/−20%) सबसे कम शेष वाले 3 विकल्प
 *   • **v10 #24** — पखवाड़े के मान-दिवस 12 default; 13 सिर्फ़ तब, जब 12 पर
 *     अंतर बहुत बड़ा बचे (इसीलिए यहाँ दोनों 12- और 13-दिन वाले विकल्प बनते हैं)
 */
function mandayOptions(desired: number, R: number, days: number): MandayOpt[] {
  if (!(desired > 0) || !(R > 0) || !(days > 0)) return [];
  const dayChoices =
    days === DEFAULT_PAKHWADA_DAYS ? [DEFAULT_PAKHWADA_DAYS, MAX_PAKHWADA_DAYS] : [Math.min(days, MAX_PAKHWADA_DAYS)];
  const rates = [R, R - 5, R - 10, R - 15, R - 20, Math.round(R * 0.9), Math.round(R * 0.8)]
    .filter((v, i, a) => v > 0 && a.indexOf(v) === i)
    .sort((a, b) => b - a);
  const out: MandayOpt[] = [];
  for (const dayN of dayChoices) {
    for (const rate of rates) {
      const totalMd = Math.floor((desired + 1e-9) / rate);
      /* v11 #15 — 1 मान-दिवस (कम से कम 1 दिन) से ही गणना चालू।
         पहले `full < 1 → skip` था, इसलिए ₹2900 / ₹6100 से नीचे कोई विकल्प
         नहीं बनता था — जबकि श्रमिक व कारीगर एक दिन तक गिने जा सकते हैं। */
      if (totalMd < 1) continue;
      const full = Math.floor(totalMd / dayN);
      const rem = totalMd % dayN;
      if (full < 1 && rem < 1) continue;
      const amount = Math.round(totalMd * rate * 100) / 100;
      if (amount > desired + 0.001) continue;
      out.push({
        workers: full + (rem ? 1 : 0),
        days: dayN,
        rate,
        amount,
        remaining: Math.round((desired - amount) * 100) / 100,
        totalMd,
        full,
        rem,
      });
    }
  }
  out.sort((a, b) => a.remaining - b.remaining || a.days - b.days);
  /* v13 #4 — हर गणना के 6 विकल्प (पहले 3 थे) */
  return out.slice(0, 6);
}

/**
 * v10 #22 — विकल्प का **विस्तृत विवरण**, बिल्कुल इस तरह:
 * “19 श्रमिक × 12 दिन + 1 श्रमिक × 2 दिन @ ₹260/दिन → ₹59,800 · चाहिए ₹60,000 · अंतर ₹200”
 */
function optDetail(o: MandayOpt, desired: number, who: string): string {
  const parts: string[] = [];
  if (o.full > 0) parts.push(`${o.full} ${who} × ${o.days} दिन`);
  if (o.rem > 0) parts.push(`1 ${who} × ${o.rem} दिन`);
  const head = parts.length ? parts.join(' + ') : `${o.workers} ${who} × ${o.days} दिन`;
  return `${head} @ ₹${o.rate}/दिन → ${formatINR(o.amount)} · चाहिए ${formatINR(desired)} · अंतर ${formatINR(o.remaining)}`;
}

/** ISO + n दिन → ISO (local, UTC off-by-one से बचाव pageEngine.toIsoLocal से) */
function addDaysIso(iso: string, n: number): string {
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  d.setDate(d.getDate() + n);
  return toIsoLocal(d);
}

/**
 * Instruction #4 + #26 — मन-डे स्वीकृति (work sanction ke andar ALAG se sanction):
 *  • desired amount डालते ही default मानक दर (कारीगर ₹600 / श्रमिक ₹260) + मान-दिवस auto
 *  • trial-and-error (rate −5/−10/−15/−20/−10%/−20%) से निकटतम amount के 2–3 options
 *  • विकल्प चुनते ही Muster Roll wizard: MR का size, उसमें कारीगर, कितने MR
 *    → स्वतः "X श्रमिक + Y कारीगर द्वारा कार्य" का पूरा विवरण
 *  • BSR page सिर्फ़ button से खुलता है (बार-बार अपने-आप नहीं — instruction #30)
 */
function MandayScreen({ back, workId }: { back: () => void; workId: string }) {
  const {
    works,
    mbLines,
    bsrRates,
    workerRates,
    mandayCalcs,
    workerRolls,
    activeFy,
    itemMasters,
    addMandayCalc,
    updateMandayCalc,
    deleteMandayCalc,
    addBsrRate,
    updateBsrRate,
    deleteBsrRate,
    addItemMaster,
    updateItemMaster,
    deleteItemMaster,
    addWorkerRoll,
    updateWorkerRoll,
    financialYears,
  } = useStore();
  const work = works.find((x) => x.id === workId);
  /* v11 #20 — BSR वर्ष dropdown: किसी भी वर्ष की दर यहीं से भरें/सुधारें/हटाएँ */
  const bsrYears = React.useMemo(() => bsrYearList(financialYears, bsrRates), [financialYears, bsrRates]);
  const [bsrYear, setBsrYear] = useState(activeFy.label);
  /* v10 #18-2 — कोई कार्य न चुना हो (workId ख़ाली) तो यह पृष्ठ स्वतंत्र रूप से चलता है:
     बिना कोई कार्य जोड़े सिर्फ़ लोग × दिन × दर = राशि का हिसाब लगाया जा सकता है। */
  const standalone = !work;
  /* ───────── v9 #10 — 'मेट' हटाया; श्रमिक व कारीगर की अलग-अलग राशि ───────── */
  const [desiredLab, setDesiredLab] = useState('');
  const [desiredKar, setDesiredKar] = useState('');
  const [selLab, setSelLab] = useState<MandayOpt | null>(null);
  const [selKar, setSelKar] = useState<MandayOpt | null>(null);
  const [bsrOpen, setBsrOpen] = useState(false);
  /* एक ही पखवाड़ा-अवधि — दोनों पक्षों के लिए एक ही 'दिन'
     v10 #19/#24 — default 12 मान-दिवस, कभी भी 13 से अधिक नहीं */
  const [daysS, setDaysS] = useState(String(DEFAULT_PAKHWADA_DAYS));
  const onDays = (t: string) => {
    const n = parseInt(t.replace(/[^0-9]/g, '') || '0', 10);
    setDaysS(String(Math.min(MAX_PAKHWADA_DAYS, Math.max(1, n || 1))));
  };
  const [from, setFrom] = useState(toIsoLocal(new Date()));

  const D = parseFloat(daysS) || 0;
  /* v11 #20 — दर उसी वर्ष की BSR से जो ऊपर dropdown में चुना है */
  const refLab = referenceRate(bsrRates, workerRates, bsrYear, 'labour');
  const refKar = referenceRate(bsrRates, workerRates, bsrYear, 'karigar');
  const Rlab = refLab.rate || 0;
  const Rkar = refKar.rate || 0;
  /* instruction #30 — BSR दर अब default (कारीगर 600 / श्रमिक 260) से भी मिल जाती है,
     इसलिए दर न मिलने पर BSR page बार-बार अपने-आप खुलना बंद — अब सिर्फ़ नीचे के
     button / header icon से खुलता है और खुलकर वापस नहीं आता। */

  /* MB component limit (rule: role ki amount MB us-role component se zyada nahi) */
  const mbLabourComp = mbLines
    .filter((m) => m.workId === workId && m.kind === 'labour')
    .reduce((s, m) => s + m.qty * m.rate, 0);
  const mbKarComp = mbLines.filter((m) => m.workId === workId && m.kind === 'artisan').reduce((s, m) => s + m.qty * m.rate, 0);
  const mbComponent = mbLabourComp + mbKarComp;

  /* v9 #10 — real-time निकटतम: जैसे-जैसे राशि/दिन बदलें, विकल्प अपने-आप */
  const optLab = React.useMemo(
    () => mandayOptions(parseFloat(desiredLab) || 0, Rlab, D),
    [desiredLab, Rlab, D]
  );
  const optKar = React.useMemo(
    () => mandayOptions(parseFloat(desiredKar) || 0, Rkar, D),
    [desiredKar, Rkar, D]
  );

  /* ───────── v9 #10 + #14 — Muster Roll composition (custom हर MR) ───────── */
  const [mrSize, setMrSize] = useState(10); // custom MR size (chips या अपने हाथ से)
  const [mrCount, setMrCount] = useState(0); // 0 = auto (ceil(लोग / size))
  const [karSplit, setKarSplit] = useState<number[]>([]);
  const [labSplit, setLabSplit] = useState<number[]>([]);

  const labW = selLab ? selLab.workers : 0;
  const karW = selKar ? selKar.workers : 0;
  const totalW = labW + karW;
  /* v10 #24 — MR की अवधि = चुने गए निकटतम विकल्प का दिन (default 12; 13 सिर्फ़ उस विकल्प में) */
  const rollDays = Math.max(selLab ? selLab.days : 0, selKar ? selKar.days : 0) || D;
  const size = Math.max(1, Math.min(60, mrSize));
  const autoCount = totalW > 0 ? Math.max(1, Math.ceil(totalW / size)) : 1;
  const count = Math.max(1, Math.min(mrCount > 0 ? mrCount : autoCount, 60));
  const toAuto = addDaysIso(from, Math.max(0, rollDays - 1));

  /* v11 #16 — हर MR **अपनी क्षमता के अनुपात** में बँटता है (पहले जैसे पहले MR में ही
     सारे कारीगर ठूँस दिए जाते थे)। जैसे 40 लोग = 8 कारीगर + 32 श्रमिक और 3 MR
     (15/15/10) → MR1 3के+12श्र · MR2 3के+12श्र · MR3 2के+8श्र;
     4 MR (10-10-10-10) → सब में 2के+8श्र। */
  const capOf = (i: number, n: number, sz: number, tw: number) =>
    i !== n - 1 ? sz : Math.max(1, Math.min(sz, tw - sz * (n - 1)));
  const autoKey = `${labW}|${karW}|${size}|${count}`;
  React.useEffect(() => {
    const caps = Array.from({ length: count }, (_, i) => capOf(i, count, size, totalW));
    const capSum = caps.reduce((s, c) => s + c, 0) || 1;
    const dist = (total: number): number[] => {
      const raw = caps.map((c) => (total * c) / capSum);
      const base = raw.map((v) => Math.floor(v));
      let rem = total - base.reduce((s, v) => s + v, 0);
      const order = raw
        .map((v, i) => ({ i, f: v - Math.floor(v) }))
        .sort((a, b) => b.f - a.f || a.i - b.i);
      let oi = 0;
      while (rem > 0 && count > 0) {
        base[order[oi % count].i] += 1;
        rem -= 1;
        oi += 1;
      }
      return base;
    };
    const k: number[] = karW ? dist(karW) : Array.from({ length: count }, () => 0);
    const l: number[] = labW ? dist(labW) : Array.from({ length: count }, () => 0);
    /* rounding से किसी MR में क्षमता से ज़्यादा न भरे — ज़्यादा हिस्सा आगे बाँट दो */
    for (let i = 0; i < count; i++) {
      let over = (k[i] || 0) + (l[i] || 0) - caps[i];
      if (over <= 0) continue;
      const takeL = Math.min(over, l[i] || 0);
      l[i] = (l[i] || 0) - takeL;
      over -= takeL;
      if (over > 0) {
        const takeK = Math.min(over, k[i] || 0);
        k[i] = (k[i] || 0) - takeK;
        over -= takeK;
      }
      for (let j = 0; j < count && over > 0; j++) {
        if (j === i) continue;
        const slack = caps[j] - (k[j] || 0) - (l[j] || 0);
        if (slack <= 0) continue;
        const g = Math.min(slack, over);
        l[j] = (l[j] || 0) + g;
        over -= g;
      }
    }
    setKarSplit(k);
    setLabSplit(l);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoKey]);
  const setKarAt = (i: number, v: number) =>
    setKarSplit((a) => {
      const b = a.slice();
      while (b.length <= i) b.push(0);
      b[i] = v;
      return b;
    });
  const setLabAt = (i: number, v: number) =>
    setLabSplit((a) => {
      const b = a.slice();
      while (b.length <= i) b.push(0);
      b[i] = v;
      return b;
    });

  const totalAmount = (selLab ? selLab.amount : 0) + (selKar ? selKar.amount : 0);
  const rcLab = selLab ? rateCheck(selLab.rate, Rlab || null) : { ok: true, warn: null as string | null };
  const rcKar = selKar ? rateCheck(selKar.rate, Rkar || null) : { ok: true, warn: null as string | null };
  /* v13 #5 — नीचे दर्ज स्वीकृतियों को यहीं से सुधारें / मिटाएँ */
  const [calcEdit, setCalcEdit] = useState<MandayCalc | null>(null);
  const calcEditMax = useModalBodyMax(0.92, 250);
  /* v13 #6 — स्वीकृति सूची के लिए BSR वर्ष चुनाव ('' = सब वर्ष) */
  const [calcYear, setCalcYear] = useState('');
  const calcList = mandayCalcs.filter((c) => c.workId === workId && (!calcYear || c.bsrYear === calcYear));
  const calcYears = React.useMemo(() => {
    const from = mandayCalcs.filter((c) => c.workId === workId).map((c) => c.bsrYear).filter(Boolean);
    return [...new Set([...bsrYears, ...from])];
  }, [mandayCalcs, workId, bsrYears]);

  /* v9 #10 + v10 #22/#23 — निकटतम विकल्पों की सूची (दोनों पक्षों के लिए एक ही renderer,
     दोनों में वही विस्तृत विवरण: कितने लोग × कितने दिन × किस दर से) */
  const optList = (
    opts: MandayOpt[],
    on: MandayOpt | null,
    set: (o: MandayOpt) => void,
    R: number,
    who: string,
    desired: number
  ) =>
    opts.length ? (
      <View style={styles.card}>
        <Text style={styles.cardTitle}>निकटतम विकल्प — {who} (एक चुनें)</Text>
        <Text style={styles.meta}>
          v10 #22/#23 — हर विकल्प का पूरा हिसाब: कितने लोग × कितने दिन × किस दर पर कितना बना, और चाहिए राशि से कितना अंतर।
        </Text>
        {opts.map((o, i) => {
          const isOn = !!on && on.rate === o.rate && on.workers === o.workers && on.days === o.days;
          return (
            <Pressable
              key={i}
              onPress={() => set(o)}
              style={[styles.field, { borderColor: isOn ? C.primary : C.border, borderWidth: isOn ? 2 : 1, marginBottom: 8 }]}
            >
              <Text style={{ fontWeight: '800', color: C.foreground }}>{isOn ? '✓ ' : ''}{optDetail(o, desired, who)}</Text>
              <Text style={styles.meta}>
                कुल मान-दिवस {o.totalMd} ({o.full} × {o.days} दिन{o.rem ? ` + 1 × ${o.rem} दिन` : ''}) · शेष{' '}
                {formatINR(o.remaining)} · दर {o.rate === R ? 'पूर्ण मानक' : `मानक−${R - o.rate}`} · दिन {o.days}
                {o.days === MAX_PAKHWADA_DAYS ? ' (अधिकतम सीमा, v10 #24)' : ''}
              </Text>
            </Pressable>
          );
        })}
      </View>
    ) : null;

  /* v9 #10 + #14 — save: एक MandayCalc + हर MR का अलग Muster Roll (CC पृष्ठ 3 में वही विवरण) */
  const saveCalc = async () => {
    if (!selLab && !selKar) return Alert.alert('पहले एक विकल्प चुनें', 'श्रमिक और/या कारीगर — दोनों में से कोई एक।');
    if (!(D > 0)) return Alert.alert('दिन भरें');
    /* v10 #24 — एक पखवाड़े में कभी 13 से अधिक मान-दिवस नहीं (default 12);
       13 सिर्फ़ तब जब 12 से राशि में बहुत बड़ा फ़ासला बचता हो। */
    if (D > MAX_PAKHWADA_DAYS)
      return Alert.alert(
        `${MAX_PAKHWADA_DAYS} से अधिक दिन नहीं`,
        `पखवाड़े में अधिकतम ${MAX_PAKHWADA_DAYS} मान-दिवस होते हैं (default ${DEFAULT_PAKHWADA_DAYS})।`
      );
    if (rollDays > MAX_PAKHWADA_DAYS)
      return Alert.alert(
        'चुना विकल्प 13 दिन का है',
        `एक पखवाड़े में अधिकतम ${MAX_PAKHWADA_DAYS} दिन। कम दिन वाला विकल्प चुनें।`
      );
    const kSum = karSplit.reduce((s, n) => s + (n || 0), 0);
    const lSum = labSplit.reduce((s, n) => s + (n || 0), 0);
    if (kSum !== karW || lSum !== labW)
      return Alert.alert('MR विभाजन पूरा नहीं', `कारीगर ${kSum}/${karW} · श्रमिक ${lSum}/${labW}\nहर MR एक-एक करके भरें।`);
    for (let i = 0; i < count; i++) {
      const cap = capOf(i, count, size, totalW);
      if ((karSplit[i] || 0) + (labSplit[i] || 0) > cap)
        return Alert.alert(`MR ${i + 1} भरें`, `इस MR में ज़्यादा से ज़्यादा ${cap} लोग आ सकते हैं।`);
    }
    if (selLab && mbLabourComp > 0 && selLab.amount > mbLabourComp)
      return Alert.alert('MB component से अधिक', `श्रमिक ${formatINR(selLab.amount)} > MB श्रम ${formatINR(mbLabourComp)}`);
    if (selKar && mbKarComp > 0 && selKar.amount > mbKarComp)
      return Alert.alert('MB component से अधिक', `कारीगर ${formatINR(selKar.amount)} > MB कारीगर ${formatINR(mbKarComp)}`);

    const mrs = Array.from({ length: count }, (_, i) => ({ karigar: karSplit[i] || 0, labour: labSplit[i] || 0 }));
    const note =
      `इस पखवाड़े में ${count} Muster Roll (${size} लोग का): कुल ${labW} श्रमिक` +
      (karW > 0 ? ` + ${karW} कारीगर` : '') +
      ` द्वारा कार्य · ${totalW} × ${rollDays} मान-दिवस · कुल राशि ${formatINR(totalAmount)} · ` +
      mrs.map((m, i) => `MR${i + 1}: ${m.karigar}के+${m.labour}श्र`).join(', ');

    const calcId = await addMandayCalc({
      workId,
      role: selLab ? 'labour' : 'karigar',
      workers: totalW,
      days: rollDays,
      rate: selLab ? selLab.rate : selKar ? selKar.rate : 0,
bsrYear: bsrYear,
      amount: totalAmount,
      mbComponentAmount: mbComponent,
      /* instruction #26 + v9 #10/#14 — MR composition (custom हर MR) साथ save */
      muster: {
        size,
        karigar: karSplit[0] || 0,
        count,
        note,
        mrs,
        lab: selLab ? { workers: selLab.workers, days: rollDays, rate: selLab.rate, amount: selLab.amount } : undefined,
        kar: selKar ? { workers: selKar.workers, days: rollDays, rate: selKar.rate, amount: selKar.amount } : undefined,
      },
    });

    const wageKar = selKar ? selKar.rate : Rkar;
    const wageLab = selLab ? selLab.rate : Rlab;
    let made = 0;
    /* v10 #18-2 — स्वतंत्र गणना में कोई कार्य नहीं, इसलिए Muster Roll नहीं बनते;
       गणना (audit trail) फिर भी save होती है। */
    if (!standalone) {
      for (let i = 0; i < count; i++) {
        const kk = karSplit[i] || 0;
        const ll = labSplit[i] || 0;
        if (!kk && !ll) continue;
        await addWorkerRoll({
          workId,
          fyId: activeFy.id,
          fromDate: from,
          toDate: toAuto,
          rollNo: `MR-${i + 1}`,
          /* v9 #12 — 'मेट' नहीं: कुशल = कारीगर, अकुशल = श्रमिक */
          mateCount: 0,
          skilledCount: kk,
          unskilledCount: ll,
          days: rollDays,
          wageMate: 0,
          wageSkilled: wageKar,
          wageUnskilled: wageLab,
          sourceId: calcId,
        });
        made += 1;
      }
    }

    setDesiredLab('');
    setDesiredKar('');
    setSelLab(null);
    setSelKar(null);
    setKarSplit([]);
    setLabSplit([]);
    setMrCount(0);
    Alert.alert(
      'स्वीकृति save हो गई',
      standalone
        ? `गणना दर्ज — ${totalW} लोग × ${rollDays} दिन × ₹${selLab ? selLab.rate : selKar ? selKar.rate : 0} = ${formatINR(totalAmount)}। (स्वतंत्र गणना: कोई Muster Roll नहीं बना)।`
        : `${made} Muster Roll कार्य की CC पृष्ठ 3 (Excel) में जुड़ गए।`
    );
  };

  /* v10 #18-2 — workId भरा है पर कार्य मिला नहीं (हटा दिया गया?) तब ही रोकें;
     workId ख़ाली = स्वतंत्र मान-दिवस गणना → आगे बढ़ें। */
  if (workId && !work) {
    return (
      <View style={styles.page}>
        <Header title="मन-डे स्वीकृति" onBack={back} badge="S-22" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="स्वीकृति के लिए पहले work चुनें" steps={['Works list खोलें', 'कोई work चुनें']} />
        </View>
      </View>
    );
  }
  return (
    <View style={styles.page}>
      <Header
        title={standalone ? 'मान-दिवस गणना (स्वतंत्र)' : 'मन-डे स्वीकृति'}
        onBack={back}
        badge="S-22"
        action={<IconBtn name="sliders" onPress={() => setBsrOpen(true)} />}
      />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{standalone ? 'स्वतंत्र मान-दिवस गणना (कोई कार्य नहीं)' : work?.name}</Text>
        <Text style={styles.hint}>
          {standalone
            ? 'v10 #18-2 — बिना कोई कार्य जोड़े: चाहिए राशि + दर → कितने लोग × कितने दिन चाहिए, वही निकटतम विकल्प यहाँ मिलेंगे।'
            : 'यह work की अलग sanction है — श्रमिक व कारीगर की राशि अलग-अलग भरें; राशि/दिन बदलते ही निकटतम विकल्प अपने-आप आ जाते हैं।'}
        </Text>

        {/* v11 #20 — BSR वर्ष चुनें: इसी वर्ष की दर से निकटतम विकल्प बनेंगे */}
        <YearField label="BSR वर्ष (किस वर्ष की दर से)" value={bsrYear} years={bsrYears} onChange={setBsrYear} />
        <Text style={styles.meta}>
          v11 #19/#20 — यह चुना हुआ वर्ष ऊपर दिखने वाली दर और save होने वाली स्वीकृति दोनों में लागू। नीचे उसी वर्ष की BSR
          items में सुधार/जोड़/हटाव भी होगा।
        </Text>

        <Text style={styles.section}>अवधि (पखवाड़ा)</Text>
        <View style={styles.row}>
          {/* v10 #19/#24 — default 12, कभी भी 13 से अधिक नहीं (सीमित keyboard) */}
          <Field label="दिन (days)" value={daysS} onChangeText={onDays} keyboardType="numeric" grow />
          <DateField label="से (दिनांक)" value={from} onChange={setFrom} grow />
        </View>
        <Text style={styles.meta}>
          अवधि {fmtDate(from)} → {fmtDate(toAuto)} · {Math.max(0, rollDays)} दिन
        </Text>
        <Text style={styles.meta}>
          v10 #19/#24 — पखवाड़े के मान-दिवस default <Text style={{ fontWeight: '900' }}>12</Text>, अधिकतम{' '}
          <Text style={{ fontWeight: '900' }}>13</Text> (13 सिर्फ़ निकटतम-राशि की गणना में)। छुट्टी चुनने का विकल्प हटाया गया — हर
          MR में 26 जनवरी · 15 अगस्त · 02 अक्टूबर अपने-आप छूटती हैं। {totalW} लोग × {Math.max(0, rollDays)} दिन = {Math.max(0, totalW * rollDays)} मान-दिवस।
        </Text>

        <Text style={styles.section}>श्रमिक (labour)</Text>
        <Field
          label="चाहिए राशि / desired amount (₹) — श्रमिक"
          value={desiredLab}
          onChangeText={(t) => {
            setDesiredLab(t);
            setSelLab(null);
          }}
          keyboardType="numeric"
        />
        {Rlab > 0 ? (
          <Text style={styles.meta}>
            मानक दर ₹{Rlab}/दिन (
            {refLab.source === 'BSR' ? `BSR ${bsrYear}` : refLab.source === 'Worker' ? 'Worker master' : 'default ₹260'} ·
            safe band ₹{Math.round(Rlab * 0.8)}–₹{Math.round(Rlab * 0.9)}
          </Text>
        ) : (
          <View style={styles.card}>
            <Text style={styles.err}>श्रमिक दर उपलब्ध नहीं — BSR पृष्ठ से जोड़ें (default ₹260 चालू है)।</Text>
            <Btn label={`BSR दर भरें (${bsrYear})`} icon="sliders" onPress={() => setBsrOpen(true)} />
          </View>
        )}
        {optList(optLab, selLab, setSelLab, Rlab, 'श्रमिक', parseFloat(desiredLab) || 0)}

        <Text style={styles.section}>कारीगर (karigar)</Text>
        <Field
          label="चाहिए राशि / desired amount (₹) — कारीगर"
          value={desiredKar}
          onChangeText={(t) => {
            setDesiredKar(t);
            setSelKar(null);
          }}
          keyboardType="numeric"
        />
        {Rkar > 0 ? (
          <Text style={styles.meta}>
            मानक दर ₹{Rkar}/दिन (
            {refKar.source === 'BSR' ? `BSR ${bsrYear}` : refKar.source === 'Worker' ? 'Worker master' : 'default ₹600'} ·
            safe band ₹{Math.round(Rkar * 0.8)}–₹{Math.round(Rkar * 0.9)}
          </Text>
        ) : (
          <View style={styles.card}>
            <Text style={styles.err}>कारीगर दर उपलब्ध नहीं — BSR पृष्ठ से जोड़ें (default ₹600 चालू है)।</Text>
            <Btn label={`BSR दर भरें (${bsrYear})`} icon="sliders" onPress={() => setBsrOpen(true)} />
          </View>
        )}
        {optList(optKar, selKar, setSelKar, Rkar, 'कारीगर', parseFloat(desiredKar) || 0)}

        {optLab.length === 0 && desiredLab && D > 0 && Rlab > 0 ? (
          <Text style={styles.meta}>
            श्रमिक: इस राशि पर मान-दिवस नहीं बनता — कम से कम {formatINR(Math.max(1, Math.round(Rlab * 0.8)))} भरें (एक
            मान-दिवस भी गिना जाता है)।
          </Text>
        ) : null}
        {optKar.length === 0 && desiredKar && D > 0 && Rkar > 0 ? (
          <Text style={styles.meta}>
            कारीगर: इस राशि पर मान-दिवस नहीं बनता — कम से कम {formatINR(Math.max(1, Math.round(Rkar * 0.8)))} भरें (एक
            मान-दिवस भी गिना जाता है)।
          </Text>
        ) : null}

        {/* v9 #10 — दोनों पक्ष चुनते ही कुल योग + MR composition */}
        {selLab || selKar ? (
          <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5 }]}>
            <Text style={styles.cardTitle}>कुल योग (श्रमिक + कारीगर)</Text>
            <Text style={styles.sumLine}>
              {selLab ? `श्रमिक ${selLab.workers} × ${selLab.days} दिन × ₹${selLab.rate} = ${formatINR(selLab.amount)}` : 'श्रमिक — नहीं चुने'}
            </Text>
            <Text style={styles.sumLine}>
              {selKar ? `कारीगर ${selKar.workers} × ${selKar.days} दिन × ₹${selKar.rate} = ${formatINR(selKar.amount)}` : 'कारीगर — नहीं चुने'}
            </Text>
            <Text style={styles.sumLine}>
              कुल {totalW} लोग · {Math.max(0, D)} दिन · कुल राशि {formatINR(totalAmount)}
            </Text>
            <Text style={styles.meta}>
              कुल मान-दिवस {totalW * Math.max(0, D)} · श्रमिक {labW} · कारीगर {karW}
            </Text>

            <Text style={styles.section}>Muster Roll composition</Text>
            <Text style={styles.meta}>एक MR में कितने लोग (custom):</Text>
            <View style={styles.chips}>
              {[5, 10, 15, 20].map((n) => (
                <Pressable key={n} onPress={() => setMrSize(n)} style={[styles.chip, size === n && styles.chipOn]}>
                  <Text style={{ color: size === n ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>{n} लोग का MR</Text>
                </Pressable>
              ))}
            </View>
            <Field
              label="अपनी MR size (लोग)"
              value={String(mrSize)}
              onChangeText={(t) => setMrSize(Math.max(1, parseInt(t || '0', 10) || 1))}
              keyboardType="numeric"
            />
            <Text style={styles.meta}>
              कुल MR: {count} (स्वतः {autoCount} — बढ़ा/घटा भी सकते हैं) · जगह {count * size} लोग की
            </Text>
            <View style={styles.chips}>
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <Pressable key={n} onPress={() => setMrCount(n)} style={[styles.chip, count === n && styles.chipOn]}>
                  <Text style={{ color: count === n ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>{n} MR</Text>
                </Pressable>
              ))}
              <Pressable onPress={() => setMrCount(0)} style={[styles.chip, mrCount === 0 && styles.chipOn]}>
                <Text style={{ color: mrCount === 0 ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>स्वतः</Text>
              </Pressable>
            </View>

            {/* v9 #14 + v11 #16 — हर MR का श्रमिक/कारीगर विभाजन अनुपातिक (स्वतः), फिर चाहें तो सुधारें */}
            <Text style={styles.meta}>
              हर MR अपनी क्षमता के अनुपात में भरा गया (अनुपातिक विभाजन) — ज़रूरत हो तो नीचे बदलें · कुल कारीगर {karW} ·
              श्रमिक {labW}:
            </Text>
            {Array.from({ length: count }).map((_, i) => {
              const kk = karSplit[i] || 0;
              const ll = labSplit[i] || 0;
              const cap = capOf(i, count, size, totalW);
              return (
                <View key={i} style={[styles.field, { marginBottom: 8 }]}>
                  <Text style={{ fontWeight: '800', color: C.foreground }}>
                    MR {i + 1} / {count} — {kk} कारीगर + {ll} श्रमिक = {kk + ll} / {cap}
                  </Text>
                  <View style={styles.row}>
                    <Field
                      label="कारीगर"
                      value={String(kk)}
                      onChangeText={(t) => setKarAt(i, Math.max(0, parseInt(t || '0', 10) || 0))}
                      keyboardType="numeric"
                      grow
                    />
                    <Field
                      label="श्रमिक"
                      value={String(ll)}
                      onChangeText={(t) => setLabAt(i, Math.max(0, parseInt(t || '0', 10) || 0))}
                      keyboardType="numeric"
                      grow
                    />
                  </View>
                  {/* v10 #22 — हर MR के नीचे भी वही विस्तृत विवरण (लोग × दिन × दर = राशि) */}
                  <Text style={styles.meta}>
                    {[
                      kk > 0
                        ? `${kk} कारीगर × ${rollDays} दिन × ₹${selKar ? selKar.rate : Rkar} = ${formatINR(kk * rollDays * (selKar ? selKar.rate : Rkar))}`
                        : '',
                      ll > 0
                        ? `${ll} श्रमिक × ${rollDays} दिन × ₹${selLab ? selLab.rate : Rlab} = ${formatINR(ll * rollDays * (selLab ? selLab.rate : Rlab))}`
                        : '',
                    ]
                      .filter(Boolean)
                      .join(' + ') || '—'}{' '}
                    = {formatINR(
                      kk * rollDays * (selKar ? selKar.rate : Rkar) + ll * rollDays * (selLab ? selLab.rate : Rlab)
                    )}
                    {kk + ll > 0 ? ` · कुल मान-दिवस ${(kk + ll) * rollDays}` : ''}
                  </Text>
                </View>
              );
            })}
            <Text style={styles.meta}>
              MR अवधि {fmtDate(from)} → {fmtDate(toAuto)} ·{' '}
              {standalone
                ? 'स्वतंत्र गणना — यहाँ सिर्फ़ हिसाब save होगा, Muster Roll नहीं बनेंगे (कोई कार्य नहीं चुना)।'
                : `save करते ही ये ${count} Muster Roll कार्य की CC पृष्ठ 3 (Excel) में उसी तरह दिखेंगे।`}
            </Text>
            <Btn label="यह स्वीकृति save करें (audit trail)" icon="check" onPress={saveCalc} />
          </View>
        ) : null}

        {rcLab.warn ? <Text style={styles.err}>श्रमिक — {rcLab.warn}</Text> : null}
        {rcKar.warn ? <Text style={styles.err}>कारीगर — {rcKar.warn}</Text> : null}
        {selLab && mbLabourComp > 0 && selLab.amount > mbLabourComp ? (
          <Text style={styles.err}>
            श्रमिक राशि {formatINR(selLab.amount)} MB श्रम घटक ({formatINR(mbLabourComp)}) से अधिक — अनुमति नहीं
          </Text>
        ) : null}
        {selKar && mbKarComp > 0 && selKar.amount > mbKarComp ? (
          <Text style={styles.err}>
            कारीगर राशि {formatINR(selKar.amount)} MB कारीगर घटक ({formatINR(mbKarComp)}) से अधिक — अनुमति नहीं
          </Text>
        ) : null}

        <Text style={styles.section}>स्वीकृतियाँ ({calcList.length})</Text>
        {/* v13 #6 — यहीं से BSR वर्ष चुनें: नई गणना इसी वर्ष की दर से बनेगी */}
        <YearField label="BSR वर्ष (नई स्वीकृति के लिए)" value={bsrYear} years={calcYears} onChange={setBsrYear} />
        <Text style={styles.fieldLabel}>दर्ज स्वीकृतियाँ छानें — BSR वर्ष</Text>
        <View style={styles.chips}>
          <Pressable
            style={[styles.chip, !calcYear ? styles.chipOn : null]}
            onPress={() => setCalcYear('')}
          >
            <Text style={{ color: !calcYear ? '#fff' : C.foreground, fontSize: 11, fontWeight: '800' }}>सब वर्ष</Text>
          </Pressable>
          {calcYears.map((y) => (
            <Pressable
              key={y}
              style={[styles.chip, calcYear === y ? styles.chipOn : null]}
              onPress={() => setCalcYear(y)}
            >
              <Text style={{ color: calcYear === y ? '#fff' : C.foreground, fontSize: 11, fontWeight: '800' }}>{y}</Text>
            </Pressable>
          ))}
        </View>
        {calcList.map((c) => (
          <View key={c.id} style={[styles.card, { flexDirection: 'row', alignItems: 'center', gap: 8 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>
                {c.muster?.lab && c.muster?.kar
                  ? `श्रमिक ${c.muster.lab.workers} + कारीगर ${c.muster.kar.workers}`
                  : c.role === 'karigar'
                    ? 'कारीगर'
                    : 'श्रमिक'}
                : {c.workers} × {c.days} × ₹{c.rate} = {formatINR(c.amount)}
              </Text>
              <Text style={styles.meta}>BSR {c.bsrYear} · MB घटक {formatINR(c.mbComponentAmount)} · {c.createdAt.slice(0, 10)}</Text>
              {c.muster?.lab || c.muster?.kar ? (
                <Text style={styles.meta}>
                  {c.muster?.lab ? `श्रमिक ${formatINR(c.muster.lab.amount)}` : ''}
                  {c.muster?.lab && c.muster?.kar ? ' · ' : ''}
                  {c.muster?.kar ? `कारीगर ${formatINR(c.muster.kar.amount)}` : ''}
                </Text>
              ) : null}
              {c.muster?.note ? <Text style={styles.meta}>{c.muster.note}</Text> : null}
            </View>
            {/* v13 #5 — सुधार (correct) + हटाव — दोनों इसी पन्ने से */}
            <IconBtn name="edit-3" onPress={() => setCalcEdit({ ...c })} />
            <IconBtn
              name="trash-2"
              onPress={() =>
                Alert.alert('स्वीकृति हटाएँ?', 'इसके बनाए Muster Roll भी CC पृष्ठ 3 से हट जाएँगे।', [
                  { text: 'नहीं', style: 'cancel' },
                  { text: 'हटाएँ', style: 'destructive', onPress: () => deleteMandayCalc(c.id) },
                ])
              }
            />
          </View>
        ))}
        {calcList.length === 0 ? (
          <Empty
            title="अभी कोई स्वीकृति नहीं"
            why={
              calcYear
                ? `वर्ष ${calcYear} की कोई स्वीकृति दर्ज नहीं — "सब वर्ष" चुनकर देखें।`
                : 'दोनों में से कोई एक (या दोनों) राशि भरकर निकटतम विकल्प चुनें'
            }
            steps={['दिन भरें', 'श्रमिक/कारीगर राशि भरें', 'विकल्प चुनें', 'MR भरकर Save करें']}
          />
        ) : null}
      </ScrollView>

      {/* v13 #5 — स्वीकृति सुधारें / मिटाएँ (इसी पन्ने से) */}
      <Modal visible={!!calcEdit} transparent animationType="slide" onRequestClose={() => setCalcEdit(null)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '94%' }]}>
            <Text style={styles.modalTitle}>स्वीकृति सुधारें (correct)</Text>
            <Text style={styles.meta}>
              राशि = संख्या × दिन × दर (अपने-आप जुड़ती है)। भूमिका नहीं बदलती; ग़लत से जुड़ी पंक्तियाँ यहीं से हटें/सुधरें।
            </Text>
            <ScrollView style={{ maxHeight: calcEditMax }} keyboardShouldPersistTaps="handled">
              {calcEdit?.muster?.lab || calcEdit?.muster?.kar ? (
                <>
                  {calcEdit?.muster?.lab ? (
                    <View style={[styles.card, { backgroundColor: C.input, borderColor: C.primary }]}>
                      <Text style={styles.cardTitle}>श्रमिक (labour)</Text>
                      <View style={styles.row}>
                        <Field
                          label="संख्या"
                          value={String(calcEdit.muster.lab.workers)}
                          keyboardType="numeric"
                          grow
                          onChangeText={(t) =>
                            setCalcEdit((c) =>
                              c && c.muster && c.muster.lab
                                ? { ...c, muster: { ...c.muster, lab: { ...c.muster.lab, workers: parseInt(t.replace(/[^0-9]/g, '') || '0', 10) } } }
                                : c
                            )
                          }
                        />
                        <Field
                          label="दिन"
                          value={String(calcEdit.muster.lab.days)}
                          keyboardType="numeric"
                          grow
                          onChangeText={(t) =>
                            setCalcEdit((c) =>
                              c && c.muster && c.muster.lab
                                ? { ...c, muster: { ...c.muster, lab: { ...c.muster.lab, days: parseInt(t.replace(/[^0-9]/g, '') || '0', 10) } } }
                                : c
                            )
                          }
                        />
                      </View>
                      <Field
                        label="दर (₹ / दिन)"
                        value={String(calcEdit.muster.lab.rate)}
                        keyboardType="numeric"
                        onChangeText={(t) =>
                          setCalcEdit((c) =>
                            c && c.muster && c.muster.lab
                              ? { ...c, muster: { ...c.muster, lab: { ...c.muster.lab, rate: parseFloat(t) || 0 } } }
                              : c
                          )
                        }
                      />
                    </View>
                  ) : null}
                  {calcEdit?.muster?.kar ? (
                    <View style={[styles.card, { backgroundColor: C.input, borderColor: C.primary }]}>
                      <Text style={styles.cardTitle}>कारीगर (skilled)</Text>
                      <View style={styles.row}>
                        <Field
                          label="संख्या"
                          value={String(calcEdit.muster.kar.workers)}
                          keyboardType="numeric"
                          grow
                          onChangeText={(t) =>
                            setCalcEdit((c) =>
                              c && c.muster && c.muster.kar
                                ? { ...c, muster: { ...c.muster, kar: { ...c.muster.kar, workers: parseInt(t.replace(/[^0-9]/g, '') || '0', 10) } } }
                                : c
                            )
                          }
                        />
                        <Field
                          label="दिन"
                          value={String(calcEdit.muster.kar.days)}
                          keyboardType="numeric"
                          grow
                          onChangeText={(t) =>
                            setCalcEdit((c) =>
                              c && c.muster && c.muster.kar
                                ? { ...c, muster: { ...c.muster, kar: { ...c.muster.kar, days: parseInt(t.replace(/[^0-9]/g, '') || '0', 10) } } }
                                : c
                            )
                          }
                        />
                      </View>
                      <Field
                        label="दर (₹ / दिन)"
                        value={String(calcEdit.muster.kar.rate)}
                        keyboardType="numeric"
                        onChangeText={(t) =>
                          setCalcEdit((c) =>
                            c && c.muster && c.muster.kar
                              ? { ...c, muster: { ...c.muster, kar: { ...c.muster.kar, rate: parseFloat(t) || 0 } } }
                              : c
                          )
                        }
                      />
                    </View>
                  ) : null}
                </>
              ) : calcEdit ? (
                <>
                  <View style={styles.row}>
                    <Field
                      label="श्रमिक/कारीगर संख्या"
                      value={String(calcEdit.workers)}
                      keyboardType="numeric"
                      grow
                      onChangeText={(t) =>
                        setCalcEdit((c) => (c ? { ...c, workers: parseInt(t.replace(/[^0-9]/g, '') || '0', 10) } : c))
                      }
                    />
                    <Field
                      label="दिन (days)"
                      value={String(calcEdit.days)}
                      keyboardType="numeric"
                      grow
                      onChangeText={(t) =>
                        setCalcEdit((c) => (c ? { ...c, days: parseInt(t.replace(/[^0-9]/g, '') || '0', 10) } : c))
                      }
                    />
                  </View>
                  <Field
                    label="दर (₹ / दिन)"
                    value={String(calcEdit.rate)}
                    keyboardType="numeric"
                    onChangeText={(t) => setCalcEdit((c) => (c ? { ...c, rate: parseFloat(t) || 0 } : c))}
                  />
                </>
              ) : null}
              <YearField
                label="BSR वर्ष"
                value={calcEdit?.bsrYear || bsrYear}
                years={calcYears}
                onChange={(y) => setCalcEdit((c) => (c ? { ...c, bsrYear: y } : c))}
              />
              <Field
                label="राशि (₹) — auto भी जुड़ती है"
                value={String(calcEdit?.amount ?? '')}
                keyboardType="numeric"
                onChangeText={(t) => setCalcEdit((c) => (c ? { ...c, amount: parseFloat(t) || 0 } : c))}
              />
              <Btn
                label="राशि फिर गिनें (संख्या × दिन × दर)"
                variant="soft"
                icon="check"
                onPress={() =>
                  setCalcEdit((c) => {
                    if (!c) return c;
                    if (c.muster?.lab || c.muster?.kar) {
                      const l = c.muster?.lab ? Math.round(c.muster.lab.workers * c.muster.lab.days * c.muster.lab.rate * 100) / 100 : 0;
                      const k = c.muster?.kar ? Math.round(c.muster.kar.workers * c.muster.kar.days * c.muster.kar.rate * 100) / 100 : 0;
                      return { ...c, amount: Math.round((l + k) * 100) / 100 };
                    }
                    return { ...c, amount: Math.round(c.workers * c.days * c.rate * 100) / 100 };
                  })
                }
              />
            </ScrollView>
            <Btn
              label="सहेजें (save correction)"
              icon="check"
              onPress={async () => {
                if (!calcEdit) return;
                const e = calcEdit;
                let workers = e.workers;
                let days = e.days;
                let rate = e.rate;
                let amount = e.amount;
                const m = e.muster ? { ...e.muster } : undefined;
                if (m?.lab || m?.kar) {
                  let total = 0;
                  if (m.lab) {
                    if (!(m.lab.workers > 0) || !(m.lab.days > 0) || m.lab.rate < 0)
                      return Alert.alert('श्रमिक: संख्या > 0, दिन > 0, दर ≥ 0 भरें');
                    m.lab = { ...m.lab, amount: Math.round(m.lab.workers * m.lab.days * m.lab.rate * 100) / 100 };
                    total += m.lab.amount;
                  }
                  if (m.kar) {
                    if (!(m.kar.workers > 0) || !(m.kar.days > 0) || m.kar.rate < 0)
                      return Alert.alert('कारीगर: संख्या > 0, दिन > 0, दर ≥ 0 भरें');
                    m.kar = { ...m.kar, amount: Math.round(m.kar.workers * m.kar.days * m.kar.rate * 100) / 100 };
                    total += m.kar.amount;
                  }
                  amount = Math.round(total * 100) / 100;
                  workers = (m.lab?.workers || 0) + (m.kar?.workers || 0) || workers;
                  days = m.lab?.days || m.kar?.days || days;
                  rate = m.kar?.rate || m.lab?.rate || rate;
                  m.note = m.note
                    .replace(/कुल राशि ₹[\d,\.]+/, `कुल राशि ${formatINR(amount)}`)
                    .replace(/द्वारा कार्य · \d+ × \d+ मान-दिवस/, `द्वारा कार्य · ${workers} × ${days} मान-दिवस`);
                } else {
                  if (!(e.workers > 0) || !(e.days > 0) || e.rate < 0)
                    return Alert.alert('संख्या > 0, दिन > 0, दर ≥ 0 भरें');
                  workers = e.workers;
                  days = e.days;
                  rate = e.rate;
                  amount = Math.round(workers * days * rate * 100) / 100;
                }
                /* MR भी इसी हिसाब से अपडेट — ताकि CC पृष्ठ 3 और स्वीकृति में फ़र्क़ न रहे */
                const linked = workerRolls
                  .filter((r) => r.sourceId === e.id)
                  .sort((a, b) => a.rollNo.localeCompare(b.rollNo, undefined, { numeric: true }));
                if (m && linked.length) {
                  const n = linked.length;
                  const split = (total: number, key: 'karigar' | 'labour') => {
                    const base: number[] = [];
                    for (let i = 0; i < n; i++) base.push(m.mrs?.[i]?.[key] ?? 0);
                    const oldSum = base.reduce((s, x) => s + x, 0);
                    const out = base.map((b) => (oldSum > 0 ? Math.round((b / oldSum) * total) : Math.floor(total / n)));
                    let diff = total - out.reduce((s, x) => s + x, 0);
                    /* शेष 1-1 करके पहली/ज़रूरत-वाली पंक्तियों में बाँट दो (कभी अनंत लूप नहीं) */
                    if (diff > 0) {
                      for (let i = 0; i < out.length && diff > 0; i++) {
                        out[i] += 1;
                        diff -= 1;
                      }
                    } else if (diff < 0) {
                      for (let pass = 0; pass < n && diff < 0; pass++) {
                        for (let i = 0; i < n && diff < 0; i++) {
                          if (out[i] > 0) {
                            out[i] -= 1;
                            diff += 1;
                          }
                        }
                      }
                    }
                    return out;
                  };
                  const labN = m.lab ? m.lab.workers : 0;
                  const karN = m.kar ? m.kar.workers : 0;
                  const labArr = split(labN, 'labour');
                  const karArr = split(karN, 'karigar');
                  m.mrs = linked.map((_, i) => ({ karigar: karArr[i] || 0, labour: labArr[i] || 0 }));
                  const wageLab = m.lab?.rate ?? 0;
                  const wageKar = m.kar?.rate ?? 0;
                  const rollDays = m.lab?.days || m.kar?.days || days;
                  for (let i = 0; i < n; i++) {
                    await updateWorkerRoll(linked[i].id, {
                      skilledCount: karArr[i] || 0,
                      unskilledCount: labArr[i] || 0,
                      days: rollDays,
                      wageSkilled: wageKar,
                      wageUnskilled: wageLab,
                    });
                  }
                }
                await updateMandayCalc(e.id, { workers, days, rate, amount, bsrYear: e.bsrYear, ...(m ? { muster: m } : {}) });
                setCalcEdit(null);
                Alert.alert('सुधार सहेजा गया', `नई राशि ${formatINR(amount)}${linked.length ? ' · जुड़े Muster Roll भी अपडेट' : ''}`);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setCalcEdit(null)} />
          </View>
        </View>
      </Modal>

      {/* BSR quick page — sirf active FY ki rate bharni; items add/edit/delete */}
      <BsrYearSheet
        open={bsrOpen}
        onClose={() => setBsrOpen(false)}
        year={bsrYear}
        bsrRates={bsrRates}
        itemMasters={itemMasters}
        addBsrRate={addBsrRate}
        updateBsrRate={updateBsrRate}
        deleteBsrRate={deleteBsrRate}
        addItemMaster={addItemMaster}
        updateItemMaster={updateItemMaster}
        deleteItemMaster={deleteItemMaster}
      />
    </View>
  );
}

type BsrRow = { key: string; name: string; unit: string; rate: string; bsrId?: string; itemMasterId?: string };

/** BSR page (instruction #4): items pehle se listed — sirf us year ki rate bharni + item add/edit/delete */
function BsrYearSheet({
  open,
  onClose,
  year,
  bsrRates,
  itemMasters,
  addBsrRate,
  updateBsrRate,
  deleteBsrRate,
  addItemMaster,
  updateItemMaster,
  deleteItemMaster,
}: {
  open: boolean;
  onClose: () => void;
  year: string;
  bsrRates: ReturnType<typeof useStore>['bsrRates'];
  itemMasters: ReturnType<typeof useStore>['itemMasters'];
  addBsrRate: ReturnType<typeof useStore>['addBsrRate'];
  updateBsrRate: ReturnType<typeof useStore>['updateBsrRate'];
  deleteBsrRate: ReturnType<typeof useStore>['deleteBsrRate'];
  addItemMaster: ReturnType<typeof useStore>['addItemMaster'];
  updateItemMaster: ReturnType<typeof useStore>['updateItemMaster'];
  deleteItemMaster: ReturnType<typeof useStore>['deleteItemMaster'];
}) {
  /* v10 #18 — BSR sheet ka body height window se (footer buttons hamesha dikhein) */
  const bodyMax = useModalBodyMax(0.92, 300);
  const buildRows = React.useCallback((): BsrRow[] => {
    const rows: BsrRow[] = [];
    const seen = new Set<string>();
    const yr = bsrRates.filter((b) => b.year === year);
    for (const t of BSR_TEMPLATE) {
      const b = yr.find((x) => x.itemName.toLowerCase() === t.name.toLowerCase());
      rows.push({ key: 't_' + t.name, name: t.name, unit: b?.unit || t.unit, rate: b ? String(b.rate) : '', bsrId: b?.id });
      seen.add(t.name.toLowerCase());
    }
    for (const im of itemMasters) {
      if (seen.has(im.name.toLowerCase())) continue;
      const b = yr.find((x) => x.itemName.toLowerCase() === im.name.toLowerCase());
      rows.push({ key: 'i_' + im.id, name: im.name, unit: b?.unit || 'नग', rate: b ? String(b.rate) : '', bsrId: b?.id, itemMasterId: im.id });
      seen.add(im.name.toLowerCase());
    }
    for (const b of yr) {
      if (seen.has(b.itemName.toLowerCase())) continue;
      rows.push({ key: 'b_' + b.id, name: b.itemName, unit: b.unit, rate: String(b.rate), bsrId: b.id });
      seen.add(b.itemName.toLowerCase());
    }
    return rows;
  }, [bsrRates, itemMasters, year]);

  const [rows, setRows] = React.useState<BsrRow[]>(buildRows);
  const [newName, setNewName] = useState('');
  const [newUnit, setNewUnit] = useState('नग');
  const [edit, setEdit] = useState<{ key: string; name: string; unit: string } | null>(null);

  React.useEffect(() => {
    if (open) setRows(buildRows());
  }, [open, buildRows]);

  const saveAll = async () => {
    for (const r of rows) {
      const rate = parseFloat(r.rate);
      /* v13 #2 — 0 भी सहेजें (पहले 0 छोड़ दिया जाता था → पुरानी दर वापस आ जाती थी) */
      if (!Number.isFinite(rate) || rate < 0) continue;
      if (r.bsrId) await updateBsrRate(r.bsrId, { rate, unit: r.unit, itemName: r.name, year });
      else await addBsrRate({ year, itemName: r.name, unit: r.unit, rate });
    }
    setRows(buildRows());
    Alert.alert('सहेजा गया', `${year} की दरें update हो गईं`);
  };

  return (
    <Modal visible={open} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalBg}>
        <View style={[styles.modalCard, { maxHeight: '92%' }]}>
          <Text style={styles.modalTitle}>BSR दर — {year}</Text>
          <Text style={styles.meta}>
            सिर्फ़ इसी साल की दर भरें; बाक़ी साल की दरें वैसी ही रहेंगी। default दर कारीगर ₹600 / श्रमिक ₹260 है।
          </Text>
          {/* instruction #30 — modal ka card background = field background thi,
              isliye box me kuch dikhta nahi tha — ab alag background + border */}
          <View style={{ flexDirection: 'row', gap: 6, marginTop: 6 }}>
            <Text style={[styles.fieldLabel, { flex: 1 }]}>मद (item)</Text>
            <Text style={[styles.fieldLabel, { width: 110, textAlign: 'right' }]}>दर (₹)</Text>
          </View>
          <ScrollView style={{ maxHeight: bodyMax }}>
            {rows.map((r) => (
              <View key={r.key} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                <Pressable
                  style={{
                    flex: 1,
                    backgroundColor: C.muted,
                    borderRadius: 10,
                    borderWidth: 1.5,
                    borderColor: r.bsrId ? C.border : C.primary,
                    paddingHorizontal: 8,
                    paddingVertical: 6,
                    minHeight: 46,
                    justifyContent: 'center',
                  }}
                  onPress={() => (r.itemMasterId || !r.bsrId ? setEdit({ key: r.key, name: r.name, unit: r.unit }) : undefined)}
                >
                  <Text style={{ fontWeight: '700', color: C.foreground }} numberOfLines={1}>{r.name}</Text>
                  <Text style={{ fontSize: 11, color: C.mutedForeground }}>{r.unit}{r.itemMasterId ? ' · टैप कर edit' : ''}</Text>
                </Pressable>
                <TextInput
                  value={r.rate}
                  onChangeText={(t) => setRows((prev) => prev.map((x) => (x.key === r.key ? { ...x, rate: t } : x)))}
                  keyboardType="numeric"
                  placeholder="दर"
                  placeholderTextColor={C.mutedForeground}
                  style={{
                    width: 110,
                    minHeight: 44,
                    borderWidth: 2,
                    borderColor: C.primary,
                    borderRadius: 10,
                    paddingHorizontal: 10,
                    backgroundColor: '#ffffff',
                    color: C.foreground,
                    fontWeight: '800',
                    fontSize: 15,
                    textAlign: 'right',
                  }}
                />
                {r.itemMasterId ? (
                  <IconBtn
                    name="trash-2"
                    onPress={() => {
                      deleteItemMaster(r.itemMasterId!);
                      if (r.bsrId) deleteBsrRate(r.bsrId);
                      setRows((prev) => prev.filter((x) => x.key !== r.key));
                    }}
                  />
                ) : null}
              </View>
            ))}
          </ScrollView>
          {/* v13 #7 — नीचे के boxes (नया मद / इकाई) का background व border अलग,
              ताकि white modal card पर भी पूरी तरह दिखें */}
          <View style={{ backgroundColor: C.muted, borderRadius: 14, borderWidth: 1.5, borderColor: C.primary, padding: 10, marginTop: 4 }}>
            <Text style={[styles.fieldLabel, { marginBottom: 6, color: C.primary, fontSize: 12 }]}>
              + नया मद जोड़ें (सिर्फ़ {year} की सूची में)
            </Text>
            <View style={[styles.row, { marginVertical: 0 }]}>
              <Field label="नया मद" value={newName} onChangeText={setNewName} bg={C.card} grow />
              <Field label="इकाई" value={newUnit} onChangeText={setNewUnit} bg={C.card} grow />
            </View>
            <Btn
              label="+ मद जोड़ें (list में आ जाएगा)"
              variant="soft"
              onPress={() => {
                if (!newName.trim()) return Alert.alert('मद का नाम चाहिए');
                addItemMaster({ name: newName.trim(), wholeNumberOnly: false, lastBillOnly: false, basicItem: false });
                setRows((prev) => [...prev, { key: 'n_' + Date.now(), name: newName.trim(), unit: newUnit.trim() || 'नग', rate: '' }]);
                setNewName('');
              }}
            />
          </View>
          <Btn label="सभी दरें सहेजें" icon="save" onPress={saveAll} />
          <Btn label="वापस जाएँ (Back)" variant="outline" onPress={onClose} />
        </View>
      </View>
      {/* item edit */}
      <Modal visible={!!edit} transparent animationType="fade" onRequestClose={() => setEdit(null)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>मद edit करें</Text>
            <Field label="नाम" value={edit?.name || ''} onChangeText={(t) => setEdit((e) => (e ? { ...e, name: t } : e))} bg={C.input} />
            <Field label="इकाई" value={edit?.unit || ''} onChangeText={(t) => setEdit((e) => (e ? { ...e, unit: t } : e))} bg={C.input} />
            <Btn
              label="सहेजें"
              onPress={() => {
                if (!edit) return;
                const row = rows.find((x) => x.key === edit.key);
                if (row) {
                  if (row.itemMasterId) updateItemMaster(row.itemMasterId, { name: edit.name.trim() });
                  if (row.bsrId) updateBsrRate(row.bsrId, { itemName: edit.name.trim(), unit: edit.unit.trim() });
                  setRows((prev) => prev.map((x) => (x.key === edit.key ? { ...x, name: edit.name.trim(), unit: edit.unit.trim() } : x)));
                }
                setEdit(null);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setEdit(null)} />
          </View>
        </View>
      </Modal>
    </Modal>
  );
}

function BillsScreen({
  back,
  workId,
  go,
  onEditTxn,
}: {
  back: () => void;
  workId: string;
  go: (s: Stage, wid?: string) => void;
  /** v10 #26 — कैशबुक व्यय-वाउचर पर tap करके उसे सुधारने भेजें */
  onEditTxn?: (id: string) => void;
}) {
  const { addBill, updateBill, deleteBill, bills, activeFy, vendors, addVendor, deleteVendor, works, mbLines: mbLinesAll, fyTransactions, cancelTransaction, categories, activeFunds,
    bsrRates, itemMasters, financialYears, addBsrRate, updateBsrRate, deleteBsrRate, addItemMaster, updateItemMaster, deleteItemMaster, addTransaction } =
    useStore();
  /* v11 #19/#20 — बिल बनाते समय BSR वर्ष चुनें + वहीं से उस वर्ष की items संपादित करें */
  const bsrYears = React.useMemo(() => bsrYearList(financialYears, bsrRates), [financialYears, bsrRates]);
  const [bsrYear, setBsrYear] = useState(activeFy.label);
  const [bsrOpen, setBsrOpen] = useState(false);
  /* v10 #26 — "अन्य व्यय (Other Expenses)" = कार्य-रहित ख़र्च की अलग प्रविष्टि */
  const isOther = workId === OTHER_WORK_ID;
  const work = works.find((x) => x.id === workId);
  const categoryNames: Record<string, string> = {};
  for (const c of categories) categoryNames[c.id] = c.name;
  const [vendor, setVendor] = useState('');
  const [amount, setAmount] = useState('');
  const [billDate, setBillDate] = useState(toIsoLocal(new Date()));
  const [payDate, setPayDate] = useState('');
  const [pageRef, setPageRef] = useState('');
  const [note, setNote] = useState('');
  /* ═══ v12 #15 — बिल का cashbook से cross-check (चुना ही नहीं / हाँ / नहीं) ═══ */
  const [crossCheck, setCrossCheck] = useState<'unset' | 'yes' | 'no'>('unset');
  /* v13 #11 — बिल का प्रकार: आरंभिक / मध्यकालीन / अंतिम (सामग्री वितरण इसी से तय) */
  const [billType, setBillType] = useState<'starting' | 'during' | 'final'>('during');
  /* v10 #25 — bill detail popup ka body height window se */
  const billBodyMax = useModalBodyMax(0.86, 270);
  /* instruction #5: vendor = dropdown; list me na ho to wahin se add */
  const [vAddOpen, setVAddOpen] = useState(false);
  /* instruction #24b — बिल पर क्लिक → विवरण पॉपअप */
  const [billDetail, setBillDetail] = useState<ReturnType<typeof useStore>['bills'][number] | null>(null);
  /* v13 #18 — बिल सुधारें / मिटाएँ (इसी कार्य के बिल पृष्ठ से, बार-बार) */
  const [billEdit, setBillEdit] = useState<ReturnType<typeof useStore>['bills'][number] | null>(null);
  const [nvName, setNvName] = useState('');
  const [nvPhone, setNvPhone] = useState('');
  const [nvKind, setNvKind] = useState<'material' | 'labour' | 'other'>('material');
  const activeVendors = vendors.filter((v) => !v.archived);
  const list = bills.filter((b) => b.workId === workId);
  /* ═══ v13 #11 — CC/MB की स्वीकृत सामग्री + निविदा दर + बँट चुकी मात्रा ═══ */
  const matLines = mbLinesAll.filter((m) => m.workId === workId && m.kind === 'material');
  const tenderPct = Math.max(0, Number(work?.tenderRatePct) || 0);
  /** दर = BSR (चुने हुए वर्ष की), निविदा कटौती लगाकर; श्रम/कारीगर पर कभी नहीं */
  const rateOf = (name: string): number => {
    const b = findBsr(bsrRates, bsrYear, name);
    const r = b && b.rate > 0 ? b.rate : 0;
    return tenderPct > 0 && r > 0 ? Math.round(r * (1 - tenderPct / 100) * 100) / 100 : r;
  };
  /** दूसरे बिलों में पहले बँट चुकी मात्रा (माना हुआ बिल छोड़कर) */
  const usedOf = (excludeId?: string): Record<string, number> => {
    const map: Record<string, number> = {};
    for (const b of bills) {
      if (b.workId !== workId || b.id === excludeId) continue;
      for (const it of b.items || []) map[it.itemName] = (map[it.itemName] || 0) + (it.qty || 0);
    }
    return map;
  };
  const sanctionedRows = () =>
    matLines.map((m) => ({ itemName: m.itemName, qty: m.qty, rate: rateOf(m.itemName) }));
  /* v10 #26 — कैशबुक के व्यय-वाउचर अपने-आप इसी कार्य के नीचे */
  const vouchers = fyTransactions
    .filter(
      (t) =>
        t.status === 'active' &&
        t.type === 'expense' &&
        (isOther ? !t.workId && t.expenseKind === 'other' : t.workId === workId)
    )
    .sort((a, b) => b.date.localeCompare(a.date));
  const [voucher, setVoucher] = useState<Transaction | null>(null);
  /* v10 #26 — voucher पर tap → विवरण + सुधार/रद्द */
  const [vCancel, setVCancel] = useState<Transaction | null>(null);
  /* instruction #23 + #24b — बिल tile → पहले कार्य चुनें (hooks ke baad) */
  if (!work && !isOther)
    return <WorkPicker title="बिल (Bills)" badge="S-53" back={back} go={go} stage="bills" includeOther />;
  const screenTitle = isOther ? 'बिल — अन्य व्यय' : `बिल — ${work?.name || ''}`;
  return (
    <View style={styles.page}>
      <Header title={screenTitle} onBack={back} badge="S-25" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          H — Bill register date-wise: bill date + cashbook payment date + page ref{'\n'}
          v10 #26 — इस कार्य के कैशबुक व्यय-वाउचर भी यहीं (नीचे) — उन पर tap करके सुधार/रद्द करें।
        </Text>
        {/* v11 #19/#20 — बिल के लिए BSR वर्ष dropdown + वहीं से उस वर्ष की items जोड़ें/सुधारें/हटाएँ */}
        <YearField label="BSR वर्ष" value={bsrYear} years={bsrYears} onChange={setBsrYear} />
        <Btn label={`BSR items संपादित करें (${bsrYear})`} icon="sliders" variant="soft" onPress={() => setBsrOpen(true)} />
        <SelectField
          label="Vendor (dropdown)"
          value={vendor}
          placeholder="vendor चुनें"
          options={activeVendors.map((v) => ({ key: v.id, label: v.name, sub: v.phone || undefined }))}
          onSelect={(id) => {
            const v = vendors.find((x) => x.id === id);
            if (v) setVendor(v.name);
          }}
          onAddNew={() => setVAddOpen(true)}
          addNewLabel="+ नया vendor जोड़ें (dropdown list में आ जाएगा)"
        />
        <Field label="Amount" value={amount} onChangeText={setAmount} keyboardType="numeric" />
        <DateField label="Bill date" value={billDate} onChange={setBillDate} />
        <DateField label="Cashbook payment date (भुगतान के बाद)" value={payDate} onChange={setPayDate} />
        <Field label="Cashbook page ref" value={pageRef} onChangeText={setPageRef} placeholder="पृष्ठ 3" keyboardType="numeric" />
        <Field label="Note" value={note} onChangeText={setNote} multiline />

        {/* ═══ v12 #15 — क्या इस बिल को cashbook की entry से cross-check करना है? ═══ */}
        <Text style={styles.section}>Cashbook cross-check (बिल)</Text>
        <View style={styles.chips}>
          <Pressable style={[styles.chip, crossCheck === 'unset' && styles.chipOn]} onPress={() => setCrossCheck('unset')}>
            <Text style={{ color: crossCheck === 'unset' ? '#fff' : C.foreground, fontWeight: '700', fontSize: 12 }}>
              चुना नहीं
            </Text>
          </Pressable>
          <Pressable style={[styles.chip, crossCheck === 'yes' && styles.chipOn]} onPress={() => setCrossCheck('yes')}>
            <Text style={{ color: crossCheck === 'yes' ? '#fff' : C.foreground, fontWeight: '700', fontSize: 12 }}>
              हाँ — cross-check
            </Text>
          </Pressable>
          <Pressable style={[styles.chip, crossCheck === 'no' && styles.chipOn]} onPress={() => setCrossCheck('no')}>
            <Text style={{ color: crossCheck === 'no' ? '#fff' : C.foreground, fontWeight: '700', fontSize: 12 }}>
              नहीं — cashbook पर असर नहीं
            </Text>
          </Pressable>
        </View>
        <Text style={styles.meta}>
          {crossCheck === 'yes'
            ? `भुगतान इसी वित्तीय वर्ष (${activeFy.label}) में हुआ तो बिल की राशि उस तारीख़ की expense entry कैशबुक में अपने-आप जुड़ जाएगी और cross-tally भी होगा। पुराने वर्ष में भुगतान वाला बिल कैशबुक पन्ने में नहीं जुड़ेगा और cross-tally भी नहीं होगा।`
            : crossCheck === 'no'
              ? 'इस बिल का cashbook की किसी entry पर कोई असर नहीं पड़ेगा।'
              : 'अभी कुछ चुना नहीं गया — ऐसे में इस बिल का cashbook की entries पर कोई असर नहीं पड़ेगा।'}
        </Text>

        {/* ═══ v13 #11 — बिल का प्रकार: शुरुआत / मध्य में / अंतिम ═══ */}
        <Text style={styles.section}>बिल का प्रकार (Tender / CC material वितरण के लिए)</Text>
        <View style={styles.chips}>
          {([
            ['starting', 'आरंभिक (Starting)', 'कार्य की शुरुआत की सामग्री'],
            ['during', 'मध्यकालीन (During)', 'जिन मदों की अभी ज़रूरत है'],
            ['final', 'अंतिम (Final)', 'टैंकर / मशीनरी / मिक्सर / वाइब्रेटर'],
          ] as const).map(([k, label, sub]) => (
            <Pressable
              key={k}
              style={[styles.chip, billType === k && styles.chipOn, { flexGrow: 1, minWidth: '31%' }]}
              onPress={() => setBillType(k)}
            >
              <Text style={{ color: billType === k ? '#fff' : C.foreground, fontWeight: '800', fontSize: 11 }}>{label}</Text>
              <Text style={{ color: billType === k ? '#e9fff6' : C.mutedForeground, fontSize: 9 }}>{sub}</Text>
            </Pressable>
          ))}
        </View>

        <Btn
          label="Add bill"
          onPress={async () => {
            if (!vendor.trim()) return Alert.alert('Vendor चुनें या जोड़ें');
            const n = Number(amount.trim());
            if (!Number.isFinite(n) || !(n > 0)) return Alert.alert('राशि > 0 चाहिए');
            if (!isValidIsoDate(billDate)) return Alert.alert('Bill date अमान्य (YYYY-MM-DD)');
            if (payDate && !isValidIsoDate(payDate)) return Alert.alert('Payment date अमान्य (YYYY-MM-DD)');
            const payIso = payDate || billDate;
            const cross = crossCheck === 'unset' ? null : crossCheck === 'yes';
            addBill({
              workId,
              fyId: activeFy.id,
              billDate,
              paymentDate: payIso,
              pageRef: pageRef.trim(),
              vendor: vendor.trim(),
              amount: n,
              note: note.trim(),
              crossCheck: cross,
              /* v13 #11 — बिल का प्रकार दर्ज (सामग्री वितरण इसी से तय होगा) */
              billType,
            });
            /* ═══ v12 #15 — हाँ चुना और भुगतान इसी FY में → कैशबुक में अपने-आप व्यय एंट्री ═══ */
            if (cross) {
              const inFy = isValidIsoDate(payIso) && payIso >= activeFy.start && payIso <= activeFy.end;
              const sch =
                work && work.schemeId && work.schemeId !== 'cash'
                  ? work.schemeId
                  : activeFunds.find((f) => f.id !== 'cash')?.id || '';
              if (!inFy) {
                Alert.alert(
                  'कैशबुक में नहीं जुड़ा',
                  'भुगतान इस वित्तीय वर्ष के बाहर का है — पुराने वर्ष का बिल कैशबुक पन्ने में नहीं जुड़ता और cross-tally भी नहीं होता।'
                );
              } else if (!sch) {
                Alert.alert('scheme नहीं मिला', 'कैशबुक एंट्री के लिए कोई scheme उपलब्ध नहीं — एंट्री नहीं बनी।');
              } else if (!isOther || work) {
                const r = await addTransaction({
                  type: 'expense',
                  date: payIso,
                  reference: pageRef.trim(),
                  ledgerFolio: '',
                  party: vendor.trim(),
                  detail: `${work ? work.name : 'अन्य व्यय'} — बिल भुगतान`,
                  note: `बिल से automatic entry (cross-check)${note ? ` · ${note}` : ''}`,
                  schemeId: sch,
                  amounts: { [sch]: n },
                  categoryId: GENERAL_CAT_ID,
                  subcategoryId: null,
                  subSubcategoryId: null,
                  workId,
                  expenseKind: isOther ? 'other' : 'work',
                  medium: 'bank',
                });
                if (!r.ok) Alert.alert('Cashbook entry नहीं बनी', r.error || '—');
                else Alert.alert('कैशबुक में जोड़ दिया', `${fmtDate(payIso)} की व्यय entry अपने-आप बन गई (cross-check)।`);
              }
            }
            setVendor('');
            setAmount('');
            setPageRef('');
            setNote('');
            setCrossCheck('unset');
          }}
        />
        <Text style={styles.section}>Vendor master ({activeVendors.length})</Text>
        {activeVendors.map((v) => (
          <View key={v.id} style={[styles.card, { flexDirection: 'row', alignItems: 'center', gap: 8 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{v.name}</Text>
              <Text style={styles.meta}>
                {v.kind === 'material' ? 'सामग्री विक्रेता' : v.kind === 'labour' ? 'ठेकेदार/श्रम' : 'अन्य'}
                {v.phone ? ` · ${v.phone}` : ''}
              </Text>
            </View>
            <IconBtn name="trash-2" onPress={async () => { const r = await deleteVendor(v.id); if (!r.ok && r.error) Alert.alert(r.error); }} />
          </View>
        ))}
        {list.map((b) => (
          <Pressable
            key={b.id}
            style={styles.card}
            /* instruction #24b — बिल पर क्लिक → पूरा विवरण (कब का, किसका, किस दर पर, छूट, राउंड-ऑफ) */
            onPress={() => setBillDetail(b)}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle}>
                  {b.billDate} · {b.vendor} · {formatINR(b.amount)}
                </Text>
                <Text style={styles.meta}>
                  {b.billType === 'starting' ? 'आरंभिक बिल' : b.billType === 'final' ? 'अंतिम बिल' : b.billType === 'during' ? 'मध्यकालीन बिल' : ''}
                  {(b.items || []).length ? ` · सामग्री ${(b.items || []).length} मद` : ''}
                </Text>
                <Text style={styles.meta}>
                  भुगतान {b.paymentDate || '—'} · page {b.pageRef || '—'} · cross-check{' '}
                  {b.crossCheck === true ? 'हाँ ✓' : b.crossCheck === false ? 'नहीं' : 'चुना नहीं'} {b.note ? ` · ${b.note}` : ''}
                </Text>
              </View>
              {/* v13 #18 — इसी पृष्ठ से बिल सुधारें / मिटाएँ */}
              <IconBtn name="edit-3" onPress={() => setBillEdit({ ...b })} />
              <IconBtn
                name="trash-2"
                onPress={() =>
                  Alert.alert('यह बिल हटाएँ?', `${b.billDate} · ${b.vendor} · ${formatINR(b.amount)}`, [
                    { text: 'रहने दें', style: 'cancel' },
                    { text: 'हटाएँ', style: 'destructive', onPress: () => deleteBill(b.id) },
                  ])
                }
              />
              <Feather name="chevron-right" size={18} color={C.mutedForeground} />
            </View>
          </Pressable>
        ))}
        {list.length === 0 ? <Empty title="कोई bill नहीं" why="इस work पर अभी bill add नहीं हुआ" steps={['Vendor dropdown से चुनें', 'राशि भरकर Add bill']} /> : null}

        {/* ═══ v10 #26 — कैशबुक व्यय-वाउचर अपने-आप इसी कार्य के नीचे ═══ */}
        <Text style={styles.section}>कैशबुक व्यय-वाउचर ({vouchers.length})</Text>
        <Text style={styles.meta}>
          Cashbook में दर्ज इसी कार्य के व्यय — voucher पर tap करके item-वार विवरण देखें, सुधारें या रद्द करें।
        </Text>
        {vouchers.map((t) => (
          <Pressable key={t.id} style={styles.card} onPress={() => setVoucher(t)}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle}>
                  {fmtDate(t.date)} · {t.party || t.detail || '—'} · {formatINR(sumAmounts(t.amounts))}
                </Text>
                <Text style={styles.meta}>
                  {t.reference ? `वाउचर ${t.reference}` : 'वाउचर —'}
                  {t.ledgerFolio ? ` · L.F. ${t.ledgerFolio}` : ''}
                  {' · '}
                  {t.medium === 'bank' ? 'बैंक' : 'नकद'}
                  {t.categoryId ? ` · ${categoryNames[t.categoryId] || ''}` : ''}
                </Text>
              </View>
              <Feather name="chevron-right" size={18} color={C.mutedForeground} />
            </View>
          </Pressable>
        ))}
        {vouchers.length === 0 ? (
          <Text style={styles.meta}>
            इस कार्य का कोई कैशबुक व्यय-वाउचर नहीं — Cashbook में व्यय दर्ज करते समय खर्च का प्रकार “कार्य” चुनें।
          </Text>
        ) : null}
      </ScrollView>
      {/* instruction #5: dropdown list me na mile to yahin se add */}
      <Modal visible={vAddOpen} transparent animationType="fade" onRequestClose={() => setVAddOpen(false)}>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>नया vendor जोड़ें</Text>
            <Field label="Vendor नाम" value={nvName} onChangeText={setNvName} placeholder="जैसे: शर्मा ट्रेडर्स" bg={C.input} />
            <Field label="फोन (वैकल्पिक)" value={nvPhone} onChangeText={setNvPhone} keyboardType="numeric" bg={C.input} />
            <Text style={styles.fieldLabel}>प्रकार</Text>
            <View style={styles.row}>
              <Btn label="सामग्री" variant={nvKind === 'material' ? 'primary' : 'outline'} onPress={() => setNvKind('material')} />
              <Btn label="ठेकेदार" variant={nvKind === 'labour' ? 'primary' : 'outline'} onPress={() => setNvKind('labour')} />
              <Btn label="अन्य" variant={nvKind === 'other' ? 'primary' : 'outline'} onPress={() => setNvKind('other')} />
            </View>
            <Btn
              label="सहेजें और चुनें"
              onPress={async () => {
                if (!nvName.trim()) return Alert.alert('नाम चाहिए');
                await addVendor({ name: nvName.trim(), phone: nvPhone.trim() || undefined, kind: nvKind });
                setVendor(nvName.trim());
                setNvName('');
                setNvPhone('');
                setVAddOpen(false);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setVAddOpen(false)} />
          </View>
        </View>
      </Modal>

      {/* instruction #24b — बिल पर क्लिक → पूरा विवरण: कब का, किसका, किस दर पर,
          सामग्री item-wise qty × rate (MB से), भुगतान तिथि */}
      <Modal visible={!!billDetail} transparent animationType="fade" onRequestClose={() => setBillDetail(null)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '86%' }]}>
            <Text style={styles.modalTitle}>बिल विवरण</Text>
            <ScrollView style={{ maxHeight: billBodyMax }}>
              {billDetail ? (
                <View>
                  <Text style={styles.cardTitle}>
                    {billDetail.vendor} · {formatINR(billDetail.amount)}
                  </Text>
                  <Text style={styles.meta}>बिल तिथि: {fmtDate(billDetail.billDate)}</Text>
                  <Text style={styles.meta}>
                    भुगतान तिथि: {billDetail.paymentDate ? fmtDate(billDetail.paymentDate) : 'अभी भुगतान नहीं'}
                  </Text>
                  <Text style={styles.meta}>कार्य: {works.find((x) => x.id === billDetail.workId)?.name || '—'}</Text>
                  {/* v12 #15 — बिल cashbook से cross-check है या नहीं */}
                  <Text style={styles.meta}>
                    Cashbook cross-check:{' '}
                    {billDetail.crossCheck === true
                      ? 'हाँ — भुगतान इसी वर्ष में होने पर expense entry कैशबुक में अपने-आप जुड़ती है'
                      : billDetail.crossCheck === false
                        ? 'नहीं — इस बिल का कैशबुक entries पर कोई असर नहीं'
                        : 'चुना नहीं गया — कोई असर नहीं'}
                  </Text>
                  <Text style={styles.meta}>पृष्ठ संदर्भ: {billDetail.pageRef || '—'}</Text>
                  {billDetail.note ? <Text style={styles.meta}>टिप्पणी: {billDetail.note}</Text> : null}

                  <Text style={styles.section}>सामग्री का विवरण (MB से — item-wise दर)</Text>
                  {mbLinesAll
                    .filter((m) => m.workId === billDetail.workId)
                    .map((m) => (
                      <Text key={m.id} style={styles.meta}>
                        {m.itemName} · {m.qty} × {formatINR(m.rate)} = {formatINR(m.qty * m.rate)} ({m.kind})
                      </Text>
                    ))}
                  {mbLinesAll.filter((m) => m.workId === billDetail.workId).length === 0 ? (
                    <Text style={styles.meta}>इस कार्य में MB पंक्तियाँ नहीं हैं — MB tile से जोड़ें।</Text>
                  ) : null}
                  <Text style={styles.hint}>
                    छूट / राउंड-ऑफ वाले मामलों में विवरण note में लिखें — वही यहाँ दिखेगा।
                  </Text>
                </View>
              ) : null}
            </ScrollView>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setBillDetail(null)} />
          </View>
        </View>
      </Modal>

      {/* ═══ v10 #26 — व्यय-वाउचर पर tap → item-वार विवरण + सुधार / रद्द ═══ */}
      <Modal visible={!!voucher} transparent animationType="fade" onRequestClose={() => setVoucher(null)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '92%' }]}>
            <Text style={styles.modalTitle}>व्यय-वाउचर विवरण</Text>
            <ScrollView style={{ maxHeight: billBodyMax }} keyboardShouldPersistTaps="handled">
              {voucher ? (
                <View>
                  <Text style={styles.cardTitle}>
                    {fmtDate(voucher.date)} · {voucher.party || voucher.detail || '—'} · {formatINR(sumAmounts(voucher.amounts))}
                  </Text>
                  <Text style={styles.meta}>योजना: {activeFunds.find((f) => f.id === voucher.schemeId)?.name || voucher.schemeId}</Text>
                  <Text style={styles.meta}>माध्यम: {voucher.medium === 'bank' ? 'बैंक' : 'नकद'}</Text>
                  <Text style={styles.meta}>वाउचर/रसीद: {voucher.reference || '—'} · L.F. {voucher.ledgerFolio || '—'}</Text>
                  <Text style={styles.meta}>
                    श्रेणी:{' '}
                    {[voucher.categoryId, voucher.subcategoryId, voucher.subSubcategoryId]
                      .map((id) => (id ? categoryNames[id] || '' : ''))
                      .filter(Boolean)
                      .join(' › ') || '—'}
                  </Text>
                  {voucher.assetPage ? <Text style={styles.meta}>परिसंपत्ति पृष्ठ: {voucher.assetPage}</Text> : null}
                  {voucher.note ? <Text style={styles.meta}>टिप्पणी: {voucher.note}</Text> : null}

                  <Text style={styles.section}>item-वार विवरण</Text>
                  {!isOther ? (
                    mbLinesAll.filter((m) => m.workId === workId).length ? (
                      mbLinesAll
                        .filter((m) => m.workId === workId)
                        .map((m) => (
                          <Text key={m.id} style={styles.meta}>
                            {m.itemName} · {m.qty} × {formatINR(m.rate)} = {formatINR(m.qty * m.rate)} ({m.kind})
                          </Text>
                        ))
                    ) : (
                      <Text style={styles.meta}>इस कार्य की MB पंक्तियाँ नहीं — MB tile से जोड़ें (सुधार वहीं से होगा)।</Text>
                    )
                  ) : (
                    <Text style={styles.meta}>अन्य व्यय — कोई MB मद नहीं; श्रेणी व विवरण से item सुधारें।</Text>
                  )}
                  <Text style={styles.hint}>
                    सुधार/स्थिति बदलने के लिए “✎ सुधारें” दबाएँ — यही वाउचर Entry फ़ॉर्म में खुलेगा। रद्द करने पर कारण लिखना अनिवार्य है।
                  </Text>
                </View>
              ) : null}
            </ScrollView>
            <View style={styles.row}>
              <Btn
                label="✎ सुधारें"
                icon="edit-3"
                onPress={() => {
                  const id = voucher?.id;
                  setVoucher(null);
                  if (id) onEditTxn?.(id);
                }}
              />
              <Btn
                label="🗑 रद्द करें"
                variant="danger"
                onPress={() => {
                  const v = voucher;
                  setVoucher(null);
                  setVCancel(v);
                }}
              />
            </View>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setVoucher(null)} />
          </View>
        </View>
      </Modal>

      {/* ═══ v13 #11 + #18 — बिल सुधारें: प्रकार, राशि व **अनुपातिक सामग्री वितरण** ═══ */}
      <Modal visible={!!billEdit} transparent animationType="slide" onRequestClose={() => setBillEdit(null)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '94%' }]}>
            <Text style={styles.modalTitle}>बिल सुधारें (correct / allocate)</Text>
            <ScrollView style={{ maxHeight: billBodyMax }} keyboardShouldPersistTaps="handled">
              <Field
                label="Vendor"
                value={billEdit?.vendor || ''}
                onChangeText={(t) => setBillEdit((c) => (c ? { ...c, vendor: t } : c))}
              />
              <Field
                label="राशि (₹)"
                value={String(billEdit?.amount ?? '')}
                keyboardType="numeric"
                onChangeText={(t) => setBillEdit((c) => (c ? { ...c, amount: parseFloat(t) || 0 } : c))}
              />
              <DateField
                label="Bill date"
                value={billEdit?.billDate || ''}
                onChange={(d) => setBillEdit((c) => (c ? { ...c, billDate: d } : c))}
              />
              <DateField
                label="भुगतान दिनांक (cashbook)"
                value={billEdit?.paymentDate || ''}
                onChange={(d) => setBillEdit((c) => (c ? { ...c, paymentDate: d } : c))}
              />
              <Field
                label="Cashbook page ref"
                value={billEdit?.pageRef || ''}
                keyboardType="numeric"
                onChangeText={(t) => setBillEdit((c) => (c ? { ...c, pageRef: t } : c))}
              />
              <Field
                label="Note"
                value={billEdit?.note || ''}
                multiline
                onChangeText={(t) => setBillEdit((c) => (c ? { ...c, note: t } : c))}
              />
              <Text style={styles.fieldLabel}>बिल का प्रकार</Text>
              <View style={styles.chips}>
                {([
                  ['starting', 'आरंभिक'],
                  ['during', 'मध्यकालीन'],
                  ['final', 'अंतिम'],
                ] as const).map(([k, l]) => (
                  <Pressable
                    key={k}
                    style={[styles.chip, billEdit?.billType === k && styles.chipOn, { flexGrow: 1 }]}
                    onPress={() => setBillEdit((c) => (c ? { ...c, billType: k } : c))}
                  >
                    <Text style={{ color: billEdit?.billType === k ? '#fff' : C.foreground, fontWeight: '800', fontSize: 11 }}>{l}</Text>
                  </Pressable>
                ))}
              </View>

              {sanctionedRows().length ? (
                <View style={[styles.card, { backgroundColor: C.input, borderColor: C.primary }]}>
                  <Text style={styles.cardTitle}>सामग्री वितरण (अनुपातिक, स्वीकृति सीमा के भीतर)</Text>
                  <Text style={styles.meta}>
                    बिल राशि {formatINR(billEdit?.amount || 0)} को CC/MB की स्वीकृत सामग्री के मूल्य के अनुपात में बाँटा जाएगा — हर मद का
                    अपना auto मात्रा व दर।{tenderPct > 0 ? ` दर = BSR −${tenderPct}% (निविदा)।` : ' दर = BSR (वर्ष चुनाव)।'}
                    {'\n'}सारे बिलों की कुल मात्रा स्वीकृत मात्रा से कभी अधिक नहीं होगी — सीमा पूरी होते ही मात्रा वहीं रुक जाएगी।
                  </Text>
                  <Btn
                    label="अनुपातिक वितरण करें (auto मात्रा + दर)"
                    icon="layers"
                    variant="soft"
                    onPress={() => {
                      if (!billEdit) return;
                      const alloc = allocateBillItems({
                        amount: billEdit.amount || 0,
                        sanctioned: sanctionedRows(),
                        alreadyUsed: usedOf(billEdit.id),
                        rateOf,
                      });
                      setBillEdit((c) =>
                        c ? { ...c, items: alloc.map(({ itemName, qty, rate }) => ({ itemName, qty, rate })) } : c
                      );
                      const capped = alloc.filter((x) => x.capped);
                      Alert.alert(
                        'वितरण हो गया',
                        capped.length
                          ? `सीमा पूरी होने के कारण ${capped.length} मद पर मात्रा अवशिष्ट पर रोक दी गई:\n${capped
                              .slice(0, 5)
                              .map((x) => x.itemName)
                              .join(', ')}`
                          : 'सारे मदों में अनुपातिक मात्रा व दर भर दी गई — मैन्युअल सुधार की छूट है।'
                      );
                    }}
                  />
                  {(billEdit?.items || []).length === 0 ? (
                    <Text style={styles.meta}>अभी कोई मद बँटा नहीं — ऊपर बटन दबाएँ, या नीचे मद जोड़ें।</Text>
                  ) : (
                    <View style={styles.tblBox}>
                      <View style={styles.tblHead}>
                        <Text style={[styles.tblHeadCell, { flex: 5 }]}>मद</Text>
                        <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>स्वीकृत</Text>
                        <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>पहले बँटा</Text>
                        <Text style={[styles.tblHeadCell, { flex: 4, textAlign: 'right' }]}>इस बिल की मात्रा</Text>
                      </View>
                      {(billEdit?.items || []).map((it, idx) => {
                        const s = matLines.find((m) => m.itemName === it.itemName);
                        const used = usedOf(billEdit?.id)[it.itemName] || 0;
                        const rest = Math.max(0, (s?.qty ?? 0) - used);
                        const bad = it.qty > rest + 1e-9;
                        return (
                          <View key={it.itemName + idx} style={[styles.tblRow, bad ? { backgroundColor: '#fdecec' } : null]}>
                            <Text numberOfLines={2} style={[styles.tblCell, { flex: 5, fontSize: 10 }]}>
                              {it.itemName}
                              <Text style={{ fontSize: 9, color: C.mutedForeground }}> · {formatINR(it.rate)}/यू</Text>
                            </Text>
                            <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontSize: 10 }]}>{s?.qty ?? '—'}</Text>
                            <Text style={[styles.tblCell, { flex: 2, textAlign: 'right', fontSize: 10 }]}>{used}</Text>
                            <View style={{ flex: 4 }}>
                              <Field
                                label=""
                                value={String(it.qty)}
                                keyboardType="numeric"
                                onChangeText={(t) => {
                                  const q = parseFloat(t) || 0;
                                  setBillEdit((c) => {
                                    if (!c) return c;
                                    const its = [...(c.items || [])];
                                    its[idx] = { ...its[idx], qty: q };
                                    return { ...c, items: its };
                                  });
                                }}
                              />
                              <Text style={[styles.meta, { color: bad ? C.expense : C.mutedForeground }]}>
                                {bad ? `⚠ अवशिष्ट सिर्फ़ ${rest}` : `बचा ${Math.max(0, Math.round((rest - it.qty) * 1000) / 1000)}`}
                              </Text>
                            </View>
                          </View>
                        );
                      })}
                    </View>
                  )}
                </View>
              ) : null}
            </ScrollView>
            <Btn
              label="✓ बिल सहेजें"
              icon="check"
              onPress={async () => {
                if (!billEdit) return;
                const b = billEdit;
                if (!b.vendor.trim()) return Alert.alert('Vendor चाहिए');
                if (!(b.amount > 0)) return Alert.alert('राशि > 0 चाहिए');
                /* v13 #11 — रोक: इस बिल की मात्रा + दूसरों की मात्रा ≤ स्वीकृत मात्रा */
                const used = usedOf(b.id);
                const over: string[] = [];
                for (const it of b.items || []) {
                  const s = matLines.find((m) => m.itemName === it.itemName);
                  if (!s) continue;
                  if ((used[it.itemName] || 0) + (it.qty || 0) > s.qty + 1e-9)
                    over.push(`${it.itemName}: ${used[it.itemName] || 0} + ${it.qty} > स्वीकृत ${s.qty}`);
                }
                if (over.length) return Alert.alert('स्वीकृत मात्रा से अधिक', over.join('\n') + '\n\nमात्रा घटाएँ या दूसरा बिल सुधारें।');
                await updateBill(b.id, {
                  vendor: b.vendor.trim(),
                  amount: b.amount,
                  billDate: b.billDate,
                  paymentDate: b.paymentDate || b.billDate,
                  pageRef: b.pageRef,
                  note: b.note,
                  billType: b.billType,
                  items: b.items,
                });
                setBillEdit(null);
                Alert.alert('बिल सुधर गया', `${b.vendor} · ${formatINR(b.amount)}${(b.items || []).length ? ` · ${(b.items || []).length} सामग्री मद` : ''}`);
              }}
            />
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setBillEdit(null)} />
          </View>
        </View>
      </Modal>
      {/* v11 #19/#20 — बिल के लिए चुने हुए वर्ष की BSR items: जोड़ें / सुधारें / हटाएँ */}
      <BsrYearSheet
        open={bsrOpen}
        onClose={() => setBsrOpen(false)}
        year={bsrYear}
        bsrRates={bsrRates}
        itemMasters={itemMasters}
        addBsrRate={addBsrRate}
        updateBsrRate={updateBsrRate}
        deleteBsrRate={deleteBsrRate}
        addItemMaster={addItemMaster}
        updateItemMaster={updateItemMaster}
        deleteItemMaster={deleteItemMaster}
      />
      {vCancel ? (
        <CancelModal
          txn={vCancel}
          onCancel={() => setVCancel(null)}
          onConfirm={async (reason) => {
            const r = await cancelTransaction(vCancel.id, reason);
            if (!r.ok) Alert.alert(r.error || 'रद्द नहीं हो सका');
            setVCancel(null);
          }}
        />
      ) : null}
    </View>
  );
}

function CcScreen({ back, workId, go }: { back: () => void; workId: string; go: (s: Stage, wid?: string) => void }) {
  const { works, mbLines, bills, workerRolls, fyTransactions, activePanchayat, activeFy, activeFunds, addWorkerRoll, updateWork, deleteWorkCascade } = useStore();
  const w0 = works.find((x) => x.id === workId);
  const [fs, setFs] = useState(w0?.fsAmount ? String(w0.fsAmount) : '');
  const [asAmt, setAsAmt] = useState('');
  const [as, setAs] = useState('');
  const [from, setFrom] = useState(toIsoLocal(new Date()));
  const [to, setTo] = useState(toIsoLocal(new Date()));
  const [rollNo, setRollNo] = useState('');
  const [mate, setMate] = useState('0');
  const [skilled, setSkilled] = useState('0');
  const [unskilled, setUnskilled] = useState('0');
  const [days, setDays] = useState('1');
  const [wMate, setWMate] = useState('0');
  const [wSkilled, setWSkilled] = useState('0');
  const [wUnskilled, setWUnskilled] = useState('0');
  /* v12 #22 — आकस्मिक व्यय (contingency): MB सामग्री राशि के 2% से अधिक नहीं */
  const [cont, setCont] = useState(w0?.contingencyAmount ? String(w0.contingencyAmount) : '');
  /* v13 #3 — निविदा दर में कटौती (%) — सिर्फ़ सामग्री के BSR दर पर लागू */
  const [tenderPct, setTenderPct] = useState(w0?.tenderRatePct ? String(w0.tenderRatePct) : '');
  const w = works.find((x) => x.id === workId);
  /* v10 #27 — CC में से ही कार्य सुधारने का विकल्प (hooks early-return से पहले) */
  const [editWork, setEditWork] = useState(false);
  const ccBodyMax = useModalBodyMax(0.9, 270);
  /* instruction #23 + #25 — CC tile → पहले कार्य चुनें (hooks ke baad, rules-of-hooks safe) */
  if (!w) return <WorkPicker title="CC (पूर्णता प्रमाण पत्र)" badge="S-54" back={back} go={go} stage="cc" />;
  const rolls = workerRolls.filter((r) => r.workId === workId);
  const c = ccBuild({ work: w, mbLines, bills, rolls, txs: fyTransactions, fsAmount: parseFloat(fs) || w.fsAmount || 0, asAmount: parseFloat(asAmt) || 0 });
  /* instruction #6 — CC ke 7 pages exactly Excel jaisa, share me PDF ya Excel */
  const hdr: FmtHeader = {
    panchayat: activePanchayat.name,
    block: activePanchayat.block,
    district: activePanchayat.district,
    fy: activeFy.label,
    formName: 'कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ)',
  };
  const fundName = activeFunds.find((f) => f.id === w.schemeId)?.name || w.schemeId;
  /* v10 #27 — वही body preview और share दोनों में (ek hi jagah likha hua) */
  const ccBody = () =>
    ccPagesHtml({
      header: hdr,
      work: w,
      c,
      mbLines,
      rolls,
      bills,
      fundName,
      bsrYear: activeFy.label,
      mbNo: w.mbNo,
      mbPage: w.mbPage,
      asNo: w.asNo,
      asDate: w.asDate,
      tsNo: w.tsNo,
      tsDate: w.tsDate,
      fsNo: w.fsNo,
      fsDate: w.fsDate,
    });
  const share = async () => {
    await askAndShare(`CC — ${w.name}`, ccBody());
  };
  /* v10 #27 — share से ठीक पहले वही print/PDF layout दिखे */
  const preview = async () => {
    try {
      await previewDoc(`CC — ${w.name}`, ccBody());
    } catch (e) {
      Alert.alert('Preview fail', String((e as Error).message || e));
    }
  };
  const num = (s: string) => parseFloat(s) || 0;
  return (
    <View style={styles.page}>
      <Header title="CC (7 pages)" onBack={back} badge="S-26" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{w.name}</Text>
        <Text style={styles.hint}>{CC_INSTRUCTIONS}</Text>
        <View style={styles.row}>
          <Field label="FS राशि (वित्तीय स्वीकृति)" value={fs} onChangeText={setFs} keyboardType="numeric" grow />
        </View>
        <View style={styles.row}>
          <Field label="AS/TS राशि (min limit)" value={asAmt} onChangeText={setAsAmt} keyboardType="numeric" grow />
        </View>
        {/* v10 #27 — CC का पूरा डेटा print/Excel जैसी table layout में (share वाला layout यही है) */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 1 — कार्य पूर्णता प्रमाण पत्र (Excel layout)</Text>
          <View style={styles.tblBox}>
            <View style={styles.tblHead}>
              <Text style={[styles.tblHeadCell, { flex: 5 }]}>विवरण</Text>
              <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>राशि (₹)</Text>
            </View>
            {[
              ['वास्तविक व्यय (लेखे अनुसार)', c.actualExpense],
              ['मूल्यांकन राशि (MB)', c.mulyaankan],
              ['श्रम', c.labour],
              ['सामग्री', c.material],
              ['FS राशि (वित्तीय स्वीकृति)', num(fs) || w.fsAmount || 0],
              ['AS/TS राशि (min limit)', num(asAmt)],
              ['कुल अनुमत राशि = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)', c.allowable],
              ['भुगतान योग्य शेष (अनुमत − भुगतान)', c.residualMaterial],
            ].map((row, i) => {
              const isTot = i >= 6;
              return (
                <View key={i} style={[styles.tblRow, isTot ? styles.tblTot : i % 2 ? { backgroundColor: '#f7faf8' } : null]}>
                  <Text style={[styles.tblCell, { flex: 5, fontWeight: isTot ? '900' : '500' }]}>{row[0] as string}</Text>
                  <Text
                    style={[
                      styles.tblCell,
                      { flex: 2, textAlign: 'right', fontWeight: '900', color: isTot ? C.primary : C.foreground },
                    ]}
                  >
                    {formatINR(row[1] as number)}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 3 — श्रमिक विवरण (पाक्षिक मस्टरोल)</Text>
          <Text style={styles.meta}>मानव दिवस = श्रमिक संख्या × दिन; व्यय = मानव दिवस × मजदूरी दर (निर्देशिका 2010 अनुसार)</Text>
          <Text style={styles.meta}>
            “मन-डे स्वीकृति” में से MR-1, MR-2 … अपने-आप यहाँ जुड़ जाते हैं (नीचे वाला फ़ॉर्म सिर्फ़ अतिरिक्त roll के लिए)।
          </Text>
          {/* v10 #27 — पृष्ठ 3 भी Excel table layout में */}
          <View style={styles.tblBox}>
            <View style={styles.tblHead}>
              <Text style={[styles.tblHeadCell, { flex: 3 }]}>अवधि</Text>
              <Text style={[styles.tblHeadCell, { flex: 2 }]}>roll</Text>
              {/* v9 #12 — 'मेट' हटाया: कुशल = कारीगर, अकुशल = श्रमिक */}
              <Text style={[styles.tblHeadCell, { flex: 3, textAlign: 'right' }]}>कारीगर</Text>
              <Text style={[styles.tblHeadCell, { flex: 3, textAlign: 'right' }]}>श्रमिक</Text>
              <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>दिन</Text>
              <Text style={[styles.tblHeadCell, { flex: 3, textAlign: 'right' }]}>राशि (₹)</Text>
            </View>
            {rolls.map((r, i) => (
              <View key={r.id} style={[styles.tblRow, i % 2 ? { backgroundColor: '#f7faf8' } : null]}>
                <Text numberOfLines={1} style={[styles.tblCell, { flex: 3, fontSize: 10 }]}>
                  {r.fromDate}→{r.toDate}
                </Text>
                <Text numberOfLines={1} style={[styles.tblCell, { flex: 2, fontSize: 10 }]}>
                  {r.rollNo || '—'}
                </Text>
                {/* v9 #12 — मेट नहीं: कुशल = कारीगर, अकुशल = श्रमिक */}
                <Text style={[styles.tblCell, { flex: 3, textAlign: 'right' }]}>{r.skilledCount}</Text>
                <Text style={[styles.tblCell, { flex: 3, textAlign: 'right' }]}>{r.unskilledCount}</Text>
                <Text style={[styles.tblCell, { flex: 2, textAlign: 'right' }]}>{r.days}</Text>
                <Text style={[styles.tblCell, { flex: 3, textAlign: 'right', fontWeight: '800' }]}>
                  {formatINR(r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled)}
                </Text>
              </View>
            ))}
            {rolls.length === 0 ? <Text style={styles.meta}>कोई roll नहीं</Text> : null}
          </View>
          <Text style={styles.sumLine}>कुल श्रम व्यय (rolls): {formatINR(c.mandays.wage)}</Text>
          <Text style={styles.meta}>MB श्रम मद: {formatINR(c.labour)}</Text>
          <Field label="मस्टरोल क्रमांक" value={rollNo} onChangeText={setRollNo} />
          <View style={styles.row}>
            <DateField label="दिनांक से" value={from} onChange={setFrom} grow />
            <DateField label="दिनांक तक" value={to} onChange={setTo} grow />
          </View>
          <View style={styles.row}>
            <Field label="मेट संख्या" value={mate} onChangeText={setMate} keyboardType="numeric" grow />
            <Field label="कुशल" value={skilled} onChangeText={setSkilled} keyboardType="numeric" grow />
            <Field label="अकुशल" value={unskilled} onChangeText={setUnskilled} keyboardType="numeric" grow />
          </View>
          <View style={styles.row}>
            <Field label="दिन" value={days} onChangeText={setDays} keyboardType="numeric" grow />
            <Field label="मेट दर" value={wMate} onChangeText={setWMate} keyboardType="numeric" grow />
          </View>
          <View style={styles.row}>
            <Field label="कुशल दर" value={wSkilled} onChangeText={setWSkilled} keyboardType="numeric" grow />
            <Field label="अकुशल दर" value={wUnskilled} onChangeText={setWUnskilled} keyboardType="numeric" grow />
          </View>
          <Btn
            label="पाक्षिक roll जोड़ें"
            onPress={() =>
              addWorkerRoll({
                workId,
                fyId: activeFy.id,
                fromDate: from,
                toDate: to,
                rollNo,
                mateCount: num(mate),
                skilledCount: num(skilled),
                unskilledCount: num(unskilled),
                days: num(days) || 1,
                wageMate: num(wMate),
                wageSkilled: num(wSkilled),
                wageUnskilled: num(wUnskilled),
              })
            }
          />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 4 — सामग्री विवरण (MB अनुसार, Excel layout)</Text>
          {/* v13 #3 — यहीं से निविदा दर में कटौती (%) भरी/सुधारी जाती है */}
          <Field
            label="निविदा दर में कटौती (%) — सिर्फ़ सामग्री के BSR दर पर"
            value={tenderPct}
            onChangeText={setTenderPct}
            keyboardType="numeric"
            placeholder="जैसे 2"
          />
          <Text style={styles.meta}>
            नियम: निविदा दर = BSR दर × (1 − कटौती/100)। उदाहरण: सीमेंट BSR ₹100 और कटौती 2% → ₹98।{'\n'}
            <Text style={{ fontWeight: '800', color: C.foreground }}>
              श्रमिक व कारीगर (labour/karigar) की दर पर इसका कोई असर नहीं — वे सीधे BSR दर से लगते हैं।
            </Text>
          </Text>
          <Btn
            label="✓ निविदा कटौती सहेजें"
            icon="check"
            variant="soft"
            onPress={async () => {
              const p = Math.max(0, Math.min(100, Number(tenderPct.trim()) || 0));
              await updateWork(workId, { tenderRatePct: p || undefined });
              Alert.alert(
                'निविदा कटौती सहेजी गई',
                p > 0
                  ? `सामग्री के BSR दरों पर −${p}% लागू (जैसे ₹100 → ₹${Math.round(100 * (1 - p / 100))})। श्रम/कारीगर दर अप्रभावित।`
                  : 'कटौती हटाई गई — सामग्री सीधे BSR दर से।'
              );
            }}
          />
          <View style={styles.tblBox}>
            <View style={styles.tblHead}>
              <Text style={[styles.tblHeadCell, { flex: 5 }]}>मद</Text>
              <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>मात्रा</Text>
              <Text style={[styles.tblHeadCell, { flex: 2, textAlign: 'right' }]}>निविदा दर</Text>
              <Text style={[styles.tblHeadCell, { flex: 3, textAlign: 'right' }]}>राशि (₹)</Text>
            </View>
            {mbLines
              .filter((m) => m.workId === workId && m.kind === 'material')
              .map((m, i) => {
                const tRate = c.tenderRateOf(m.rate, m.kind);
                return (
                  <View key={m.id} style={[styles.tblRow, i % 2 ? { backgroundColor: '#f7faf8' } : null]}>
                    <Text numberOfLines={2} style={[styles.tblCell, { flex: 5, fontSize: 10 }]}>{m.itemName}</Text>
                    <Text style={[styles.tblCell, { flex: 2, textAlign: 'right' }]}>{m.qty}</Text>
                    <Text style={[styles.tblCell, { flex: 2, textAlign: 'right' }]}>
                      {formatINR(tRate)}
                      {c.tenderPct > 0 && tRate !== m.rate ? (
                        <Text style={{ fontSize: 8, color: C.mutedForeground }}> (BSR {formatINR(m.rate)})</Text>
                      ) : null}
                    </Text>
                    <Text style={[styles.tblCell, { flex: 3, textAlign: 'right', fontWeight: '700' }]}>
                      {formatINR(Math.round(m.qty * tRate * 100) / 100)}
                    </Text>
                  </View>
                );
              })}
            <View style={styles.tblTot}>
              <Text style={[styles.tblCell, { flex: 9, fontWeight: '900' }]}>सामग्री योग</Text>
              <Text style={[styles.tblCell, { flex: 3, textAlign: 'right', fontWeight: '900', color: C.primary }]}>
                {formatINR(c.material)}
              </Text>
            </View>
          </View>
          {c.tenderPct > 0 ? (
            <Text style={styles.meta}>
              BSR दर योग {formatINR(c.materialBsr)} · निविदा कटौती {c.tenderPct}% · निविदा दर योग {formatINR(c.material)} · बचत{' '}
              {formatINR(Math.round((c.materialBsr - c.material) * 100) / 100)}
            </Text>
          ) : null}
          {/* ═══ v12 #17 — स्वीकृत सामग्री राशि + सीमा से बाहर होने पर लाल चेतावनी ═══ */}
          <Text style={styles.sumLine}>
            स्वीकृत सामग्री राशि (F.S.):{' '}
            {c.sanctionedMaterial > 0 ? formatINR(c.sanctionedMaterial) : '— (स्वीकृति में हिस्सा नहीं बाँटा गया)'}
          </Text>
          <Text style={styles.meta}>
            MB में सामग्री {formatINR(c.material)} · अंतर{' '}
            {formatINR(Math.round((c.material - c.sanctionedMaterial) * 100) / 100)} (सकारात्मक = सीमा से बाहर)
          </Text>
          {c.materialOver > 0 ? (
            <Text style={[styles.err, { fontWeight: '900' }]}>
              ⚠ चेतावनी: MB की सामग्री राशि स्वीकृत सामग्री राशि से {formatINR(c.materialOver)} अधिक है — स्वीकृति में संशोधन
              करें या माप पुस्तिका सुधारें।
            </Text>
          ) : null}
        </View>
        {/* ═══ v12 #22 — आकस्मिक व्यय ≤ MB सामग्री राशि का 2% ═══ */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>आकस्मिक व्यय (Contingency)</Text>
          <Field
            label="आकस्मिक व्यय राशि (₹)"
            value={cont}
            onChangeText={setCont}
            keyboardType="numeric"
          />
          <Text style={styles.meta}>
            नियम: MB की सामग्री राशि के 2% से अधिक नहीं होनी चाहिए।
          </Text>
          <Text style={styles.sumLine}>
            अनुमति: {formatINR(c.contingencyCap)} (सामग्री मद {formatINR(c.material)} के 2%) · दर्ज:{' '}
            {formatINR(c.contingency)}
          </Text>
          {c.contingencyOver > 0 ? (
            <Text style={[styles.err, { fontWeight: '900' }]}>
              ⚠ चेतावनी: आकस्मिक व्यय अनुमति से {formatINR(c.contingencyOver)} अधिक है — 2% से अधिक आकस्मिक व्यय स्वीकृत
              नहीं होगा।
            </Text>
          ) : null}
          <Btn
            label="✓ आकस्मिक व्यय सहेजें"
            icon="check"
            variant="soft"
            onPress={async () => {
              const n = Math.max(0, Number(cont.trim()) || 0);
              await updateWork(workId, { contingencyAmount: n || undefined });
              Alert.alert(
                c.contingencyOver > 0 ? 'सहेजा गया — चेतावनी जारी' : 'आकस्मिक व्यय सहेजा गया',
                `दर्ज ${formatINR(n)} · अनुमत सीमा ${formatINR(c.contingencyCap)} (सामग्री मद के 2%)।`
              );
            }}
          />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 2 · 5 · 6 · 7</Text>
          <Text style={styles.meta}>2 — उपयोगिता प्रमाण पत्र: व्यय {formatINR(c.actualExpense)} / अनुमत {formatINR(c.allowable)}</Text>
          <Text style={styles.meta}>5 — तकनीकी निरीक्षण: ग्रामीण कार्य निर्देशिका 2010 प्रावधानों अनुसार मूल्यांकन सत्यापित</Text>
          <Text style={styles.meta}>6 — पूर्ण कार्य फोटो + हस्ताक्षर (सरपंच, VDO, कनिष्ठ अभियंता)</Text>
          <Text style={styles.meta}>7 — पहले व कार्य के दौरान फोटो</Text>
        </View>
        <Btn label="CC PDF / Excel (7 pages) — share" icon="share-2" onPress={share} />
        {/* v10 #27 — यहाँ से ही कार्य सुधारें (edit/correct) */}
        <Btn label="✎ कार्य सुधारें (AS/TS/FS, तिथि, अवधि)" icon="edit-3" variant="soft" onPress={() => setEditWork(true)} />
        {/* ═══ v13 #19/#20 — CC पेज से ही MB पंक्तियाँ व बिल सुधारें/हटाएँ (अलग-अलग tile नहीं ढूँढ़ने) ═══ */}
        <View style={styles.row}>
          <Btn
            label="MB पंक्तियाँ सुधारें"
            icon="clipboard"
            variant="outline"
            onPress={() => go('mb', workId)}
          />
          <Btn
            label="बिल सुधारें / हटाएँ"
            icon="file-text"
            variant="outline"
            onPress={() => go('bills', workId)}
          />
        </View>
        <Btn
          label="🗑 यह कार्य हटाएँ (CC/MB/बिल सहित)"
          icon="trash-2"
          variant="danger"
          onPress={() =>
            Alert.alert(
              'कार्य हटाएँ?',
              `${w.name} — इसकी MB, बिल, CC और जुड़ी कैशबुक entries भी हटेंगी (cascade)। यह सुधार नहीं, स्थायी मिटाव है।`,
              [
                { text: 'रहने दें', style: 'cancel' },
                {
                  text: 'हटाएँ',
                  style: 'destructive',
                  onPress: async () => {
                    const r = await deleteWorkCascade(workId);
                    if (!r.ok) return Alert.alert('हटाया नहीं जा सका', 'कृपया दोबारा कोशिश करें।');
                    Alert.alert('कार्य हटा दिया गया', `${w.name}\nMB ${r.mb} · बिल ${r.bills} · मान-दिवस ${r.mr} · entries ${r.txns} हटाई गईं।`);
                    go('works', '');
                  },
                },
              ]
            )
          }
        />
        <Btn label="पूर्व-दृश्य (print/PDF layout)" variant="outline" onPress={preview} />
        <Text style={styles.meta}>
          ऊपर की tables वही layout हैं जो PDF/Excel में जाती हैं — ग़लती दिखे तो “कार्य सुधारें” से ठीक करें, फिर share करें।
          {'\n'}
          v12 #13 — यह सुधार कार्य के **पूर्ण (completed)** होने या **MB पूर्ण** होने के बाद भी चालू रहता है: AS/TS/FS क्रमांक-तिथि,
          कार्य अवधि, MB विवरण (संख्या/पृष्ठ/मूल्यांकन/श्रम/सामग्री) और स्वीकृति के दोनों हिस्से किसी भी समय बदले जा सकते हैं।
        </Text>
      </ScrollView>

      {/* v10 #27 — CC से ही कार्य का edit/correct */}
      <Modal visible={editWork} transparent animationType="slide" onRequestClose={() => setEditWork(false)}>
        <View style={styles.modalBg}>
          <View style={[styles.modalCard, { maxHeight: '96%' }]}>
            <Text style={styles.modalTitle}>CC — कार्य सुधारें</Text>
            <Text style={styles.meta}>{w.name}</Text>
            <ScrollView style={{ maxHeight: ccBodyMax }} keyboardShouldPersistTaps="handled">
              <WorkAddForm edit={w} onDone={() => setEditWork(false)} />
            </ScrollView>
            <Btn label="वापस जाएँ (Back)" variant="outline" onPress={() => setEditWork(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}

/**
 * v13 #14a — **S-06 की "व्यवस्था (Settings)" अब एक अपना पन्ना (Stage)**, Modal नहीं।
 *   • S-06 पर tile दबाने से यही पेज खुलता है (stack में `settings` जुड़ता है)
 *   • किसी item (Masters / Formats / FY समापन / Backup / Reports / Categories / Fund heads)
 *     को चुनकर Back दबाने पर **वापस इसी व्यवस्था-पेज पर** आते हैं — S-06 home पर नहीं।
 */
function SettingsScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { app, updateApp, activePanchayat, activeFy, totalOpening, activeFunds, fyTransactions } = useStore();
  const lang = useLang();
  return (
    <View style={styles.page}>
      <Header title={t(lang, 'home.settings', 'व्यवस्था (Settings)')} onBack={back} badge="S-57" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          {activePanchayat.name} · FY {activeFy.label} · कुल प्रारंभिक शेष {formatINR(totalOpening)} ·{' '}
          {activeFunds.length} निधि · {fyTransactions.length} entries
        </Text>

        {/* ═══ v13 #14a — भाषा चुनाव (पन्ने के सबसे ऊपर) ═══ */}
        <Text style={styles.section}>{t(lang, 'lang.label', 'ऐप की भाषा (App language)')}</Text>
        <View style={styles.chips}>
          {LANGS.map((l) => {
            const on = (app.lang || 'hinglish') === l.key;
            return (
              <Pressable key={l.key} style={[styles.chip, on && styles.chipOn]} onPress={() => updateApp({ lang: l.key })}>
                <Text style={{ color: on ? '#fff' : C.foreground, fontSize: 12, fontWeight: '700' }}>{l.label}</Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={styles.meta}>
          {t(
            lang,
            'lang.hint',
            'सिर्फ़ मेन्यू, tile और बटन बदलते हैं — आधिकारिक प्रपत्र (रोकड़ बही, गोशवारा, प्रपत्र-1/2/4, CC) हिन्दी में ही रहते हैं।'
          )}
        </Text>

        <Text style={styles.section}>{t(lang, 'home.settings', 'व्यवस्था (Settings)')}</Text>
        {[
          ['masters', 'sliders', 'Masters (BSR/Items/मान-दिवस)', 'दर सूची + flags + हिसाब'],
          ['formats', 'file-text', 'प्रपत्र / Formats Centre', 'f-01… — प्रिंट लेआउट + मैन्युअल संपादन'],
          ['closing', 'lock', 'FY समापन wizard', 'जाँच → गोशवारा → backup → lock'],
          ['backup', 'hard-drive', 'Backup / Export', 'JSON + CSV + डेली बैकअप'],
          ['reports', 'bar-chart-2', 'Reports hub', 'CSV share'],
          ['categories', 'git-branch', 'Categories 3-level', 'Income & expense trees'],
          ['funds', 'layers', 'Fund heads', 'Opening + delete'],
        ].map(([id, icon, title, sub]) => (
          <Pressable key={id} style={[styles.homeRow, { marginBottom: 6 }]} onPress={() => go(id as Stage)}>
            <View style={styles.homeIcon}>
              <Feather name={icon as any} size={18} color={C.primary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{t(lang, `set.${id}`, title)}</Text>
              <Text style={styles.meta}>{sub}</Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
        <Text style={styles.meta}>
          v13 #14a — किसी भी item को चुनकर Back दबाने पर वापस इसी पेज पर आएँगे (S-06 home पर नहीं)।
        </Text>
        <Btn label="◀ वापस (S-06 home)" icon="chevron-left" variant="outline" onPress={back} />
      </ScrollView>
    </View>
  );
}

function FormatsScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, categories, activeFunds, totalOpening, activePanchayat, activeFy, works, mbLines, bills, bankLines, workerRolls, vendors, bankAccounts, bsrRates, mandayCalcs } = useStore();
  /* v10 #15 — Format Centre: dropdown से कोई भी format चुनें, फिर share से पहले preview */
  const [fmtKey, setFmtKey] = useState('goswara');
  /* v13 #14b — हर format का **अपना अलग पृष्ठ** (list → चुनो → उसी का प्रिंट लेआउट + मैन्युअल संपादन) */
  const [fmtSel, setFmtSel] = useState<string | null>(null);
  /* v13 #14b — मैन्युअल रूप से सुधारा हुआ HTML (key = format) */
  const [fmtHtml, setFmtHtml] = useState<Record<string, string>>({});
  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;
  const fundNames: Record<string, string> = {};
  for (const f of activeFunds) fundNames[f.id] = f.name;
  const hdr = {
    panchayat: activePanchayat.name,
    block: activePanchayat.block,
    district: activePanchayat.district,
    fy: activeFy.label,
  };
  /* instruction #12 — har प्रपत्र: share me PDF ya Excel (Excel-type format, original dikhta hua) */
  const mkHdr = (formName: string): FmtHeader => ({ ...hdr, formName });
  const g = buildGoswara(
    fyTransactions,
    catNames,
    totalOpening,
    Object.fromEntries(works.map((w) => [w.id, w.name])),
    Object.fromEntries(activeFunds.map((f) => [f.id, f.name]))
  );
  const p1 = buildPrapt1(works.filter((w) => w.fyId === activeFy.id), mbLines, fyTransactions, fundNames, (w) => w.materialPrior + w.labourPrior);
  const p4 = buildPrapt4(mbLines);
  /* प्रपत्र-2 (श्रम) — pakhwada rolls से: प्रति role एक row (श्रमिक × दिन × दर) */
  const nameOfWork = (id: string) => works.find((w) => w.id === id)?.name || id;
  const p2: { workName: string; workers: number; days: number; rate: number; amount: number; role?: string }[] = [];
  for (const r of workerRolls.filter((x) => x.fyId === activeFy.id)) {
    const groups: [number, number, string][] = [
      [r.mateCount, r.wageMate, 'मेट'],
      [r.skilledCount, r.wageSkilled, 'कारीगर (कुशल)'],
      [r.unskilledCount, r.wageUnskilled, 'श्रमिक (अकुशल)'],
    ];
    for (const [count, wage, role] of groups) {
      if (count > 0 && wage > 0) {
        p2.push({ workName: nameOfWork(r.workId), workers: count, days: r.days, rate: wage, amount: Math.round(count * r.days * wage * 100) / 100, role });
      }
    }
  }
  const fyBankLines = bankLines.filter((l) => l.fyId === activeFy.id);
  /* बैंक विवरण (#13) — दिनांक/विवरण/संदर्भ/जमा/नाम/शेष + tagging */
  const bankBody = () => {
    let bal = 0;
    const rows = [...fyBankLines]
      .filter((l) => !l.ignored)
      .sort((a, b) => a.date.localeCompare(b.date))
      .map((l) => {
        bal += l.side === 'credit' ? l.amount : -l.amount;
        const w = works.find((x) => x.id === l.workId);
        const v = vendors.find((x) => x.id === l.vendorId);
        const h = categories.find((x) => x.id === l.categoryId);
        const s = activeFunds.find((x) => x.id === l.schemeId);
        return {
          date: l.date,
          narration: l.narration,
          instrument: l.instrument,
          deposit: l.side === 'credit' ? l.amount : 0,
          withdrawal: l.side === 'debit' ? l.amount : 0,
          balance: Math.round(bal * 100) / 100,
          scheme: s?.name,
          work: w?.name,
          vendor: v?.name,
          head: h?.name,
          note: l.note,
          posted: !!l.postedTxnId,
        };
      });
    const acc = bankAccounts[0];
    return bankStatementHtml({
      header: mkHdr('बैंक विवरण (Bank statement)'),
      accountName: acc?.name || '—',
      accountNo: acc?.accountNo || '—',
      bankName: acc?.bankName || '—',
      rows,
    });
  };
  const goswaraBody = () => {
    const fyBank = bankLines.filter((l) => l.fyId === activeFy.id && !l.ignored);
    const antimBank = fyBank.reduce((s, l) => s + (l.side === 'credit' ? l.amount : -l.amount), 0);
    return goswaraHtml({
      header: mkHdr('वार्षिक आय-व्यय सामान्य रोकड़ बही'),
      rows: g.rows,
      aayYog: g.aayYog,
      vyayYog: g.vyayYog,
      prarambhikNagad: g.prarambhikNagad,
      prarambhikBank: 0,
      antimNagad: Math.round((g.antSheshNagad - antimBank) * 100) / 100,
      antimBank: Math.round(antimBank * 100) / 100,
    });
  };
  const ledgerBody = () =>
    ledgerHtml({ header: mkHdr('खाता बही — सभी योजनाएँ'), rows: buildLedger(totalOpening, fyTransactions) });

  /* ═══ instruction #20 — audit engine ═══
     "audit formet demo.xlsx" की 6 sheets ठीक वैसे ही एक workbook में:
     full ghoswara · ghoswara · prapatra 1 · samgri audit · labour audit · patta audit */
  const table = (head: string[], rows: string[][]) =>
    `<table><tr>${head.map((h) => `<th>${h}</th>`).join('')}</tr>${rows
      .map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`)
      .join('')}</table>`;

  const txActive = fyTransactions.filter((t) => t.status === 'active');

  const fullGoswaraHtml = () => {
    let bal = totalOpening;
    const rows: string[][] = txActive.map((t, i) => {
      bal += t.type === 'income' ? sumAmounts(t.amounts) : -sumAmounts(t.amounts);
      return [
        String(i + 1),
        fmtDate(t.date),
        catNames[t.categoryId || ''] || '—',
        fundNames[t.schemeId] || '—',
        t.party || t.detail || '—',
        t.type === 'income' ? formatINR(sumAmounts(t.amounts)) : '',
        t.type === 'expense' ? formatINR(sumAmounts(t.amounts)) : '',
        formatINR(Math.round(bal * 100) / 100),
        t.ledgerFolio || '—',
        t.reference || '—',
      ];
    });
    rows.push(['', '', '', '', 'आय योग', formatINR(g.aayYog), '', '']);
    rows.push(['', '', '', '', 'व्यय योग', '', formatINR(g.vyayYog), '']);
    rows.push(['', '', '', '', 'अंतिम शेष', '', '', formatINR(g.antSheshNagad)]);
    return (
      `<div class="head"><h1>पूर्ण गोशवारा (Full गोशवारा) — ${activePanchayat.name}</h1>` +
      `<div class="sm">वित्तीय वर्ष ${activeFy.label} · ${activePanchayat.district}</div></div>` +
      table(
        ['क्र.स.', 'दिनांक', 'श्रेणी', 'योजना', 'विवरण', 'आय', 'व्यय', 'शेष', 'L.F.', 'संदर्भ'],
        rows
      )
    );
  };

  /* सामग्री audit — MB की item-wise मात्रा × दर + BSR से मिलान */
  const samgriAuditHtml = () => {
    const rows: string[][] = mbLines
      .filter((m) => works.find((w) => w.id === m.workId)?.fyId === activeFy.id)
      .map((m) => {
        const b = findBsr(bsrRates, activeFy.label, m.itemName);
        const calc = Math.round(m.qty * m.rate * 100) / 100;
        return [
          nameOfWork(m.workId),
          m.itemName,
          m.kind === 'material' ? 'सामग्री' : m.kind === 'artisan' ? 'कारीगर' : 'श्रम',
          String(m.qty),
          formatINR(m.rate),
          formatINR(calc),
          b ? formatINR(b.rate) : '—',
          b ? (Math.abs(b.rate - m.rate) < 0.01 ? '✓ मिला' : 'जाँचें') : 'BSR नहीं',
        ];
      });
    rows.push(['', '', '', '', 'योग', formatINR(p4.reduce((s, r) => s + r.cost, 0)), '', '']);
    return (
      `<div class="head"><h1>सामग्री ऑडिट (Material audit)</h1>` +
      `<div class="sm">MB item-wise मात्रा × दर बनाम BSR दर · ${activeFy.label}</div></div>` +
      table(['कार्य', 'मद', 'पक्ष', 'मात्रा', 'दर', 'राशि', 'BSR दर', 'मिलान'], rows)
    );
  };

  /* श्रम audit — पाक्षिक rolls + मन-डे स्वीकृतियाँ */
  const labourAuditHtml = () => {
    const rows: string[][] = [];
    for (const r of workerRolls.filter((x) => x.fyId === activeFy.id)) {
      /* v9 #10 — मन-डे स्वीकृति से बने MR में कुशल = कारीगर, अकुशल = श्रमिक */
      const auto = !!r.sourceId;
      const groups: [number, number, string][] = auto
        ? [
            [0, r.wageMate, 'मेट'],
            [r.skilledCount, r.wageSkilled, 'कारीगर'],
            [r.unskilledCount, r.wageUnskilled, 'श्रमिक'],
          ]
        : [
            [r.mateCount, r.wageMate, 'मेट'],
            [r.skilledCount, r.wageSkilled, 'कारीगर (कुशल)'],
            [r.unskilledCount, r.wageUnskilled, 'श्रमिक (अकुशल)'],
          ];
      for (const [count, wage, role] of groups) {
        if (count > 0 && wage > 0) {
          rows.push([nameOfWork(r.workId), r.rollNo || '—', role, String(count), String(r.days), formatINR(wage), formatINR(count * r.days * wage)]);
        }
      }
    }
    for (const c of mandayCalcs.filter((x) => works.find((w) => w.id === x.workId)?.fyId === activeFy.id)) {
      /* v9 #10 — जिन स्वीकृतियों के MR ऊपर जुड़ चुके हैं, उन्हें दोबारा मत जोड़ो (doble count rukega) */
      if (c.muster?.lab || c.muster?.kar) continue;
      rows.push([
        nameOfWork(c.workId),
        'स्वीकृति',
        c.role === 'karigar' ? 'कारीगर' : c.role === 'mate' ? 'मेट' : 'श्रमिक',
        String(c.workers),
        String(c.days),
        formatINR(c.rate),
        formatINR(c.amount),
      ]);
    }
    const total = rows.reduce((s, r) => s + (parseFloat(r[6]?.replace(/[₹,]/g, '')) || 0), 0);
    rows.push(['', '', 'योग', '', '', '', formatINR(total)]);
    return (
      `<div class="head"><h1>श्रम ऑडिट (Labour audit)</h1>` +
      `<div class="sm">पाक्षिक मान-दिवस + मन-डे स्वीकृतियाँ · ${activeFy.label}</div></div>` +
      table(['कार्य', 'रोल / संदर्भ', 'श्रेणी', 'श्रमिक', 'दिन', 'दर', 'राशि'], rows)
    );
  };

  /* पट्टा audit — आय में 'पट्टा' वाली entries */
  const pattaAuditHtml = () => {
    const rows = txActive
      .filter((t) => t.type === 'income')
      .filter((t) =>
        `${catNames[t.categoryId || '']} ${t.party} ${t.detail} ${t.note}`.toLowerCase().includes('पट्टा') ||
        `${catNames[t.categoryId || '']} ${t.party} ${t.detail}`.toLowerCase().includes('patta')
      )
      .map((t) => ({ date: fmtDate(t.date), from: t.party || t.detail || '—', amount: sumAmounts(t.amounts), ref: t.reference || '—' }));
    return pattaHtml({ header: mkHdr('आबादी भूमि मे पट्टे जारी करना का विवरण'), rows });
  };

  const auditSheets = (): { name: string; html: string }[] => [
    { name: 'full ghoswara', html: fullGoswaraHtml() },
    { name: 'ghoswara', html: goswaraBody() },
    { name: 'prapatra 1', html: prapt1Html(p1, mkHdr('SFC/TFC/FFC/BRGF योजनाओं में कार्यों का विवरण')) },
    { name: 'samgri audit', html: samgriAuditHtml() },
    { name: 'labour audit', html: labourAuditHtml() },
    { name: 'patta audit', html: pattaAuditHtml() },
  ];

  /* ═══ v11 #13 — Format Centre में भी CC (कार्य पूर्णता प्रमाण पत्र):
     photo page पर ही फोटो space, उसके ठीक नीचे सरपंच/सचिव/जीवीए/JTA के हस्ताक्षर ═══ */
  const ccWork: Work | null =
    works.filter((x) => x.fyId === activeFy.id && x.status === 'completed')[0] ||
    works.filter((x) => x.fyId === activeFy.id)[0] ||
    null;
  const ccRolls = workerRolls.filter((r) => ccWork && r.workId === ccWork.id);
  const ccBills = bills.filter((b) => ccWork && b.workId === ccWork.id);
  const ccBody = (): string => {
    if (!ccWork) return `<p>कोई कार्य दर्ज नहीं — Works में कार्य जोड़ें।</p>`;
    const cc = ccBuild({
      work: ccWork,
      mbLines,
      bills: ccBills,
      rolls: ccRolls,
      txs: fyTransactions,
      fsAmount: ccWork.fsAmount || 0,
      asAmount: 0,
    });
    return ccPagesHtml({
      header: mkHdr('कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ)'),
      work: ccWork,
      c: cc,
      mbLines,
      rolls: ccRolls,
      bills: ccBills,
      fundName: activeFunds.find((f) => f.id === ccWork.schemeId)?.name || ccWork.schemeId,
      bsrYear: activeFy.label,
      mbNo: ccWork.mbNo,
      mbPage: ccWork.mbPage,
      asNo: ccWork.asNo,
      asDate: ccWork.asDate,
      tsNo: ccWork.tsNo,
      tsDate: ccWork.tsDate,
      fsNo: ccWork.fsNo,
      fsDate: ccWork.fsDate,
    });
  };

  /* ═══ v10 #15 — सारे formats की dropdown + share से ठीक पहले layout preview ═══ */
  const fmtList: { key: string; label: string; sub: string; landscape: boolean; body: () => string }[] = [
    ...(ccWork
      ? [
          {
            key: 'cc',
            label: `CC — कार्य पूर्णता प्रमाण पत्र`,
            sub: `${ccWork.name} · 7 पृष्ठ · photo page पर फोटो space + नीचे हस्ताक्षर`,
            landscape: false,
            body: ccBody,
          },
        ]
      : []),
    {
      key: 'goswara',
      label: 'गोशवारा — वार्षिक आय-व्यय सामान्य रोकड़ बही',
      sub: `${g.rows.length} मद · आय योग ${formatINR(g.aayYog)}`,
      landscape: true,
      body: goswaraBody,
    },
    { key: 'ledger', label: 'खाता बही (Ledger)', sub: 'श्री पोते → जमा/नाम → शेष', landscape: true, body: ledgerBody },
    {
      key: 'p1',
      label: 'प्रपत्र-1 — SFC/TFC/FFC/BRGF कार्य विवरण',
      sub: `कार्य ${p1.length}`,
      landscape: false,
      body: () => prapt1Html(p1, mkHdr('SFC/TFC/FFC/BRGF योजनाओं में कार्यों का विवरण — प्रपत्र-1')),
    },
    {
      key: 'p2',
      label: 'प्रपत्र-2 — निर्माण कार्यों पर व्यय श्रम राशि',
      sub: `श्रम rows ${p2.length}`,
      landscape: false,
      body: () => prapt2Html(p2, mkHdr('निर्माण कार्यों पर व्यय की गयी श्रम राशि — प्रपत्र-2')),
    },
    {
      key: 'p4',
      label: 'प्रपत्र-4 — निर्माण सामग्री विवरण',
      sub: `सामग्री मद ${p4.length} · योग ${formatINR(p4.reduce((s, r) => s + r.cost, 0))}`,
      landscape: false,
      body: () => prapt4Html(p4, mkHdr('निर्माण कार्यों पर व्यय सामग्री — प्रपत्र-4')),
    },
    {
      key: 'bank',
      label: 'बैंक विवरण (Bank statement)',
      sub: `Lines ${fyBankLines.length}`,
      landscape: true,
      body: bankBody,
    },
    {
      key: 'patta',
      label: 'पट्टा ऑडिट (आबादी भूमि पट्टे)',
      sub: 'आय में पट्टे की entries',
      landscape: false,
      body: pattaAuditHtml,
    },
    {
      key: 'audit',
      label: 'Audit workbook — 6 sheets (एक Excel में)',
      sub: 'full गोशवारा · गोशवारा · प्रपत्र-1 · सामग्री · श्रम · पट्टा',
      landscape: true,
      body: () => auditSheets().map((s) => `<div class="pg">${s.html}</div>`).join(''),
    },
    {
      key: 'all',
      label: 'पूरा प्रपत्र केंद्र — सभी formats एक document',
      sub: 'गोशवारा + खाता बही + प्रपत्र-1/2/4 + बैंक',
      landscape: true,
      body: () =>
        [
          `<div class="pg">${goswaraBody()}</div>`,
          `<div class="pg">${ledgerBody()}</div>`,
          `<div class="pg">${prapt1Html(p1, mkHdr('SFC/TFC/FFC/BRGF योजनाओं में कार्यों का विवरण — प्रपत्र-1'))}</div>`,
          `<div class="pg">${prapt2Html(p2, mkHdr('निर्माण कार्यों पर व्यय की गयी श्रम राशि — प्रपत्र-2'))}</div>`,
          `<div class="pg">${prapt4Html(p4, mkHdr('निर्माण कार्यों पर व्यय सामग्री — प्रपत्र-4'))}</div>`,
          `<div class="pg">${bankBody()}</div>`,
          `<div class="pg">${ccBody()}</div>`,
        ].join(''),
    },
  ];
  const curFmt = fmtList.find((f) => f.key === fmtKey) || fmtList[0];
  /* v13 #15 — सारे share/export formats को f-01, f-02, f-03… क्रमांक */
  const fmtList2 = fmtList.map((f, i) => ({ ...f, no: `f-${String(i + 1).padStart(2, '0')}` }));
  const doPreview = async () => {
    try {
      await previewDoc(`${curFmt.label} — ${activePanchayat.name}`, curFmt.body(), curFmt.landscape);
    } catch (e) {
      Alert.alert('Preview fail', String((e as Error).message || e));
    }
  };
  return (
    <View style={styles.page}>
      <Header title="प्रपत्र / Formats Centre" onBack={back} badge="S-56" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          आपकी demo files के अनुसार — हर format entries से auto-update होता है (ledger की तरह, कोई generate step नहीं)। Share/Excel me kholen.
        </Text>

        {/* ═══ v13 #14b + #15 — सारे formats f-01, f-02… क्रमांकित सूची; हर एक का
            अपना अलग पृष्ठ (प्रिंट लेआउट + मैन्युअल संपादन) ═══ */}
        {fmtSel ? (
          (() => {
            const f = fmtList2.find((x) => x.key === fmtSel) || fmtList2[0];
            const edited = fmtHtml[f.key] !== undefined;
            const html = edited ? fmtHtml[f.key] : f.body();
            return (
              <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5 }]}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <View style={{ backgroundColor: C.primary, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 }}>
                    <Text style={{ color: '#fff', fontWeight: '900', fontSize: 12 }}>{f.no}</Text>
                  </View>
                  <Text style={[styles.cardTitle, { flex: 1, marginTop: 0 }]}>{f.label}</Text>
                </View>
                <Text style={styles.meta}>{f.sub}</Text>
                <Text style={styles.meta}>
                  {f.landscape ? 'A4 landscape (चौड़ा)' : 'A4 portrait (खड़ा)'} · फ़ाइल का नाम “{f.no} - {f.label}”
                </Text>
                <View style={styles.row}>
                  <Btn label="प्रिंट लेआउट देखें" icon="eye" variant="soft" onPress={() => previewDoc(`${f.no} ${f.label}`, html, f.landscape)} />
                  <Btn label="Share — PDF / Excel" icon="share-2" onPress={() => askAndShare(`${f.no} ${f.label}`, html, f.landscape)} />
                </View>

                {/* v13 #14b — मैन्युअल संपादन: जो यहाँ बदलेंगे वही प्रिंट व शेयर में जाएगा */}
                <Text style={[styles.fieldLabel, { marginTop: 8 }]}>
                  मैन्युअल संपादन — प्रिंट/शेयर से पहले कोई भी बदलाव यहीं करें
                </Text>
                <Field
                  label={`${f.no} का HTML / लेख`}
                  value={html}
                  multiline
                  onChangeText={(t) => setFmtHtml((m) => ({ ...m, [f.key]: t }))}
                  bg={C.input}
                />
                <Text style={styles.meta}>
                  यह वही layout है जो PDF/Excel में जाता है — अंक, नाम या शीर्षक ठीक करके सीधे Share करें।
                </Text>
                <View style={styles.row}>
                  {edited ? (
                    <Btn
                      label="मूल (auto) पर वापस"
                      variant="outline"
                      onPress={() =>
                        setFmtHtml((m) => {
                          const n = { ...m };
                          delete n[f.key];
                          return n;
                        })
                      }
                    />
                  ) : null}
                  <Btn label="◀ सभी प्रपत्र (सूची)" icon="chevron-left" variant="outline" onPress={() => setFmtSel(null)} />
                </View>
              </View>
            );
          })()
        ) : (
          <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5 }]}>
            <Text style={styles.cardTitle}>प्रपत्र केंद्र — सभी formats ({fmtList2.length})</Text>
            <Text style={styles.meta}>
              v13 #15 — हर share/export format का अपना क्रमांक f-01, f-02, f-03… · किसी पर दबाएँ → उसके अपने पृष्ठ में प्रिंट लेआउट
              व मैन्युअल संपादन खुलेगा।
            </Text>
            {fmtList2.map((f) => (
              <Pressable
                key={f.key}
                style={[styles.card, { backgroundColor: C.input, borderColor: f.key === fmtKey ? C.primary : C.border }]}
                onPress={() => {
                  setFmtKey(f.key);
                  setFmtSel(f.key);
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <View
                    style={{
                      backgroundColor: C.primary,
                      borderRadius: 8,
                      paddingHorizontal: 8,
                      paddingVertical: 4,
                      minWidth: 46,
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ color: '#fff', fontWeight: '900', fontSize: 12 }}>{f.no}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.cardTitle, { marginTop: 0 }]} numberOfLines={2}>
                      {f.label}
                    </Text>
                    <Text style={styles.meta}>{f.sub}</Text>
                    <Text style={styles.meta}>{f.landscape ? 'A4 landscape' : 'A4 portrait'}</Text>
                  </View>
                  <Feather name="chevron-right" size={18} color={C.mutedForeground} />
                </View>
              </Pressable>
            ))}
            <Text style={styles.meta}>
              प्रत्येक प्रपत्र entries से auto-update होता है (ledger की तरह, कोई generate step नहीं)।
            </Text>
          </View>
        )}

        <View style={[styles.card, { borderColor: C.primary, borderWidth: 1.5 }]}>
          <Text style={styles.cardTitle}>Audit workbook — 6 sheets (एक ही Excel file में)</Text>
          <Text style={styles.meta}>
            full गोशवारा · गोशवारा · प्रपत्र-1 · सामग्री ऑडिट · श्रम ऑडिट · पट्टा ऑडिट — ठीक वैसा ही जैसे audit formet demo.xlsx
          </Text>
          <View style={styles.row}>
            <Btn label="6 sheets Excel (.xlsx)" icon="share-2" onPress={() => shareWorkbook('Audit format', auditSheets())} />
            <Btn label="A4 page (PDF)" variant="outline" onPress={() => askAndShare('Audit — 6 formats (A4)', auditSheets().map((s) => `<div class="pg">${s.html}</div>`).join(''), true)} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पूरा प्रपत्र केंद्र — एक ही A4 पृष्ठ (Excel जैसा)</Text>
          <Text style={styles.meta}>सारे formats क्रम से एक document में — print / PDF / Excel तीनों।</Text>
          <View style={styles.row}>
            <Btn
              label="पूरा Formats Centre खोलें (A4)"
              icon="share-2"
              onPress={() =>
                askAndShare(
                  'प्रपत्र केंद्र (सभी formats)',
                  [
                    `<div class="pg">${goswaraBody()}</div>`,
                    `<div class="pg">${ledgerBody()}</div>`,
                    `<div class="pg">${prapt1Html(p1, mkHdr('SFC/TFC/FFC/BRGF योजनाओं में कार्यों का विवरण — प्रपत्र-1'))}</div>`,
                    `<div class="pg">${prapt2Html(p2, mkHdr('निर्माण कार्यों पर व्यय की गयी श्रम राशि — प्रपत्र-2'))}</div>`,
                    `<div class="pg">${prapt4Html(p4, mkHdr('निर्माण कार्यों पर व्यय सामग्री — प्रपत्र-4'))}</div>`,
                    `<div class="pg">${bankBody()}</div>`,
                  ].join(''),
                  true
                )
              }
            />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>गोशवारा — वार्षिक आय-व्यय सामान्य रोकड़ बही</Text>
          <Text style={styles.meta}>
            मद {g.rows.length} · आय योग {formatINR(g.aayYog)} · व्यय योग {formatINR(g.vyayYog)} · अंतिम शेष {formatINR(g.antSheshNagad)}
          </Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() => askAndShare('गोशवारा (रोकड़ बही)', goswaraBody(), true)}
            />
            <Btn label="Open" variant="outline" onPress={() => go('goswara')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Ledger — खाता बही</Text>
          <Text style={styles.meta}>श्री पोते → जमा/नाम → शेष (ledger.pdf layout, दो-पक्षीय)</Text>
          <View style={styles.row}>
            <Btn label="PDF / Excel" icon="share-2" onPress={() => askAndShare('खाता बही (Ledger)', ledgerBody(), true)} />
            <Btn label="Open" variant="outline" onPress={() => go('ledgers')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-1 — SFC/TFC/FFC/BRGF कार्य विवरण</Text>
          <Text style={styles.meta}>कार्य {p1.length} · FS/व्यय/मूल्यांकन/स्थिति auto</Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() =>
                askAndShare(
                  'प्रपत्र-1',
                  prapt1Html(p1, mkHdr('SFC/TFC/FFC/BRGF योजनाओं में कार्यों का विवरण — प्रपत्र-1')),
                  true
                )
              }
            />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-2 — निर्माण कार्यों पर व्यय श्रम राशि</Text>
          <Text style={styles.meta}>श्रम rows {p2.length} · मानव दिवस × दर (पाक्षिक rolls से)</Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() => askAndShare('प्रपत्र-2', prapt2Html(p2, mkHdr('निर्माण कार्यों पर व्यय की गयी श्रम राशि — प्रपत्र-2')))}
            />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-4 — निर्माण सामग्री विवरण</Text>
          <Text style={styles.meta}>सामग्री मद {p4.length} · योग {formatINR(p4.reduce((s, r) => s + r.cost, 0))}</Text>
          <View style={styles.row}>
            <Btn
              label="PDF / Excel"
              icon="share-2"
              onPress={() => askAndShare('प्रपत्र-4', prapt4Html(p4, mkHdr('निर्माण कार्यों पर व्यय सामग्री — प्रपत्र-4')))}
            />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Bank statement (बैंक विवरण)</Text>
          <Text style={styles.meta}>Lines {fyBankLines.length} · दिनांक/विवरण/संदर्भ/जमा/नाम/शेष + tagging</Text>
          <View style={styles.row}>
            <Btn label="PDF / Excel" icon="share-2" onPress={() => askAndShare('बैंक विवरण', bankBody(), true)} />
            <Btn label="Open" variant="outline" onPress={() => go('bank')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>CC — कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ)</Text>
          <Text style={styles.meta}>Works {works.filter((w) => w.fyId === activeFy.id).length} · पाक्षिक rolls {workerRolls.length} — work detail se open karein</Text>
          <View style={styles.row}>
            <Btn label="Open Works" variant="outline" onPress={() => go('works')} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function ClosingScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { activeFy, fyTransactions, activePanchayat, bankLines, exportBackupJson, closeFinancialYearCarryForward, totalOpening, categories } = useStore();
  const [ack, setAck] = useState({ pages: false, bank: false, attach: false });
  const nx = nextFyParts(activeFy);
  const cancelled = fyTransactions.filter((t) => t.status === 'cancelled').length;
  const untagged = bankLines.filter((l) => l.fyId === activeFy.id && !l.postedTxnId && !l.ignored).length;
  const ready = ack.pages && ack.bank && ack.attach;

  /* instruction #28 — FY समापन का safe backup: text message नहीं, असली फ़ाइल / zip share */
  const stamp = activeFy.label.replace(/[^\w-]+/g, '_');
  const doSafeBackup = () => {
    const json = exportBackupJson();
    const catNames: Record<string, string> = {};
    for (const c of categories) catNames[c.id] = c.name;
    const g = buildGoswara(fyTransactions, catNames, totalOpening);
    const fyBank = bankLines.filter((l) => l.fyId === activeFy.id && !l.ignored);
    const antimBank = fyBank.reduce((s, l) => s + (l.side === 'credit' ? l.amount : -l.amount), 0);
    const hdr: FmtHeader = {
      panchayat: activePanchayat.name,
      block: activePanchayat.block,
      district: activePanchayat.district,
      fy: activeFy.label,
      formName: 'वार्षिक आय-व्यय सामान्य रोकड़ बही',
    };
    const goswara = goswaraHtml({
      header: hdr,
      rows: g.rows,
      aayYog: g.aayYog,
      vyayYog: g.vyayYog,
      prarambhikNagad: g.prarambhikNagad,
      prarambhikBank: 0,
      antimNagad: Math.round((g.antSheshNagad - antimBank) * 100) / 100,
      antimBank: Math.round(antimBank * 100) / 100,
    });
    const ledger = ledgerHtml({ header: { ...hdr, formName: 'खाता बही — सभी योजनाएँ' }, rows: buildLedger(totalOpening, fyTransactions) });
    const run = async (label: string, fn: () => Promise<void>) => {
      try {
        await fn();
      } catch (e) {
        Alert.alert(`${label} fail`, String((e as Error)?.message || e));
      }
    };
    Alert.alert(
      'Operation-पूर्व safe backup',
      'अब फ़ाइल share होगी (text message नहीं) — कौन-सी?',
      [
        { text: '.json (पूरा database)', onPress: () => run('JSON', () => shareRawFile(`SafeBackup-${stamp}.json`, json, 'application/json')) },
        {
          text: '.zip (backup + गोशवारा + खाता बही)',
          onPress: () =>
            run('ZIP', () =>
              shareZipBundle(`SafeBackup-${stamp}`, [
                { name: 'database-backup.json', content: json },
                { name: 'goswara.html', content: goswara },
                { name: 'ledger.html', content: ledger },
                {
                  name: 'README.txt',
                  content:
                    `Gram Panchayat Cashbook — FY ${activeFy.label} safe backup\n` +
                    `पंचायत: ${activePanchayat.name} (${activePanchayat.district})\n` +
                    `database-backup.json = ऐप में वापस लाने के लिए (Backup screen → Restore from file)\n` +
                    `goswara.html / ledger.html = ब्राउज़र में खोलकर PDF बनाया जा सकता है\n`,
                },
              ])
            ),
        },
        { text: 'रद्द', style: 'cancel' },
      ]
    );
  };
  return (
    <View style={styles.page}>
      <Header title={`वित्तीय वर्ष समापन — ${activeFy.label}`} onBack={back} badge="S-45" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>FY lock se pehle: sab jagah janch, final गोशवारा, safe backup (kabhi delete nahi), phir lock.</Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>1. जाँच सूची</Text>
          {[
            ['pages', 'सभी pages जाँचा-परखा (मैन्युअल रूप से सत्यापित)'],
            ['bank', `बैंक statements upload + verify (${untagged} untagged lines बाकी)`],
            ['attach', `Missing attachments की सूची देखी (${cancelled} cancelled entries)`],
          ].map(([k, label]) => (
            <Pressable key={k} onPress={() => setAck((a) => ({ ...a, [k]: !a[k as keyof typeof ack] }))} style={styles.homeRow}>
              <Feather name={ack[k as keyof typeof ack] ? 'check-square' : 'square'} size={18} color={C.primary} />
              <Text style={{ flex: 1, fontSize: 12, color: C.foreground }}>{label}</Text>
            </Pressable>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>2. Final गोशवारा</Text>
          <Text style={styles.meta}>31-03 annual गोशवारा Formats Centre / गोशवारा screen se verify karein</Text>
          <Btn label="गोशवारा खोलें" variant="outline" onPress={() => go('goswara')} />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>3. Operation-पूर्व safe backup</Text>
          <Text style={styles.meta}>यह backup कभी auto-delete नहीं होगा</Text>
          <Btn label="Safe backup — फ़ाइल / .zip share करें" icon="download" onPress={doSafeBackup} />
          <Text style={styles.meta}>.json पूरा database है (Restore से वापस); .zip में गोशवारा + खाता बही भी जुड़े होते हैं।</Text>
        </View>
        <Btn
          label="4. FY Lock → नए वर्ष की opening carry-forward"
          variant="danger"
          disabled={!ready}
          onPress={() =>
            Alert.alert(
              'FY lock?',
              `${activeFy.label} read-only archive हो जाएगा. Closing balances (opening ${formatINR(totalOpening)} से गणित) नए FY ${nx.label} की opening बनेंगी.`,
              [
                { text: 'नहीं', style: 'cancel' },
                {
                  text: 'Lock करें',
                  style: 'destructive',
                  onPress: async () => {
                    // bug fix: pehle result check nahi hota tha + hardcoded 2027–28
                    const r = await closeFinancialYearCarryForward(activeFy.id, nx.label, nx.start, nx.end);
                    if (!r.ok) return Alert.alert('FY lock नहीं हुआ', r.error || '—');
                    Alert.alert('FY lock हो गया', `नया FY ${nx.label} खुल गया — opening balances carry-forward`);
                    back();
                  },
                },
              ]
            )
          }
        />
        {!ready ? <Text style={styles.meta}>उपरोक्त तीनों जाँच ✓ करने के बाद ही lock सक्रिय होगा</Text> : null}
      </ScrollView>
    </View>
  );
}

function BackupScreen({ back }: { back: () => void }) {
  const { exportCsvForFy, exportBackupJson, importBackupJson, activePanchayat, updateApp, app } = useStore();
  const [restoreText, setRestoreText] = useState('');
  /* instruction #14 — file storage folder me save + app se hi permission */
  const [dirUri, setDirUri] = useState<string | null>(null);
  const [files, setFiles] = useState<BackupEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const now = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  const backupName = `Cashbook-Backup-${activePanchayat.name.replace(/\s+/g, '_')}-${now}`;

  const refresh = React.useCallback(async () => {
    setDirUri(await getBackupDirUri());
    setFiles(await listBackups());
  }, []);
  React.useEffect(() => {
    refresh();
  }, [refresh]);

  /* v12 #25 — रोज़ाना बैकअप: फ़ोल्डर जुड़ते ही अपने-आप चालू, समय default रात 2 बजे */
  const autoHour = typeof app.backupHour === 'number' ? app.backupHour : 2;
  const autoOn = app.autoBackup === true;
  const hhLabel = (h: number) => `${String(h).padStart(2, '0')}:00 ${h < 6 ? '(रात)' : h < 12 ? '(सुबह)' : h < 17 ? '(दोपहर)' : '(शाम)'}`;

  const chooseFolder = async () => {
    const uri = await pickBackupDir();
    if (!uri) return; // cancel
    await refresh();
    /* v12 #25 — फ़ोल्डर जुड़ते ही daily auto-backup अपने-आप चालू (समय default 2 AM) */
    if (app.autoBackup !== false) await updateApp({ autoBackup: true, backupHour: autoHour });
    Alert.alert(
      'फ़ोल्डर जुड़ गया + रोज़ाना बैकअप चालू',
      `एक बार अनुमति के बाद हर बैकअप इसी फ़ोल्डर में सहेजा जाएगा (फ़ाइलें uninstall पर भी बनी रहेंगी)।\n\n` +
        `• रोज़ाना बैकअप: चालू ✓\n• निर्धारित समय: ${hhLabel(autoHour)}\n• बदलना हो तो नीचे “रोज़ाना बैकअप”कार्ड से समय बदलें या बंद करें।`
    );
  };

  const dbObj = () => JSON.parse(exportBackupJson()) as Record<string, unknown>;

  /** instruction #19 — बैकअप .json / .csv / .xlsx / .zip में; तीनों restore भी होते हैं */
  const encode = (ext: 'json' | 'csv' | 'xlsx' | 'zip'): string | Uint8Array =>
    ext === 'csv'
      ? backupToCsv(dbObj())
      : ext === 'xlsx'
        ? backupToXlsx(dbObj())
        : ext === 'zip'
          ? backupToZip(dbObj())
          : exportBackupJson();

  const fmtChoice = (title: string, onPick: (ext: 'json' | 'csv' | 'xlsx' | 'zip') => void) =>
    Alert.alert(title, 'Format चुनें — चारों file को app restore कर सकता है', [
      { text: '.json (पूरा database)', onPress: () => onPick('json') },
      { text: '.csv (Excel/Sheets)', onPress: () => onPick('csv') },
      { text: '.xlsx (असली Excel)', onPress: () => onPick('xlsx') },
      { text: '.zip (json + csv)', onPress: () => onPick('zip') },
      { text: 'रद्द', style: 'cancel' },
    ]);

  const saveToFolder = (ext: 'json' | 'csv' | 'xlsx' | 'zip') => {
    (async () => {
      try {
        if (!dirUri) {
          const uri = await pickBackupDir();
          if (!uri) return;
          setDirUri(uri);
        }
        setBusy(true);
        const p = await saveBackup(`${backupName}.${ext}`, encode(ext));
        await refresh();
        /* v10 #30-B — बैकअप होते ही घड़ी रीसेट, ताकि Home पर अगला reminder सही वक़्त पर आए */
        updateApp({ lastBackupAt: new Date().toISOString() });
        Alert.alert('बैकअप सहेजा गया', p);
      } catch (e) {
        Alert.alert('बैकअप fail', String((e as Error)?.message || e));
      } finally {
        setBusy(false);
      }
    })();
  };

  /* instruction #17/#18 — share हमेशा असली file (message नहीं) */
  const shareBackupFile = async (ext: 'json' | 'csv' | 'xlsx' | 'zip') => {
    try {
      await shareRawFile(`${backupName}.${ext}`, encode(ext), mimeForExt(ext));
      /* v10 #30-B */
      updateApp({ lastBackupAt: new Date().toISOString() });
    } catch (e) {
      Alert.alert('Share fail', String((e as Error)?.message || e));
    }
  };

  const doRestore = (obj: Record<string, unknown> | null, label: string) => {
    if (!obj) {
      Alert.alert('Restore fail', 'यह backup file पहचानी नहीं गई — .json / .csv / .xlsx / .zip में से होनी चाहिए');
      return;
    }
    Alert.alert('Restore करें?', `${label}\nमौजूदा data replace हो जाएगा — ज़रूरी हो तो पहले नया backup ले लें।`, [
      { text: 'नहीं', style: 'cancel' },
      {
        text: 'Restore',
        style: 'destructive',
        onPress: () => {
          const r = importBackupJson(JSON.stringify(obj));
          if (r.ok) Alert.alert('Restore सफल', 'Data वापस आ गया');
          else Alert.alert('Restore fail', r.error || 'Invalid file');
        },
      },
    ]);
  };

  const restoreFrom = async (f: BackupEntry) => {
    try {
      const obj = parseBackupBytes(await readBackupBytes(f.uri));
      doRestore(obj, f.name);
    } catch (e) {
      Alert.alert('फ़ाइल नहीं पढ़ी', String((e as Error)?.message || e));
    }
  };

  /* instruction #19 — phone में कहीं भी रखी .json / .csv / .xlsx backup उठाकर restore */
  const pickAndRestore = async () => {
    try {
      const res = await File.pickFileAsync({ mimeTypes: ['*/*'] });
      if (res.canceled || !res.result) return;
      const bytes = new Uint8Array(await res.result.arrayBuffer());
      doRestore(parseBackupBytes(bytes), res.result.name);
    } catch (e) {
      Alert.alert('Restore fail', String((e as Error)?.message || e));
    }
  };

  return (
    <View style={styles.page}>
      <Header title="Backup & export" onBack={back} badge="S-42" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>बैकअप फ़ोल्डर (storage)</Text>
          <Text style={styles.meta}>
            {dirUri ? `जुड़ा हुआ: ${dirUri}` : 'अभी फ़ोल्डर नहीं चुना — नीचे “फ़ोल्डर चुनें” दबाएँ (एक बार अनुमति, फिर अपने-आप)।'}
          </Text>
          <Btn label={dirUri ? 'फ़ोल्डर बदलें / अनुमति दोबारा दें' : '📁 फ़ोल्डर चुनें (एक बार अनुमति)'} icon="folder" onPress={chooseFolder} />
          <Btn label={busy ? 'सहेजा जा रहा है…' : '⬇ इस फ़ोल्डर में बैकअप फ़ाइल सहेजें (format चुनें)'} icon="download" disabled={busy} onPress={() => fmtChoice('बैकअप सहेजें', saveToFolder)} />
          <Btn label="फ़ोल्डर की अनुमति हटाएँ (app से)" variant="outline" icon="x" onPress={async () => { await clearBackupDir(); await refresh(); }} />
          <Text style={styles.meta}>
            फ़ाइल: {backupName}.json / .csv / .xlsx / .zip — app uninstall करने पर भी फ़ोल्डर में बनी रहती है। Android/data वाले folder में कभी न सहेजें (uninstall पर delete)।
          </Text>
        </View>

        {/* ═══════════ v12 #25 — रोज़ाना बैकअप सेटिंग्स ═══════════ */}
        <View style={[styles.card, { borderColor: autoOn ? C.primary : C.border, borderWidth: 1.5 }]}>
          <Text style={styles.cardTitle}>रोज़ाना बैकअप (Daily auto backup)</Text>
          <Text style={styles.meta}>
            {autoOn
              ? `चालू ✓ — हर दिन ${hhLabel(autoHour)} पर जुड़े फ़ोल्डर में .json बैकअप अपने-आप सहेजा जाता है (app खुलते ही जाँच होती है; समय पार होते ही आज का बैकअप अपने-आप बन जाता है)।`
              : 'बंद है — फ़ोल्डर चुनते ही यह अपने-आप चालू हो जाता है; नीचे से दोबारा चालू कर सकते हैं।'}
            {app.backupLastRun ? ` · आख़िरी अपने-आप बैकअप: ${app.backupLastRun.slice(0, 16).replace('T', ' ')}` : ' · अभी कोई अपने-आप बैकअप नहीं'}
          </Text>
          <Btn
            label={autoOn ? 'रोज़ाना बैकअप बंद करें' : 'रोज़ाना बैकअप चालू करें'}
            variant={autoOn ? 'outline' : 'primary'}
            icon={autoOn ? 'x' : 'check'}
            onPress={() => updateApp({ autoBackup: !autoOn })}
          />
          <SelectField
            label="बैकअप का समय (interval / time)"
            value={hhLabel(autoHour)}
            options={Array.from({ length: 24 }, (_, h) => ({ key: String(h), label: hhLabel(h) }))}
            onSelect={(k) => updateApp({ backupHour: Number(k), backupLastRun: undefined })}
            hint="Default रात 2:00 — कोई भी घंटा चुनें (यही “समय/interval” है जो Settings से बदला जाता है)।"
          />
          <Text style={styles.meta}>
            जैसे ही कोई बैकअप इस फ़ोल्डर में सहेजा जाता है, घड़ी रीसेट हो जाती है ताकि उस दिन का अपने-आप बैकअप दोबारा न बने।
          </Text>
        </View>

        <Text style={styles.section}>फ़ोल्डर की बैकअप फ़ाइलें ({files.length})</Text>
        {files.map((f) => (
          <View key={f.uri} style={[styles.card, { flexDirection: 'row', alignItems: 'center', gap: 8 }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle} numberOfLines={2}>{f.name}</Text>
              <Text style={styles.meta}>{f.size ? `${(f.size / 1024).toFixed(1)} KB` : ''}</Text>
            </View>
            <Btn label="Restore" variant="soft" onPress={() => restoreFrom(f)} />
            <IconBtn
              name="trash-2"
              onPress={() =>
                Alert.alert('फ़ाइल हटाएँ?', f.name, [
                  { text: 'नहीं', style: 'cancel' },
                  { text: 'हटाएँ', style: 'destructive', onPress: async () => { await deleteBackup(f.uri); await refresh(); } },
                ])
              }
            />
          </View>
        ))}
        {dirUri && files.length === 0 ? (
          <Empty title="अभी कोई backup file नहीं" why="ऊपर का बैकअप बटन दबाते ही पहली फ़ाइल बन जाएगी" steps={['फ़ोल्डर चुनें', 'बैकअप सहेजें']} />
        ) : null}
        {!dirUri ? (
          <Empty title="फ़ोल्डर नहीं जुड़ा" why="App सीधे storage folder में फ़ाइल नहीं लिख सकती — एक बार अनुमति देनी होती है" steps={['📁 फ़ोल्डर चुनें', 'बैकअप सहेजें', 'Restore यहीं से']} />
        ) : null}

        <Text style={styles.section}>Share (हमेशा असली फ़ाइल, message नहीं)</Text>
        <Btn label="⬇ Full Backup — Share (.json / .csv / .xlsx / .zip)" icon="share-2" onPress={() => fmtChoice('बैकअप शेयर करें', (ext) => shareBackupFile(ext))} />
        <Btn label="Share FY CSV (Excel / .xlsx)" icon="share-2" onPress={async () => {
          try {
            const csv = exportCsvForFy();
            await shareRawFile(`${backupName}-FY.csv`, csv, 'text/csv');
            await shareRawFile(`${backupName}-FY.xlsx`, csvToXlsx(csv, 'FY'), mimeForExt('xlsx'));
          } catch (e) {
            Alert.alert('Share fail', String((e as Error)?.message || e));
          }
        }} />
        <Btn label="फ़ोन में से फ़ाइल चुनकर Restore (json / csv / xlsx)" icon="folder" variant="soft" onPress={pickAndRestore} />
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Restore (phone transfer / paste)</Text>
          <Text style={styles.meta}>Naye phone par: backup file चुनें (ऊपर) या JSON/CSV का text paste करके Restore दबाएँ।</Text>
          <Field label="Backup JSON / CSV paste करें" value={restoreText} onChangeText={setRestoreText} multiline />
          <Btn
            label="Restore data"
            variant="danger"
            onPress={() => {
              if (!restoreText.trim()) return Alert.alert('JSON/CSV paste करें');
              doRestore(parseBackupText(restoreText), 'pasted text');
              setRestoreText('');
            }}
          />
        </View>
      </ScrollView>
    </View>
  );
}

function FundsScreen({ back }: { back: () => void }) {
  const { activeFunds, updateFundOpening, deleteFundFy, addFund, fundOpening, activeFy } = useStore();
  const [name, setName] = useState('');
  const [open, setOpen] = useState('0');
  /* v10 #8 — cash यहाँ नहीं दिखेगा: cash कोई fund head / योजना नहीं, सिर्फ़ लेन-देन का माध्यम */
  const heads = activeFunds.filter((f) => f.id !== 'cash');
  return (
    <View style={styles.page}>
      <Header title="Fund heads" onBack={back} badge="S-35" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          योजना-वार fund heads (SFC/TFC/Own/MP/…) — यही सब योजना dropdown में दिखते हैं।{'\n'}
          नकद (Cash) यहाँ नहीं है, क्योंकि वह कोई योजना नहीं — सिर्फ़ नकद/बैंक माध्यम है (v10 #8)।
        </Text>
        {heads.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>
              {formatINR(fundOpening(f))} · {f.openingSource === 'carry-forward' ? '↩ carry-forward' : '✎ manual'} · {f.shortName}
            </Text>
            <Text style={styles.meta}>इस FY ({activeFy.label}) का प्रारंभिक शेष</Text>
            <View style={styles.row}>
              <Btn label="Delete (FY)" variant="danger" onPress={() => deleteFundFy(f.id)} />
            </View>
          </View>
        ))}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>+ नया fund head</Text>
          <Field label="नाम (जैसे: MGNREGA)" value={name} onChangeText={setName} />
          <Field label="प्रारंभिक शेष (₹)" value={open} onChangeText={setOpen} keyboardType="numeric" />
          <Btn
            label="Add"
            icon="plus"
            onPress={() => {
              addFund(name, parseFloat(open) || 0);
              setName('');
              setOpen('0');
            }}
          />
        </View>
      </ScrollView>
    </View>
  );
}

function Shell() {
  const [stage, setStage] = useState<Stage>('login');
  const [workId, setWorkId] = useState<string>('');
  const [editTxnId, setEditTxnId] = useState<string | null>(null);
  const { hydrated, app, updateApp, exportBackupJson } = useStore();

  // Theme color: App Settings me choose kiya gaya theme yahin apply hota hai
  React.useEffect(() => {
    applyThemeAndStyles(app?.themeId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [app?.themeId]);

  /* ═══════════ v12 #25 — रोज़ाना बैकअप (default: रात 2 बजे) ═══════════
     फ़ोल्डर चुनते ही `autoBackup` अपने-आप चालू हो जाता है। हर बार app खुलते/वापस
     आते ही यह जाँच चलती है — अगर निर्धारित समय पार हो चुका है और आज का अपने-आप
     बैकअप नहीं हुआ, तो चुने हुए फ़ोल्डर में .json बैकअप सहेज लिया जाता है।
     (समय Settings/Backup स्क्रीन से कभी भी बदला जा सकता है — `backupHour` 0–23.) */
  React.useEffect(() => {
    if (!hydrated || app?.autoBackup !== true) return;
    const hour = typeof app?.backupHour === 'number' ? app.backupHour : 2;
    const now = new Date();
    const scheduled = new Date(now);
    scheduled.setHours(hour, 0, 0, 0);
    if (now.getTime() < scheduled.getTime()) return;
    const last = app?.backupLastRun ? new Date(app.backupLastRun) : null;
    if (last && !Number.isNaN(last.getTime()) && last.getTime() >= scheduled.getTime()) return;
    let cancelled = false;
    (async () => {
      try {
        const dir = await getBackupDirUri();
        if (!dir || cancelled) return;
        const stamp = new Date().toISOString().slice(0, 10);
        await saveBackup(`Cashbook-AutoBackup-${stamp}.json`, exportBackupJson());
        if (cancelled) return;
        await updateApp({ lastBackupAt: new Date().toISOString(), backupLastRun: new Date().toISOString() });
      } catch {
        /* चुपचाप — अगली बार app खुलने पर फिर कोशिश होगी */
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, app?.autoBackup, app?.backupHour, app?.backupLastRun]);

  // bug fix: pehle stack state ke andar Alert/setStage (side-effects) chalte the —
  // StrictMode me updater 2 baar chalta hai = duplicate Exit dialog + double nav.
  // Ab navigation-stack ki ek authoritative copy ref me; re-render setStage karta hai.
  const stackRef = useRef<Stage[]>(['login']);

  const go = useCallback((s: Stage, wid?: string) => {
    /* v10 #18-2 — wid === '' का मतलब "कोई कार्य नहीं" (स्वतंत्र मान-दिवस गणना);
       wid अनुपस्थित = पिछला चुना हुआ कार्य यथावत रहे (पुराना व्यवहार)। */
    if (wid !== undefined) setWorkId(wid);
    stackRef.current = [...stackRef.current, s];
    setStage(s);
  }, []);

  const exitConfirm = useCallback(() => {
    Alert.alert('Exit?', undefined, [
      { text: 'Stay', style: 'cancel' },
      { text: 'Exit', style: 'destructive', onPress: () => BackHandler.exitApp() },
    ]);
  }, []);

  const back = useCallback(() => {
    if (stackRef.current.length <= 1) {
      exitConfirm();
      return;
    }
    stackRef.current = stackRef.current.slice(0, -1);
    setStage(stackRef.current[stackRef.current.length - 1]);
  }, [exitConfirm]);

  React.useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      back();
      return true;
    });
    return () => sub.remove();
  }, [back]);

  /* v10 #30-A — App lock: ऐप background गई तो चुनी हुई देरी बाद फिर से login पर लौटो।
     (default 30 सेकंड — छोटे app-switch पर अधूरा फ़ॉर्म न खत्म हो; उससे ज़्यादा देर
      तो lock, वापस आने पर PIN/अंगुली माँगी जाएगी।) */
  React.useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | null = null;
    const lockSec = app?.autoLockSec ?? 30;
    const clear = () => {
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
    };
    const sub = AppState.addEventListener('change', (st) => {
      if (st === 'background' || st === 'inactive') {
        clear();
        timer = setTimeout(() => {
          stackRef.current = ['login'];
          setStage('login');
        }, Math.max(0, lockSec) * 1000);
      } else if (st === 'active') {
        clear();
      }
    });
    return () => {
      sub.remove();
      clear();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [app?.autoLockSec]);

  if (!hydrated) {
    return (
      <View style={[styles.page, { alignItems: 'center', justifyContent: 'center' }]}>
        <Text>Loading…</Text>
      </View>
    );
  }

  switch (stage) {
    case 'login':
      return <LoginScreen onDone={() => go('panchayat')} />;
    case 'panchayat':
      return <PanchayatScreen onContinue={() => go('fy')} onBack={back} onSettings={() => go('appSettings')} />;
    case 'appSettings':
      return <AppSettingsScreen onBack={back} />;
    case 'fy':
      return <FYScreen onContinue={() => go('home')} onBack={back} onSettings={() => go('fySettings')} />;
    case 'fySettings':
      return <FYSettingsScreen onBack={back} />;
    case 'home':
      return <HomeScreen go={go} back={back} />;
    case 'cashbook':
      return (
        <CashbookScreen
          back={back}
          go={go}
          onEdit={(id) => {
            setEditTxnId(id);
            go('entry');
          }}
          /* v12 #30 — ख़ाली जगह tap = **नई entry**, पिछली entry का edit id हमेशा साफ़ करके */
          onNewEntry={() => {
            setEditTxnId(null);
            go('entry');
          }}
        />
      );
    case 'entry':
      return <EntryScreen back={back} editTxnId={editTxnId} onClearEdit={() => setEditTxnId(null)} />;
    case 'funds':
      return <FundsScreen back={back} />;
    case 'categories':
      return <CategoriesScreen back={back} />;
    case 'monthly':
      return <MonthlyScreen back={back} />;
    case 'goswara':
      return <GoswaraScreen back={back} go={go} />;
    case 'ledgers':
      return <LedgersScreen back={back} go={go} />;
    case 'reports':
      return <ReportsScreen back={back} go={go} />;
    case 'bank':
      return <BankScreen back={back} />;
    case 'works':
      return <WorksScreen back={back} go={go} />;
    case 'workDetail':
      return <WorkDetailScreen back={back} workId={workId} go={go} />;
    case 'mb':
      return <MbScreen back={back} workId={workId} go={go} />;
    case 'manday':
      return <MandayScreen back={back} workId={workId} />;
    case 'bills':
      return (
        <BillsScreen
          back={back}
          workId={workId}
          go={go}
          /* v10 #26 — कार्य के नीचे का व्यय-वाउचर सुधारने के लिए */
          onEditTxn={(id) => {
            setEditTxnId(id);
            go('entry');
          }}
        />
      );
    case 'cc':
      return <CcScreen back={back} workId={workId} go={go} />;
    case 'formats':
      return <FormatsScreen back={back} go={go} />;
    case 'masters':
      return <MastersScreen back={back} />;
    case 'closing':
      return <ClosingScreen back={back} go={go} />;
    /* v13 #14a — व्यवस्था अब एक अपना पन्ना (Back से इसी पर वापसी) */
    case 'settings':
      return <SettingsScreen back={back} go={go} />;
    case 'backup':
      return <BackupScreen back={back} />;
    default:
      return <HomeScreen go={go} back={back} />;
  }
}

export default function Index() {
  return <Shell />;
}

// Theme support: styles ab function se bante hain — theme badalne par rebuild
// karna zaroori hai (StyleSheet.create values usi waqt capture karta hai).
function makeStyles() {
  return StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  dark: { flex: 1, backgroundColor: C.darkForest, padding: 24, justifyContent: 'center' },
  loginPad: { gap: 8 },
  loginLogoWrap: { alignItems: 'center', marginBottom: 10 },
  loginLogo: { width: 96, height: 96, borderRadius: 48, borderWidth: 3, borderColor: '#f0b429' },
  brand: { color: C.accent, letterSpacing: 2, fontWeight: '800', fontSize: 12 },
  loginHi: { color: '#fff', fontSize: 28, fontWeight: '800' },
  loginSub: { color: 'rgba(255,255,255,0.7)', marginBottom: 12 },
  header: { backgroundColor: C.primary, paddingHorizontal: 12, paddingBottom: 10 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  eyebrow: { color: 'rgba(255,255,255,0.75)', fontSize: 11 },
  hTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  mark: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  iconBtn: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  pad: { padding: 14, paddingBottom: 40 },
  btn: { flex: 1, flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', paddingVertical: 11, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, marginVertical: 4 },
  btnText: { fontWeight: '800', fontSize: 13 },
  fieldWrap: { marginBottom: 10 },
  fieldLabel: { fontSize: 11, fontWeight: '700', color: C.mutedForeground, marginBottom: 4 },
  /* v10 #18/#29 — input box ka background card se alag + thoda mota, taaki
     input hamesha dikhe aur card me embedded na lage. */
  field: {
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 12,
    minHeight: 46,
    backgroundColor: C.input,
    color: C.foreground,
    fontSize: 14,
  },
  err: { color: C.expense, marginBottom: 8 },
  hint: { color: C.mutedForeground, fontSize: 12, marginBottom: 10, lineHeight: 17 },
  section: { fontWeight: '800', marginTop: 12, marginBottom: 8, color: C.foreground },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  cardOn: { borderColor: C.primary, backgroundColor: C.primarySoft },
  cardTitle: { fontWeight: '800', color: C.foreground, fontSize: 14 },
  meta: { color: C.mutedForeground, fontSize: 11, marginTop: 3 },
  gosHead: { fontSize: 12, fontWeight: '800', color: C.foreground },
  row: { flexDirection: 'row', gap: 8, marginVertical: 6 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12, justifyContent: 'flex-start' },
  /* instruction #2 — hamesha exactly 2 tile per row (width 47.5% + gap 10 < 100%) */
  stat: {
    width: '47.5%',
    flexGrow: 0,
    flexShrink: 0,
    minHeight: 84,
    justifyContent: 'center',
    gap: 3,
    backgroundColor: C.card,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: C.border,
    borderLeftWidth: 3,
    borderLeftColor: C.primary,
    paddingHorizontal: 11,
    paddingVertical: 10,
    overflow: 'hidden',
  },
  statPressed: { opacity: 0.7, transform: [{ scale: 0.985 }] },
  statLabel: { fontSize: 11, fontWeight: '800', color: C.mutedForeground, letterSpacing: 0.2 },
  statValue: { fontSize: 17, fontWeight: '900', color: C.foreground },
  statHint: { fontSize: 10, fontWeight: '800', color: C.primary },
  /* instruction #9 — गोशवारा/ledger जैसी Excel-like table (border + header band) */
  tblBox: { borderWidth: 1, borderColor: '#9db9a8', borderRadius: 6, overflow: 'hidden', backgroundColor: '#ffffff', marginBottom: 10 },
  tblHead: { flexDirection: 'row', backgroundColor: '#e8f2ec', borderBottomWidth: 1, borderBottomColor: '#9db9a8' },
  tblHeadCell: {
    paddingVertical: 6,
    paddingHorizontal: 5,
    fontSize: 10,
    fontWeight: '800',
    color: '#1d2b23',
    borderRightWidth: 1,
    borderRightColor: '#9db9a8',
  },
  tblRow: { flexDirection: 'row', borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#c9d8d0' },
  tblCell: {
    paddingVertical: 5,
    paddingHorizontal: 5,
    fontSize: 11,
    color: C.foreground,
    borderRightWidth: StyleSheet.hairlineWidth,
    borderRightColor: '#c9d8d0',
  },
  tblTot: { flexDirection: 'row', backgroundColor: '#eef6f0', borderTopWidth: 1, borderTopColor: '#9db9a8' },
  homeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  homeIcon: { width: 38, height: 38, borderRadius: 11, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
  chipOn: { backgroundColor: C.primary, borderColor: C.primary },
  summary: { marginTop: 14, padding: 12, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.8)', borderWidth: 1, borderColor: C.border },
  sumLine: { fontWeight: '800', marginBottom: 4 },
  empty: { backgroundColor: C.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.border, gap: 6 },
  emptyTitle: { fontWeight: '800', fontSize: 15 },
  emptyWhy: { color: C.mutedForeground, fontSize: 12, lineHeight: 18 },
  emptyStep: { fontSize: 12 },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 22 },
  modalCard: { backgroundColor: C.card, borderRadius: 16, padding: 16, gap: 8 },
  modalTitle: { fontWeight: '800', fontSize: 16 },
  });
}

let styles = StyleSheet.create(makeStyles());

/** Theme change: palette apply + stylesheet rebuild (inline `C.x` + styles dono update). */
function applyThemeAndStyles(themeId?: string) {
  applyTheme(themeId);
  styles = StyleSheet.create(makeStyles());
}
