# Cashbook Project — Master Document (एकमात्र .md file)

**Document purpose:** पूरे project की **एक ही** authoritative requirements + design file। Original baseline, पूरी discussion/chat, Round decisions और FINAL locks — सब यहीं। अलग overlapping `.md` files नहीं बनेंगी; updates सिर्फ़ इसी file में।

**App UI:** हर screen के corner पर screen number (`S-01` … `S-n`) — discussion/correction number से। **App Settings हमेशा अंतिम screen number**।

**Status:** Requirements FINAL for Phase 1 implementation (20-09-2026 decisions locked).

**Last updated:** 20-09-2026 — Merged baseline + chat + Round 5 + line-map Option A + Phase-1 full scope

---

# PART 0 — FINAL DECISIONS LOG (20-09-2026)

ये locks पुराने टकरावों को resolve करते हैं। Implementation इन्हीं पर चले।

| # | Topic | FINAL |
|---|--------|--------|
| D1 | Default lines per page side | **25** (Cashbook Settings से बदल सकते हैं) |
| D2 | Line map | **Option A** (income: top श्री पोते + bottom 3; expense: top line always blank + bottom 3) |
| D3 | Transaction lines (default) | **21** = `totalLines - 4` |
| D4 | Amounts on a line | **Multi-column** (Cash, SFC, FFC, Own, MP/MLA/TAD, …) **and** scheme select **required** on save (default **SFC**) |
| D5 | Columns | Default **11** (incl. Total); fund/scheme add-edit-delete से columns बढ़/घट सकते हैं |
| D6 | Roles (now) | **Admin only** |
| D7 | Settings hierarchy | **Round 5** (Login → Panchayat+App Settings → FY+FY Settings → FY Home) |
| D8 | Balance guards | Same-day total expense ≤ income-side महायोग; per-scheme minus = FY toggle (default OFF) |
| D9 | New page | **Auto** when txn lines full **+ manual** Add Page |
| D10 | Empty days | Skip by default; **optional insert empty-day page** between two dates |
| D11 | Bank module | **Phase 1** |
| D12 | Works / MB / Bills / CC / BSR | **Phase 1** (full stack) |
| D13 | Storage | **SAF `Documents/Cashbook/...` mandatory Phase 1** |
| D14 | PDF/Excel share background | **Plain white** |
| D15 | Fixed signing keystore | **Later** (not in this doc yet) |
| D16 | Login biometric | **Phase 1**; optional after PIN; toggle/change in **App Settings** |
| D17 | FY isolation | **Only closing balances** carry to next FY opening — **not entries** |
| D18 | Category taxonomy | **Category → Subcategory → Sub-subcategory** CRUD in Cashbook Settings; archive if in use |
| D19 | Ledgers/reports | **Auto from first entry**; every entry updates all views — no separate “generate” step |
| D20 | Monthly check | **All transactions** of period; edit/complete scheme & category path in-place |

---

# PART A — Product vision

Hindi-first Android digital cashbook:

```text
Digital Cashbook
+ Side-by-side Income | Expense pages
+ Configurable N-line pages (default 25)
+ Dynamic fund/scheme columns
+ Scheme-required multi-column amounts
+ Category / sub / sub-sub taxonomy
+ Work / MB / Bills / CC (Phase 1)
+ Bank statement → tag → auto entry (Phase 1)
+ Auto ledgers & reports
+ Annual & till-date गोशवारा
+ PDF + Excel export/share (compulsory)
+ Grid + form data entry
+ Backdated correction + audit trail
+ SAF Documents/Cashbook storage
+ Backup / restore / phone transfer
+ Period lock + FY closing
+ Admin-only (multi-role later)
```

---

# PART B — Financial year

- FY window: **1 April → 31 March** (example: FY 2026–27 = 01-04-2026 … 31-03-2027).
- Each FY has **isolated** transactions, pages, statements, attachments under that FY id.
- **Carry-forward only balances:** previous FY **closing** (fund-wise नकद + bank / scheme) → new FY **opening श्री पोते**. **Previous FY transaction rows must never appear in current FY lists/pages.**
- New scheme in new year: opening may be manual; Page 1 श्री पोते shows indicator **Carry-forward** vs **Manual**.
- 31 March: annual गोशवारा; year-close checklist; backup; then lock → archive read-only.
- Unauthorized edit of locked FY blocked; corrections via correction/adjustment entries + audit.

---

# PART C — Cashbook page engine

## C.1 Layout

- Page split **horizontally 50/50**: **Left = Income (प्राप्तियाँ)**, **Right = Expense (भुगतान)**.
- Default **25 lines** per side; setting range suggested **16–40** (implementation may clamp).
- Changing line count changes **only the middle transaction zone**.
- Fixed zones never removed by line-count setting.

## C.2 Default line map (total L = 25 → txn = 21)

### Income (Left)

| Lines | Role | Editable |
|-------|------|----------|
| **1** | **श्री पोते** — fund-wise opening / previous बचत; label in «किससे प्राप्त किया»; **light red** font | No (auto) |
| **2 … (L−3)** | Transaction lines (**21** when L=25) | Via form/grid only |
| **L−2** | **आय योग** — sum of txn lines only (not line 1) | No |
| **L−1** | **श्री पोते** — same balances as line 1 / policy | No |
| **L** | **महायोग** = आय योग + श्री पोते | No |

### Expense (Right)

| Lines | Role | Editable |
|-------|------|----------|
| **1** | **Always blank** (parallel to income श्री पोते) — **no entry ever** | N/A |
| **2 … (L−3)** | Transaction lines (**21** when L=25) | Via form/grid only |
| **L−2** | **व्यय योग** | No |
| **L−1** | **बचत पोते** = left महायोग − व्यय योग (per fund column) | No |
| **L** | **महायोग** = व्यय योग + बचत पोते | No |

General: `transaction_lines = L - 4`.

## C.3 Columns (default 11; dynamic)

Shared structure (wording side-specific):

1. Date  
2. Invoice number/date **or** Voucher number/date  
3. किससे प्राप्त किया **or** किसको भुगतान किया  
4. Details  
5. Ledger folio  
6. Cash  
7. SFC  
8. FFC  
9. Own Fund / Interest  
10. MP / MLA / TAD  
11. **Total** (automatic; not manually editable)

- Fund/scheme heads live in master; **add / rename / reorder / archive / FY-delete** from settings → columns appear/disappear on pages, reports, exports.
- Historical amounts: prefer **archive/disable** over hard delete; FY-scoped remove does not wipe other years.

## C.4 Entry model (Excel cashbook)

- One transaction line may hold **amounts in multiple fund columns** simultaneously.
- On save, **scheme selection is mandatory** (default **SFC**). Blocks save if missing.
- **Category path** (see Part E): store category / subcategory / sub-subcategory where applicable (especially expense Other/Work classification and income detail taxonomy).
- Additional **manual note** always available.
- Attachments (photo/PDF) linked to transaction id.
- **Blank-line gap** after each entry: setting **1 or 2** empty visual lines (default **1**).

## C.5 Formulas (active fund set F)

```text
LineTotal = sum(amount[f] for f in F on that line)

आय योग[f]     = sum over income transaction lines of amount[f]
श्री पोते[f]    = opening / carried balance for f
महायोग_L[f]    = आय योग[f] + श्री पोते[f]

व्यय योग[f]    = sum over expense transaction lines of amount[f]
बचत पोते[f]    = महायोग_L[f] − व्यय योग[f]
महायोग_R[f]    = व्यय योग[f] + बचत पोते[f]
```

Summary lines (**श्री पोते, योग, बचत पोते, महायोग**) have **no manual edit UI**.

## C.6 Balance guards

1. **Overall (mandatory):** for a calendar date D,  
   `sum(all expense amounts on D) ≤ income-side महायोग applicable to D`  
   (implementation uses running opening + income through D − prior expense; must keep **overall book balance from going negative**).
2. **Per-scheme minus:** FY setting OFF (default) blocks scheme balance &lt; 0; ON allows scheme negative **without** violating (1).

## C.7 Pages, dates, empty days

- When transaction zone is full → **auto-create** next page; page numbers automatic.
- **Manual Add Page** always available.
- After last entry date → reserve **+2 blank pages**.
- **Empty days skipped** by default (do not consume lines).
- **Optional:** insert a page/marker for a specific empty calendar day between two dates.
- Store **transaction date**, **created at**, **updated at**, user id.
- Chronological order by transaction date; backdated entry recalculates page placement, all totals, carry-forward, reports; show impact warning.

## C.8 Carry-forward

```text
Next active date/page श्री पोते[f] = previous बचत पोते[f]
```

Page 1 openings = FY opening balances (from prior close or manual).

## C.9 Appearance (Cashbook Settings)

| Setting | Default |
|---------|---------|
| Page background | Light green register tint |
| Transaction font colour | **Blue** (ball-pen) |
| Income line-1 श्री पोते colour | **Light red** |
| Top श्री पोते + bottom-3 | Bold; font size = entry size **+1** |
| Bottom-3 font colour | Configurable |
| PDF/Excel export background | **Plain white** |

Other safe options (column width hints, show/hide ledger folio, etc.) with on-screen help text.

---

# PART D — Income & expense entry details

## D.1 Income

**Fields:** transaction date, invoice no/date, किससे प्राप्त, details, ledger folio, multi-fund amounts, total auto, scheme (required), category path, note, attachment.

**Source list (editable):** Govt, व्यक्ति, Bank, संस्था, Firm/Vendor, अन्य.

**Detail / income taxonomy:** managed as Category tree (Part E) — includes SFC, FFC, MP/MLA/TAD, पट्टा शुल्क, विवाह/जन्म/मृत्यु प्रमाण शुल्क, Other, plus user-defined.

## D.2 Expense

**Fields:** transaction date, voucher no/date, party/vendor, Work **or** Other, work name or other category path, ledger, multi-fund amounts, total auto, scheme required, note, attachment, payment mode Cash/Bank when needed for reconciliation.

**Party master:** select / add / search; vendor-wise reports.

**Work:** name required; master select or add; optional code, location/ward, sanction reference.

**Other:** category tree (Stationery, Printing, भत्ता, बिजली, सफाई, ईंधन, यात्रा, मरम्मत, डाक, बैठक, मोबाइल/इंटरनेट, अन्य, …).

## D.3 Repeat entry

Copy previous entry as template (monthly बिजली/सफाई etc.).

## D.4 Cancel entry

Reason required; print strikethrough (red); excluded from totals; remains in audit.

---

# PART E — Category / subcategory / sub-subcategory

## E.1 Model

Three levels maximum:

```text
Category
 └── Subcategory
      └── Sub-subcategory
```

Separate trees (or namespaced) for **Income** and **Expense** (and Work classification as needed).

## E.2 Management

- **Cashbook Settings** (and/or Masters): add / edit / correction / delete.
- If any transaction references a node → **archive** (not hard-delete); archived nodes remain on old rows for history.
- Every transaction should allow assigning the deepest applicable path; incomplete path flaggable in Monthly Check.

## E.3 Use

- गोशवारा grouping/filter  
- Ledgers by category path  
- Reports sort/filter  
- Identify all txns sharing same path  

---

# PART F — Auto ledgers & reports

- From **first saved transaction** of an FY, ledger and report views are available for that FY (may show single row).
- **No separate “generate report” prerequisite.**
- On every add / edit / cancel / category change → aggregates refresh.
- Empty state only when filtered set is truly empty — message explains why and next steps (e.g. “Is FY selected?”, “No expense in this category yet”).

### Compulsory on every report/page share

```text
Export Excel | Export PDF | Share Excel | Share PDF | Print
```

### Report catalogue (minimum)

1. Page-wise cashbook  
2. Date-wise  
3. Daily / weekly / monthly / custom range  
4. Full FY  
5. Income  
6. Expense  
7. Work-wise expenditure  
8. Other-category (tree) expenditure  
9. Vendor/firm-wise  
10. Fund/scheme-wise  
11. Ledger-folio-wise  
12. Category / sub / sub-sub wise  
13. Monthly dashboard  
14. गोशवारा till-date & annual  
15. Backdated entries  
16. Edited / corrected  
17. Cancelled  
18. Audit trail  
19. Validation / incomplete (missing scheme or category path)  
20. Reconciliation  
21. Attachments  
22. Pending verification  
23. Search results  

**Contextual reports:** from Cashbook, Bank, Work, Bill, गोशवारा, etc., with drill-down back to source transaction.

Excel = editable workbook (multiple sheets, filters, freeze, Hindi headings, formulas where useful).  
PDF = configured line layout, landscape options, **embedded Devanagari font**, white background for share, optional watermark/signatures.

---

# PART G — Bank statement (Phase 1)

- Bank account master  
- Upload PDF (password unlock)  
- AI/OCR → editable grid (user corrects before post)  
- Tag: scheme, work/category, or ignore  
- Grouping rules (multi-line one instrument), **D−1** date rule as adopted in discussion, instrument number  
- Post → cashbook entries (not free-text only — structured)  
- Month locked for re-upload when entries exist **and** verified  
- **No bank→cash withdrawal entry type** (GP practice)  
- Optional entry type: **Cash → Bank deposit** (reduces cash, increases bank; not income/expense)  
- Files under SAF FY folder  

---

# PART H — Works, MB, Bills, CC (Phase 1)

Full stack from discussion (not name-only):

- Ongoing works list; scheme-wise grouping/filter  
- Add old work with prior material/labour spent + optional bill-wise history  
- Work payments list → bills → material lines  
- **MB:** मद-वार material + कारीगर + labour; total valuation  
- **Man-days / master roll:** named workers and **group** rows (e.g. 5 labour × 12 days)  
- **Bill register** date-wise; bill date + cashbook payment date + page ref  
- **CC — 7 pages:** (1) Completion certificate with AS/TS/FS, MB refs, valuations, allowable = min rules (2) UC (3) Labour by pakhwada (4) Material as per MB (5) Technical verification (6) Completion photo + signatures (7) Before & during photos  
- **Live status residual:** after MB, residual from **CC allowable − payments** (material/labour separate); before MB from FS  
- Special case toggle when MB labour &gt; FS labour (documented warning)  
- Masters: BSR (year-wise rates), Workers/roles, Items (whole/decimal flags), Holidays (pakhwada)  
- Rate band: operator chooses within BSR −10%…−20% style guidance (not single fixed %)

---

# PART I — गोशवारा

- **Till date** from FY Home  
- **Annual 31 March** classified income (left) / expense (right)  
- Bottom lines: आय योग, प्रारंभिक बैंक/नकद; व्यय योग, अंतिम बैंक/नकद; महायोग equality check  
- Tap head → ledger of that head for the year  
- Optional monthly reminder (e.g. 5th) to share PDF  

---

# PART J — Dashboard & Monthly check

## J.1 FY Home dashboard

Financial year, opening, income, expense, current balance, pages, pending verification, missing attachments, unbalanced/incomplete flags. Quick actions: Add Income/Expense, Cashbook, Reports, Backup, Bank, Works.

## J.2 Monthly check

- Lists **all transactions** in the selected month/period (not only warnings).  
- Incomplete: missing **scheme** and/or **category / sub / sub-sub** → highlight + filter.  
- Tap row → edit / correct / cancel / fill classification.  
- Also surface: unverified pages, untagged bank lines, missing bill attachments, pending statements.

---

# PART K — App flow, settings, security

## K.1 Flow

```text
S-01 Login (Admin PIN + optional biometric)
  → S-02 Panchayat selection  +  [App Settings]
       → S-05 Financial Year (status + chooser)  +  [FY / Cashbook Settings]
            → S-06 FY Home
                 → Cashbook | Bank | Works | गोशवारा | Ledgers/Reports | Monthly check | Backup | …
```

## K.2 App Settings (canonical last screen number)

- Theme (multi-colour), logo, UI language (English/Hinglish), screen-number badge on/off  
- **Security:** change PIN; enable/disable biometric; re-enrol biometric  
- Panchayat add / edit / correction / delete — **destructive & edit require PIN re-confirm**  
- Global backup defaults  

## K.3 FY / Cashbook Settings (from S-05)

- FY add / edit / delete (confirm policy)  
- Scheme/fund CRUD for **this FY**; opening balance editor **visible**; red delete = **this FY only**  
- Line count L; blank gap 1|2; allow scheme negative ON/OFF  
- Appearance colours  
- Link to **Category tree** editors (income & expense)  
- Optional: insert-empty-day tools help text  

## K.4 Auth

- **Admin only** for Phase 1  
- PIN required to establish account; **biometric optional** thereafter  
- PIN or biometric unlock; Settings can toggle/change either  
- Future roles (Operator, Checker, Approver, Viewer) reserved in model, not exposed now  

## K.5 Navigation UX

- Hardware Back and in-app back → **parent** in stack; do not exit to Android Home until root confirm  
- No silent dead clicks — empty states with **why + steps**  
- Screen badges S-01…S-n; **renumber freely when screens added**; App Settings always **last**

---

# PART L — Storage, backup, audit (Phase 1)

## L.1 SAF layout (mandatory)

```text
Documents/Cashbook/
  <PanchayatName_or_Id>/
    <FY_Label>/
      database /
      exports /
      bank_statements /
      attachments /
      backups /
```

App uses Storage Access Framework; user-visible folder structure preferred.

## L.2 Backup / restore

- Auto-save after transactions  
- Manual backup; versioned list; restore  
- Backup before FY lock and before destructive schema/column changes  
- **Phone transfer wizard:** backup zip + **4-digit restore code** guided flow  
- Optional cloud later; not required to block Phase 1 if local SAF works  

## L.3 Audit trail

Log: user, time, entity id, action, field, old/new, reason. Prefer Cancelled/Archived over hard delete.

## L.4 Attachments

Receipt/bill/voucher/sanction/MB photo/PDF linked to txn; included in backup policy.

---

# PART M — Validation (non-exhaustive)

- Invalid dates; non-numeric amounts; negative amount prevention where policy says  
- Scheme required; category incompleteness warning (Monthly Check)  
- At least one fund amount &gt; 0  
- Work name if Work; other path if Other  
- Duplicate invoice/voucher warning  
- Expense vs day महायोग; optional scheme minus  
- Mahayog mismatch / unbalanced page warnings  
- Backdated impact confirmation  

**Money:** cashbook stores **paise-precision (2 decimal)**; other displays may round to rupee per earlier rounding policy.

---

# PART N — Suggested data entities

FinancialYear, Panchayat, Page, PageOpening (per fund), Transaction, TransactionAmount, FundColumn/Scheme, CategoryNode (level, parent, kind income|expense), IncomeSource, Work, Vendor, Attachment, BankAccount, BankStatement, BankLine, MeasurementBook, ManDayEntry, Bill, BillLine, CompletionCertificate, AuditLog, PeriodLock, User (admin), BackupRecord, AppSettings, FySettings, ExportHistory.

---

# PART O — Screen index (baseline; renumber when expanded)

> Numbers will be **rewritten** when screens are added. App Settings remains **last**.

| # | Screen | Notes |
|---|--------|--------|
| S-01 | Login | PIN + biometric |
| S-02 | Panchayat selection | + entry to App Settings |
| S-05 | Financial Year page | + FY/Cashbook Settings |
| S-06 | FY Home | Dashboard + module tiles |
| S-07 | Cashbook page view | N-line Option A |
| S-08 | Add/Edit Income | Multi-column + scheme + category |
| S-09 | Add/Edit Expense | Work/Other + scheme + category |
| S-10 | Entry detail / cancel / correct | |
| S-11+ | Page list / range share | PDF/Excel white |
| S-13–S-16 | Bank accounts / upload / tag / post | Phase 1 |
| S-17–S-26 | Works / MB / Man-days / Bills / CC | Phase 1 |
| S-27 | गोशवारा | Till-date + annual |
| S-28–S-34 | Ledgers & Reports Hub | Auto-updated |
| S-35 | Fund / column settings | |
| S-36–S-41 | BSR, Workers, Vendors, Items, Holidays, Users | |
| S-42 | Backup & restore | SAF |
| S-43 | Global search | |
| S-44 | Export centre | |
| S-45 | FY Closing wizard | |
| S-46 | New phone transfer | |
| S-xx | Category tree manager | Income & expense |
| S-xx | Monthly check (full txn list) | |
| S-**Last** | **App Settings** | PIN/biometric, theme, panchayat CRUD |

*(Exact numeric assignment to be frozen in implementation sprint 1 after UI list freeze.)*

---

# PART P — Phase 1 build order (recommended)

1. Admin PIN + biometric + App Settings security toggles  
2. SAF folder bootstrap + FY-scoped DB  
3. Panchayat / FY settings hierarchy  
4. Fund columns + **page engine Option A (L=25)** + openings  
5. Income/expense save with multi-column amounts + **scheme required** + category path  
6. **Strict FY filter** (regression: old year entries never leak)  
7. Carry-forward balances only; indicators CF/Manual  
8. Auto ledgers/reports refresh pipeline  
9. Monthly check full list + incomplete classification  
10. PDF/Excel page export (white)  
11. Backup/restore SAF  
12. Bank statement pipeline  
13. Works → MB → Bills → CC  
14. गोशवारा + FY closing wizard  
15. Empty-day insert option; +2 pages; polish navigation/empty states  

---

# PART Q — Acceptance criteria (Phase 1 gate)

- [ ] Default 25-line page; 21 txn lines; Option A blank expense line 1  
- [ ] Multi-column amounts + scheme mandatory (default SFC)  
- [ ] Summary lines not user-editable; formulas correct; left/right महायोग coherent  
- [ ] Switching FY never shows previous FY transaction rows; only openings carried  
- [ ] Category 3-level CRUD; archive if in use; filter in गोशवारा/ledgers  
- [ ] First entry makes ledgers/reports meaningful; each entry updates them  
- [ ] Monthly check lists all period txns; can set scheme/category there  
- [ ] Biometric optional; PIN/biometric change in App Settings  
- [ ] SAF Documents/Cashbook tree used for DB exports/statements/backups  
- [ ] Bank upload→tag→post path works for at least one statement PDF fixture  
- [ ] One work can go MB → bill → CC allowable residual path  
- [ ] Excel + PDF export on cashbook page and one summary report  
- [ ] Back navigation stays inside app stack  
- [ ] Day expense ≤ day mahayog enforced; scheme-minus respects FY flag  
- [ ] Auto + manual new page; empty day skip; optional empty-day insert  

---

# PART R — Deferred (explicitly not blocking Phase 1 doc)

- Multi-role Operator/Checker/Approver/Viewer UI  
- Fixed Play-style signing keystore documentation  
- TDS/GST  
- Multi-device realtime sync  
- Demo/sample training mode (rejected earlier)  

---

# PART S — Contradiction resolution (reference)

| Conflict | Resolution |
|----------|------------|
| 25 vs 30 lines | Default **25**; setting changes L; txn = L−4 |
| श्री पोते top vs only bottom | **Option A** both top+bottom income; expense top blank |
| Single scheme vs multi-column | **Both**: columns hold amounts; scheme required on entry |
| Admin vs multi-role | Admin only now |
| Entries vs balances on new FY | **Balances only** |
| Report “generate” step | **None** — auto from data |
| Bank/Works scope | **In Phase 1** |

---

**End of master document.**  
Implementation and GitHub issues should quote Part/section ids (e.g. `C.2`, `D17`, `Q`).
