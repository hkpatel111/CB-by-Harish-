import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { useStore } from '@/context/AppStore';
import colors from '@/constants/colors';

export function ScreenBadge({ label }: { label: string }) {
  const { app } = useStore();
  if (!app.showScreenBadge) return null;
  return (
    <View style={styles.badge}>
      <Text style={styles.text}>{label}</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  badge: { backgroundColor: 'rgba(0,0,0,0.2)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  text: { color: '#fff', fontSize: 10, fontWeight: '800' },
});
