import React from 'react';
import { Text, View, Pressable, StyleSheet } from 'react-native';

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { err?: Error }> {
  state = { err: undefined as Error | undefined };
  static getDerivedStateFromError(err: Error) {
    return { err };
  }
  render() {
    if (this.state.err) {
      return (
        <View style={s.box}>
          <Text style={s.t}>Something went wrong</Text>
          <Text style={s.m}>{this.state.err.message}</Text>
          <Pressable onPress={() => this.setState({ err: undefined })}>
            <Text style={s.b}>Retry</Text>
          </Pressable>
        </View>
      );
    }
    return this.props.children;
  }
}
const s = StyleSheet.create({
  box: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  t: { fontSize: 18, fontWeight: '800' },
  m: { marginVertical: 12, textAlign: 'center' },
  b: { color: '#1e6048', fontWeight: '800' },
});
