/** PROJECT_MASTER — core domain types (Phase 1) */

export type Id = string;

export type Fund = {
  id: Id;
  name: string;
  shortName: string;
  openingBalance: number;
  enabled: boolean;
  openingSource: 'carry-forward' | 'manual';
  sortOrder: number;
};

export type CategoryKind = 'income' | 'expense';

export type CategoryNode = {
  id: Id;
  kind: CategoryKind;
  name: string;
  parentId: Id | null;
  level: 1 | 2 | 3;
  archived: boolean;
};

export type Panchayat = {
  id: Id;
  name: string;
  block: string;
  district: string;
};

export type FinancialYear = {
  id: Id;
  label: string;
  start: string;
  end: string;
  locked: boolean;
};

export type TxType = 'income' | 'expense';

export type Transaction = {
  id: Id;
  fyId: Id;
  type: TxType;
  date: string;
  reference: string;
  party: string;
  detail: string;
  note: string;
  schemeId: Id;
  amounts: Record<string, number>;
  categoryId: Id | null;
  subcategoryId: Id | null;
  subSubcategoryId: Id | null;
  workId: Id | null;
  expenseKind: 'work' | 'other' | null;
  status: 'active' | 'cancelled';
  createdAt: string;
  updatedAt: string;
};

export type Work = {
  id: Id;
  fyId: Id;
  name: string;
  schemeId: Id;
  ward: string;
  sanctionRef: string;
  materialPrior: number;
  labourPrior: number;
  status: 'ongoing' | 'completed';
};

export type MbLine = {
  id: Id;
  workId: Id;
  itemName: string;
  qty: number;
  rate: number;
  kind: 'material' | 'labour' | 'artisan';
};

export type Bill = {
  id: Id;
  workId: Id;
  fyId: Id;
  billDate: string;
  paymentDate: string;
  pageRef: string;
  vendor: string;
  amount: number;
  note: string;
};

export type BankAccount = {
  id: Id;
  name: string;
  accountNo: string;
  bankName: string;
};

export type BankLine = {
  id: Id;
  accountId: Id;
  fyId: Id;
  statementMonth: string;
  date: string;
  narration: string;
  amount: number;
  side: 'credit' | 'debit';
  instrument: string;
  schemeId: Id | null;
  workId: Id | null;
  ignored: boolean;
  postedTxnId: Id | null;
};

export type FySettings = {
  lineCount: number;
  blankLineGap: 1 | 2;
  allowSchemeNegative: boolean;
  pageBackground: string;
  entryFontColor: string;
  shriPoteColor: string;
  summaryFontColor: string;
};

export type AppSettings = {
  pin: string | null;
  biometricEnabled: boolean;
  setupComplete: boolean;
  adminName: string;
  themeId: string;
  language: 'hi' | 'en' | 'hinglish';
  showScreenBadge: boolean;
};

export type RootData = {
  version: 3;
  app: AppSettings;
  fySettings: FySettings;
  panchayats: Panchayat[];
  activePanchayatId: Id;
  financialYears: FinancialYear[];
  activeFinancialYearId: Id;
  funds: Fund[];
  categories: CategoryNode[];
  transactions: Transaction[];
  works: Work[];
  mbLines: MbLine[];
  bills: Bill[];
  bankAccounts: BankAccount[];
  bankLines: BankLine[];
};
