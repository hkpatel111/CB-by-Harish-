import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type {
  AppSettings,
  BankAccount,
  BankLine,
  Bill,
  CategoryNode,
  FinancialYear,
  Fund,
  FySettings,
  MbLine,
  Panchayat,
  RootData,
  Transaction,
  Work,
} from '@/types/models';
import { dayExpenseTotal, dayMahayog, formatINR, schemeBalance, sumAmounts } from '@/services/pageEngine';

const STORAGE = 'gpc-cashbook-v3';

const defaultFySettings: FySettings = {
  lineCount: 25,
  blankLineGap: 1,
  allowSchemeNegative: false,
  pageBackground: '#E9F4E9',
  entryFontColor: '#1565C0',
  shriPoteColor: '#C62828',
  summaryFontColor: '#1B5E20',
};

const seedFunds: Fund[] = [
  { id: 'cash', name: 'Cash / नकद', shortName: 'Cash', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 0 },
  { id: 'sfc', name: 'SFC', shortName: 'SFC', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 1 },
  { id: 'ffc', name: 'FFC', shortName: 'FFC', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 2 },
  { id: 'own', name: 'Own Fund / Interest', shortName: 'Own', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 3 },
  { id: 'mp', name: 'MP / MLA / TAD', shortName: 'MP/MLA', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 4 },
];

const seedCategories: CategoryNode[] = [
  { id: 'inc-sfc', kind: 'income', name: 'SFC', parentId: null, level: 1, archived: false },
  { id: 'inc-ffc', kind: 'income', name: 'FFC', parentId: null, level: 1, archived: false },
  { id: 'inc-fee', kind: 'income', name: 'शुल्क', parentId: null, level: 1, archived: false },
  { id: 'inc-fee-birth', kind: 'income', name: 'जन्म प्रमाण', parentId: 'inc-fee', level: 2, archived: false },
  { id: 'inc-fee-death', kind: 'income', name: 'मृत्यु प्रमाण', parentId: 'inc-fee', level: 2, archived: false },
  { id: 'inc-fee-marriage', kind: 'income', name: 'विवाह पंजीयन', parentId: 'inc-fee', level: 2, archived: false },
  { id: 'exp-stat', kind: 'expense', name: 'Stationery', parentId: null, level: 1, archived: false },
  { id: 'exp-power', kind: 'expense', name: 'बिजली शुल्क', parentId: null, level: 1, archived: false },
  { id: 'exp-clean', kind: 'expense', name: 'सफाई कार्य', parentId: null, level: 1, archived: false },
  { id: 'exp-work', kind: 'expense', name: 'Work / कार्य', parentId: null, level: 1, archived: false },
];

const seedPanchayat: Panchayat = { id: 'gp-mal', name: 'ग्राम पंचायत माल', block: 'साबला', district: 'डूंगरपुर' };
const seedFy: FinancialYear = { id: 'fy-2026-27', label: '2026–27', start: '2026-04-01', end: '2027-03-31', locked: false };

const defaultData: RootData = {
  version: 3,
  app: {
    pin: null,
    biometricEnabled: false,
    setupComplete: false,
    adminName: 'Admin',
    themeId: 'green',
    language: 'hinglish',
    showScreenBadge: true,
  },
  fySettings: defaultFySettings,
  panchayats: [seedPanchayat],
  activePanchayatId: seedPanchayat.id,
  financialYears: [seedFy],
  activeFinancialYearId: seedFy.id,
  funds: seedFunds,
  categories: seedCategories,
  transactions: [],
  works: [],
  mbLines: [],
  bills: [],
  bankAccounts: [{ id: 'ba1', name: 'GP Main', accountNo: 'XXXX1234', bankName: 'SBI' }],
  bankLines: [],
};

type Store = RootData & {
  hydrated: boolean;
  activePanchayat: Panchayat;
  activeFy: FinancialYear;
  activeFunds: Fund[];
  /** STRICT FY filter — only current FY transactions */
  fyTransactions: Transaction[];
  totalOpening: number;
  totalIncome: number;
  totalExpense: number;
  currentBalance: number;
  setPin: (pin: string) => Promise<void>;
  verifyPin: (pin: string) => boolean;
  setBiometricEnabled: (v: boolean) => Promise<void>;
  updateApp: (p: Partial<AppSettings>) => Promise<void>;
  updateFySettings: (p: Partial<FySettings>) => Promise<void>;
  setActivePanchayatId: (id: string) => void;
  setActiveFinancialYearId: (id: string) => void;
  addPanchayat: (p: Omit<Panchayat, 'id'>) => Promise<void>;
  updatePanchayat: (id: string, p: Partial<Panchayat>) => Promise<void>;
  deletePanchayat: (id: string) => Promise<{ ok: boolean; error?: string }>;
  addFinancialYear: (label: string, start: string, end: string) => Promise<void>;
  closeFinancialYearCarryForward: (fromFyId: string, toLabel: string, toStart: string, toEnd: string) => Promise<void>;
  addFund: (name: string, opening: number, source?: 'carry-forward' | 'manual') => Promise<void>;
  updateFundOpening: (id: string, opening: number, source?: 'carry-forward' | 'manual') => Promise<void>;
  deleteFundFy: (id: string) => Promise<void>;
  addCategory: (kind: 'income' | 'expense', name: string, parentId: string | null) => Promise<void>;
  archiveCategory: (id: string) => Promise<void>;
  renameCategory: (id: string, name: string) => Promise<void>;
  addTransaction: (
    t: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'fyId'>
  ) => Promise<{ ok: true } | { ok: false; error: string }>;
  updateTransaction: (id: string, patch: Partial<Transaction>) => Promise<{ ok: true } | { ok: false; error: string }>;
  cancelTransaction: (id: string) => Promise<void>;
  addWork: (w: Omit<Work, 'id'>) => Promise<void>;
  addMbLine: (line: Omit<MbLine, 'id'>) => Promise<void>;
  addBill: (b: Omit<Bill, 'id'>) => Promise<void>;
  addBankLine: (line: Omit<BankLine, 'id'>) => Promise<void>;
  updateBankLine: (id: string, patch: Partial<BankLine>) => Promise<void>;
  postBankLineToCashbook: (lineId: string) => Promise<{ ok: boolean; error?: string }>;
  exportCsvForFy: () => string;
};

const Ctx = createContext<Store | null>(null);

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export function AppStoreProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<RootData>(defaultData);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE)
      .then((raw) => {
        if (!raw) return;
        const parsed = JSON.parse(raw);
        setData({
          ...defaultData,
          ...parsed,
          app: { ...defaultData.app, ...(parsed.app || {}) },
          fySettings: { ...defaultFySettings, ...(parsed.fySettings || {}) },
          funds: parsed.funds?.length ? parsed.funds : seedFunds,
          categories: parsed.categories?.length ? parsed.categories : seedCategories,
          financialYears: parsed.financialYears?.length ? parsed.financialYears : [seedFy],
          panchayats: parsed.panchayats?.length ? parsed.panchayats : [seedPanchayat],
        });
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (hydrated) AsyncStorage.setItem(STORAGE, JSON.stringify(data)).catch(() => undefined);
  }, [data, hydrated]);

  const value = useMemo<Store>(() => {
    const activeFunds = data.funds.filter((f) => f.enabled).sort((a, b) => a.sortOrder - b.sortOrder);
    const activePanchayat = data.panchayats.find((p) => p.id === data.activePanchayatId) || data.panchayats[0];
    const activeFy = data.financialYears.find((f) => f.id === data.activeFinancialYearId) || data.financialYears[0];
    // CRITICAL: FY isolation — only this FY's transactions
    const fyTransactions = data.transactions.filter((t) => t.fyId === activeFy.id);
    const totalOpening = activeFunds.reduce((s, f) => s + f.openingBalance, 0);
    const totalIncome = fyTransactions
      .filter((t) => t.status === 'active' && t.type === 'income')
      .reduce((s, t) => s + sumAmounts(t.amounts), 0);
    const totalExpense = fyTransactions
      .filter((t) => t.status === 'active' && t.type === 'expense')
      .reduce((s, t) => s + sumAmounts(t.amounts), 0);

    return {
      ...data,
      hydrated,
      activePanchayat,
      activeFy,
      activeFunds,
      fyTransactions,
      totalOpening,
      totalIncome,
      totalExpense,
      currentBalance: totalOpening + totalIncome - totalExpense,
      setPin: async (pin) => setData((d) => ({ ...d, app: { ...d.app, pin, setupComplete: true } })),
      verifyPin: (pin) => !!data.app.pin && data.app.pin === pin,
      setBiometricEnabled: async (v) => setData((d) => ({ ...d, app: { ...d.app, biometricEnabled: v } })),
      updateApp: async (p) => setData((d) => ({ ...d, app: { ...d.app, ...p } })),
      updateFySettings: async (p) => setData((d) => ({ ...d, fySettings: { ...d.fySettings, ...p } })),
      setActivePanchayatId: (id) => setData((d) => ({ ...d, activePanchayatId: id })),
      setActiveFinancialYearId: (id) => setData((d) => ({ ...d, activeFinancialYearId: id })),
      addPanchayat: async (p) => {
        const id = 'gp-' + uid();
        setData((d) => ({ ...d, panchayats: [...d.panchayats, { ...p, id }], activePanchayatId: id }));
      },
      updatePanchayat: async (id, p) =>
        setData((d) => ({ ...d, panchayats: d.panchayats.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
      deletePanchayat: async (id) => {
        if (data.panchayats.length <= 1) return { ok: false, error: 'कम से कम एक पंचायत' };
        setData((d) => {
          const panchayats = d.panchayats.filter((x) => x.id !== id);
          return {
            ...d,
            panchayats,
            activePanchayatId: d.activePanchayatId === id ? panchayats[0].id : d.activePanchayatId,
          };
        });
        return { ok: true };
      },
      addFinancialYear: async (label, start, end) => {
        const id = 'fy-' + uid();
        setData((d) => ({
          ...d,
          financialYears: [...d.financialYears, { id, label, start, end, locked: false }],
          activeFinancialYearId: id,
        }));
      },
      closeFinancialYearCarryForward: async (fromFyId, toLabel, toStart, toEnd) => {
        // Closing balances → new FY openings only (no entry copy)
        const fromTx = data.transactions.filter((t) => t.fyId === fromFyId && t.status === 'active');
        setData((d) => {
          const funds = d.funds.map((f) => {
            const bal = schemeBalance(f.id, f.openingBalance, fromTx);
            return { ...f, openingBalance: bal, openingSource: 'carry-forward' as const };
          });
          const id = 'fy-' + uid();
          return {
            ...d,
            funds,
            financialYears: [
              ...d.financialYears.map((fy) => (fy.id === fromFyId ? { ...fy, locked: true } : fy)),
              { id, label: toLabel, start: toStart, end: toEnd, locked: false },
            ],
            activeFinancialYearId: id,
          };
        });
      },
      addFund: async (name, opening, source = 'manual') => {
        const n = name.trim();
        if (!n) return;
        setData((d) => ({
          ...d,
          funds: [
            ...d.funds,
            {
              id: uid(),
              name: n,
              shortName: n.slice(0, 10),
              openingBalance: opening,
              enabled: true,
              openingSource: source,
              sortOrder: d.funds.length,
            },
          ],
        }));
      },
      updateFundOpening: async (id, opening, source) =>
        setData((d) => ({
          ...d,
          funds: d.funds.map((f) =>
            f.id === id ? { ...f, openingBalance: opening, openingSource: source ?? f.openingSource } : f
          ),
        })),
      deleteFundFy: async (id) =>
        setData((d) => ({ ...d, funds: d.funds.map((f) => (f.id === id ? { ...f, enabled: false } : f)) })),
      addCategory: async (kind, name, parentId) => {
        const parent = parentId ? data.categories.find((c) => c.id === parentId) : null;
        const level = parent ? ((parent.level + 1) as 1 | 2 | 3) : 1;
        if (level > 3) return;
        setData((d) => ({
          ...d,
          categories: [
            ...d.categories,
            { id: uid(), kind, name: name.trim(), parentId, level, archived: false },
          ],
        }));
      },
      archiveCategory: async (id) =>
        setData((d) => ({
          ...d,
          categories: d.categories.map((c) => (c.id === id ? { ...c, archived: true } : c)),
        })),
      renameCategory: async (id, name) =>
        setData((d) => ({
          ...d,
          categories: d.categories.map((c) => (c.id === id ? { ...c, name } : c)),
        })),
      addTransaction: async (t) => {
        if (!t.schemeId) return { ok: false as const, error: 'Scheme चुनना अनिवार्य है' };
        const lineTotal = sumAmounts(t.amounts);
        if (lineTotal <= 0) return { ok: false as const, error: 'कम से कम एक राशि > 0' };
        const opening = totalOpening;
        if (t.type === 'expense') {
          const mahayog = dayMahayog(opening, fyTransactions, t.date);
          const already = dayExpenseTotal(fyTransactions, t.date);
          if (already + lineTotal > mahayog + 0.001) {
            return { ok: false as const, error: `व्यय इस दिन के महायोग (${formatINR(mahayog)}) से अधिक नहीं` };
          }
          if (!data.fySettings.allowSchemeNegative) {
            const fund = activeFunds.find((f) => f.id === t.schemeId);
            const bal =
              schemeBalance(t.schemeId, fund?.openingBalance ?? 0, fyTransactions) - lineTotal;
            if (bal < -0.001) return { ok: false as const, error: `Scheme ${fund?.shortName} minus नहीं` };
          }
        }
        const now = new Date().toISOString();
        setData((d) => ({
          ...d,
          transactions: [
            ...d.transactions,
            {
              ...t,
              id: uid(),
              fyId: d.activeFinancialYearId,
              status: 'active',
              createdAt: now,
              updatedAt: now,
            },
          ],
        }));
        return { ok: true as const };
      },
      updateTransaction: async (id, patch) => {
        setData((d) => ({
          ...d,
          transactions: d.transactions.map((t) =>
            t.id === id ? { ...t, ...patch, updatedAt: new Date().toISOString() } : t
          ),
        }));
        return { ok: true as const };
      },
      cancelTransaction: async (id) =>
        setData((d) => ({
          ...d,
          transactions: d.transactions.map((t) =>
            t.id === id ? { ...t, status: 'cancelled', updatedAt: new Date().toISOString() } : t
          ),
        })),
      addWork: async (w) => setData((d) => ({ ...d, works: [...d.works, { ...w, id: uid() }] })),
      addMbLine: async (line) => setData((d) => ({ ...d, mbLines: [...d.mbLines, { ...line, id: uid() }] })),
      addBill: async (b) => setData((d) => ({ ...d, bills: [...d.bills, { ...b, id: uid() }] })),
      addBankLine: async (line) => setData((d) => ({ ...d, bankLines: [...d.bankLines, { ...line, id: uid() }] })),
      updateBankLine: async (id, patch) =>
        setData((d) => ({
          ...d,
          bankLines: d.bankLines.map((l) => (l.id === id ? { ...l, ...patch } : l)),
        })),
      postBankLineToCashbook: async (lineId) => {
        const line = data.bankLines.find((l) => l.id === lineId);
        if (!line || line.ignored) return { ok: false, error: 'Line invalid' };
        if (!line.schemeId) return { ok: false, error: 'Scheme tag required' };
        if (line.postedTxnId) return { ok: false, error: 'Already posted' };
        const type = line.side === 'credit' ? 'income' : 'expense';
        const now = new Date().toISOString();
        const txnId = uid();
        setData((d) => ({
          ...d,
          transactions: [
            ...d.transactions,
            {
              id: txnId,
              fyId: d.activeFinancialYearId,
              type,
              date: line.date,
              reference: line.instrument,
              party: line.narration.slice(0, 40),
              detail: 'Bank auto-entry',
              note: `Bank ${line.statementMonth}`,
              schemeId: line.schemeId!,
              amounts: { [line.schemeId!]: Math.abs(line.amount) },
              categoryId: null,
              subcategoryId: null,
              subSubcategoryId: null,
              workId: line.workId,
              expenseKind: line.workId ? 'work' : 'other',
              status: 'active',
              createdAt: now,
              updatedAt: now,
            },
          ],
          bankLines: d.bankLines.map((l) => (l.id === lineId ? { ...l, postedTxnId: txnId } : l)),
        }));
        return { ok: true };
      },
      exportCsvForFy: () => {
        const rows = [['id', 'type', 'date', 'party', 'scheme', 'total', 'category', 'status']];
        for (const t of fyTransactions) {
          rows.push([
            t.id,
            t.type,
            t.date,
            t.party,
            t.schemeId,
            String(sumAmounts(t.amounts)),
            [t.categoryId, t.subcategoryId, t.subSubcategoryId].filter(Boolean).join('/'),
            t.status,
          ]);
        }
        return rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
      },
    };
  }, [data, hydrated]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useStore outside provider');
  return v;
}

export { formatINR };
