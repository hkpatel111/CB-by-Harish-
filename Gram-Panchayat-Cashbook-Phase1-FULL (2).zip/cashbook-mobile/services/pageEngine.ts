/** PROJECT_MASTER Part C — page engine helpers */

export function transactionLineCount(totalLines: number) {
  return Math.max(1, totalLines - 4);
}

export function sumAmounts(amounts: Record<string, number>) {
  return Object.values(amounts).reduce((s, a) => s + (Number(a) || 0), 0);
}

export function formatINR(n: number) {
  const neg = n < 0;
  const abs = Math.abs(Math.round(n * 100) / 100);
  const [r, p] = abs.toFixed(2).split('.');
  return `${neg ? '-' : ''}₹${r.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}.${p}`;
}

export type TxLike = {
  type: 'income' | 'expense';
  date: string;
  status: string;
  amounts: Record<string, number>;
  schemeId: string;
};

/** Day महायोग approximation: opening + income through date - expense before date */
export function dayMahayog(
  opening: number,
  txs: TxLike[],
  date: string
): number {
  const active = txs.filter((t) => t.status === 'active');
  const incomeToDate = active
    .filter((t) => t.type === 'income' && t.date <= date)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const expenseBefore = active
    .filter((t) => t.type === 'expense' && t.date < date)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
  return opening + incomeToDate - expenseBefore;
}

export function dayExpenseTotal(txs: TxLike[], date: string) {
  return txs
    .filter((t) => t.status === 'active' && t.type === 'expense' && t.date === date)
    .reduce((s, t) => s + sumAmounts(t.amounts), 0);
}

export function schemeBalance(
  fundId: string,
  opening: number,
  txs: TxLike[]
) {
  const active = txs.filter((t) => t.status === 'active' && t.schemeId === fundId);
  const inc = active.filter((t) => t.type === 'income').reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const exp = active.filter((t) => t.type === 'expense').reduce((s, t) => s + sumAmounts(t.amounts), 0);
  return opening + inc - exp;
}

export function pageTotals(
  openingByFund: Record<string, number>,
  fundIds: string[],
  incomeLines: Record<string, number>[],
  expenseLines: Record<string, number>[]
) {
  const aayYog: Record<string, number> = {};
  const vyayYog: Record<string, number> = {};
  const shri: Record<string, number> = {};
  const mahayogL: Record<string, number> = {};
  const bachat: Record<string, number> = {};
  const mahayogR: Record<string, number> = {};
  for (const f of fundIds) {
    aayYog[f] = incomeLines.reduce((s, line) => s + (line[f] || 0), 0);
    vyayYog[f] = expenseLines.reduce((s, line) => s + (line[f] || 0), 0);
    shri[f] = openingByFund[f] || 0;
    mahayogL[f] = aayYog[f] + shri[f];
    bachat[f] = mahayogL[f] - vyayYog[f];
    mahayogR[f] = vyayYog[f] + bachat[f];
  }
  return { aayYog, vyayYog, shri, mahayogL, bachat, mahayogR };
}
