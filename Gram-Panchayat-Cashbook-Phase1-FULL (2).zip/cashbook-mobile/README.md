# Gram Panchayat Cashbook — Phase 1 Source

Implements **PROJECT_MASTER.md** (20-09-2026 FINAL) in one Expo (React Native) app.

## Included (discussion scope)

- Admin PIN + biometric toggle (App Settings)
- Round-5 navigation hierarchy + hardware back → parent
- FY isolation: **only balances** carry forward; entries never cross FY
- Cashbook Option A, default **25 lines / 21 txn**, multi-column amounts + **scheme required**
- Category → sub → sub-sub CRUD + archive
- Auto ledgers / गोशवारा from first entry
- Monthly check: all txns + fill missing scheme/category
- Bank lines → tag scheme → post to cashbook
- Works → MB lines → Bills → CC 7-page outline
- CSV share export; SAF path documented for device builds
- Balance guards (day mahayog, scheme-minus flag)
- `PROJECT_MASTER.md` bundled in project root

## Run

```bash
cd cashbook-mobile
npm install   # or pnpm install
npx expo start
```

## Note

True bank **PDF OCR**, native **PDF page printer**, and **SAF folder create** need device permissions / native modules on release builds — data models and UI flows are wired; CSV share works immediately offline.
