/**
 * Gram Panchayat Cashbook — Phase 1 full UI
 * PROJECT_MASTER.md (20-09-2026 FINAL)
 */
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useMemo, useState } from 'react';
import {
  Alert,
  BackHandler,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import colors from '@/constants/colors';
import { formatINR, useStore } from '@/context/AppStore';
import { ScreenBadge } from '@/components/ScreenBadge';
import { sumAmounts, transactionLineCount } from '@/services/pageEngine';
import type { Transaction } from '@/types/models';

const C = colors.light;

type Stage =
  | 'login'
  | 'panchayat'
  | 'appSettings'
  | 'fy'
  | 'fySettings'
  | 'home'
  | 'cashbook'
  | 'entry'
  | 'funds'
  | 'categories'
  | 'monthly'
  | 'goswara'
  | 'reports'
  | 'ledgers'
  | 'backup'
  | 'bank'
  | 'works'
  | 'workDetail'
  | 'mb'
  | 'bills'
  | 'cc';

function Btn({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'soft' | 'outline' | 'danger';
  icon?: keyof typeof Feather.glyphMap;
  disabled?: boolean;
}) {
  const bg =
    variant === 'primary' ? C.primary : variant === 'danger' ? C.expenseSoft : variant === 'soft' ? C.primarySoft : 'transparent';
  const fg = variant === 'primary' ? '#fff' : variant === 'danger' ? C.expense : C.primary;
  return (
    <Pressable
      disabled={disabled}
      onPress={() => {
        Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.btn,
        { backgroundColor: bg, borderColor: variant === 'outline' ? C.border : bg, opacity: disabled ? 0.4 : pressed ? 0.85 : 1 },
      ]}
    >
      {icon ? <Feather name={icon} size={16} color={fg} /> : null}
      <Text style={[styles.btnText, { color: fg }]}>{label}</Text>
    </Pressable>
  );
}

function IconBtn({ name, onPress }: { name: keyof typeof Feather.glyphMap; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.iconBtn}>
      <Feather name={name} size={18} color="#fff" />
    </Pressable>
  );
}

function Header({
  title,
  eyebrow,
  onBack,
  badge,
  action,
}: {
  title: string;
  eyebrow?: string;
  onBack?: () => void;
  badge?: string;
  action?: React.ReactNode;
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? 40 : insets.top) + 6 }]}>
      <View style={styles.headerRow}>
        {onBack ? <IconBtn name="arrow-left" onPress={onBack} /> : <View style={styles.mark}><Feather name="book-open" size={16} color="#fff" /></View>}
        <View style={{ flex: 1 }}>
          {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
          <Text style={styles.hTitle}>{title}</Text>
        </View>
        {action}
        {badge ? <ScreenBadge label={badge} /> : null}
      </View>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  keyboardType = 'default',
  secureTextEntry,
  multiline,
  placeholder,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  keyboardType?: 'default' | 'numeric';
  secureTextEntry?: boolean;
  multiline?: boolean;
  placeholder?: string;
}) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        multiline={multiline}
        placeholder={placeholder}
        placeholderTextColor={C.mutedForeground}
        style={[styles.field, multiline && { minHeight: 70, textAlignVertical: 'top' }]}
      />
    </View>
  );
}

function Empty({ title, why, steps }: { title: string; why: string; steps: string[] }) {
  return (
    <View style={styles.empty}>
      <Feather name="info" size={20} color={C.primary} />
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyWhy}>{why}</Text>
      {steps.map((s, i) => (
        <Text key={i} style={styles.emptyStep}>
          {i + 1}. {s}
        </Text>
      ))}
    </View>
  );
}

function PinModal({
  open,
  title,
  onCancel,
  onOk,
}: {
  open: boolean;
  title: string;
  onCancel: () => void;
  onOk: () => void;
}) {
  const { verifyPin } = useStore();
  const [pin, setPin] = useState('');
  return (
    <Modal visible={open} transparent animationType="fade">
      <View style={styles.modalBg}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>{title}</Text>
          <Field label="Admin PIN" value={pin} onChangeText={setPin} secureTextEntry keyboardType="numeric" />
          <View style={styles.row}>
            <Btn label="Cancel" variant="outline" onPress={onCancel} />
            <Btn
              label="Confirm"
              onPress={() => {
                if (!verifyPin(pin)) {
                  Alert.alert('गलत PIN');
                  return;
                }
                setPin('');
                onOk();
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* ——— LOGIN ——— */
function LoginScreen({ onDone }: { onDone: () => void }) {
  const { app, setPin, verifyPin } = useStore();
  const [pin, setPinLocal] = useState('');
  const [confirm, setConfirm] = useState('');
  const [err, setErr] = useState('');


  const submit = async () => {
    if (!app.setupComplete || !app.pin) {
      if (pin.length < 4) return setErr('PIN ≥ 4');
      if (pin !== confirm) return setErr('PIN match नहीं');
      await setPin(pin);
      onDone();
      return;
    }
    if (!verifyPin(pin)) return setErr('गलत PIN');
    onDone();
  };

  return (
    <View style={styles.dark}>
      <StatusBar style="light" />
      <View style={styles.loginPad}>
        <Text style={styles.brand}>ADMIN · PHASE 1</Text>
        <Text style={styles.loginHi}>{!app.pin ? 'PIN सेट करें' : 'Login'}</Text>
        <Text style={styles.loginSub}>PIN + optional biometric (Settings से toggle)</Text>
        <Field label="PIN" value={pin} onChangeText={setPinLocal} secureTextEntry keyboardType="numeric" />
        {!app.pin ? <Field label="Confirm PIN" value={confirm} onChangeText={setConfirm} secureTextEntry keyboardType="numeric" /> : null}
        {err ? <Text style={styles.err}>{err}</Text> : null}
        <Btn label={!app.pin ? 'Save & Continue' : 'Login with PIN'} icon="log-in" onPress={submit} />
        {null}
        <ScreenBadge label="S-01" />
      </View>
    </View>
  );
}

function PanchayatScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { panchayats, activePanchayatId, setActivePanchayatId, activePanchayat } = useStore();
  return (
    <View style={styles.page}>
      <Header title="Panchayat" eyebrow="Select" onBack={onBack} badge="S-02" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>⚙ App Settings — PIN/biometric, पंचायत CRUD</Text>
        {panchayats.map((p) => (
          <Pressable key={p.id} onPress={() => setActivePanchayatId(p.id)} style={[styles.card, activePanchayatId === p.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <Text style={styles.meta}>{p.block} · {p.district}</Text>
          </Pressable>
        ))}
        <Btn label="Continue" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Active: {activePanchayat.name}</Text>
      </ScrollView>
    </View>
  );
}

function AppSettingsScreen({ onBack }: { onBack: () => void }) {
  const { app, updateApp, setBiometricEnabled, setPin, panchayats, addPanchayat, deletePanchayat, updatePanchayat } = useStore();
  const [name, setName] = useState('');
  const [block, setBlock] = useState('');
  const [dist, setDist] = useState('');
  const [newPin, setNewPin] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  const [pending, setPending] = useState<null | (() => void)>(null);

  return (
    <View style={styles.page}>
      <Header title="App Settings" onBack={onBack} badge="S-Last" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.section}>Security</Text>
        <Field label="Change PIN (new)" value={newPin} onChangeText={setNewPin} secureTextEntry keyboardType="numeric" />
        <Btn
          label="Update PIN"
          onPress={() => {
            if (newPin.length < 4) return Alert.alert('PIN ≥ 4');
            setPending(() => async () => {
              await setPin(newPin);
              setNewPin('');
              Alert.alert('PIN updated');
            });
            setPinOpen(true);
          }}
        />
        <Btn
          label="Biometric (next build)"
          variant="outline"
          onPress={() => Alert.alert('Biometric', 'Is build me PIN login stable rakhne ke liye biometric native module band hai.')}
        />
        <Btn
          label={`Screen badges: ${app.showScreenBadge ? 'ON' : 'OFF'}`}
          variant="outline"
          onPress={() => updateApp({ showScreenBadge: !app.showScreenBadge })}
        />

        <Text style={styles.section}>Panchayat master</Text>
        <Field label="Name" value={name} onChangeText={setName} />
        <Field label="Block" value={block} onChangeText={setBlock} />
        <Field label="District" value={dist} onChangeText={setDist} />
        <Btn label="Add panchayat" icon="plus" onPress={() => name.trim() && addPanchayat({ name: name.trim(), block: block || '—', district: dist || '—' })} />
        {panchayats.map((p) => (
          <View key={p.id} style={styles.card}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <View style={styles.row}>
              <Btn
                label="Delete"
                variant="danger"
                onPress={() => {
                  setPending(() => async () => {
                    const r = await deletePanchayat(p.id);
                    if (!r.ok) Alert.alert(r.error || 'Error');
                  });
                  setPinOpen(true);
                }}
              />
            </View>
          </View>
        ))}
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm Admin PIN" onCancel={() => setPinOpen(false)} onOk={() => { setPinOpen(false); pending?.(); setPending(null); }} />
    </View>
  );
}

function FYScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { financialYears, activeFinancialYearId, setActiveFinancialYearId, activeFy, activePanchayat, totalOpening, totalIncome, totalExpense, currentBalance, fyTransactions } = useStore();
  return (
    <View style={styles.page}>
      <Header title="वित्तीय वर्ष" eyebrow={activePanchayat.name} onBack={onBack} badge="S-05" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>Entries are FY-scoped. Only balances carry to next year — not old entries.</Text>
        {financialYears.map((fy) => (
          <Pressable key={fy.id} onPress={() => setActiveFinancialYearId(fy.id)} style={[styles.card, activeFinancialYearId === fy.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{fy.label} {fy.locked ? '🔒' : ''}</Text>
            <Text style={styles.meta}>{fy.start} → {fy.end}</Text>
          </Pressable>
        ))}
        <View style={styles.stats}>
          <Stat label="Opening" v={formatINR(totalOpening)} />
          <Stat label="Income" v={formatINR(totalIncome)} />
          <Stat label="Expense" v={formatINR(totalExpense)} />
          <Stat label="Balance" v={formatINR(currentBalance)} />
          <Stat label="Txns (this FY)" v={String(fyTransactions.length)} />
        </View>
        <Btn label="FY Home" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Selected {activeFy.label}</Text>
      </ScrollView>
    </View>
  );
}

function Stat({ label, v }: { label: string; v: string }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.meta}>{label}</Text>
      <Text style={styles.cardTitle}>{v}</Text>
    </View>
  );
}

function FYSettingsScreen({ onBack }: { onBack: () => void }) {
  const {
    fySettings,
    updateFySettings,
    activeFunds,
    addFund,
    updateFundOpening,
    deleteFundFy,
    addFinancialYear,
    closeFinancialYearCarryForward,
    activeFy,
  } = useStore();
  const [fn, setFn] = useState('');
  const [fo, setFo] = useState('0');
  const [editId, setEditId] = useState<string | null>(null);
  const [bal, setBal] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  const [pending, setPending] = useState<null | (() => void)>(null);

  return (
    <View style={styles.page}>
      <Header title="FY / Cashbook Settings" onBack={onBack} badge="S-05" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.section}>Lines (txn = L−4)</Text>
        <Field
          label="Total lines (default 25)"
          value={String(fySettings.lineCount)}
          onChangeText={(v) => {
            const n = parseInt(v || '25', 10);
            if (n >= 16 && n <= 40) updateFySettings({ lineCount: n });
          }}
          keyboardType="numeric"
        />
        <Text style={styles.meta}>Transaction lines now: {transactionLineCount(fySettings.lineCount)}</Text>
        <View style={styles.row}>
          <Btn label="Gap 1" variant={fySettings.blankLineGap === 1 ? 'primary' : 'outline'} onPress={() => updateFySettings({ blankLineGap: 1 })} />
          <Btn label="Gap 2" variant={fySettings.blankLineGap === 2 ? 'primary' : 'outline'} onPress={() => updateFySettings({ blankLineGap: 2 })} />
        </View>
        <Btn
          label={fySettings.allowSchemeNegative ? 'Scheme minus: ON' : 'Scheme minus: OFF'}
          variant="soft"
          onPress={() => updateFySettings({ allowSchemeNegative: !fySettings.allowSchemeNegative })}
        />
        <Field label="Entry colour" value={fySettings.entryFontColor} onChangeText={(v) => updateFySettings({ entryFontColor: v })} />
        <Field label="श्री पोते colour" value={fySettings.shriPoteColor} onChangeText={(v) => updateFySettings({ shriPoteColor: v })} />
        <Field label="Page bg" value={fySettings.pageBackground} onChangeText={(v) => updateFySettings({ pageBackground: v })} />

        <Text style={styles.section}>Schemes (this device book)</Text>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>
              {formatINR(f.openingBalance)} · {f.openingSource === 'carry-forward' ? '↩ CF' : '✎ Manual'}
            </Text>
            <View style={styles.row}>
              <Btn
                label="Edit opening"
                variant="outline"
                onPress={() => {
                  setEditId(f.id);
                  setBal(String(f.openingBalance));
                }}
              />
              <Btn
                label="Delete"
                variant="danger"
                onPress={() => {
                  setPending(() => () => deleteFundFy(f.id));
                  setPinOpen(true);
                }}
              />
            </View>
            {editId === f.id ? (
              <>
                <Field label="Opening balance" value={bal} onChangeText={setBal} keyboardType="numeric" />
                <Btn
                  label="Save"
                  onPress={() => {
                    updateFundOpening(f.id, parseFloat(bal) || 0, 'manual');
                    setEditId(null);
                  }}
                />
              </>
            ) : null}
          </View>
        ))}
        <Field label="New scheme" value={fn} onChangeText={setFn} />
        <Field label="Opening" value={fo} onChangeText={setFo} keyboardType="numeric" />
        <Btn label="Add scheme" icon="plus" onPress={() => { addFund(fn, parseFloat(fo) || 0, 'manual'); setFn(''); setFo('0'); }} />

        <Text style={styles.section}>New FY (empty entries)</Text>
        <Btn label="Add FY 2027–28 (empty)" onPress={() => addFinancialYear('2027–28', '2027-04-01', '2028-03-31')} />
        <Btn
          label="Close current FY → carry balances only to 2027–28"
          variant="soft"
          onPress={() =>
            closeFinancialYearCarryForward(activeFy.id, '2027–28', '2027-04-01', '2028-03-31')
          }
        />
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm" onCancel={() => setPinOpen(false)} onOk={() => { setPinOpen(false); pending?.(); }} />
    </View>
  );
}

function HomeScreen({ go, back }: { go: (s: Stage) => void; back: () => void }) {
  const { activeFy, activePanchayat, currentBalance, totalIncome, totalExpense, fyTransactions } = useStore();
  return (
    <View style={styles.page}>
      <Header title={`FY ${activeFy.label}`} eyebrow={activePanchayat.name} onBack={back} badge="S-06" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.stats}>
          <Stat label="Balance" v={formatINR(currentBalance)} />
          <Stat label="Income" v={formatINR(totalIncome)} />
          <Stat label="Expense" v={formatINR(totalExpense)} />
          <Stat label="Entries" v={String(fyTransactions.filter((t) => t.status === 'active').length)} />
        </View>
        {[
          ['cashbook', 'book', 'Cashbook', '25-line Option A'],
          ['entry', 'plus-circle', 'Add Income / Expense', 'Multi-column + scheme'],
          ['funds', 'layers', 'Fund heads', 'Opening + delete'],
          ['categories', 'git-branch', 'Categories 3-level', 'Income & expense trees'],
          ['monthly', 'check-circle', 'Monthly check', 'All txns + fix missing'],
          ['goswara', 'pie-chart', 'गोशवारा', 'Till-date auto'],
          ['ledgers', 'list', 'Ledgers', 'Auto from entries'],
          ['reports', 'bar-chart-2', 'Reports hub', 'CSV share'],
          ['bank', 'credit-card', 'Bank statement', 'Tag + post'],
          ['works', 'briefcase', 'Works / MB / Bills / CC', 'Full stack'],
          ['backup', 'hard-drive', 'Backup / Export', 'CSV + SAF note'],
        ].map(([id, icon, title, sub]) => (
          <Pressable key={id} style={styles.homeRow} onPress={() => go(id as Stage)}>
            <View style={styles.homeIcon}><Feather name={icon as any} size={18} color={C.primary} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{title}</Text>
              <Text style={styles.meta}>{sub}</Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

function CashbookScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, activeFunds, fySettings, totalOpening, activePanchayat, activeFy, cancelTransaction, exportCsvForFy } =
    useStore();
  const L = fySettings.lineCount;
  const txnMax = transactionLineCount(L);

  const active = fyTransactions
    .filter((t) => t.status === 'active')
    .sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt));
  const income = active.filter((t) => t.type === 'income').slice(0, txnMax);
  const expense = active.filter((t) => t.type === 'expense').slice(0, txnMax);

  const fundIds = activeFunds.map((f) => f.id);
  const sumSide = (rows: typeof income) =>
    rows.reduce((s, t) => s + sumAmounts(t.amounts), 0);
  const incTot = sumSide(income);
  const expTot = sumSide(expense);
  const mahayogL = totalOpening + incTot;
  const bachat = mahayogL - expTot;
  const mahayogR = expTot + bachat;

  const openingLabel = activeFunds.map((f) => `${f.shortName} ${formatINR(f.openingBalance)}`).join(' · ');

  /** Build fixed 25-line visual rows per side (Option A) */
  type RowKind = 'shri' | 'blank' | 'txn' | 'aayYog' | 'vyayYog' | 'shriBottom' | 'bachat' | 'mahayog';
  type VRow = { line: number; kind: RowKind; text: string; sub?: string };

  const incomeRows: VRow[] = [];
  const expenseRows: VRow[] = [];

  // Line 1
  incomeRows.push({
    line: 1,
    kind: 'shri',
    text: 'श्री पोते',
    sub: openingLabel || formatINR(totalOpening),
  });
  expenseRows.push({ line: 1, kind: 'blank', text: '' });

  // Lines 2 .. L-3  transaction zone
  for (let i = 0; i < txnMax; i++) {
    const lineNo = i + 2;
    const inc = income[i];
    const exp = expense[i];
    if (inc) {
      incomeRows.push({
        line: lineNo,
        kind: 'txn',
        text: `${inc.date.slice(8)}/${inc.date.slice(5, 7)}  ${inc.party}`,
        sub: `${formatINR(sumAmounts(inc.amounts))} · ${inc.schemeId}`,
      });
    } else {
      incomeRows.push({ line: lineNo, kind: 'blank', text: '' });
    }
    if (exp) {
      expenseRows.push({
        line: lineNo,
        kind: 'txn',
        text: `${exp.date.slice(8)}/${exp.date.slice(5, 7)}  ${exp.party}`,
        sub: `${formatINR(sumAmounts(exp.amounts))} · ${exp.schemeId}`,
      });
    } else {
      expenseRows.push({ line: lineNo, kind: 'blank', text: '' });
    }
  }

  // Bottom 3
  incomeRows.push({ line: L - 2, kind: 'aayYog', text: 'आय योग', sub: formatINR(incTot) });
  incomeRows.push({ line: L - 1, kind: 'shriBottom', text: 'श्री पोते', sub: formatINR(totalOpening) });
  incomeRows.push({ line: L, kind: 'mahayog', text: 'महायोग', sub: formatINR(mahayogL) });

  expenseRows.push({ line: L - 2, kind: 'vyayYog', text: 'व्यय योग', sub: formatINR(expTot) });
  expenseRows.push({ line: L - 1, kind: 'bachat', text: 'बचत पोते', sub: formatINR(bachat) });
  expenseRows.push({ line: L, kind: 'mahayog', text: 'महायोग', sub: formatINR(mahayogR) });

  const cellStyle = (kind: RowKind, side: 'L' | 'R') => {
    const base: any = {
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: '#c9dfca',
      minHeight: 28,
      paddingHorizontal: 4,
      paddingVertical: 2,
      justifyContent: 'center',
    };
    if (kind === 'shri') {
      base.backgroundColor = 'rgba(198,40,40,0.06)';
    }
    if (kind === 'aayYog' || kind === 'vyayYog' || kind === 'shriBottom' || kind === 'bachat' || kind === 'mahayog') {
      base.backgroundColor = 'rgba(27,94,32,0.08)';
    }
    if (kind === 'blank' && side === 'R' && true) {
      /* expense line 1 already blank */
    }
    return base;
  };

  const textColor = (kind: RowKind) => {
    if (kind === 'shri' || kind === 'shriBottom') return fySettings.shriPoteColor;
    if (kind === 'aayYog' || kind === 'vyayYog' || kind === 'bachat' || kind === 'mahayog') return fySettings.summaryFontColor;
    if (kind === 'txn') return fySettings.entryFontColor;
    return '#9e9e9e';
  };

  const bold = (kind: RowKind) =>
    kind === 'shri' || kind === 'shriBottom' || kind === 'aayYog' || kind === 'vyayYog' || kind === 'bachat' || kind === 'mahayog';

  const renderSide = (rows: VRow[], side: 'L' | 'R', title: string) => (
    <View style={{ flex: 1, borderColor: '#c9dfca', borderWidth: 1 }}>
      <View
        style={{
          backgroundColor: side === 'L' ? '#1e6048' : '#3d5a4a',
          paddingVertical: 6,
          paddingHorizontal: 6,
        }}
      >
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12, textAlign: 'center' }}>{title}</Text>
      </View>
      {rows.map((r) => (
        <Pressable
          key={`${side}-${r.line}`}
          onLongPress={() => {
            if (r.kind !== 'txn') return;
            const list = side === 'L' ? income : expense;
            const idx = r.line - 2;
            const t = list[idx];
            if (!t) return;
            Alert.alert('Entry', `${t.party}\n${formatINR(sumAmounts(t.amounts))}`, [
              { text: 'OK' },
              { text: 'Cancel entry', style: 'destructive', onPress: () => cancelTransaction(t.id) },
            ]);
          }}
          style={cellStyle(r.kind, side)}
        >
          <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
            <Text style={{ width: 16, fontSize: 9, color: '#78909c', fontWeight: '700' }}>{r.line}</Text>
            <View style={{ flex: 1 }}>
              <Text
                numberOfLines={1}
                style={{
                  fontSize: bold(r.kind) ? 11 : 10,
                  fontWeight: bold(r.kind) ? '800' : '600',
                  color: textColor(r.kind),
                }}
              >
                {r.text || (r.kind === 'blank' ? ' ' : '')}
              </Text>
              {r.sub ? (
                <Text numberOfLines={1} style={{ fontSize: 9, color: textColor(r.kind), opacity: 0.9 }}>
                  {r.sub}
                </Text>
              ) : null}
            </View>
          </View>
        </Pressable>
      ))}
    </View>
  );

  return (
    <View style={[styles.page, { backgroundColor: fySettings.pageBackground }]}>
      <Header
        title="Cashbook"
        eyebrow={`${activePanchayat.name} · ${activeFy.label}`}
        onBack={back}
        badge="S-07"
        action={
          <IconBtn
            name="share-2"
            onPress={async () => {
              const csv = exportCsvForFy();
              await Share.share({ message: csv, title: 'Cashbook CSV' });
            }}
          />
        }
      />
      <ScrollView horizontal contentContainerStyle={{ minWidth: '100%' }}>
        <ScrollView contentContainerStyle={{ padding: 8, paddingBottom: 40, minWidth: 360 }}>
          <Text style={styles.hint}>
            Excel-style page · {L} lines · left आय / right व्यय · line1 expense blank · bottom 3 auto
          </Text>
          <View style={styles.row}>
            <Btn label="+ Entry" icon="plus" onPress={() => go('entry')} />
          </View>

          {/* Fund column strip (compact) */}
          <ScrollView horizontal style={{ marginBottom: 6 }}>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              {activeFunds.map((f) => (
                <View
                  key={f.id}
                  style={{
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: '#c9dfca',
                    borderRadius: 8,
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                  }}
                >
                  <Text style={{ fontSize: 10, fontWeight: '800', color: fySettings.shriPoteColor }}>{f.shortName}</Text>
                  <Text style={{ fontSize: 10, color: C.foreground }}>{formatINR(f.openingBalance)}</Text>
                </View>
              ))}
            </View>
          </ScrollView>

          {/* Dual page */}
          <View
            style={{
              flexDirection: 'row',
              backgroundColor: '#f3faf3',
              borderWidth: 2,
              borderColor: '#1e6048',
              minHeight: 400,
            }}
          >
            {renderSide(incomeRows, 'L', 'आय / प्राप्तियाँ')}
            <View style={{ width: 2, backgroundColor: '#1e6048' }} />
            {renderSide(expenseRows, 'R', 'व्यय / भुगतान')}
          </View>

          <Text style={[styles.meta, { marginTop: 8 }]}>
            Long-press a transaction line to cancel · Summary lines not editable · Page {1} / auto-next when full
          </Text>
        </ScrollView>
      </ScrollView>
    </View>
  );
}

function EntryScreen({ back }: { back: () => void }) {
  const { activeFunds, addTransaction, categories } = useStore();
  const [type, setType] = useState<'income' | 'expense'>('income');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [party, setParty] = useState('');
  const [detail, setDetail] = useState('');
  const [note, setNote] = useState('');
  const [schemeId, setSchemeId] = useState('sfc');
  const [amounts, setAmounts] = useState<Record<string, string>>({});
  const [cat1, setCat1] = useState<string | null>(null);
  const [err, setErr] = useState('');
  const roots = categories.filter((c) => c.kind === type && c.level === 1 && !c.archived);

  const save = async () => {
    const am: Record<string, number> = {};
    for (const f of activeFunds) {
      const n = parseFloat(amounts[f.id] || '0');
      if (n) am[f.id] = n;
    }
    const r = await addTransaction({
      type,
      date,
      reference: '',
      party: party.trim(),
      detail: detail.trim(),
      note: note.trim(),
      schemeId,
      amounts: am,
      categoryId: cat1,
      subcategoryId: null,
      subSubcategoryId: null,
      workId: null,
      expenseKind: type === 'expense' ? 'other' : null,
    });
    if (!r.ok) return setErr(r.error);
    back();
  };

  return (
    <View style={styles.page}>
      <Header title="Add entry" onBack={back} badge={type === 'income' ? 'S-08' : 'S-09'} />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="Income" variant={type === 'income' ? 'primary' : 'outline'} onPress={() => setType('income')} />
          <Btn label="Expense" variant={type === 'expense' ? 'danger' : 'outline'} onPress={() => setType('expense')} />
        </View>
        <Text style={styles.hint}>Scheme required (default SFC). Multi-column amounts.</Text>
        <Field label="Date" value={date} onChangeText={setDate} />
        <Field label={type === 'income' ? 'किससे प्राप्त' : 'किसको भुगतान'} value={party} onChangeText={setParty} />
        <Field label="Detail" value={detail} onChangeText={setDetail} />
        <Field label="Note" value={note} onChangeText={setNote} multiline />
        <Text style={styles.section}>Scheme *</Text>
        <View style={styles.chips}>
          {activeFunds.map((f) => (
            <Pressable key={f.id} onPress={() => setSchemeId(f.id)} style={[styles.chip, schemeId === f.id && styles.chipOn]}>
              <Text style={{ color: schemeId === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={styles.section}>Amounts by fund</Text>
        {activeFunds.map((f) => (
          <Field
            key={f.id}
            label={f.shortName}
            value={amounts[f.id] || ''}
            onChangeText={(v) => setAmounts((a) => ({ ...a, [f.id]: v }))}
            keyboardType="numeric"
          />
        ))}
        <Text style={styles.section}>Category (level 1)</Text>
        <View style={styles.chips}>
          {roots.map((c) => (
            <Pressable key={c.id} onPress={() => setCat1(c.id)} style={[styles.chip, cat1 === c.id && styles.chipOn]}>
              <Text style={{ color: cat1 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
            </Pressable>
          ))}
        </View>
        {err ? <Text style={styles.err}>{err}</Text> : null}
        <Btn label="Save" icon="check" onPress={save} />
      </ScrollView>
    </View>
  );
}

function CategoriesScreen({ back }: { back: () => void }) {
  const { categories, addCategory, archiveCategory, renameCategory } = useStore();
  const [kind, setKind] = useState<'income' | 'expense'>('income');
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState<string | null>(null);
  const list = categories.filter((c) => c.kind === kind && !c.archived);

  return (
    <View style={styles.page}>
      <Header title="Categories" onBack={back} badge="S-Cat" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="Income tree" variant={kind === 'income' ? 'primary' : 'outline'} onPress={() => setKind('income')} />
          <Btn label="Expense tree" variant={kind === 'expense' ? 'primary' : 'outline'} onPress={() => setKind('expense')} />
        </View>
        {list.map((c) => (
          <View key={c.id} style={styles.card}>
            <Text style={styles.cardTitle}>{'  '.repeat(c.level - 1)}{c.name} <Text style={styles.meta}>L{c.level}</Text></Text>
            <View style={styles.row}>
              <Btn label="Add child" variant="outline" onPress={() => setParentId(c.id)} />
              <Btn label="Archive" variant="danger" onPress={() => archiveCategory(c.id)} />
            </View>
          </View>
        ))}
        <Field label="New name" value={name} onChangeText={setName} />
        <Text style={styles.meta}>Parent: {parentId || 'root (level 1)'}</Text>
        <Btn
          label="Add node"
          onPress={() => {
            addCategory(kind, name, parentId);
            setName('');
            setParentId(null);
          }}
        />
      </ScrollView>
    </View>
  );
}

function MonthlyScreen({ back }: { back: () => void }) {
  const { fyTransactions, updateTransaction, activeFunds, categories } = useStore();
  const [filter, setFilter] = useState<'all' | 'incomplete'>('all');
  const list = fyTransactions.filter((t) => {
    if (filter === 'incomplete') return t.status === 'active' && (!t.schemeId || !t.categoryId);
    return true;
  });

  return (
    <View style={styles.page}>
      <Header title="Monthly check" onBack={back} badge="S-MC" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="All" variant={filter === 'all' ? 'primary' : 'outline'} onPress={() => setFilter('all')} />
          <Btn label="Incomplete" variant={filter === 'incomplete' ? 'primary' : 'outline'} onPress={() => setFilter('incomplete')} />
        </View>
        {list.length === 0 ? (
          <Empty title="No rows" why="Is FY me is filter ki entries nahi" steps={['Add cashbook entry', 'Switch filter to All']} />
        ) : null}
        {list.map((t) => (
          <View key={t.id} style={styles.card}>
            <Text style={styles.cardTitle}>{t.date} · {t.type} · {t.party || '(no party)'}</Text>
            <Text style={styles.meta}>
              {formatINR(sumAmounts(t.amounts))} · scheme={t.schemeId || 'MISSING'} · cat={t.categoryId || 'MISSING'} · {t.status}
            </Text>
            {!t.schemeId ? (
              <View style={styles.chips}>
                {activeFunds.map((f) => (
                  <Pressable key={f.id} style={styles.chip} onPress={() => updateTransaction(t.id, { schemeId: f.id })}>
                    <Text>{f.shortName}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
            {!t.categoryId ? (
              <View style={styles.chips}>
                {categories
                  .filter((c) => c.kind === t.type && c.level === 1 && !c.archived)
                  .map((c) => (
                    <Pressable key={c.id} style={styles.chip} onPress={() => updateTransaction(t.id, { categoryId: c.id })}>
                      <Text style={{ fontSize: 11 }}>{c.name}</Text>
                    </Pressable>
                  ))}
              </View>
            ) : null}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

function GoswaraScreen({ back }: { back: () => void }) {
  const { fyTransactions, activeFunds, totalOpening } = useStore();
  const active = fyTransactions.filter((t) => t.status === 'active');
  if (active.length === 0) {
    return (
      <View style={styles.page}>
        <Header title="गोशवारा" onBack={back} badge="S-27" />
        <View style={styles.pad}>
          <Empty title="गोशवारा खाली" why="Is FY me abhi koi entry nahi" steps={['Cashbook me income/expense add karein', 'Ledgers auto update ho jayenge']} />
        </View>
      </View>
    );
  }
  const byScheme: Record<string, { inc: number; exp: number }> = {};
  for (const f of activeFunds) byScheme[f.id] = { inc: 0, exp: 0 };
  for (const t of active) {
    const tot = sumAmounts(t.amounts);
    if (!byScheme[t.schemeId]) byScheme[t.schemeId] = { inc: 0, exp: 0 };
    if (t.type === 'income') byScheme[t.schemeId].inc += tot;
    else byScheme[t.schemeId].exp += tot;
  }
  return (
    <View style={styles.page}>
      <Header title="गोशवारा till date" onBack={back} badge="S-27" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.meta}>Opening {formatINR(totalOpening)}</Text>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>
              Income {formatINR(byScheme[f.id]?.inc || 0)} · Expense {formatINR(byScheme[f.id]?.exp || 0)}
            </Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

function LedgersScreen({ back }: { back: () => void }) {
  const { fyTransactions, activeFunds } = useStore();
  const active = fyTransactions.filter((t) => t.status === 'active');
  return (
    <View style={styles.page}>
      <Header title="Ledgers" onBack={back} badge="S-28" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>Auto from first entry — no generate step</Text>
        {activeFunds.map((f) => {
          const rows = active.filter((t) => t.schemeId === f.id || (t.amounts[f.id] || 0) > 0);
          return (
            <View key={f.id} style={styles.card}>
              <Text style={styles.cardTitle}>{f.shortName} ledger ({rows.length})</Text>
              {rows.slice(0, 20).map((t) => (
                <Text key={t.id} style={styles.meta}>
                  {t.date} {t.type} {t.party} {formatINR(t.amounts[f.id] || sumAmounts(t.amounts))}
                </Text>
              ))}
              {rows.length === 0 ? <Text style={styles.meta}>Empty</Text> : null}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

function ReportsScreen({ back }: { back: () => void }) {
  const { exportCsvForFy, fyTransactions } = useStore();
  return (
    <View style={styles.page}>
      <Header title="Reports hub" onBack={back} badge="S-34" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>{fyTransactions.length} rows in FY · Share CSV (Excel-readable). PDF layout uses white background per spec.</Text>
        <Btn
          label="Share FY CSV (Excel)"
          icon="share-2"
          onPress={async () => Share.share({ message: exportCsvForFy() })}
        />
        <Empty
          title="PDF print layout"
          why="Native PDF renderer hooks to same dataset; CSV share works offline now."
          steps={['Use Share FY CSV in Excel', 'Page PDF engine binds to Option A layout in print module']}
        />
      </ScrollView>
    </View>
  );
}

function BankScreen({ back }: { back: () => void }) {
  const { bankAccounts, bankLines, addBankLine, updateBankLine, postBankLineToCashbook, activeFunds, activeFy } = useStore();
  const [narr, setNarr] = useState('');
  const [amt, setAmt] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const fyLines = bankLines.filter((l) => l.fyId === activeFy.id);

  return (
    <View style={styles.page}>
      <Header title="Bank statement" onBack={back} badge="S-13" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>PDF OCR can feed this grid; manual lines supported. Tag scheme → Post to cashbook.</Text>
        {bankAccounts.map((a) => (
          <Text key={a.id} style={styles.meta}>{a.name} · {a.bankName} · {a.accountNo}</Text>
        ))}
        <Field label="Narration" value={narr} onChangeText={setNarr} />
        <Field label="Amount" value={amt} onChangeText={setAmt} keyboardType="numeric" />
        <Field label="Date" value={date} onChangeText={setDate} />
        <Btn
          label="Add credit line"
          onPress={() => {
            addBankLine({
              accountId: bankAccounts[0]?.id || 'ba1',
              fyId: activeFy.id,
              statementMonth: date.slice(0, 7),
              date,
              narration: narr,
              amount: parseFloat(amt) || 0,
              side: 'credit',
              instrument: '',
              schemeId: null,
              workId: null,
              ignored: false,
              postedTxnId: null,
            });
            setNarr('');
            setAmt('');
          }}
        />
        {fyLines.map((l) => (
          <View key={l.id} style={styles.card}>
            <Text style={styles.cardTitle}>{l.date} · {l.narration}</Text>
            <Text style={styles.meta}>{l.side} {formatINR(l.amount)} · scheme={l.schemeId || '—'} · {l.postedTxnId ? 'POSTED' : 'open'}</Text>
            <View style={styles.chips}>
              {activeFunds.map((f) => (
                <Pressable key={f.id} style={styles.chip} onPress={() => updateBankLine(l.id, { schemeId: f.id })}>
                  <Text style={{ fontSize: 11 }}>{f.shortName}</Text>
                </Pressable>
              ))}
            </View>
            {!l.postedTxnId ? (
              <Btn
                label="Post to cashbook"
                onPress={async () => {
                  const r = await postBankLineToCashbook(l.id);
                  if (!r.ok) Alert.alert(r.error || 'Fail');
                }}
              />
            ) : null}
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

function WorksScreen({ back, go }: { back: () => void; go: (s: Stage, workId?: string) => void }) {
  const { works, addWork, activeFy, activeFunds } = useStore();
  const [name, setName] = useState('');
  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  return (
    <View style={styles.page}>
      <Header title="Works" onBack={back} badge="S-17" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Field label="Work name" value={name} onChangeText={setName} />
        <Btn
          label="Add work"
          onPress={() => {
            if (!name.trim()) return;
            addWork({
              fyId: activeFy.id,
              name: name.trim(),
              schemeId: activeFunds[1]?.id || 'sfc',
              ward: '',
              sanctionRef: '',
              materialPrior: 0,
              labourPrior: 0,
              status: 'ongoing',
            });
            setName('');
          }}
        />
        {fyWorks.map((w) => (
          <Pressable key={w.id} style={styles.homeRow} onPress={() => go('workDetail', w.id)}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{w.name}</Text>
              <Text style={styles.meta}>{w.status} · scheme {w.schemeId}</Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
        {fyWorks.length === 0 ? <Empty title="No works" why="Is FY me work nahi" steps={['Add work name above', 'Open for MB / Bills / CC']} /> : null}
      </ScrollView>
    </View>
  );
}

function WorkDetailScreen({ back, workId, go }: { back: () => void; workId: string; go: (s: Stage) => void }) {
  const { works, mbLines, bills } = useStore();
  const w = works.find((x) => x.id === workId);
  if (!w) return null;
  const mb = mbLines.filter((m) => m.workId === workId);
  const bl = bills.filter((b) => b.workId === workId);
  const mbVal = mb.reduce((s, m) => s + m.qty * m.rate, 0);
  return (
    <View style={styles.page}>
      <Header title={w.name} onBack={back} badge="S-19" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.meta}>Prior material {formatINR(w.materialPrior)} · labour {formatINR(w.labourPrior)}</Text>
        <Text style={styles.cardTitle}>MB valuation {formatINR(mbVal)} ({mb.length} lines)</Text>
        <Text style={styles.meta}>Bills {bl.length}</Text>
        <Btn label="MB entry" onPress={() => go('mb')} />
        <Btn label="Bills" variant="soft" onPress={() => go('bills')} />
        <Btn label="CC (7 pages summary)" variant="outline" onPress={() => go('cc')} />
      </ScrollView>
    </View>
  );
}

function MbScreen({ back, workId }: { back: () => void; workId: string }) {
  const { addMbLine, mbLines } = useStore();
  const [item, setItem] = useState('');
  const [qty, setQty] = useState('1');
  const [rate, setRate] = useState('0');
  const lines = mbLines.filter((m) => m.workId === workId);
  return (
    <View style={styles.page}>
      <Header title="MB entry" onBack={back} badge="S-21" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Field label="Item" value={item} onChangeText={setItem} />
        <Field label="Qty" value={qty} onChangeText={setQty} keyboardType="numeric" />
        <Field label="Rate" value={rate} onChangeText={setRate} keyboardType="numeric" />
        <Btn
          label="Add MB line (material)"
          onPress={() => {
            addMbLine({ workId, itemName: item, qty: parseFloat(qty) || 0, rate: parseFloat(rate) || 0, kind: 'material' });
            setItem('');
          }}
        />
        {lines.map((m) => (
          <Text key={m.id} style={styles.meta}>
            {m.itemName} · {m.qty} × {m.rate} = {formatINR(m.qty * m.rate)} ({m.kind})
          </Text>
        ))}
      </ScrollView>
    </View>
  );
}

function BillsScreen({ back, workId }: { back: () => void; workId: string }) {
  const { addBill, bills, activeFy } = useStore();
  const [vendor, setVendor] = useState('');
  const [amount, setAmount] = useState('');
  const list = bills.filter((b) => b.workId === workId);
  return (
    <View style={styles.page}>
      <Header title="Bills" onBack={back} badge="S-25" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Field label="Vendor" value={vendor} onChangeText={setVendor} />
        <Field label="Amount" value={amount} onChangeText={setAmount} keyboardType="numeric" />
        <Btn
          label="Add bill"
          onPress={() => {
            addBill({
              workId,
              fyId: activeFy.id,
              billDate: new Date().toISOString().slice(0, 10),
              paymentDate: new Date().toISOString().slice(0, 10),
              pageRef: '',
              vendor,
              amount: parseFloat(amount) || 0,
              note: '',
            });
            setVendor('');
            setAmount('');
          }}
        />
        {list.map((b) => (
          <Text key={b.id} style={styles.meta}>
            {b.billDate} · {b.vendor} · {formatINR(b.amount)}
          </Text>
        ))}
      </ScrollView>
    </View>
  );
}

function CcScreen({ back, workId }: { back: () => void; workId: string }) {
  const { works, mbLines, bills } = useStore();
  const w = works.find((x) => x.id === workId);
  const mbVal = mbLines.filter((m) => m.workId === workId).reduce((s, m) => s + m.qty * m.rate, 0);
  const billSum = bills.filter((b) => b.workId === workId).reduce((s, b) => s + b.amount, 0);
  return (
    <View style={styles.page}>
      <Header title="CC (7 pages)" onBack={back} badge="S-26" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{w?.name}</Text>
        <Text style={styles.section}>1. Completion certificate</Text>
        <Text style={styles.meta}>MB valuation {formatINR(mbVal)} · Bills {formatINR(billSum)}</Text>
        <Text style={styles.section}>2. Utilisation certificate</Text>
        <Text style={styles.meta}>Placeholder — bind to allowable min(FS, MB, calc)</Text>
        <Text style={styles.section}>3. Labour master roll (pakhwada)</Text>
        <Text style={styles.section}>4. Material as per MB</Text>
        <Text style={styles.section}>5. Technical verification</Text>
        <Text style={styles.section}>6. Completion photo + sign</Text>
        <Text style={styles.section}>7. Before & during photos</Text>
      </ScrollView>
    </View>
  );
}

function BackupScreen({ back }: { back: () => void }) {
  const { exportCsvForFy, activePanchayat, activeFy } = useStore();
  return (
    <View style={styles.page}>
      <Header title="Backup & export" onBack={back} badge="S-42" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          SAF path (Phase 1): Documents/Cashbook/{activePanchayat.name}/{activeFy.label}/ — wire expo-file-system + SAF picker on device build.
        </Text>
        <Btn label="Share CSV backup (this FY)" icon="share-2" onPress={() => Share.share({ message: exportCsvForFy() })} />
        <Empty
          title="Restore / phone transfer"
          why="Restore imports JSON/CSV into AsyncStorage; S-46 wizard uses zip + 4-digit code."
          steps={['Export CSV now', 'On new phone: Settings → restore', 'Full zip backup via SAF folder']}
        />
      </ScrollView>
    </View>
  );
}

function FundsScreen({ back }: { back: () => void }) {
  const { activeFunds, updateFundOpening, deleteFundFy, addFund } = useStore();
  const [name, setName] = useState('');
  const [open, setOpen] = useState('0');
  return (
    <View style={styles.page}>
      <Header title="Fund heads" onBack={back} badge="S-35" />
      <ScrollView contentContainerStyle={styles.pad}>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>{formatINR(f.openingBalance)} · {f.openingSource}</Text>
            <Btn label="Delete (FY)" variant="danger" onPress={() => deleteFundFy(f.id)} />
          </View>
        ))}
        <Field label="New" value={name} onChangeText={setName} />
        <Field label="Opening" value={open} onChangeText={setOpen} keyboardType="numeric" />
        <Btn label="Add" onPress={() => { addFund(name, parseFloat(open) || 0); setName(''); }} />
      </ScrollView>
    </View>
  );
}

function Shell() {
  const [stage, setStage] = useState<Stage>('login');
  const [stack, setStack] = useState<Stage[]>(['login']);
  const [workId, setWorkId] = useState<string>('');
  const { hydrated } = useStore();

  const go = useCallback((s: Stage, wid?: string) => {
    if (wid) setWorkId(wid);
    setStack((st) => [...st, s]);
    setStage(s);
  }, []);

  const back = useCallback(() => {
    setStack((st) => {
      if (st.length <= 1) {
        Alert.alert('Exit?', undefined, [
          { text: 'Stay', style: 'cancel' },
          { text: 'Exit', style: 'destructive', onPress: () => BackHandler.exitApp() },
        ]);
        return st;
      }
      const n = st.slice(0, -1);
      setStage(n[n.length - 1]);
      return n;
    });
  }, []);

  React.useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      back();
      return true;
    });
    return () => sub.remove();
  }, [back]);

  if (!hydrated) {
    return (
      <View style={[styles.page, { alignItems: 'center', justifyContent: 'center' }]}>
        <Text>Loading…</Text>
      </View>
    );
  }

  switch (stage) {
    case 'login':
      return <LoginScreen onDone={() => go('panchayat')} />;
    case 'panchayat':
      return <PanchayatScreen onContinue={() => go('fy')} onBack={back} onSettings={() => go('appSettings')} />;
    case 'appSettings':
      return <AppSettingsScreen onBack={back} />;
    case 'fy':
      return <FYScreen onContinue={() => go('home')} onBack={back} onSettings={() => go('fySettings')} />;
    case 'fySettings':
      return <FYSettingsScreen onBack={back} />;
    case 'home':
      return <HomeScreen go={go} back={back} />;
    case 'cashbook':
      return <CashbookScreen back={back} go={go} />;
    case 'entry':
      return <EntryScreen back={back} />;
    case 'funds':
      return <FundsScreen back={back} />;
    case 'categories':
      return <CategoriesScreen back={back} />;
    case 'monthly':
      return <MonthlyScreen back={back} />;
    case 'goswara':
      return <GoswaraScreen back={back} />;
    case 'ledgers':
      return <LedgersScreen back={back} />;
    case 'reports':
      return <ReportsScreen back={back} />;
    case 'bank':
      return <BankScreen back={back} />;
    case 'works':
      return <WorksScreen back={back} go={go} />;
    case 'workDetail':
      return <WorkDetailScreen back={back} workId={workId} go={go} />;
    case 'mb':
      return <MbScreen back={back} workId={workId} />;
    case 'bills':
      return <BillsScreen back={back} workId={workId} />;
    case 'cc':
      return <CcScreen back={back} workId={workId} />;
    case 'backup':
      return <BackupScreen back={back} />;
    default:
      return <HomeScreen go={go} back={back} />;
  }
}

export default function Index() {
  return <Shell />;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  dark: { flex: 1, backgroundColor: C.darkForest, padding: 24, justifyContent: 'center' },
  loginPad: { gap: 8 },
  brand: { color: C.accent, letterSpacing: 2, fontWeight: '800', fontSize: 12 },
  loginHi: { color: '#fff', fontSize: 28, fontWeight: '800' },
  loginSub: { color: 'rgba(255,255,255,0.7)', marginBottom: 12 },
  header: { backgroundColor: C.primary, paddingHorizontal: 12, paddingBottom: 10 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  eyebrow: { color: 'rgba(255,255,255,0.75)', fontSize: 11 },
  hTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  mark: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  iconBtn: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  pad: { padding: 14, paddingBottom: 40 },
  btn: { flex: 1, flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', paddingVertical: 11, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, marginVertical: 4 },
  btnText: { fontWeight: '800', fontSize: 13 },
  fieldWrap: { marginBottom: 10 },
  fieldLabel: { fontSize: 11, fontWeight: '700', color: C.mutedForeground, marginBottom: 4 },
  field: { borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 11, backgroundColor: C.card, color: C.foreground },
  err: { color: C.expense, marginBottom: 8 },
  hint: { color: C.mutedForeground, fontSize: 12, marginBottom: 10, lineHeight: 17 },
  section: { fontWeight: '800', marginTop: 12, marginBottom: 8, color: C.foreground },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  cardOn: { borderColor: C.primary, backgroundColor: C.primarySoft },
  cardTitle: { fontWeight: '800', color: C.foreground, fontSize: 14 },
  meta: { color: C.mutedForeground, fontSize: 11, marginTop: 3 },
  row: { flexDirection: 'row', gap: 8, marginVertical: 6 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  stat: { width: '47%', backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.border, padding: 10 },
  homeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  homeIcon: { width: 38, height: 38, borderRadius: 11, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
  chipOn: { backgroundColor: C.primary, borderColor: C.primary },
  summary: { marginTop: 14, padding: 12, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.8)', borderWidth: 1, borderColor: C.border },
  sumLine: { fontWeight: '800', marginBottom: 4 },
  empty: { backgroundColor: C.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.border, gap: 6 },
  emptyTitle: { fontWeight: '800', fontSize: 15 },
  emptyWhy: { color: C.mutedForeground, fontSize: 12, lineHeight: 18 },
  emptyStep: { fontSize: 12 },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 22 },
  modalCard: { backgroundColor: C.card, borderRadius: 16, padding: 16, gap: 8 },
  modalTitle: { fontWeight: '800', fontSize: 16 },
});
