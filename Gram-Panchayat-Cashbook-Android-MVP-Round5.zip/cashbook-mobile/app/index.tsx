/**
 * Gram Panchayat Cashbook — Expo MVP
 * Aligned to PROJECT_MASTER.md Section 19 (Round 5) + core cashbook rules.
 */
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useMemo, useState } from 'react';
import {
  Alert,
  BackHandler,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import colors from '@/constants/colors';
import {
  CashbookProvider,
  formatINR,
  TransactionType,
  useCashbook,
  Fund,
} from '@/context/CashbookContext';
import { ScreenBadge } from '@/components/ScreenBadge';

const C = colors.light;

type Stage =
  | 'login'
  | 'panchayat'
  | 'appSettings'
  | 'fy'
  | 'fySettings'
  | 'home'
  | 'cashbook'
  | 'funds'
  | 'monthlyCheck'
  | 'goswara'
  | 'reports'
  | 'backup'
  | 'bank'
  | 'info';

function IconButton({
  name,
  onPress,
  tint = C.primary,
}: {
  name: keyof typeof Feather.glyphMap;
  onPress: () => void;
  tint?: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
    >
      <Feather name={name} size={19} color={tint} />
    </Pressable>
  );
}

function Button({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled = false,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'soft' | 'outline' | 'danger';
  icon?: keyof typeof Feather.glyphMap;
  disabled?: boolean;
}) {
  const background =
    variant === 'primary'
      ? C.primary
      : variant === 'danger'
        ? C.expenseSoft
        : variant === 'soft'
          ? C.primarySoft
          : 'transparent';
  const foreground =
    variant === 'primary' ? C.primaryForeground : variant === 'danger' ? C.expense : C.primary;
  return (
    <Pressable
      disabled={disabled}
      onPress={() => {
        Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.button,
        {
          backgroundColor: background,
          borderColor: variant === 'outline' ? C.border : background,
          opacity: disabled ? 0.45 : pressed ? 0.82 : 1,
        },
      ]}
    >
      {icon ? <Feather name={icon} size={17} color={foreground} /> : null}
      <Text style={[styles.buttonText, { color: foreground }]}>{label}</Text>
    </Pressable>
  );
}

function Header({
  eyebrow,
  title,
  onBack,
  action,
  badge,
}: {
  eyebrow?: string;
  title: string;
  onBack?: () => void;
  action?: React.ReactNode;
  badge?: string;
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.header, { paddingTop: Platform.OS === 'web' ? 48 : insets.top + 8 }]}>
      <View style={styles.headerRow}>
        {onBack ? (
          <IconButton name="arrow-left" onPress={onBack} />
        ) : (
          <View style={styles.mark}>
            <Feather name="book-open" size={18} color={C.primaryForeground} />
          </View>
        )}
        <View style={styles.headerCopy}>
          {eyebrow ? <Text style={styles.headerEyebrow}>{eyebrow}</Text> : null}
          <Text style={styles.headerTitle}>{title}</Text>
        </View>
        <View>{action ?? (badge ? <ScreenBadge label={badge} /> : null)}</View>
      </View>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType = 'default',
  multiline = false,
  secureTextEntry = false,
}: {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder?: string;
  keyboardType?: 'default' | 'numeric';
  multiline?: boolean;
  secureTextEntry?: boolean;
}) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={C.mutedForeground}
        keyboardType={keyboardType}
        multiline={multiline}
        secureTextEntry={secureTextEntry}
        style={[styles.field, multiline && styles.multiline]}
      />
    </View>
  );
}

function EmptyState({
  title,
  why,
  steps,
}: {
  title: string;
  why: string;
  steps: string[];
}) {
  return (
    <View style={styles.emptyCard}>
      <Feather name="info" size={22} color={C.primary} />
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyWhy}>{why}</Text>
      <Text style={styles.emptyStepsHead}>रिपोर्ट / डेटा पाने के लिए:</Text>
      {steps.map((s, i) => (
        <Text key={i} style={styles.emptyStep}>
          {i + 1}. {s}
        </Text>
      ))}
    </View>
  );
}

function PasswordConfirmModal({
  visible,
  onCancel,
  onConfirm,
  title,
}: {
  visible: boolean;
  onCancel: () => void;
  onConfirm: () => void;
  title: string;
}) {
  const { verifyPin } = useCashbook();
  const [pin, setPin] = useState('');
  const [err, setErr] = useState('');
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={styles.modalBackdrop}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>{title}</Text>
          <Text style={styles.modalBody}>सुरक्षा के लिए Admin PIN दोबारा दर्ज करें (Section 19.2)।</Text>
          <TextInput
            value={pin}
            onChangeText={setPin}
            secureTextEntry
            keyboardType="number-pad"
            maxLength={6}
            placeholder="PIN"
            placeholderTextColor={C.mutedForeground}
            style={styles.field}
          />
          {err ? <Text style={styles.formError}>{err}</Text> : null}
          <View style={styles.rowGap}>
            <Button label="Cancel" variant="outline" onPress={onCancel} />
            <Button
              label="Confirm"
              onPress={() => {
                if (!verifyPin(pin)) {
                  setErr('PIN गलत है');
                  return;
                }
                setPin('');
                setErr('');
                onConfirm();
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* ——— S-01 Login (Admin only) ——— */
function LoginScreen({ onContinue }: { onContinue: () => void }) {
  const { pin, setupComplete, setPin } = useCashbook();
  const [value, setValue] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');

  const submit = async () => {
    if (!setupComplete || !pin) {
      if (value.length < 4) {
        setError('PIN कम से कम 4 अंक का होना चाहिए');
        return;
      }
      if (value !== confirm) {
        setError('PIN match नहीं हुआ');
        return;
      }
      await setPin(value);
      onContinue();
      return;
    }
    if (value !== pin) {
      setError('गलत PIN');
      return;
    }
    onContinue();
  };

  return (
    <View style={styles.darkPage}>
      <StatusBar style="light" />
      <View style={styles.loginOrbOne} />
      <View style={styles.loginOrbTwo} />
      <View style={styles.loginContent}>
        <View style={styles.loginTop}>
          <View style={styles.logoBox}>
            <Feather name="shield" size={26} color="#fff" />
          </View>
          <View>
            <Text style={styles.brandKicker}>ADMIN ONLY</Text>
            <Text style={styles.brandTitle}>Gram Panchayat Cashbook</Text>
          </View>
        </View>
        <View style={styles.loginMiddle}>
          <Text style={styles.loginGreeting}>
            {!setupComplete || !pin ? 'Admin PIN सेट करें' : 'Admin Login'}
          </Text>
          <Text style={styles.loginDescription}>
            केवल Admin — सारी permissions (PROJECT_MASTER §19.1)
          </Text>
          <Field label="PIN" value={value} onChangeText={setValue} keyboardType="numeric" secureTextEntry />
          {!setupComplete || !pin ? (
            <Field label="Confirm PIN" value={confirm} onChangeText={setConfirm} keyboardType="numeric" secureTextEntry />
          ) : null}
          {error ? <Text style={styles.formError}>{error}</Text> : null}
          <Button label={!setupComplete || !pin ? 'Save PIN & Continue' : 'Login'} onPress={submit} icon="log-in" />
        </View>
        <ScreenBadge label="S-01" />
      </View>
    </View>
  );
}

/* ——— S-02 Panchayat + App Settings entry ——— */
function PanchayatScreen({
  onContinue,
  onBack,
  onSettings,
}: {
  onContinue: () => void;
  onBack: () => void;
  onSettings: () => void;
}) {
  const { panchayats, activePanchayatId, setActivePanchayatId, activePanchayat } = useCashbook();
  return (
    <View style={styles.page}>
      <StatusBar style="dark" />
      <Header
        eyebrow="Good day"
        title="Panchayat चुनें"
        onBack={onBack}
        badge="S-02"
        action={
          <IconButton name="settings" onPress={onSettings} />
        }
      />
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.hint}>Settings (⚙) से universal settings + पंचायत add/edit/delete (PIN confirm)</Text>
        {panchayats.map((p) => (
          <Pressable
            key={p.id}
            onPress={() => setActivePanchayatId(p.id)}
            style={[styles.listCard, activePanchayatId === p.id && styles.listCardActive]}
          >
            <Text style={styles.listTitle}>{p.name}</Text>
            <Text style={styles.listMeta}>
              पं.समि. {p.block}, जिला {p.district}
            </Text>
          </Pressable>
        ))}
        <Button label="प्रवेश करें" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.footerNote}>Active: {activePanchayat.name}</Text>
      </ScrollView>
    </View>
  );
}

function AppSettingsScreen({ onBack }: { onBack: () => void }) {
  const {
    panchayats,
    addPanchayat,
    updatePanchayat,
    deletePanchayat,
    activePanchayatId,
  } = useCashbook();
  const [name, setName] = useState('');
  const [block, setBlock] = useState('');
  const [district, setDistrict] = useState('');
  const [editId, setEditId] = useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<null | (() => void)>(null);

  const requestConfirm = (fn: () => void) => {
    setPendingAction(() => fn);
    setConfirmOpen(true);
  };

  return (
    <View style={styles.page}>
      <Header title="App Settings" eyebrow="Universal + Panchayat" onBack={onBack} badge="S-47" />
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.settingsIntro}>
          <View style={styles.settingsIcon}>
            <Feather name="sliders" size={18} color={C.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.settingsTitle}>Universal settings</Text>
            <Text style={styles.settingsBody}>
              Theme / logo / language — S-47 hooks. नीचे पंचायत master (add/edit/delete + PIN confirm)।
            </Text>
          </View>
        </View>

        <Text style={styles.sectionLabel}>पंचायत जोड़ें</Text>
        <Field label="नाम" value={name} onChangeText={setName} placeholder="ग्राम पंचायत …" />
        <Field label="पं.समिति" value={block} onChangeText={setBlock} />
        <Field label="जिला" value={district} onChangeText={setDistrict} />
        <Button
          label="Add Panchayat"
          icon="plus"
          onPress={async () => {
            if (!name.trim()) {
              Alert.alert('नाम आवश्यक');
              return;
            }
            await addPanchayat({ name: name.trim(), block: block.trim() || '—', district: district.trim() || '—' });
            setName('');
            setBlock('');
            setDistrict('');
          }}
        />

        <Text style={[styles.sectionLabel, { marginTop: 18 }]}>मौजूदा पंचायतें</Text>
        {panchayats.map((p) => (
          <View key={p.id} style={styles.fundSettingRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.listTitle}>{p.name}</Text>
              <Text style={styles.fundMeta}>
                {p.block} · {p.district}
              </Text>
            </View>
            <Pressable
              onPress={() => {
                setEditId(p.id);
                setName(p.name);
                setBlock(p.block);
                setDistrict(p.district);
              }}
            >
              <Text style={styles.editLink}>Edit</Text>
            </Pressable>
            <Pressable
              onPress={() =>
                requestConfirm(async () => {
                  const r = await deletePanchayat(p.id);
                  if (!r.ok) Alert.alert('Error', r.error);
                })
              }
            >
              <Text style={styles.deleteLink}>Delete</Text>
            </Pressable>
          </View>
        ))}

        {editId ? (
          <View style={styles.inlineEdit}>
            <Text style={styles.sectionLabel}>Edit save (PIN confirm)</Text>
            <Button
              label="Save changes"
              onPress={() =>
                requestConfirm(async () => {
                  await updatePanchayat(editId, {
                    name: name.trim(),
                    block: block.trim(),
                    district: district.trim(),
                  });
                  setEditId(null);
                  setName('');
                  setBlock('');
                  setDistrict('');
                })
              }
            />
          </View>
        ) : null}

        <Text style={styles.footerNote}>Active panchayat id: {activePanchayatId}</Text>
      </ScrollView>
      <PasswordConfirmModal
        visible={confirmOpen}
        title="Confirm with Admin PIN"
        onCancel={() => {
          setConfirmOpen(false);
          setPendingAction(null);
        }}
        onConfirm={() => {
          setConfirmOpen(false);
          pendingAction?.();
          setPendingAction(null);
        }}
      />
    </View>
  );
}

/* ——— S-05 FY + settings ——— */
function FYScreen({
  onContinue,
  onBack,
  onSettings,
}: {
  onContinue: () => void;
  onBack: () => void;
  onSettings: () => void;
}) {
  const {
    financialYears,
    activeFinancialYearId,
    setActiveFinancialYearId,
    activeFinancialYear,
    totalOpening,
    totalIncome,
    totalExpense,
    currentBalance,
    activePanchayat,
  } = useCashbook();

  return (
    <View style={styles.page}>
      <Header
        eyebrow={activePanchayat.name}
        title="वित्तीय वर्ष"
        onBack={onBack}
        badge="S-05"
        action={<IconButton name="settings" onPress={onSettings} />}
      />
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.hint}>⚙ Settings: FY/scheme CRUD, line-count, blank gap, scheme-minus policy</Text>
        {financialYears.map((fy) => (
          <Pressable
            key={fy.id}
            onPress={() => setActiveFinancialYearId(fy.id)}
            style={[styles.listCard, activeFinancialYearId === fy.id && styles.listCardActive]}
          >
            <Text style={styles.listTitle}>{fy.label}</Text>
            <Text style={styles.listMeta}>
              {fy.start} → {fy.end}
            </Text>
          </Pressable>
        ))}
        <View style={styles.statRow}>
          <Stat label="Opening" value={formatINR(totalOpening)} />
          <Stat label="Income" value={formatINR(totalIncome)} />
          <Stat label="Expense" value={formatINR(totalExpense)} />
          <Stat label="Balance" value={formatINR(currentBalance)} />
        </View>
        <Button label="Proceed → FY Home" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.footerNote}>Selected: {activeFinancialYear.label}</Text>
      </ScrollView>
    </View>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

function FYSettingsScreen({ onBack }: { onBack: () => void }) {
  const {
    fySettings,
    updateFySettings,
    activeFunds,
    addFund,
    updateOpeningBalance,
    deleteFundFromFy,
    addFinancialYear,
  } = useCashbook();
  const [newFund, setNewFund] = useState('');
  const [newOpen, setNewOpen] = useState('0');
  const [editId, setEditId] = useState<string | null>(null);
  const [editBal, setEditBal] = useState('');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pending, setPending] = useState<null | (() => void)>(null);
  const [fyLabel, setFyLabel] = useState('');

  const ask = (fn: () => void) => {
    setPending(() => fn);
    setConfirmOpen(true);
  };

  return (
    <View style={styles.page}>
      <Header title="Panchayat / FY Settings" onBack={onBack} badge="S-05" />
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.sectionLabel}>Cashbook lines (middle zone only)</Text>
        <Field
          label="Total lines per side (default 30)"
          value={String(fySettings.lineCount)}
          onChangeText={(v) => {
            const n = parseInt(v || '30', 10);
            if (!Number.isNaN(n) && n >= 10 && n <= 40) updateFySettings({ lineCount: n });
          }}
          keyboardType="numeric"
        />
        <Text style={styles.hint}>केवल बीच की transaction lines बदलती हैं — श्री पोते + नीचे 3 fixed (§19.4)</Text>

        <Text style={styles.sectionLabel}>Blank lines after each entry</Text>
        <View style={styles.rowGap}>
          <Button
            label="1 line"
            variant={fySettings.blankLineGap === 1 ? 'primary' : 'outline'}
            onPress={() => updateFySettings({ blankLineGap: 1 })}
          />
          <Button
            label="2 lines"
            variant={fySettings.blankLineGap === 2 ? 'primary' : 'outline'}
            onPress={() => updateFySettings({ blankLineGap: 2 })}
          />
        </View>

        <Text style={styles.sectionLabel}>Scheme balance may go negative?</Text>
        <Button
          label={fySettings.allowSchemeNegative ? 'ON — scheme minus allowed' : 'OFF — scheme minus blocked'}
          variant={fySettings.allowSchemeNegative ? 'soft' : 'outline'}
          onPress={() => updateFySettings({ allowSchemeNegative: !fySettings.allowSchemeNegative })}
        />
        <Text style={styles.hint}>Overall day expense ≤ income महायोग हमेशा लागू (§19.6)</Text>

        <Text style={styles.sectionLabel}>Appearance</Text>
        <Field
          label="Entry font colour (hex)"
          value={fySettings.entryFontColor}
          onChangeText={(v) => updateFySettings({ entryFontColor: v })}
        />
        <Field
          label="श्री पोते colour"
          value={fySettings.shriPoteColor}
          onChangeText={(v) => updateFySettings({ shriPoteColor: v })}
        />
        <Field
          label="Page background"
          value={fySettings.pageBackground}
          onChangeText={(v) => updateFySettings({ pageBackground: v })}
        />

        <Text style={styles.sectionLabel}>Schemes (इस FY)</Text>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.fundSettingRow}>
            <View style={styles.fundSettingDot}>
              <Text style={{ fontSize: 10, fontWeight: '800', color: C.primary }}>{f.shortName.slice(0, 3)}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.listTitle}>{f.name}</Text>
              <Text style={styles.fundMeta}>
                Opening {formatINR(f.openingBalance)} · {f.openingSource === 'carry-forward' ? '↩ Carry-forward' : '✎ Manual'}
              </Text>
            </View>
            <Pressable
              onPress={() => {
                setEditId(f.id);
                setEditBal(String(f.openingBalance));
              }}
            >
              <Text style={styles.editLink}>Edit</Text>
            </Pressable>
            <Pressable
              onPress={() =>
                ask(() => {
                  deleteFundFromFy(f.id);
                })
              }
            >
              <Text style={styles.deleteLink}>Delete</Text>
            </Pressable>
            {editId === f.id ? (
              <View style={styles.inlineEdit}>
                <Text style={styles.amountLabel}>Opening balance (visible — layout fix §19.5)</Text>
                <TextInput
                  value={editBal}
                  onChangeText={setEditBal}
                  keyboardType="numeric"
                  style={styles.inlineInput}
                />
                <Button
                  label="Save opening"
                  onPress={() => {
                    updateOpeningBalance(f.id, parseFloat(editBal) || 0, 'manual');
                    setEditId(null);
                  }}
                />
              </View>
            ) : null}
          </View>
        ))}

        <Field label="New scheme name" value={newFund} onChangeText={setNewFund} />
        <Field label="Opening balance" value={newOpen} onChangeText={setNewOpen} keyboardType="numeric" />
        <Button
          label="Add scheme (this FY)"
          icon="plus"
          onPress={() => {
            addFund(newFund, parseFloat(newOpen) || 0, 'manual');
            setNewFund('');
            setNewOpen('0');
          }}
        />

        <Text style={styles.sectionLabel}>Add financial year</Text>
        <Field label="Label e.g. 2027–28" value={fyLabel} onChangeText={setFyLabel} />
        <Button
          label="Add FY"
          onPress={() => {
            if (!fyLabel.trim()) return;
            addFinancialYear({
              label: fyLabel.trim(),
              start: '2027-04-01',
              end: '2028-03-31',
            });
            setFyLabel('');
          }}
        />
      </ScrollView>
      <PasswordConfirmModal
        visible={confirmOpen}
        title="Delete scheme from this FY?"
        onCancel={() => {
          setConfirmOpen(false);
          setPending(null);
        }}
        onConfirm={() => {
          setConfirmOpen(false);
          pending?.();
          setPending(null);
        }}
      />
    </View>
  );
}

/* ——— S-06 FY Home ——— */
function HomeScreen({
  onCashbook,
  onBack,
  onFunds,
  onNavigate,
}: {
  onCashbook: () => void;
  onBack: () => void;
  onFunds: () => void;
  onNavigate: (s: Stage) => void;
}) {
  const { activeFinancialYear, activePanchayat, currentBalance, totalIncome, totalExpense, transactions } =
    useCashbook();
  const activeCount = transactions.filter((t) => t.status === 'active').length;

  return (
    <View style={styles.page}>
      <Header
        eyebrow={activePanchayat.name}
        title={`FY ${activeFinancialYear.label}`}
        onBack={onBack}
        badge="S-06"
      />
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.statRow}>
          <Stat label="Balance" value={formatINR(currentBalance)} />
          <Stat label="Income" value={formatINR(totalIncome)} />
          <Stat label="Expense" value={formatINR(totalExpense)} />
          <Stat label="Entries" value={String(activeCount)} />
        </View>

        <HomeRow icon="book" title="Cashbook" subtitle="30-line page · income / expense" onPress={onCashbook} />
        <HomeRow icon="layers" title="Fund / Scheme heads" subtitle="Opening balance · delete (FY)" onPress={onFunds} />
        <HomeRow
          icon="check-circle"
          title="मासिक जाँच (Monthly check)"
          subtitle="Warnings → open entry"
          onPress={() => onNavigate('monthlyCheck')}
        />
        <HomeRow icon="pie-chart" title="गोशवारा till date" subtitle="Classified summary" onPress={() => onNavigate('goswara')} />
        <HomeRow icon="bar-chart-2" title="Reports & Ledgers" subtitle="Hub + empty-state guidance" onPress={() => onNavigate('reports')} />
        <HomeRow icon="hard-drive" title="Backup & Restore" subtitle="Save / restore / export" onPress={() => onNavigate('backup')} />
        <HomeRow icon="credit-card" title="Bank Statement" subtitle="Upload · tag · auto entry (§11)" onPress={() => onNavigate('bank')} />
      </ScrollView>
    </View>
  );
}

function HomeRow({
  icon,
  title,
  subtitle,
  onPress,
}: {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  subtitle: string;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.homeRow, pressed && styles.pressed]}>
      <View style={styles.homeIcon}>
        <Feather name={icon} size={18} color={C.primary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.listTitle}>{title}</Text>
        <Text style={styles.listMeta}>{subtitle}</Text>
      </View>
      <Feather name="chevron-right" size={18} color={C.mutedForeground} />
    </Pressable>
  );
}

/* ——— Cashbook S-07 + entry ——— */
function CashbookScreen({ onBack, onFunds }: { onBack: () => void; onFunds: () => void }) {
  const {
    activeFunds,
    transactions,
    addTransaction,
    cancelTransaction,
    fySettings,
    totalOpening,
    activePanchayat,
    activeFinancialYear,
  } = useCashbook();
  const [showForm, setShowForm] = useState(false);
  const [type, setType] = useState<TransactionType>('income');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [party, setParty] = useState('');
  const [detail, setDetail] = useState('');
  const [note, setNote] = useState('');
  const [schemeId, setSchemeId] = useState('sfc');
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');

  const active = useMemo(
    () =>
      [...transactions]
        .filter((t) => t.status === 'active')
        .sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt)),
    [transactions]
  );

  const income = active.filter((t) => t.type === 'income');
  const expense = active.filter((t) => t.type === 'expense');
  const incomeTotal = income.reduce((s, t) => s + Object.values(t.amounts).reduce((a, b) => a + b, 0), 0);
  const expenseTotal = expense.reduce((s, t) => s + Object.values(t.amounts).reduce((a, b) => a + b, 0), 0);
  const mahayogIncome = totalOpening + incomeTotal;
  const bachat = mahayogIncome - expenseTotal;

  const save = async () => {
    setError('');
    if (!schemeId) {
      setError('Scheme चुनना अनिवार्य है');
      return;
    }
    const n = parseFloat(amount);
    if (!party.trim() || !(n > 0)) {
      setError('पार्टी / राशि आवश्यक');
      return;
    }
    const result = await addTransaction({
      type,
      date,
      reference: '',
      party: party.trim(),
      detail: detail.trim(),
      note: note.trim(),
      schemeId,
      amounts: { [schemeId]: n },
    });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setShowForm(false);
    setParty('');
    setDetail('');
    setNote('');
    setAmount('');
    setSchemeId('sfc');
  };

  return (
    <View style={[styles.page, { backgroundColor: fySettings.pageBackground }]}>
      <Header
        eyebrow={`${activePanchayat.name} · ${activeFinancialYear.label}`}
        title="Cashbook"
        onBack={onBack}
        badge="S-07"
        action={
          <View style={{ flexDirection: 'row', gap: 6 }}>
            <IconButton name="layers" onPress={onFunds} />
            <IconButton name="share-2" onPress={() => Alert.alert('Share', 'Page/range PDF & Excel — white background (§19.10). Native share next build.')} />
          </View>
        }
      />
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.rowGap}>
          <Button label="+ आय" icon="plus" onPress={() => { setType('income'); setSchemeId('sfc'); setShowForm(true); }} />
          <Button label="+ व्यय" icon="minus" variant="danger" onPress={() => { setType('expense'); setSchemeId('sfc'); setShowForm(true); }} />
        </View>

        <Text style={[styles.sectionLabel, { color: fySettings.shriPoteColor }]}>श्री पोते (auto · not editable)</Text>
        {activeFunds.map((f) => (
          <Text key={f.id} style={{ color: fySettings.shriPoteColor, fontWeight: '800', fontSize: 13, marginBottom: 4 }}>
            {f.shortName}: {formatINR(f.openingBalance)}{' '}
            {f.openingSource === 'carry-forward' ? '↩ CF' : '✎ Manual'}
          </Text>
        ))}

        <Text style={styles.sectionLabel}>Income</Text>
        {income.length === 0 ? <Text style={styles.listMeta}>No income entries yet</Text> : null}
        {income.map((t, idx) => (
          <View key={t.id}>
            <Pressable
              onLongPress={() =>
                Alert.alert('Cancel entry?', t.party, [
                  { text: 'No' },
                  { text: 'Cancel entry', style: 'destructive', onPress: () => cancelTransaction(t.id) },
                ])
              }
              style={styles.txRow}
            >
              <Text style={[styles.txText, { color: fySettings.entryFontColor }]}>
                {t.date} · {t.party} · {formatINR(Object.values(t.amounts).reduce((a, b) => a + b, 0))} · {t.schemeId.toUpperCase()}
              </Text>
            </Pressable>
            {Array.from({ length: fySettings.blankLineGap }).map((_, i) => (
              <View key={`${t.id}-b${i}`} style={{ height: 8 }} />
            ))}
            {idx === income.length - 1 ? null : null}
          </View>
        ))}

        <Text style={[styles.sectionLabel, { marginTop: 12 }]}>Expense (line 1 blank on printed page)</Text>
        {expense.length === 0 ? <Text style={styles.listMeta}>No expense entries yet</Text> : null}
        {expense.map((t) => (
          <Pressable
            key={t.id}
            onLongPress={() =>
              Alert.alert('Cancel entry?', t.party, [
                { text: 'No' },
                { text: 'Cancel entry', style: 'destructive', onPress: () => cancelTransaction(t.id) },
              ])
            }
            style={styles.txRow}
          >
            <Text style={[styles.txText, { color: fySettings.entryFontColor }]}>
              {t.date} · {t.party} · {formatINR(Object.values(t.amounts).reduce((a, b) => a + b, 0))} · {t.schemeId.toUpperCase()}
            </Text>
          </Pressable>
        ))}

        <View style={styles.summaryBox}>
          <Text style={[styles.summaryLine, { color: fySettings.summaryFontColor }]}>आय योग: {formatINR(incomeTotal)}</Text>
          <Text style={[styles.summaryLine, { color: fySettings.summaryFontColor }]}>श्री पोते: {formatINR(totalOpening)}</Text>
          <Text style={[styles.summaryLine, { color: fySettings.summaryFontColor }]}>महायोग: {formatINR(mahayogIncome)}</Text>
          <Text style={[styles.summaryLine, { color: fySettings.summaryFontColor }]}>व्यय योग: {formatINR(expenseTotal)}</Text>
          <Text style={[styles.summaryLine, { color: fySettings.summaryFontColor }]}>बचत पोते: {formatINR(bachat)}</Text>
          <Text style={styles.hint}>Summary lines auto-only — manual edit नहीं (§19.11)</Text>
        </View>
      </ScrollView>

      <Modal visible={showForm} animationType="slide" onRequestClose={() => setShowForm(false)}>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.page}>
          <Header title={type === 'income' ? 'Add Income' : 'Add Expense'} onBack={() => setShowForm(false)} badge={type === 'income' ? 'S-08' : 'S-09'} />
          <ScrollView contentContainerStyle={styles.scroll}>
            <Text style={styles.hint}>Default scheme = SFC · scheme required (§19.6)</Text>
            <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} />
            <Field label={type === 'income' ? 'किससे प्राप्त' : 'किसको भुगतान'} value={party} onChangeText={setParty} />
            <Field label="Detail" value={detail} onChangeText={setDetail} />
            <Field label="Note" value={note} onChangeText={setNote} multiline />
            <Text style={styles.sectionLabel}>Scheme</Text>
            <View style={styles.chipRow}>
              {activeFunds.map((f) => (
                <Pressable
                  key={f.id}
                  onPress={() => setSchemeId(f.id)}
                  style={[styles.chip, schemeId === f.id && styles.chipOn]}
                >
                  <Text style={[styles.chipText, schemeId === f.id && styles.chipTextOn]}>{f.shortName}</Text>
                </Pressable>
              ))}
            </View>
            <Field label="Amount (₹)" value={amount} onChangeText={setAmount} keyboardType="numeric" />
            {error ? <Text style={styles.formError}>{error}</Text> : null}
            <Button label="Save" icon="check" onPress={save} />
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

function FundsScreen({ onBack }: { onBack: () => void }) {
  const { activeFunds, updateOpeningBalance, deleteFundFromFy, addFund } = useCashbook();
  const [editId, setEditId] = useState<string | null>(null);
  const [bal, setBal] = useState('');
  const [name, setName] = useState('');
  const [open, setOpen] = useState('0');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingId, setPendingId] = useState<string | null>(null);

  return (
    <View style={styles.page}>
      <Header title="Fund / Scheme heads" onBack={onBack} badge="S-35" />
      <ScrollView contentContainerStyle={styles.scroll}>
        {activeFunds.length === 0 ? (
          <EmptyState
            title="कोई active fund head नहीं"
            why="सभी schemes disable हैं या अभी add नहीं की गईं।"
            steps={['नीचे नई scheme add करें', 'FY Settings से भी manage कर सकते हैं']}
          />
        ) : null}
        {activeFunds.map((f: Fund) => (
          <View key={f.id} style={styles.fundSettingRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.listTitle}>{f.name}</Text>
              <Text style={styles.fundMeta}>
                Opening {formatINR(f.openingBalance)} · {f.openingSource === 'carry-forward' ? 'Carry-forward' : 'Manual'}
              </Text>
            </View>
            <Pressable
              onPress={() => {
                setEditId(f.id);
                setBal(String(f.openingBalance));
              }}
            >
              <Text style={styles.editLink}>Edit</Text>
            </Pressable>
            <Pressable
              onPress={() => {
                setPendingId(f.id);
                setConfirmOpen(true);
              }}
            >
              <Text style={styles.deleteLink}>Delete</Text>
            </Pressable>
            {editId === f.id ? (
              <View style={styles.inlineEdit}>
                <Text style={styles.amountLabel}>Opening balance</Text>
                <TextInput value={bal} onChangeText={setBal} keyboardType="numeric" style={styles.inlineInput} />
                <Button
                  label="Save"
                  onPress={() => {
                    updateOpeningBalance(f.id, parseFloat(bal) || 0, 'manual');
                    setEditId(null);
                  }}
                />
              </View>
            ) : null}
          </View>
        ))}
        <Field label="New scheme" value={name} onChangeText={setName} />
        <Field label="Opening" value={open} onChangeText={setOpen} keyboardType="numeric" />
        <Button
          label="Add"
          onPress={() => {
            addFund(name, parseFloat(open) || 0, 'manual');
            setName('');
            setOpen('0');
          }}
        />
      </ScrollView>
      <PasswordConfirmModal
        visible={confirmOpen}
        title="इस FY से scheme हटाएँ?"
        onCancel={() => {
          setConfirmOpen(false);
          setPendingId(null);
        }}
        onConfirm={() => {
          if (pendingId) deleteFundFromFy(pendingId);
          setConfirmOpen(false);
          setPendingId(null);
        }}
      />
    </View>
  );
}

function MonthlyCheckScreen({ onBack }: { onBack: () => void }) {
  const { transactions, cancelTransaction } = useCashbook();
  const warnings = transactions.filter((t) => t.status === 'active' && !t.party.trim());
  // sample warnings: missing party already blocked; show cancelled count etc.
  const cancelled = transactions.filter((t) => t.status === 'cancelled');

  return (
    <View style={styles.page}>
      <Header title="मासिक जाँच" onBack={onBack} badge="S-06" />
      <ScrollView contentContainerStyle={styles.scroll}>
        {warnings.length === 0 && cancelled.length === 0 ? (
          <EmptyState
            title="कोई warning नहीं"
            why="अभी unchecked / incomplete entries नहीं मिलीं।"
            steps={['Cashbook में entries डालें', 'Bank statement upload + tag करें', 'Pages verify करें']}
          />
        ) : null}
        {cancelled.map((t) => (
          <Pressable
            key={t.id}
            style={styles.listCard}
            onPress={() =>
              Alert.alert('Cancelled entry', `${t.date} · ${t.party}\nLong-press actions available on cashbook.`)
            }
          >
            <Text style={styles.listTitle}>Cancelled · {t.party || '(no party)'}</Text>
            <Text style={styles.listMeta}>{t.date} · tap for detail</Text>
          </Pressable>
        ))}
        {warnings.map((t) => (
          <Pressable
            key={t.id}
            style={styles.listCard}
            onPress={() =>
              Alert.alert('Fix entry', 'Open cashbook to edit/correct/cancel this entry.', [
                { text: 'OK' },
                {
                  text: 'Cancel entry',
                  style: 'destructive',
                  onPress: () => cancelTransaction(t.id),
                },
              ])
            }
          >
            <Text style={styles.listTitle}>Warning · incomplete party</Text>
            <Text style={styles.listMeta}>{t.id}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

function PlaceholderModule({
  title,
  badge,
  onBack,
  why,
  steps,
}: {
  title: string;
  badge: string;
  onBack: () => void;
  why: string;
  steps: string[];
}) {
  return (
    <View style={styles.page}>
      <Header title={title} onBack={onBack} badge={badge} />
      <ScrollView contentContainerStyle={styles.scroll}>
        <EmptyState title={`${title} — जानकारी`} why={why} steps={steps} />
      </ScrollView>
    </View>
  );
}

/* ——— Navigation shell with Android back → parent (Section 19.3) ——— */
function AppContent() {
  const [stage, setStage] = useState<Stage>('login');
  const [stack, setStack] = useState<Stage[]>(['login']);
  const { hydrated } = useCashbook();

  const go = useCallback((next: Stage) => {
    setStack((s) => [...s, next]);
    setStage(next);
  }, []);

  const back = useCallback(() => {
    setStack((s) => {
      if (s.length <= 1) {
        Alert.alert('Exit app?', 'Login screen पर हैं। बाहर निकलें?', [
          { text: 'Stay', style: 'cancel' },
          {
            text: 'Exit',
            style: 'destructive',
            onPress: () => {
              if (Platform.OS !== 'web') BackHandler.exitApp();
            },
          },
        ]);
        return s;
      }
      const next = s.slice(0, -1);
      setStage(next[next.length - 1]);
      return next;
    });
  }, []);

  React.useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      back();
      return true; // consume — do not leave to Android home (§19.3)
    });
    return () => sub.remove();
  }, [back]);

  if (!hydrated) {
    return (
      <View style={styles.loading}>
        <Feather name="loader" size={24} color={C.primary} />
        <Text style={styles.loadingText}>Loading secure cashbook…</Text>
      </View>
    );
  }

  if (stage === 'login') return <LoginScreen onContinue={() => go('panchayat')} />;
  if (stage === 'panchayat')
    return <PanchayatScreen onContinue={() => go('fy')} onBack={back} onSettings={() => go('appSettings')} />;
  if (stage === 'appSettings') return <AppSettingsScreen onBack={back} />;
  if (stage === 'fy')
    return <FYScreen onContinue={() => go('home')} onBack={back} onSettings={() => go('fySettings')} />;
  if (stage === 'fySettings') return <FYSettingsScreen onBack={back} />;
  if (stage === 'funds') return <FundsScreen onBack={back} />;
  if (stage === 'cashbook') return <CashbookScreen onBack={back} onFunds={() => go('funds')} />;
  if (stage === 'monthlyCheck') return <MonthlyCheckScreen onBack={back} />;
  if (stage === 'goswara')
    return (
      <PlaceholderModule
        title="गोशवारा till date"
        badge="S-27"
        onBack={back}
        why="अभी classified गोशवारा के लिए पर्याप्त categorized data / year activity नहीं है, या module data pipeline बाकी है।"
        steps={['Cashbook में scheme-wise आय/व्यय entries डालें', 'FY home से गोशवारा तब दिखेगा जब totals उपलब्ध हों', 'Full annual गोशवारा 31 March / FY Closing (S-45)']}
      />
    );
  if (stage === 'reports')
    return (
      <PlaceholderModule
        title="Reports & Ledgers"
        badge="S-34"
        onBack={back}
        why="Reports Hub खाली है क्योंकि अभी exportable datasets generate नहीं हुए।"
        steps={['Transactions जोड़ें', 'Fund-wise / work modules भरें', 'फिर page-wise / fund-wise reports यहाँ मिलेंगी']}
      />
    );
  if (stage === 'backup')
    return (
      <PlaceholderModule
        title="Backup & Restore"
        badge="S-42"
        onBack={back}
        why="Local AsyncStorage में data सुरक्षित है; full zip backup UI अगले slice में Documents/Cashbook (SAF) से जुड़ेगा।"
        steps={['अभी data device local storage में auto-save है', 'Production: Settings → Backup zip + restore code (S-46)', 'Year lock से पहले safe backup compulsory (§4)']}
      />
    );
  if (stage === 'bank')
    return (
      <PlaceholderModule
        title="Bank Statement"
        badge="S-13"
        onBack={back}
        why="Bank PDF upload + AI read + tagging + auto cashbook entry (Section 11) का full pipeline इस build में scaffold है — files/permissions next."
        steps={['Account master जोड़ें', 'Password-protected PDF upload', 'Tag scheme/कार्य', 'Auto-entry review (D−1 / grouping rules)']}
      />
    );

  return (
    <HomeScreen
      onCashbook={() => go('cashbook')}
      onBack={back}
      onFunds={() => go('funds')}
      onNavigate={(s) => go(s)}
    />
  );
}

export default function Index() {
  return (
    <CashbookProvider>
      <AppContent />
    </CashbookProvider>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  darkPage: { flex: 1, backgroundColor: C.darkForest, overflow: 'hidden' },
  loginContent: { flex: 1, paddingHorizontal: 24, paddingBottom: 28, justifyContent: 'space-between' },
  loginOrbOne: {
    position: 'absolute',
    width: 320,
    height: 320,
    borderRadius: 160,
    backgroundColor: '#1d6147',
    top: -150,
    right: -120,
    opacity: 0.42,
  },
  loginOrbTwo: {
    position: 'absolute',
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: '#244f3d',
    bottom: -160,
    left: -140,
    opacity: 0.65,
  },
  loginTop: { paddingTop: 68, flexDirection: 'row', alignItems: 'center', gap: 13 },
  logoBox: {
    width: 54,
    height: 54,
    borderRadius: 17,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.16)',
  },
  brandKicker: { color: C.accent, letterSpacing: 3, fontSize: 11, fontWeight: '700' },
  brandTitle: { color: '#ffffff', fontSize: 16, marginTop: 3, fontWeight: '600' },
  loginMiddle: { paddingBottom: 12 },
  loginGreeting: { color: '#ffffff', fontSize: 28, fontWeight: '700', letterSpacing: -0.6, marginBottom: 8 },
  loginDescription: { color: 'rgba(255,255,255,0.68)', fontSize: 14, lineHeight: 20, marginBottom: 18 },
  header: { backgroundColor: C.primary, paddingHorizontal: 14, paddingBottom: 12 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  headerCopy: { flex: 1 },
  headerEyebrow: { color: 'rgba(255,255,255,0.75)', fontSize: 11, fontWeight: '600' },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  mark: {
    width: 36,
    height: 36,
    borderRadius: 11,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 11,
    backgroundColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: { opacity: 0.75 },
  scroll: { padding: 16, paddingBottom: 40 },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 13,
    borderWidth: 1,
    marginVertical: 4,
    flex: 1,
  },
  buttonText: { fontSize: 14, fontWeight: '800' },
  fieldWrap: { marginBottom: 12 },
  fieldLabel: { color: C.mutedForeground, fontSize: 11, fontWeight: '700', marginBottom: 6 },
  field: {
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 13,
    backgroundColor: C.card,
    color: C.foreground,
    fontSize: 14,
    paddingHorizontal: 13,
    paddingVertical: 12,
  },
  multiline: { minHeight: 74, textAlignVertical: 'top' },
  formError: { color: C.expense, fontSize: 12, marginBottom: 10, lineHeight: 18 },
  hint: { color: C.mutedForeground, fontSize: 12, lineHeight: 17, marginBottom: 12 },
  listCard: {
    backgroundColor: C.card,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 16,
    padding: 14,
    marginBottom: 10,
  },
  listCardActive: { borderColor: C.primary, backgroundColor: C.primarySoft },
  listTitle: { color: C.foreground, fontSize: 15, fontWeight: '800' },
  listMeta: { color: C.mutedForeground, fontSize: 12, marginTop: 4 },
  footerNote: { color: C.mutedForeground, fontSize: 11, marginTop: 14, textAlign: 'center' },
  sectionLabel: { color: C.foreground, fontSize: 13, fontWeight: '800', marginTop: 8, marginBottom: 8 },
  settingsIntro: {
    flexDirection: 'row',
    gap: 12,
    backgroundColor: C.primarySoft,
    borderRadius: 18,
    padding: 15,
    marginBottom: 18,
  },
  settingsIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: 'rgba(255,255,255,0.68)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  settingsTitle: { color: C.primary, fontSize: 14, fontWeight: '800' },
  settingsBody: { color: C.secondaryForeground, fontSize: 11, lineHeight: 17, marginTop: 5 },
  fundSettingRow: {
    backgroundColor: C.card,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 16,
    padding: 13,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 9,
    flexWrap: 'wrap',
  },
  fundSettingDot: {
    width: 33,
    height: 33,
    borderRadius: 11,
    backgroundColor: C.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fundMeta: { color: C.mutedForeground, fontSize: 10, marginTop: 4 },
  editLink: { color: C.primary, fontSize: 11, fontWeight: '800' },
  deleteLink: { color: C.expense, fontSize: 11, fontWeight: '800' },
  inlineEdit: { width: '100%', marginTop: 8, gap: 8 },
  inlineInput: {
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 11,
    backgroundColor: C.background,
    padding: 10,
    color: C.foreground,
  },
  amountLabel: { color: C.mutedForeground, fontSize: 10, fontWeight: '700', marginBottom: 4 },
  loading: { flex: 1, backgroundColor: C.background, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingText: { color: C.mutedForeground, fontSize: 13 },
  statRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  statCard: {
    width: '47%',
    backgroundColor: C.card,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: C.border,
    padding: 12,
  },
  statLabel: { color: C.mutedForeground, fontSize: 11, fontWeight: '700' },
  statValue: { color: C.foreground, fontSize: 15, fontWeight: '800', marginTop: 4 },
  homeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: C.card,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 16,
    padding: 14,
    marginBottom: 10,
  },
  homeIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: C.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowGap: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  txRow: {
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: C.border,
  },
  txText: { fontSize: 13, fontWeight: '600' },
  summaryBox: {
    marginTop: 18,
    padding: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.72)',
    borderWidth: 1,
    borderColor: C.border,
  },
  summaryLine: { fontSize: 14, fontWeight: '800', marginBottom: 6 },
  emptyCard: {
    backgroundColor: C.card,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: C.border,
    padding: 18,
    gap: 8,
  },
  emptyTitle: { fontSize: 16, fontWeight: '800', color: C.foreground },
  emptyWhy: { fontSize: 13, color: C.mutedForeground, lineHeight: 19 },
  emptyStepsHead: { fontSize: 12, fontWeight: '800', color: C.primary, marginTop: 8 },
  emptyStep: { fontSize: 12, color: C.foreground, lineHeight: 18 },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: { backgroundColor: C.card, borderRadius: 18, padding: 18, gap: 10 },
  modalTitle: { fontSize: 16, fontWeight: '800', color: C.foreground },
  modalBody: { fontSize: 13, color: C.mutedForeground, lineHeight: 18 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: C.card,
  },
  chipOn: { backgroundColor: C.primary, borderColor: C.primary },
  chipText: { fontSize: 12, fontWeight: '700', color: C.foreground },
  chipTextOn: { color: '#fff' },
});
