# Cashbook Project — Master Document (एकमात्र .md file)

**Document purpose:** पूरे project की **एक ही** .md file — original planning (Part A), नए design decisions (Part B) और पूरा screen index (Part C), सब merge करके. आगे के सारे updates/decisions सिर्फ़ इसी file में जुड़ेंगे — अलग .md files नहीं बनेंगी.

**App बनने पर:** हर window/page के corner में उसका छोटा सा screen number (`S-01`…`S-47`) दिखेगा — ताकि app में किसी page पर correction/addition बताना हो तो number से बोला जा सके (विवरण Part B, Section 15.3). अंतिम screen (S-47) हमेशा **App Settings** रहेगी.

**Status:** Planning + Round 5 UX/settings rules locked in doc; implementation ongoing — Admin-only app, settings hierarchy, cashbook UX (Section 19).

**Last updated:** 20-09-2026 (Round 5 — Admin-only, settings hierarchy, cashbook UX, navigation, empty-state fixes)


---

# PART A — Original Progress & Development Record

*(पहले का PROJECT_PROGRESS.md — जैसा था वैसा ही, reference के लिए)*

# Cashbook Android Project — Progress & Development Record

**Document purpose:** यह file अब तक हुई पूरी planning, requirements, technical decisions, build attempts, errors और future development roadmap का consolidated record है। इसे GitHub repository में `PROJECT_PROGRESS.md` या `docs/PROJECT_PROGRESS.md` के रूप में रखें।

**Current status:** Planning complete; Android project starter और CI workflow experiments तैयार हुए हैं; production cashbook अभी बनना बाकी है।

---

## 1. Project vision

यह Hindi-first Android application एक Excel-जैसी digital cashbook होगी। इसका उपयोग पूरे financial year में income, expense, balances, work/category analysis, annual गोशवारा और printable financial records के लिए होगा।

Target product:

```text
Digital Cashbook
+ Excel-like Grid
+ Automatic 30-line Pages
+ Dynamic Fund Columns
+ Work/Category Analysis
+ Annual Goswara
+ PDF/Excel Export
+ Backdated Correction
+ Audit Trail
+ Backup/Restore
+ Period Lock
+ Modular Updates
```

---

## 2. Financial year rules

- Financial year 1 April से 31 March तक होगा।
- उदाहरण: FY 2026–27 = 01-04-2026 से 31-03-2027।
- हर financial year का data अलग रहेगा।
- पुराने year को archive/read-only किया जा सकेगा।
- नए year का opening balance पिछले year के closing balance से लिया जा सकेगा।
- 31 March को annual गोशवारा बनेगा।
- Year close से पहले validation और backup होगा।
- Year lock के बाद normal users historical data edit नहीं कर सकेंगे।

---

## 3. Cashbook page design

हर printed page पर कुल 30 lines होंगी:

| Lines | Purpose |
|---|---|
| 1–27 | वास्तविक income/expense transactions |
| 28 | आय योग / व्यय योग |
| 29 | श्री पोते / बचत पोते |
| 30 | महायोग / महायोग |

Page दो बराबर हिस्सों में होगा:

- Left side: आय / Income / प्राप्तियाँ।
- Right side: व्यय / Expenses / भुगतान।

### 3.1 Income columns

Default structure:

1. Date
2. Invoice number/date
3. किससे प्राप्त किया
4. Details
5. Ledger folio
6. Cash
7. SFC
8. FFC
9. Own Fund/Interest
10. MP/MLA/TAD
11. Total
12. Additional note/attachment reference, यदि print layout में जगह दी जाए

### 3.2 Expense columns

Default structure:

1. Date
2. Voucher number/date
3. किसको भुगतान किया
4. Details
5. Ledger folio
6. Cash
7. SFC
8. FFC
9. Own Fund/Interest
10. MP/MLA/TAD
11. Total
12. Additional note/attachment reference, यदि print layout में जगह दी जाए

### 3.3 Summary lines

Income side:

- Line 28: `आय योग` — पहली 27 income lines का column-wise total।
- Line 29: `श्री पोते` — opening/previous closing balance। Label `किससे प्राप्त किया` में।
- Line 30: `महायोग` — `आय योग + श्री पोते`। Label `किससे प्राप्त किया` में।

Expense side:

- Line 28: `व्यय योग` — पहली 27 expense lines का column-wise total।
- Line 29: `बचत पोते` — income-side महायोग minus expense योग। Label `किसको भुगतान किया` में।
- Line 30: `महायोग` — `व्यय योग + बचत पोते`। Label `किसको भुगतान किया` में।

---

## 4. Page and date behavior

- 27 transaction lines पूरी होने पर अगला page automatic बनेगा।
- Page number automatic होगा।
- Empty days को skip किया जा सकेगा।
- Empty days page lines consume नहीं करेंगे।
- Reports में केवल active transaction dates या सभी calendar days दिखाने का option होगा।
- Actual transaction date और entry-created date अलग-अलग store होंगे।
- Entries chronological transaction date के आधार पर arrange होंगी।

### 4.1 Carry-forward balance

मुख्य rule:

```text
अगली active transaction date की श्री पोते
= पिछली active date/page की बचत पोते
```

प्रत्येक amount column के लिए:

```text
बचत पोते = श्री पोते + उस दिन की income - उस दिन का expense
```

Page 1 की बचत पोते अगले दिन की active entry अथवा अगले page की श्री पोते बनेगी। बीच में कई दिन खाली हों तो अगली active date पर वही balance आएगा।

---

## 5. Income features

### 5.1 Source dropdown

Default options:

- Govt / Government
- व्यक्ति
- Bank
- संस्था
- Firm/Vendor
- अन्य

यह list editable होगी।

### 5.2 Income detail dropdown

Default options:

- SFC
- FFC
- MP/MLA/TAD
- पट्टा शुल्क
- विवाह पंजीयन शुल्क
- जन्म प्रमाण शुल्क
- मृत्यु प्रमाण शुल्क
- Other/अन्य

`अन्य` चुनने पर custom description field खुलेगी।

### 5.3 Income fields

- Transaction date
- Invoice number/date
- Source
- Income detail
- Ledger folio
- Active fund amounts
- Automatic total
- Additional note
- Receipt/related attachment

---

## 6. Expense features

### 6.1 Expense party

`किसको भुगतान किया` में firm/vendor/person का नाम आएगा। Party master में:

- Existing party select।
- New party add।
- Search।
- Vendor-wise report।

### 6.2 Work

यदि `Work` चुना जाए:

- Work name required।
- Work master से select या नया work add।
- Work code/location/ward optional।
- Sanction/order reference optional।
- Work-wise annual expenditure report।

### 6.3 Other

यदि `Other` चुना जाए तो category select होगी:

- Stationery
- Printing
- भत्ता
- बिजली शुल्क
- सफाई कार्य
- ईंधन
- यात्रा
- मरम्मत
- डाक/कूरियर
- बैठक व्यय
- मोबाइल/इंटरनेट
- अन्य

यह list editable होगी।

### 6.4 Expense fields

- Transaction date
- Voucher number/date
- Vendor/party
- Work या Other
- Work name या category
- Ledger folio
- Active fund amounts
- Automatic total
- Additional note
- Bill/voucher attachment
- Cash/Bank payment mode

---

## 7. Additional note and attachments

Income और expense दोनों transactions में manual additional note होगा।

Examples:

```text
बिल क्रमांक 18, माप पुस्तिका पृष्ठ 42
वार्ड 3 के लिए रजिस्टर और फाइल खरीदी गईं
```

Attachments:

- Receipt photo
- Bill photo
- Voucher photo
- Sanction order
- Measurement book page
- PDF document

Attachment transaction ID से linked रहेगा।

---

## 8. Dynamic amount/fund columns

Default fund columns:

- Cash
- SFC
- FFC
- Own Fund/Interest
- MP/MLA/TAD

इन columns को hard-code नहीं करना है। `FundColumn` master/database table में रखना है।

### 8.1 First-page settings

Authorized user पहले page के left side से `Column/Fund Settings` खोल सकेगा:

- Add column
- Rename label
- Hindi/English label edit
- Stable code maintain
- Reorder
- Enable/disable
- Archive
- Show/hide in print
- Show/hide in reports
- Opening balance

### 8.2 Automatic propagation

Column change का प्रभाव automatic होगा:

- Existing pages
- New pages
- Income/expense headings
- Line totals
- आय योग/व्यय योग
- श्री पोते/बचत पोते
- महायोग
- Carry-forward balances
- Dashboard
- Reports
- Excel exports
- PDF layouts

Historical data वाला column direct delete न करें; archive/disable करें।

---

## 9. Formula rules

Dynamic active fund list `F` के लिए:

```text
Line Total = sum(amount[f] for f in active fund columns)
```

```text
आय योग[f] = पहली 27 income lines में f का sum
```

```text
व्यय योग[f] = पहली 27 expense lines में f का sum
```

```text
आय महायोग[f] = आय योग[f] + श्री पोते[f]
```

```text
बचत पोते[f] = आय महायोग[f] - व्यय योग[f]
```

```text
व्यय महायोग[f] = व्यय योग[f] + बचत पोते[f]
```

Total automatic होगा और manually editable नहीं होगा।

---

## 10. Backdated entries and correction

### 10.1 Backdated entry

पुरानी transaction date में entry add की जा सकेगी। Store करें:

- Transaction date
- Entry-created date/time
- Last-updated date/time
- User ID

Backdated entry पर:

- Chronological ordering update
- Page placement recalculate
- All affected page totals recalculate
- श्री पोते/बचत पोते/महायोग recalculate
- Future page openings update
- Reports/export update
- Impact warning

### 10.2 Editing

Existing transaction edit हो सकेगी। Reason required options:

- गलत amount
- गलत date
- गलत category
- गलत party/vendor
- गलत invoice/voucher
- गलत fund head
- अन्य

### 10.3 Locked period correction

Locked period में original entry delete न करें। Correction/adjustment entry बनाएं:

- Original transaction reference
- Old value
- Correct value
- Difference
- Reason
- Approval status

---

## 11. Annual गोशवारा — 31 March

31 March पर पूरे financial year का classified annual summary बनेगा।

### 11.1 Income side

Category-wise income:

- SFC
- FFC
- MP/MLA/TAD
- पट्टा शुल्क
- विवाह पंजीयन शुल्क
- जन्म प्रमाण शुल्क
- मृत्यु प्रमाण शुल्क
- Own Fund/Interest
- Other income
- Future-added categories

हर row में active fund columns और Total होंगे।

### 11.2 Expense side

Category-wise expenditure:

- Work name-wise
- Other category-wise
- Vendor-wise optional detail
- Active fund columns
- Total

### 11.3 Goswara bottom summary

Income side:

```text
आय योग
प्रारंभिक बैंक शेष
प्रारंभिक नकद शेष
महायोग
```

Expense side:

```text
व्यय योग
अंतिम बैंक शेष
अंतिम नकद शेष
महायोग
```

Formulas:

```text
आय महायोग = आय योग + प्रारंभिक बैंक शेष + प्रारंभिक नकद शेष
```

```text
व्यय महायोग = व्यय योग + अंतिम बैंक शेष + अंतिम नकद शेष
```

Validation:

```text
आय महायोग == व्यय महायोग
```

Mismatch होने पर warning/close block।

---

## 12. Reports required

हर report में compulsory:

```text
Export Excel
Export PDF
Share Excel
Share PDF
Print
```

Required reports:

1. Page-wise cashbook।
2. Date-wise।
3. Daily/weekly/monthly/custom date range।
4. Full financial-year।
5. Income।
6. Expense।
7. Work-wise expenditure।
8. Other-category expenditure।
9. Vendor/firm-wise।
10. Fund-wise।
11. Ledger-folio-wise।
12. Monthly dashboard।
13. Annual गोशवारा।
14. Backdated entries।
15. Edited/corrected entries।
16. Cancelled entries।
17. Audit trail।
18. Validation/error।
19. Reconciliation।
20. Attachment/document।
21. Pending verification/approval।
22. Search results।

---

## 13. Excel-like UI

- Grid view
- Form view for mobile entry
- Cell editing
- Copy/paste
- Duplicate row
- Undo/redo
- Sort/filter
- Search
- Freeze header
- Column resize/reorder
- Dropdown validation
- Dependent dropdowns
- Automatic formulas
- Auto-save
- Draft state
- Excel import/export
- Error validation

Mobile में 12+12 columns के कारण form view default और grid view optional रखना बेहतर है।

---

## 14. Excel export

Editable workbook में suggested sheets:

1. Cashbook Print
2. All Transactions
3. Income Summary
4. Expense Summary
5. Work-wise Analysis
6. Other Category Analysis
7. Vendor-wise Analysis
8. Fund-wise Analysis
9. Monthly Summary
10. Annual Goswara
11. Validation/Errors
12. Audit Trail

Excel में formulas, filters, freeze panes, Hindi headings, date/amount formatting, summaries और optional charts होंगे। Raw data अलग sheet पर रहेगा।

---

## 15. PDF export and sharing

PDF modes:

- Original 30-line cashbook
- Full-year cashbook
- Annual गोशवारा
- Work/category analysis
- Monthly dashboard
- Audit/error report

Options:

- A4 landscape
- Legal/A3 landscape if needed
- Compact layout
- Split report
- Header/footer
- Page numbering
- Signature fields
- Draft/Verified/Final watermark
- Password-protected PDF optional

Share:

- WhatsApp
- Email
- Device storage
- Print
- Open in Excel/Google Sheets

### 15.1 Hindi font issue

पहली example PDF में Hindi अक्षर black boxes में दिखाई दिए क्योंकि proper Devanagari Unicode font embed नहीं था। Final PDF generator में यह अनिवार्य है:

- Mangal या Noto Sans Devanagari font file bundle करें।
- Font को PDF में embed करें।
- Hindi headings, categories और notes test करें।
- Android app में font resource रखें:

```text
app/src/main/res/font/noto_sans_devanagari.ttf
```

Compose example:

```kotlin
val DevanagariFont = FontFamily(
    Font(R.font.noto_sans_devanagari)
)
```

ReportLab/other generator में font registration और embedding test किया जाए। केवल font name बदलना पर्याप्त नहीं है।

---

## 16. Dashboard

Home screen:

```text
Financial Year
Opening Balance
Total Income
Total Expense
Current Balance
Total Pages
Pending Verification
Missing Attachments
Unbalanced Entries
```

Quick actions:

- Add Income
- Add Expense
- Current Page
- Reports
- Export
- Search
- Backup
- Reconciliation

---

## 17. Validation and error prevention

- Invalid date warning
- Numeric amount validation
- Negative amount prevention
- Duplicate invoice/voucher warning
- At least one amount required
- Work name required for Work
- Other category required for Other
- Missing attachment warning configurable
- Expense greater than balance warning
- Mahayog mismatch warning
- Unbalanced page warning
- Missing invoice/voucher report
- Incomplete transaction report
- Backdated impact warning

---

## 18. Roles and security

Roles (historical multi-role design retained for future; **Round 5 / Section 19.1 supersedes for current product**):

- Admin ← **CURRENT: केवल Admin** — सारी permissions Admin के पास
- Data Entry Operator *(deferred — multi-user later)*
- Checker *(deferred)*
- Approver *(deferred)*
- Read-only Viewer *(deferred)*

Security:

- PIN/password (Admin login; panchayat edit/delete/correction पर password re-confirm — Section 19.2)
- Biometric optional
- Role permissions *(when multi-role returns)*
- Page verification
- Month/year lock
- Admin-only column settings
- Admin-only locked-period correction
- Export permissions
- Attachment permissions

---

## 19. Audit trail

Every add/edit/archive/cancel/approve/unlock/column change log करें:

- User
- Date/time
- Entity/transaction ID
- Action
- Field changed
- Old value
- New value
- Reason
- Approver

Delete के बजाय Cancelled/Archived status preferred है।

---

## 20. Backup and restore

- Local auto-save
- Daily automatic backup
- Manual backup
- Restore
- Versioned backups
- Optional cloud/Google Drive backup
- Backup before year lock
- Backup before column/schema change
- Export history

---

## 21. Modular architecture

Core app:

```text
Core
├── Database
├── Transaction engine
├── Page engine
├── Balance engine
├── Audit trail
├── Permissions
└── Export interfaces
```

Optional features:

```text
Features
├── Annual Goswara
├── Work Analysis
├── Backup/Restore
├── Cloud Sync
├── OCR
├── Dashboard
└── Advanced Approval
```

Rules:

- Stable plugin interfaces
- Feature registry
- Versioned migrations
- Feature manifest with minimum core version
- Signed releases/modules
- Configuration-driven fund/category lists
- Backward-compatible data model
- Backup before update
- Rollback on failed update

Untrusted arbitrary code को download करके execute न करें। Android signed release/dynamic feature modules और JSON/database configuration सुरक्षित approach है।

---

## 22. Suggested database entities

- FinancialYear
- Page
- Transaction
- TransactionAmount
- FundColumn
- IncomeSource
- IncomeCategory
- ExpenseCategory
- Work
- Vendor/Party
- Attachment
- AuditLog
- PeriodLock
- User
- Role
- Approval
- ExportHistory
- BackupRecord

---

## 23. GitHub and CI progress

### 23.1 Starter files prepared

Discussion के दौरान निम्न प्रकार की starter files बनाई गईं:

- Android Kotlin/Compose starter project।
- `settings.gradle.kts`।
- Root `build.gradle.kts`।
- `app/build.gradle.kts`।
- `gradle.properties`।
- `AndroidManifest.xml`।
- Basic `MainActivity.kt`।
- README।
- GitHub Actions workflow।
- Source ZIP for repository upload।
- Final requirements Markdown।
- Two-page example PDF।

### 23.2 ZIP upload issue

GitHub repository में ZIP upload करने पर GitHub उसे automatically extract नहीं करता। इसलिए workflow में root ZIP खोजकर extract करने का logic जोड़ा गया। Workflow nested project folder और direct project files दोनों पहचानने के लिए बनाया गया।

Expected project after extraction:

```text
settings.gradle.kts
build.gradle.kts
app/
```

### 23.3 Gradle cache issue

`actions/setup-java` में `cache: gradle` लगाने पर error आया क्योंकि wrapper/dependency files मौजूद नहीं थे। बाद के workflow में Gradle cache हटाकर direct Gradle setup इस्तेमाल किया गया।

### 23.4 JVM target issue

Build में error आया:

```text
compileDebugJavaWithJavac: 1.8
compileDebugKotlin: 17
```

इसका समाधान:

```kotlin
android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}
```

Workflow में automatic patch लगाने का प्रयास किया गया। Production solution के रूप में इसे source ZIP के `app/build.gradle.kts` में स्थायी रूप से रखना चाहिए, केवल workflow patch पर निर्भर नहीं रहना चाहिए।

### 23.5 YAML syntax issues

कई workflows में line 85/86 के आसपास syntax error आया, मुख्यतः:

- YAML multiline heredoc indentation।
- Bash escaping।
- Python block और YAML indentation।
- `find` command के escaped parentheses।

अंतिम robust approach:

- Python heredoc हटाएँ।
- Simple Bash commands रखें।
- Workflow को GitHub web editor में paste करने से पहले YAML validation करें।
- एक समय में केवल एक active workflow रखें।

### 23.6 Recommended CI workflow strategy

सबसे stable approach:

1. ZIP को local machine पर extract करें।
2. Actual files repository root में commit करें।
3. Official Gradle wrapper generate/commit करें।
4. `gradlew assembleDebug` चलाएँ।
5. `actions/setup-java@v5` इस्तेमाल करें।
6. `gradle/actions/setup-gradle` इस्तेमाल करें।
7. Build logs और APK artifacts upload करें।

ZIP auto-extraction workflow fallback है, preferred long-term repository layout नहीं।

---

## 24. Example PDF progress

एक two-page example PDF generate की गई थी, जिसमें:

- Income left और expense right layout।
- 30-line page concept।
- Summary lines।
- Page 1 balance से Page 2 opening balance।
- Income categories।
- Work/Other expense examples।
- Cash/SFC/FFC/Own Fund/MP/MLA/TAD columns।

पहली PDF में Hindi text black boxes में दिखा। कारण proper Devanagari font embedding का अभाव था। Final PDF से पहले Devanagari font upload/bundle करना आवश्यक है।

---

## 25. Recommended implementation order

1. Official Android project + Gradle wrapper।
2. Database schema and migrations।
3. Financial year setup।
4. Dynamic fund columns।
5. Income/expense masters।
6. Transaction entry form।
7. 30-line page engine।
8. Page creation and balance carry-forward।
9. Backdated entry and correction।
10. Audit trail and period locks।
11. Work/category/vendor masters।
12. Annual गोशवारा।
13. Reports/dashboard।
14. Devanagari-safe PDF generator।
15. Excel export।
16. Share/print।
17. Backup/restore।
18. Authentication/roles।
19. Tests/reconciliation।
20. Modular update system।

---

## 26. Acceptance criteria

Project milestone complete तभी मानी जाए जब:

- 1 April–31 March financial year सही बने।
- 27 transaction lines के बाद नया page automatic बने।
- Empty dates skip हों।
- अगली active date की श्री पोते पिछली बचत से आए।
- Backdated entry से all affected pages recalculate हों।
- 30th line के दोनों महायोग बराबर हों।
- Work/category reports सही totals दें।
- New fund column जोड़ने पर पूरी book update हो।
- Historical column archive होने पर data सुरक्षित रहे।
- Excel/PDF exports काम करें।
- Hindi font boxes के बिना सही दिखाई दे।
- Share/print काम करें।
- Build failure पर logs downloadable हों।
- Audit trail old/new values दिखाए।
- Locked period unauthorized edit रोके।
- Backup restore काम करे।
- 31 March annual गोशवारा generate हो।

---

## 27. Immediate next actions

1. `PROJECT_PROGRESS.md` को GitHub repository में commit करें।
2. ZIP के बजाय extracted Android project files repository root में रखें।
3. Official Gradle wrapper add करें।
4. `app/build.gradle.kts` में JVM 17 fix स्थायी रूप से रखें।
5. Devanagari font file project में add करें।
6. Basic app build verify करें।
7. Room database implement करें।
8. First vertical slice बनाएं: income + expense + page totals।
9. Tests लिखें: formulas, carry-forward, backdated entry।
10. उसके बाद reports और exports implement करें।

---

## Final note

अब तक की सबसे महत्वपूर्ण architectural सीख यह है कि source ZIP upload करने के बजाय extracted project files और official Gradle wrapper को GitHub repository में commit करना चाहिए। इससे workflow सरल, reproducible और debugging-friendly होगा। पहले production milestone में केवल आवश्यक core cashbook बनाएं; annual reports, export, audit और modular features को versioned modules में क्रमशः जोड़ें।

---

# PART B — New Design Decisions & Module Specifications

*(सितंबर 2026 की discussions के design decisions; Project के सारे नए rules)*

**Document purpose:** सितंबर 2026 की discussions में लिए गए नए design decisions, नए modules और rules का पूरा record. इसे `PROJECT_PROGRESS.md` के साथ repository में रखें — वो document पुरानी planning है, ये नए decisions की विस्तृत specification है.

**Status:** केवल discussion/planning. App का निर्माण अभी शून्य से शुरू नहीं हुआ है — जब कहा जाएगा तभी बनेगा.

**Topics:** सितंबर 2026 की चर्चाएँ (Hindi font, श्री पोते layout, green page, offline policy, versioning/backup, BSR, Measurement Book, man-days गणित, Bill module, AI Estimate Reader, Completion Certificate, Bank Statement Reader, Ledger system, UI/Main page).

---

## 1. Hindi fonts और PDF rendering

### 1.1 Font selection

- **App UI (Android/Compose):** Noto Sans Devanagari — Regular + Bold (+ Medium/SemiBold आवश्यकतानुसार). `app/src/main/res/font/` में रखें.
- **Print layout (12+12 columns का tight grid):** Noto Sans Devanagari के **Condensed** variants — कम जगह में ज़्यादा text.
- **Headings/गोशवारा (optional):** Noto Serif Devanagari — printed register जैसा look.
- **Mangal का उपयोग नहीं करना है** — पुराने (2005–2016) versions हैं, license साफ़ नहीं (OFL नहीं), quality Noto से बेहतर नहीं.
- Noto fonts **OFL-licensed** हैं — repository में `OFL.txt` ज़रूर रखें (license शर्त).

### 1.2 PDF में Devanagari shaping (critical)

- **ReportLab Devanagari की complex shaping नहीं करता** — मात्राएँ (ि, ी, ु) गलत जगह आ जाती हैं, संयुक्ताक्षर (क्ष, त्र, श्र) टूटते हैं. केवल font embed करना पर्याप्त नहीं.
- PDF generator के लिए shaping-capable pipeline ही इस्तेमाल करें:
  - **HTML → PDF (Chromium/WeasyPrint)** — HarfBuzz/Pango आधारित, shaping सही, या
  - **Android-native rendering** (PdfDocument/Compose) — Android का text engine खुद shaping करता है.
- Demo में यह verify हो चुका है: HTML → headless Chromium से बनी 2-page demo PDF में श्री, पंचायत, निर्माण, कूरियर, ब्याज जैसे शब्द perfect render हुए, fonts पूरी तरह embedded थे (`pdffonts` से verify), और सारे totals code से compute हुए — कोई हाथ की गिनती नहीं.

### 1.3 Demo PDF record

- 2-page A4 landscape demo: 12+12 columns, 30-line page, आय योग/श्री पोते/महायोग summary lines, sample GP data, "नमूना–DEMO" watermark, signature lines.
- Page 1: आय योग 1,64,050; व्यय योग 66,000; श्री पोते 45,500; बचत पोते 1,43,550; दोनों महायोग 2,09,550 (बराबर).
- Page 2 की श्री पोते = Page 1 की बचत पोते (1,43,550) — carry-forward verified.
- Build script reusable है — data list बदलने से totals खुद recalculate होते हैं.

---

## 2. Cashbook page layout — updated rules

### 2.1 श्री पोते — हर पृष्ठ की पहली पंक्ति, लाल अक्षरों में

- **हर page की प्राप्ति (income) side की FIRST line पर श्री पोते लाल अक्षरों में लिखा होगा** (red text, हल्का red/pink tint background).
- **Page 1 का आंकड़ा:** विगत वित्तीय वर्ष का बचत शेष (closing balance) — automatic.
  - अगर पिछला साल app में है → उसका closing balance खुद-ब-खुद आ जाएगा.
  - अगर पहला साल है (पुराना data नहीं) → admin एक बार manually fund-wise opening balance डालेगा — उसके बाद कभी हाथ नहीं लगेगा.
- **Page 2 और आगे के हर page पर:** श्री पोते = पिछले page की बचत पोते — पूरी तरह automatic.
- टिप्पणी column में source दिखेगा: "विगत वर्ष का बचत शेष" (page 1) / "पूर्व पृष्ठ का बचत पोते" (बाद के pages).

### 2.2 Line structure (FINAL — Round 4 correction, 19-09-2026) — दोनों sides 30-30 lines

*(पहले Section 16.2 में "नीचे भी श्री पोते" और यहाँ के "सिर्फ़ line 1" के बीच count का टकराव था — 30 लाइनों में fit नहीं होता था. नीचे दिया structure वही टकराव ठीक करता है: चूँकि income side पर श्री पोते **दो बार** (ऊपर + नीचे) आती है, वहाँ transaction lines एक कम — 26 — रखी गई हैं; expense side पर बचत पोते सिर्फ़ **एक बार** आती है, इसलिए वहाँ पूरी 27 transaction lines रहती हैं. दोनों तरफ़ का कुल जोड़ 30-30 ही रहता है.)*

*(Round 5 — Section 19.4: expense **line 1 always blank** (parallel to income श्री पोते); expense transactions start below. Line-count setting changes **only middle transaction zone**. Summary lines remain non-editable.)*


प्राप्ति (income) side — 26 transaction lines:

```text
Line 1    : श्री पोते (लाल) — opening balance (ऊपर)
Line 2-27 : 26 transaction lines
Line 28   : आय योग (केवल इन 26 transactions का योग, श्री पोते शामिल नहीं)
Line 29   : श्री पोते (वही opening आंकड़ा, नीचे दोबारा — expense side की बचत पोते line से symmetry के लिए)
Line 30   : महायोग (= आय योग + श्री पोते)
```

व्यय (expense) side — 27 transaction lines:

```text
Line 1-27 : 27 transaction lines
Line 28   : व्यय योग
Line 29   : बचत पोते (= आय महायोग − व्यय योग)
Line 30   : महायोग (= व्यय योग + बचत पोते)
```

- दोनों महायोग हमेशा बराबर — validation locked.
- Income side पर श्री पोते की value line 1 और line 29 दोनों जगह **same** रहती है (सिर्फ़ visual symmetry के लिए दोहराई जाती है, दोबारा जोड़ी नहीं जाती — महायोग की formula में सिर्फ़ एक बार गिनी जाती है).
- यह structure Section 16.2 के "नीचे से 3 lines दोनों तरफ़" वाले rule को बिना किसी line-count टकराव के पूरा संतुष्ट करता है.

### 2.3 हल्का हरा पृष्ठ (5–10% green tint)

- पूरा page हल्का हरा (जैसे `#e9f4e9`, लगभग 5–10% transparency) — classic सरकारी register look.
- Print के लिए तीन विकल्प चर्चित:
  1. Print में भी green (हर page पर हल्की ink लगती है, पर 5–10% में cost का फ़र्क़ नगण्य).
  2. हरा काग़ज़ + white print (असली GP registers ऐसे ही होते हैं — ink सबसे बचत).
  3. **Hybrid (recommended):** app में हमेशा green दिखे; print करते समय option — "रंगीन पृष्ठ" / "सफ़ेद पृष्ठ (ink बचत)".
- Photocopy पर हल्का green हल्का grey बनता है — readability पर कोई असर नहीं.
- **निर्णय लंबित:** print mode (1/2/3) कौन-सा default रखना है.

---

## 3. Offline policy और compulsory storage permission

- App **100% offline-first** रहेगी — कोई cloud sync नहीं. (केवल दो online exceptions: Section 9 का AI Estimate Reader और Section 11 का Bank Statement Reader.)
- **First launch पर ही `Documents/Cashbook` folder की permission COMPULSORY होगी** — बिना उसके app एक क़दम भी आगे नहीं बढ़ेगी (क्योंकि पूरा backup system इसी पर टिका है).
- User ने बाद में permission revoke कर दी तो app सबसे पहले उसे वापस allow कराने का screen दिखाएगी.
- Android technical note:
  - `/Android/data/<package>/` में backup कभी नहीं — uninstall पर delete हो जाता है.
  - SAF (folder picker) से user एक बार `Documents/Cashbook` चुनेगा; permission install भर में persist रहती है; नए install पर एक बार फिर चुनना होगा (files बनी रहती हैं).

---

## 4. Versioning, Backup और Restore (long-term project)

यह project लंबा चलेगा, इसलिए **data ही असली asset है** — app versions बदलते रहेंगे.

### 4.1 Update-over-old-version (uninstall किए बिना)

- नया APK **same signing key** से sign होकर पुराने पर install होगा → internal data (`/data/data/...`) अपने आप सुरक्षित.
- **Signing keystore सबसे क़ीमती चीज़** — बाहर सुरक्षित backup ज़रूरी. Kehystore खोया → नया version पुराने पर install ही नहीं होगा → uninstall करना पड़ेगा → internal data गया.
- Database **versioned migrations** (Room):
  - कभी भी "purana schema drop करके नया बना दो" वाला approach नहीं.
  - केवल नए columns/tables add; कोई column delete/rename नहीं — पुराने data के लिए "archived" flag.
  - हर पुराने version से नए version तक का migration path लिखा जाएगा.

### 4.2 Backup system

- **जगह:** public `Documents/Cashbook/` (uninstall से बचता है).
- **Format:** zip — database (WAL checkpoint के बाद) + attachments + `manifest.json` (app version, DB schema version, date, checksum).
- **नामकरण:** `GP_Jhariyana_YYYY-MM-DD_vX.Y.zip`.
- **Auto-backup कब:**
  - रोज़ app खुलने पर पहली बार (daily backup).
  - हर बड़े operation से **पहले** (year lock, column change, migration) — "operation-पूर्व safe backup" — **यह कभी auto-delete नहीं होगा**.
- **Retention:** last 15 daily backups + **हर महीने एक snapshot permanently** (महीनों बाद पुरानी ग़लती पकड़ने के लिए).
- **JSON export भी** — human-readable, ताकि 5 साल बाद technology बदल जाए तो भी data पढ़ा जा सके.

### 4.3 Restore flow (uninstall + fresh install वाला case)

1. नया install होते ही app `Documents/Cashbook/` में पुराने backups ढूँढेगी.
2. "पुराना डेटा मिला — Restore करें?" screen.
3. List में हर backup की date, size, app version.
4. User select करे → checksum से integrity verify.
5. Backup की schema को current version तक **migrate** करके restore (backup पुराने version का हो सकता है — सिर्फ़ copy पर्याप्त नहीं).

---

## 5. BSR Master (वार्षिक दर सूची)

- **2020-21 से हर साल का BSR** अलग-अलग, manually add करने का option.
- Fields: item का नाम, unit (मीटर/बस्ता/घनफुट आदि), rate, year.
- पुराने साल का BSR read-only रहेगा.
- Estimate/bill/completion certificate सब इसी master से rate लेंगे.

---

## 6. Measurement Book (MB) module

- **Work से linked** — हर कार्य की अपनी MB.
- हर MB entry में:
  - **Material items:** quantity + BSR item से link.
  - **Labour component — दो हिस्सों में:** कारीगर (मिस्त्री) राशि + लेबर (मजदूर) राशि.
- **Worker/Role masters:** कारीगर और लेबर अलग-अलग master; दैनिक rate **year-wise** store (हर साल बदल सकता है).
- Example: total labour part 60,500 = कारीगर 20,100 + लेबर 40,400.

---

## 7. Man-days distribution engine (कारीगर/लेबर का गणित)

### 7.1 पखवाड़ा गणना (working days)

```text
पखवाड़ा = 15 दिन
− 2 रविवार (chutti)
− सरकारी/विशेष छुट्टियाँ (यदि पड़ें)
= लगभग 12 working days
```

- App में: operator पखवाड़े की date range डालेगा → रविवार auto घटेंगे → **Holiday master** (साल-वार सरकारी छुट्टियों की list) से छुट्टियाँ घटेंगी → working days auto निकलेंगे.
- Manual override allowed (कभी 11, कभी 13 भी हो सकता है).

### 7.2 Rate के नियम

- **HARD RULE:** rate कभी भी चुनी हुई BSR से **ज़्यादा नहीं** हो सकती — BSR या उससे नीचे कोई भी rate लिया जा सकता है.
- **Safe band (app की default suggestion):** BSR से **10–20% कम**. कारण — काम अगर दो financial years में फैला हो और बाद वाले साल की (ऊँची) BSR ले ली जाए, तो ऑडिट में वह राशि **recoverable** बन सकती है. 10–20% कम rate से यह जोखिम टलता है.
- पूर्ण BSR के क़रीब rate चुनने पर app सावधानी दिखाएगी.
- **अंतर-वर्षीय कार्य (cross-FY) के लिए:**
  - Work master में काम का **sanction वर्ष** store होगा.
  - App default रूप से **sanction वर्ष की BSR** लगाएगी.
  - Operator बाद वाले साल की (ऊँची) BSR चुने और दोनों सालों की BSR उपलब्ध हों, तो तुरंत चेतावनी: "यह दर पिछले वर्ष की BSR (₹X) से अधिक है — ऑडिट में recoverable बन सकती है."
  - Completion certificate में हमेशा दिखेगा कि **किस वर्ष की BSR** से गणना हुई.

### 7.3 Distribution के नियम (locked)

1. **Man-day हमेशा पूरा** — आधा/partial किसी भी condition में नहीं गिना जाएगा.
2. हर role (कारीगर, लेबर) का कुल amount **MB के उस component की value से अधिक नहीं** हो सकता.
3. Goal: MB value के **जितना करीब जाया जा सके (नीचे रहकर)** — पूरी value का उपयोग करना ज़रूरी नहीं.
4. App **auto-suggest** करेगी (workers × days × rate के combos), operator **trial-and-error** से adjust कर सकेगा — app calculator की तरह काम करेगी.
5. हर calculation audit trail में जाएगा (rate, man-days, BSR year) — certificate के पीछे-का-गणित दोबारा दिखाया जा सकेगा.

### 7.4 Worked examples

**कारीगर भाग ₹20,100 (BSR ₹700, चुनी rate ₹670):**

```text
2 कारीगर × 12 दिन × ₹670 = ₹16,080
1 कारीगर ×  6 दिन × ₹670 = ₹ 4,020
कुल                     = ₹20,100 (exact match — अच्छी rate से संभव है)
```

**लेबर भाग ₹40,400 (BSR ₹300, चुनी rate ₹280):**

```text
12 मजदूर × 12 दिन × ₹280 = ₹40,320 (₹80 शेष — छोड़ सकते हैं)
```

- App और combos भी दिखाएगी (जैसे ₹264 × 153 मान-दिन = ₹40,392, सिर्फ़ ₹8 शेष) — operator तय करेगा कौन-सा combo हक़ीक़त के क़रीब है (वास्तविक मजदूरों की संख्या भी वास्तविक होनी चाहिए).

---

## 8. Bill (नमूना बिल) module

### 8.1 आधार

- Bill बनाने के लिए **estimate + BSR rates** ज़रूरी — कार्य चलते समय ये दोनों पहले से उपलब्ध रहते हैं.
- एक bill में **एक से ज़्यादा मदें** हो सकती हैं.

### 8.2 Payment का sequence (material पहले)

- किसी कार्य में payment करते समय **हमेशा material part का payment पहले**.
- लगभग सभी cases में — material part का **पूरा** payment होने के **बाद ही** labour/कारीगर के **Master Roll** का payment.
- App इसे enforce करेगी: जब तक उस कार्य के material bills का योग काम की material value तक नहीं पहुँचता, master roll payment पर warning (चाहें तो strict block — configurable).
- Bill का payment cashbook entry से linked रहेगा (कार्य + चरण reference के साथ) — रोकड़ बही में पैसा जाते ही पता चलेगा कि किस कार्य का कौन-सा चरण चल रहा है.

### 8.3 Item के नियम

- **अंतिम-बिल मदें (editable master list):** पानी, टेंकर, मशीनरी, वाइब्रेटर, मिक्सर मशीन, डिस्प्ले बोर्ड, पॉलिश — ये **सिर्फ़ उस कार्य के LAST bill में** आएँगी; बीच के bills में app इन्हें लेने ही नहीं देगी. (भविष्य में नई मद जोड़ने का option खुला.)
- **Quantity के नियम:**
  - Cement bag, ईंट जैसी चीज़ें — **केवल पूर्ण संख्या**, कभी point/दशमलव में नहीं (app input level पर रोकेगी).
  - सिर्फ़ **loose सामग्री** — रेत, गिट्टी, लोहा — दशमलव में आ सकती है.
  - Item master में हर item पर flag: "पूर्ण संख्या" vs "दशमलव संभव".
- **आधारभूत मदें (front-loading):** concrete कार्य के लिए cement, रेत, गिट्टी basic हैं (इनके बिना काम हो ही नहीं सकता) — इनकी मात्रा **पहले-पहले के bills में maximum** रूप से डाली जाएगी.
  - App bill बनाते समय suggest करेगी: "यह मद आधारभूत है — शेष मात्रा (X) इसी bill में डालें?" Operator हाँ/ना कर सकेगा.

### 8.4 कार्य-wise material ledger और reconciliation

- हर कार्य का material ledger: सभी bills की मद-wise quantity और amount जुड़ती जाएगी.
- Estimate/BSR से लगातार तुलना — ज़्यादा जाने पर पहले ही warning.
- **Completion Certificate बनते समय final validation: कार्य के सभी material bills का योग = CC में लिया गया material amount/quantity.** यानी "सभी bills मिलकर ही completion certificate का material बनते हैं" — कोई bill छूटे तो CC generate होने से पहले पकड़ा जाएगा.

### 8.5 कार्य-wise खर्च का live status (payment करते समय) — excess payment रोकना

- Cashbook में किसी कार्य की **payment entry करते समय** screen पर दिखेगा:
  - उस कार्य पर **अब तक खर्च** — labour और material **अलग-अलग** (उस कार्य की सभी linked transactions का योग).
  - **Material breakdown** — कौन-सी मद, कितनी quantity, किस rate से (bills से, जहाँ उपलब्ध हो).
  - स्वीकृत (FS) राशि से तुलना — labour शेष, material शेष, कुल शेष.
- नई payment शेष balance से ज़्यादा होने पर **warning** — excess payment न हो सके.
- यह status कार्य के सभी transactions से **live** जुड़ी रहेगी — bank auto-entries (Section 11.2) और manual entries दोनों से.

---

## 9. AI Estimate Reader (optional online module)

- App के offline-first वाले policy का **केवल यही exception** — इस module के उपयोग के समय ही internet चाहिए.
- OCR app के अंदर डालने से app heavy हो जाती — इसलिए **AI-based reading cloud पर**:
  1. Operator technical assistance से मिला estimate PDF upload करेगा.
  2. App उसे AI को भेजकर पढ़वाएगी.
  3. Extracted data (मद, यूनिट, मात्रा, दर, राशि) **review screen** में operator के सामने आएगा.
  4. Operator verify/edit करेगा — **यह review step अनिवार्य** (AI की ग़लती संभव है; ग़लत मात्रा आगे का पूरा गणित बिगाड़ देगी).
  5. Save → structured estimate, work से linked.
- **Requirement:** जब यह module बने, 2–3 sample estimate PDF (technical assistance वाले) testing के लिए चाहिए.

---

## 10. Completion / Utilisation Certificate (कार्य पूर्णता एवं उपयोगिता प्रमाण पत्र)

- **Material part:** सामग्री की quantity × **उस वर्ष की** BSR rate; कुल material, MB के material amount से अधिक नहीं.
- **Labour part:** Section 7 के engine से (कारीगर/लेबर अलग-अलग man-days गणित).
- **Allowed expenditure का core rule** — हर component (labour, material) के लिए अनुमत राशि = **तीनों में से जो सबसे कम**:

```text
Allowed = min(
  1. वित्तीय स्वीकृति (financial sanction) में दी गई राशि,
  2. मापन पुस्तिका (MB) में दी गई राशि,
  3. हमारे बनाए गणित (man-days गणना + BSR multiplication) से आई राशि
)
```

- Certificate **किसी भी condition में sanction से बड़ा generate नहीं होगा** — warning + minimum figure पर बनेगा.
- Certificate में दिखेगा: किस वर्ष की BSR से गणना, कुल man-days, rates, material breakdown.
- **Format:** राजस्थान पंचायती राज का actual sample format चाहिए जब बनाएँ — layout उसी के अनुसार रहेगा.

---

## 11. Bank Statement Reader (मासिक बैंक विवरण module)

### 11.1 Upload और tagging

- बैंक हर महीने हर account का **password-protected PDF statement** भेजता है.
- **Upload flow:**
  1. Operator वह PDF app में upload करेगा और PDF का password डालेगा — app password खुद हटाकर statement खोलेगी.
  2. Statement की reading **OCR/AI से (cloud)** — offline policy का दूसरा online exception.
  3. पढ़ा हुआ data app में **Excel-जैसे editable grid** में आ जाएगा: तिथि, विवरण (narration), संदर्भ/चेक संख्या, जमा (deposit), निकासी (withdrawal), शेष (balance).
  4. Operator हर entry के आगे अपनी **tagging** कर सकेगा — योजना (SFC/FFC/MP-MLA आदि), कार्य, vendor/party, लेखा शीर्ष, टिप्पणी.
- **Account master:** बैंक + खाता संख्या + IFSC; statement की खाता संख्या से account अपने आप पहचाना जाएगा; नया account मिले तो एक बार master में जोड़ा जाएगा.
- **संगठन:** account-wise + month-wise. उसी month का statement दोबारा upload पर duplicate की चेतावनी (period range से पहचान).
- **Print:** पूरा statement भविष्य में app से **register/full format में print** हो सकेगा.
- **Reconciliation का आधार:** tagged entries आगे cashbook से मिलान (cheque/UTR संदर्भ) का आधार बनेंगी — future feature #1 से जुड़ेगा.
- **Privacy note (Round 4 update, 19-09-2026):** bank statement/estimate जैसा data cloud AI के पास processing के लिए जाता है — यह Gram Panchayat का सरकारी वित्तीय रिकॉर्ड है, जो वैसे भी RTI/public-domain के अंतर्गत उपलब्ध रहता है, इसलिए अलग से sensitive-data handling policy फ़िलहाल ज़रूरी नहीं मानी गई (**final, इस पर आगे चर्चा नहीं**). भविष्य में चाहें तो offline OCR option सोचा जा सकता है (app भारी होगी).

### 11.2 Bank statement से automatic cashbook entry engine

**शर्त:** operator ने cashbook किसी date तक नहीं लिखी, और उस date तक का bank statement upload हो गया → app statement के अनुसार cashbook में **automatic entries** बनाएगी (review screen पर — एक tap में सब accept, या edit करके).

**A. Debit (निकासी) entries का नियम:**

- Statement की हर debit entry, debit date से **एक दिन पहले** की date से cashbook में ली जाएगी (cheque देने और bank में debit होने में समय का अंतर).
- **Balance शर्त:** जिस दिन entry रखी जा रही है, उस दिन cashbook का balance उस debit amount के **बराबर या उससे अधिक** होना चाहिए — तभी उस दिन entry बनेगी; otherwise statement की अपनी date पर entry होगी.

**B. Page-opening optimization (असली बही 40–50 पृष्ठों की):**

- असली cashbook साल में 40–50 पृष्ठों की ही होती है — 365 दिन खोलना ज़रूरी नहीं (empty days पहले से skip होते हैं).
- जैसे statement में 3, 4, 5, 7, 8 तारीख़ों की एक-एक entry हो → इन सबको **02 तारीख़ (सबसे पुरानी debit से एक दिन पहले) के एक ही दिन में साथ** लिखा जा सकता है — शर्त: 02 तारीख़ को इन पाँचों entries के योग के बराबर या उससे ज़्यादा balance हो.
- Balance कम हो → जितने का balance है उतनी ही entries उस दिन (क्रम से), बाक़ी entries **amount प्राप्त होने के बाद** वाली दिन में जाएँगी (अगली credit receipt के बाद).
- **(Confirmed) Grouping window:** entries **10–15 दिन के range** में हों (जैसे 5 entries) → **एक ही page** पर एक ही दिन में group हो सकती हैं; range उससे बड़ा हो → **2 pages** पर बाँट दी जाएँगी (हर group का अपना दिन). Balance शर्त हर group पर अलग से लागू.

**C. Credit (जमा) entries का नियम:**

- Statement की credit entries, credit date के **बाद** उस दिन cashbook में की जाएँगी जिस दिन cashbook debit entries के लिए खोली गई हो.
- या — हर माह के last days में cashbook खोलने की practice हो तो receiving की entries वहीं की जा सकती हैं (दोनों modes supported रहेंगे).

**D. Labour payment का consolidation:**

- Statement में एक साथ बहुत सारी **same-same debit** entries आएँ → संभव है किसी कार्य के labours को payment की गई हो.
- ऐसी case में cashbook में बहुत सारी अलग entries की जगह **उस कार्य के लिए एक ही debit entry** (कार्य हेतु labour भुगतान) बनेगी — app यह detect करके suggest करेगी, operator confirm करेगी.

**E. कार्य selection (drop-down):**

- Cashbook में कार्य हेतु payment चुनने पर **ongoing कार्यों की drop-down list** खुलेगी — इसमें से चुना जा सकेगा कि इस कार्य हेतु इस vendor को payment हो रहा है (labour की case में vendor नहीं होगा).
- **AS/FS/TS:** कार्यों की list/entry operator द्वारा **किसी भी समय** AS/FS/TS (प्रशासनिक/तकनीकी/वित्तीय स्वीकृति) number और date के साथ जोड़ी जा सकेगी.
- Auto-entries में date placement के लिए पहले से बना backdated-entry machinery (page re-sort, totals recalc, श्री/बचत पोते update) ही use होगा.

---

## 12. Ledger system और Audit Report

सभी ledgers वित्तीय वर्ष-wise होंगी, custom date-range filter के साथ, और हर report के compulsory exports (Excel/PDF/Print/Share) लागू रहेंगे.

### 12.1 Cash ledger (नकद)

- उक्त वित्तीय वर्ष में **कुल नकद प्राप्त**, **कुल नकद खर्च**, और **शेष balance**.
- प्रत्येक transaction की cash ledger entry — opening balance से closing तक **running balance** के साथ.

### 12.2 Scheme/fund-wise ledger (हर योजना की अलग ledger)

- हर योजना/निधि (नकद, SFC, FFC, स्वयं निधि, MP/MLA/TAD...) की **अलग ledger**:
  - आय — कब, किससे, कितनी.
  - व्यय — कब, किस कार्य/शीर्ष में.
  - Running balance.
- Fund columns पहले से dynamic हैं — यह ledger उन्हीं से खुद-ब-खुद बनेगी।

### 12.3 Material item-wise ledger (वस्तु/सामग्री की ledger)

- वित्तीय वर्ष में **कुल कितनी cement bags, रेत, गिट्टी, ईंट, लोहा** आदि खर्च हुई.
- हर material item की अलग ledger — किस कार्य में, किस bill से, किस rate से, कितनी quantity.
- Bills के item-level data से खुद-ब-खुद जुड़ती है (Section 8.4 के work-wise material ledger का विस्तार).

### 12.4 Labour ledger (कार्य-wise)

- हर कार्य पर **कितना labour खर्च हुआ** — man-days, rates, master rolls, payments.
- वित्तीय वर्ष का कुल labour (और कारीगर) खर्च भी.

### 12.5 Audit report में मदद

- ये सभी ledgers मिलकर **audit report का आधार** बनेंगी — किसी भी आंकड़े (figure) को drill-down करके source transaction तक पहुँचा जा सकेगा.
- Audit report के exact formats sample formats (user upload करेगा) से बनेंगे.

### 12.6 शुल्क/fee-category ledgers (पट्टा शुल्क, विवाह पंजीयन आदि)

- Cashbook की प्राप्ति में जो fee-type शुल्क आते हैं — **पट्टा शुल्क, विवाह पंजीयन शुल्क, जन्म/मृत्यु प्रमाण शुल्क और ऐसी ही अन्य प्राप्तियाँ** — इन सबकी **अलग-अलग ledgers** बनेंगी:
  - साल में **कितनी प्राप्तियाँ हुईं (count)** — जैसे साल में कितने पट्टे बने.
  - **कुल प्राप्त राशि**.
  - पूरी list — दिनांक, किससे प्राप्त, राशि, reference.
- **पट्टा शुल्क की प्राप्ति entry में extra fields (cashbook में):**
  - पट्टा क्रमांक (app अगला क्रमांक सुझाएगी).
  - पट्टाधारक का नाम.
  - पट्टा जारी दिनांक.
- ये details पट्टे की ledger में दिखेंगी — ऑडिट में सीधा जवाब मिलेगा: "साल में कितने पट्टे बने और कितनी राशि प्राप्त हुई".
- यही pattern extensible है — आगे किसी अन्य शुल्क पर भी उसके अनुसार extra fields जोड़े जा सकेंगे.

---

## 12.7 Rounding rules (राशि की सटीकता) — FINAL (Round 4, 19-09-2026)

- **Cashbook (transactions, line totals, आय/व्यय योग, श्री/बचत पोते, महायोग, carry-forward):** राशि हमेशा **दशमलव के बाद 2 digits (paise) तक** store और calculate होगी — यहाँ कहीं भी rounding नहीं होगी, exact paise रहेंगे.
- **बाक़ी जगह** (dashboard cards, quick summaries, गोशवारा/reports की display-level figures जहाँ paise ज़रूरी नहीं): **nearest रुपये में round** करके दिखेगा — पर underlying stored value हमेशा 2-decimal ही रहेगी, सिर्फ़ display पर round होगा, calculation पूरी precision से होगी.

---

## 13. Proposed future features (चर्चित — बाद में तय होंगे)

प्राथमिकता क्रम में सुझाए गए, अभी केवल proposal:

1. **Bank reconciliation** — Section 11 के tagged bank statements + cashbook entries का मिलान (cheque/UTR संदर्भ से), unmatched list.
2. **अग्रिम (Advance) tracking** — advance register + settlement/adjustment, पूरा adjust होने तक warning.
3. **Pending bills/liabilities register** — गोशवारा से पहले सारी liability सामने.
4. **निधि उपयोग प्रमाण-पत्र** — fund-wise ready format export.
5. **Budget vs Actual** — साल शुरू में head-wise budget, reports में budget–खर्च–balance.
6. Hindi number-to-words — voucher/print पर ₹ आंकड़े के साथ शब्दों में राशि.
7. Voice entry (Hindi) — बोलकर entry (Bhashini/ASP), later phase.
8. Frequent templates — रोज़ की एक जैसी entries एक tap में.
9. Devanagari numerals toggle (१२३) — केवल display/print option.
10. Page-level e-sign/verification stamp — "जाँचा-परखा" + user + date.
11. Year comparison report.
12. Asset/dead-stock register (सम्पत्ति पंजिका).
13. Onboarding demo data + Hindi help screens.
14. Large-font / dark mode.
15. Reminder notifications — backup, missing attachment, month lock.
16. Multi-Panchayat mode — database में `PanchayatID` पहले से रखना सस्ता है.
17. **TDS/GST deduction** (vendor/material payments पर) — अभी scope से बाहर, फ़िलहाल नहीं जोड़ना (Round 4 decision, 19-09-2026).
18. **Multi-device/multi-operator sync** (एक साथ 2 devices से एक ही GP पर काम) — अभी scope से बाहर, single-device assumption ही बनी रहेगी (Round 4 decision, 19-09-2026).

---

## 14. लंबित निर्णय (open decisions)

| # | निर्णय | विकल्प |
|---|---|---|
| 1 | Print में green कैसे | ink से रंग / हरा काग़ज़ / hybrid (recommended) |
| 2 | बचत पोते (line 29) highlight | किसी रंग में या normal |
| 3 | Master roll payment, material अधूरा हो तो | strict block / केवल warning |
| 4 | Rate band | ✔ FINAL (conditional): कोई एक fixed % लॉक नहीं होगा — हर कार्य के case के हिसाब से operator BSR के 10–20% कम वाले band में rate चुनेगा (ऊपर जाने की छूट पूरी BSR तक); detail Section 7.2 में |
| 5 | गोशवारा demo | अलग से बनाना है या नहीं |
| 6 | Bank statement की reading | cloud AI (recommended, app lightweight) / बाद में offline OCR option |
| 7 | Bank से auto cashbook entries | review screen के साथ (recommended) / direct automatic |
| 8 | GP selection | ✔ FINAL: हर बार दिखेगी |
| 9 | Login कब | ✔ FINAL: app खुलते ही (Admin only — Section 19.1); GP selection login के बाद |
| 10 | First page पर क्या | ✔ FINAL: सिर्फ़ FY status (शेष/आय/व्यय/balance) + FY chooser |
| 11 | App खुलते ही क्या खुले | ✔ FINAL Round 5: Login → Panchayat (+ App Settings) → FY page (+ Panchayat/FY Settings) → FY home (Section 15.2 + 19.2–19.3) |

---

## 15. UI — Main page और Dashboard

### 15.1 Main page (launch screen) — FINAL

- **सिर्फ़ एक काम: ग्राम पंचायत चुनना** — और कुछ नहीं.
- **Style: Sample 3 (dropdown minimal)** — deep green gradient header, white sheet, GP dropdown field, "प्रवेश करें" button, "100% ऑफ़लाइन · डेटा सुरक्षित" note.
- **Greeting (header में, English, time-based):** Good Morning! / Good Afternoon! / Good Evening! — personal touch. **App की UI भाषा: English/Hinglish** (screen labels English में); printed documents (cashbook, गोशवारा, CC आदि) हिंदी में ही रहेंगे.
- Material Design (M3), हल्का हरा theme, Noto Sans Devanagari. चार samples बनकर review हुए (list / grid / dropdown / dark) — **dropdown final**.

### 15.2 App flow — FINAL (Login → Panchayat → FY → FY home)

*(Round 5 updates — Section 19.2–19.3; multi-role UI हटाकर Admin-only)*

1. **Login screen (S-01)** — app खुलते ही **Admin** credentials (PIN/password; biometric optional). अन्य roles का UI नहीं।
2. **Panchayat selection (S-02)** — **हर बार दिखेगी** (Sample 3 dropdown style) + उसी page पर **App Settings** entry (universal settings + Panchayat add/edit/correction/delete; destructive actions पर password re-confirm — Section 19.2).
3. **Financial Year page (S-05)** — status details: शुरुआती शेष, कुल आय, कुल व्यय, **वर्तमान शेष** (fund-wise) + **FY chooser** + उसी page पर **Panchayat / FY Settings** (FY CRUD, scheme CRUD, scheme-wise opening balance, line-count, blank-line gap, scheme-negative-balance policy — Section 19.3).
4. **FY home (S-06)** — उस financial year से जुड़े सारे options:
   - **Cashbook** — खोलने पर बही + entries (+ आय / + व्यय यहीं से).
   - **Bank Statement** — monthly statement upload + tagging.
   - **Ongoing कार्य** — जिन कार्यों का payment उस FY में हुआ. Tap पर कार्यों की list → कार्य select करने पर **पूरी details + ledger** (कब, किस firm को, कितना payment — सब कुछ) → किसी payment पर tap करने पर **हर bill-wise material details** (जहाँ उपलब्ध हो).
   - **गोशवारा till date** — आज तक का गोशवारा.
   - **Material Ledger (Stock Register)** — वस्तु-wise कुल खर्च + पूरा ledger.
   - **Schemes** — tap पर scheme की list → scheme select करने पर उस scheme की सारी details: opening balance, income, expenditure, payment vouchers आदि — उस scheme से जुड़ा सब कुछ.
   - **Reports** — सभी reports की central list (Reports Hub); साथ ही **contextual reports** — हर details screen (cashbook, कार्य, scheme, bank, MB, गोशवारा, ledgers) पर उससे संबंधित reports का option, और हर report से source details पर drill-down (vice-versa).
- **First-launch flow (एक बार):** Documents/Cashbook permission (compulsory) + restore check — FY page से पहले.

### 15.3 App में screen numbers (हर page के corner में) — FINAL

- App बनने पर **हर window/page के corner (bottom-right) में छोटा सा नंबर दिखेगा** — जैसे `S-07`, `S-22` — muted/light रंग में ताकि design disturb न हो.
- उद्देश्य: app खोलकर बैठे-बैठे भी किसी page पर correction/addition की ज़रूरत हो तो उस page का नंबर बताकर बोला जा सके — "S-19 पर यह option होना चाहिए", "S-22 को ऐसे सुधारो".
- नंबरिंग हमेशा screen index (Part C) से synced रहेगी.
- चाहें तो Settings से hide/show toggle रखेंगे, पर default हमेशा दिखता रहेगा.

---

## Implementation notes

- **क्रम बना रहेगा:** पहले core cashbook (PROJECT_PROGRESS.md की original planning), फिर ये नए modules — BSR → MB → distribution engine → Bills → Completion Certificate → AI Estimate Reader → Bank Statement Reader → Ledgers/Audit reports.
- **Sample formats:** user Excel bank statement, cashbook, MB, CC, UC आदि की soft copies upload करेगा — हर module बनने से पहले उसका actual format इन्हीं samples से लिया जाएगा.
- **Screen index:** पूरे app के pages/windows का नंबरित index इसी document के Part C में है (S-01 से S-47, अंतिम screen हमेशा App Settings) — screen-by-screen discussion उसी order में होगा.
- हर नया module इसी document में "implemented" mark होता जाएगा जब बनेगा.
- यह document `PROJECT_PROGRESS.md` का पूरक है — दोनों repository में साथ रहेंगे.

---

# PART C — App Screen Index

**Document purpose:** पूरे app के सारे pages/windows का नंबरित index — किस point पर कौन-सी screen खुलेगी. इसी order में एक-एक screen पर discussion होगी.

**Related docs:** `PROJECT_PROGRESS.md` (original planning), `PROJECT_DESIGN_DECISIONS.md` (सारे design decisions).

**Note:** UI English/Hinglish में, printed documents (cashbook, गोशवारा, CC) हिंदी में.

---

## Part 1 — App Flow (क्रम से)

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-01 | **Login Screen** | App खुलते ही, हर बार | **Admin only** + PIN/password (biometric optional). अन्य roles UI नहीं (Section 19.1) |
| S-02 | **Panchayat Selection** | Login के तुरंत बाद, हर बार | GP dropdown + greeting + **App Settings** (universal + Panchayat CRUD; edit/delete/correction पर password confirm — Section 19.2) |
| S-03 | **Storage Permission** | सिर्फ़ first launch (एक बार) | `Documents/Cashbook` folder permission — बिना इसके app आगे नहीं बढ़ेगी |
| S-04 | **Restore Detected** | First launch पर पुराना backup मिलने पर | "पुराना डेटा मिला — Restore करें?" — backups की list, select कर restore + migration |
| S-05 | **Financial Year Page** | Panchayat select के बाद | Status (शेष/आय/व्यय/balance fund-wise) + FY chooser + **Panchayat/FY Settings** (FY/scheme CRUD, opening balance, line-count, blank-gap, scheme-minus policy — Section 19.3) → Proceed |
| S-06 | **FY Home (2nd page)** | FY proceed करने के बाद | उस साल के options: Cashbook · Bank Statement · Ongoing कार्य · गोशवारा till date · Material Ledger · Schemes · Reports; + **मासिक जाँच checklist** (unverified pages, untagged bank entries, missing bill attachments, pending statements); + FY Closing (S-45) का button 31 मार्च के आसपास |

---

## Part 2 — Cashbook (FY Home → Cashbook)

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-07 | **Cashbook Page View** | FY Home → Cashbook | 30-line page दोनों तरफ़: income side (श्री पोते line 1 पर लाल + 26 transactions + आय योग + श्री पोते दोबारा + महायोग), expense side (27 transactions + व्यय योग + बचत पोते + महायोग) — पूरा detail Section 2.2 — हल्का हरा page |
| S-08 | **Add Income** | + आय button से | Form: date, receipt, source, detail dropdown; पट्टा शुल्क चुनने पर पट्टा क्रमांक/पट्टाधारक/जारी दिनांक fields; + **"पिछली entry से copy" (repeat template)** मासिक/दोहराई जाने वाली entries के लिए |
| S-09 | **Add Expense** | + व्यय button से | Form: date, voucher, party, Work या Other; work dropdown (AS/FS/TS), 8.5 का live खर्च status, excess payment warning; + **"पिछली entry से copy" (repeat template)**; + तीसरा entry-type **"नकद से बैंक जमा"** (आय/व्यय नहीं, सिर्फ़ transfer) |
| S-10 | **Edit / Correction** | किसी entry पर tap | Reason required; locked period में correction/adjustment entry (original reference सहित); + **Entry रद्द (cancel)** — reason अनिवार्य, print में लाल strikethrough, totals से हटेगी, audit trail में बनी रहेगी |
| S-11 | **Print / PDF Preview** | Print/Share से | हिंदी printed page — 12+12 columns, गोशवारा आदि; green page option (रंगीन/सफ़ेद) |
| S-12 | **Page Verification** | Checker role के लिए | Page-level "जाँचा-परखा" stamp + user + date |

---

## Part 3 — Bank Statement (FY Home → Bank Statement)

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-13 | **Statement List** | FY Home → Bank Statement | Account-wise + month-wise statements; duplicate upload warning |
| S-14 | **Upload Statement** | + से | Password-protected PDF upload + password डालकर unlock → AI reading |
| S-15 | **Editable Grid + Tagging** | Upload के बाद | Excel-जैसा grid; हर entry पर scheme/कार्य/vendor/शीर्ष tagging |
| S-16 | **Auto-Entry Review** | Statement save करने पर | Statement → cashbook automatic entries की review (D−1 date, grouping, labour consolidation) — एक tap में accept या edit |

---

## Part 4 — कार्य / Works (FY Home → Ongoing कार्य)

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-17 | **Works List** | FY Home → Ongoing कार्य | उस FY में payment वाले/चालू कार्यों की list |
| S-18 | **Work Add / Edit** | + या list से edit | कार्य नाम + AS/FS/TS number & date, sanction राशि; कभी भी जोड़ा जा सकता है |
| S-19 | **Work Details + Ledger** | कार्य select करने पर | पूरी details: कब, किस firm को, कितना payment — सब; खर्च labour/material अलग |
| S-20 | **Payment Detail** | किसी payment पर tap | उस payment से जुड़े हर bill-wise material details |
| S-21 | **Measurement Book Entry** | कार्य के अंदर से | Material items (quantity + BSR link) + labour component (कारीगर/लेबर राशि) |
| S-22 | **Man-Days Calculator** | MB labour भाग से | Trial-and-error engine: workers × days × rate, pakhwada working days, rate < BSR (10–20% कम suggested), amount ≤ MB value, पूरे मान-दिन |
| S-23 | **Master Roll** | कार्य/MB से | कारीगर/लेबर मान-दिन पंजिका — payment का आधार |
| S-24 | **Bill Create** | कार्य से | मदें + quantity (पूर्ण संख्या/दशमलव rules), अंतिम-बिल मदें केवल last bill में, आधारभूत मदें front-load suggestion |
| S-25 | **Bills List / Work Material Ledger** | कार्य से | सभी bills का योग vs estimate/CC — reconciliation |
| S-26 | **Completion / Utilisation Certificate** | कार्य पूर्ण होने पर | min(sanction, MB, हमारा गणित) rule; BSR year दिखेगा; print format |

---

## Part 5 — गोशवारा

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-27 | **गोशवारा till Date** | FY Home → गोशवारा | आज तक का classified गोशवारा; 31 March का full annual; आय/व्यय महायोग validation; + हर महीने की **5 तारीख़ reminder notification** + **one-tap WhatsApp PDF share** (पं.समि./BDO को) |

---

## Part 6 — Ledgers & Reports (FY Home के options + drill-down)

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-28 | **Material Ledger (Stock Register)** | FY Home → Material Ledger | वस्तु-wise कुल (कितनी bags/रेत/गिट्टी…), item select पर पूरा ledger |
| S-29 | **Cash Ledger** | Ledgers में से | नकद प्राप्त/खर्च/शेष, running balance |
| S-30 | **Scheme Ledger** | Schemes → scheme select | Opening balance, income, expenditure, payment vouchers — सब |
| S-31 | **Labour Ledger** | Ledgers में से | कार्य-wise labour खर्च, man-days, rates |
| S-32 | **Patta / Fee Ledgers** | Ledgers में से | पट्टा/विवाह पंजीयन आदि — count + राशि + पूरी list |
| S-33 | **Audit Report (drill-down)** | Ledgers/Reports से | किसी भी आंकड़े से source transaction तक पहुँच |
| S-34 | **Reports Hub** | FY Home → Reports | सभी reports की central list (original planning की 22+), category-wise; हर report से अपने source details पर drill-down |

---

## Part 7 — Masters & Settings (कभी भी, Settings से)

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-35 | **Fund / Column Settings** | Admin only | Columns add/rename/reorder/archive, opening balance |
| S-36 | **BSR Master** | Settings | 2020-21 से हर साल की दर सूची; पुरानी read-only |
| S-37 | **Workers / Role Master** | Settings | कारीगर/लेबर, year-wise rates |
| S-38 | **Vendor / Party Master** | Settings | Firms, search, vendor-wise report |
| S-39 | **Item Master** | Settings | मदें + flags: पूर्ण संख्या/दशमलव, अंतिम-बिल, आधारभूत |
| S-40 | **Holiday Master** | Settings | साल-वार सरकारी छुट्टियाँ (pakhwada गणना के लिए) |
| S-41 | **Users & Roles** | Settings | Users, PIN, permissions |
| S-42 | **Backup & Restore** | Settings (+ auto) | Manual backup, restore list, retention status. *(नए फ़ोन पर guided restore अब अलग screen **S-46** पर है।)* |
| S-43 | **Search (Global)** | Search से | सभी transactions/कार्य/vouchers में खोज |
| S-44 | **Export / Share** | हर report से | Excel/PDF export, share, print |

---

## Part 8 — App-level & Lifecycle (Round 4 — जोड़े गए, 19-09-2026)

| # | Page/Window | कब खुलेगी | क्या है |
|---|---|---|---|
| S-45 | **वित्तीय वर्ष समापन (FY Closing Wizard)** | 31 मार्च को, या S-05/S-06 से button से | Verification checklist (pages verified, bank statements uploaded+verified, missing attachments), final गोशवारा generate, operation-पूर्व safe backup, FY lock → नए FY की opening balance auto (Section 17.1.1) |
| S-46 | **नया फ़ोन Transfer Wizard** | Settings → Backup से, या restore flow से | पुराने फ़ोन का backup zip + 4-अंकों का restore code → guided restore नए फ़ोन में (Section 17.1.8) |
| S-47 | **App Settings (Main Settings)** | Settings — हमेशा अंतिम screen number | Theme (6 themes), Logo बदलना, UI language (English/Hinglish), screen-number badge on/off (Section 16.1) |

*(कुल screens: **47 (S-01 → S-47)**। App Settings हमेशा सबसे आख़िरी नंबर पर रहेगी — कोई नया screen जुड़े तो App Settings से पहले नंबर मिलेगा, App Settings का नंबर हर बार shift होकर आख़िरी बना रहेगा.)*

---

## Contextual Reports का नियम (vice-versa)

- **जहाँ जहाँ details हैं — वहाँ वहाँ संबंधित reports का option:**
  - S-07 Cashbook → page-wise/date-wise cashbook reports
  - S-13/S-15 Bank Statement → reconciliation + statement reports
  - S-19 Work Details → work-wise expenditure report
  - S-21/S-23 MB / Master Roll → MB व man-days reports
  - S-25 Bills → bill-wise material reports
  - S-26 CC → CC register
  - S-27 गोशवारा → annual गोशवारा
  - S-28–S-32 हर ledger → अपने-अपने reports
- **और हर report से उसके source details पर वापस (drill-down)** — report में किसी figure पर tap करो, सीधा वह transaction/page/work खुले।
- यानी Reports Hub (S-34) central जगह है, पर reports तक पहुँच हर related screen से भी — दोनों तरफ़ से।

---

## Discussion order (सुझाव)

1. **S-01 → S-06** (flow screens) — pehle ये छह final करेंगे
2. फिर **S-07 → S-12** (cashbook — app का दिल)
3. फिर S-13 → S-16 (bank), S-17 → S-26 (कार्य), S-27 (गोशवारा), S-28 → S-34 (ledgers/reports), S-35 → S-44 (masters/settings), S-45 → S-47 (FY closing, phone transfer, App Settings — सबसे आख़िर में)

## खुले सवाल (index में)

- ~~Reports hub कहाँ जाएगी~~ ✔ FINAL: FY Home पर अलग **Reports** option + contextual reports हर details screen पर (ऊपर देखें)।
- S-03/S-04 first-launch के अलावा Settings से भी खुलेंगे (Settings अब **S-45** App Settings है — नीचे Section 16 देखें)।

---

# PART B — SECTION 16: Prototype Review Round 1 — FINAL Decisions (19-09-2026)

*(User ने HTML prototype के सभी 45 pages देखकर ये changes दिए — सब APPROVED और prototype v0.2 में लागू।)*

## 16.1 Global
- **GP का नाम (sample data): ग्राम पंचायत माल** (पं.समि. साबला, जिला डूंगरपुर) — पहले वाला झरियाना replace।
- **S-01 का default user: Harish Patidar — Operator।**
- **App logo:** पहली बार खोलने पर 8 finance-related logo options में से choose करना होगा (₹, किताब, सिक्का, बैंक, बिल, चार्ट, पैसा, scroll) — बाद में App Settings से बदल सकते हैं।
- **Colour themes (नया):** सिर्फ़ green नहीं — App Settings (नया screen) में कम से कम 6 themes: हरा, नीला, टील, मैरून, बैंगनी, केसरिया। Theme सिर्फ़ app की दिखावट बदलेगी — printed documents (cashbook/CC/गोशवारा) का हिंदी format वही रहेगा।
- **नया screen — App Settings (Main Settings):** Theme selection, Logo बदलना, UI language (English/Hinglish), screen-number badge on/off। *(Round 4 में final screen number तय हुआ: **S-47** — हमेशा सबसे आख़िरी, Part B Section 18.2/Part C देखें।)*

## 16.2 Cashbook page (S-07) — नए rules
- **पृष्ठ संख्या top-right corner में।**
- **Header में सिर्फ़ GP का नाम + वि.व.** — नीचे कोई date range नहीं।
- **तिथि (date) सिर्फ़ श्री पोते की line के सामने आएगी** — page में कहीं और नहीं।
- **श्री पोते दो जगह:** ऊपर line 1 पर (opening) और नीचे भी।
- **नीचे से 3 lines दोनों तरफ़ (प्राप्ति और व्यय):**
  1. आय योग / व्यय योग
  2. श्री पोते / बचत पोते
  3. महायोग (दोनों तरफ़ बराबर)
  *(Exact line-numbering — 26 बनाम 27 transaction lines का split — अब Section 2.2 में final है.)*

## 16.3 कार्य / Works
- **S-06 से 'Ongoing कार्य' पर click → scheme-wise view (S-17):** कार्य योजना के हिसाब से grouped — SFC में ये कार्य, FFC में ये, MP/MLA में ये। Filter tabs भी (सभी/SFC/FFC/MP-MLA/स्वयं)।
- **S-18 में पुराना कार्य जोड़ते समय:** app पूछेगा — अब तक कितना **Material** खर्च हुआ, कितना **Labour** खर्च हुआ (पिछले वर्षों में)। अगर material है तो **bill-wise details भी** (कौन-सी सामग्री, कब, कितने का) — ताकि **Audit Report** में साफ़ दिखे कि पिछले वित्तीय वर्ष में किस सामग्री के bill का payment हुआ और इस वर्ष में किसका।
- **S-20:** किसी payment पर tap → उस कार्य पर भुगतान किए **सभी bills की list** → कोई bill चुनो → उस bill में **सामग्री की पूरी detail**।
- **S-21 MB entry में:** Material मद-वार मूल्यांकन (Cement इतने बैग, रेत इतनी cum…) + **कुल मूल्यांकन (Total Valuation as per MB)** = Material + कारीगर + लेबर।
- **S-22 Man-Days:** worker का **individual नाम optional** — बिना नाम की **group entry** चलेगी: जैसे "5 लेबर 12 दिन आए = 60 मान-दिन", "1 लेबर 9 दिन = 9" → कुल 69 मान-दिन। नाम सहित rows और group rows दोनों एक साथ भी।
- **S-09 Live Status — नया शेष राशि rule (round 2):** MB हो चुकी हो तो शेष राशि **CC के allowable expenditure (minimum rule लागू करने के बाद) में से अब तक की payment राशि घटाकर** दिखेगी — FS की शेष राशि ignore (जैसे CC allowable ₹1,00,000 है तो उसी में से घटाकर शेष, चाहे FS material में ₹2,00,000 पड़े हों)। शेष **Material और Labour (कारीगर सहित) अलग-अलग** दिखेगी। MB से पहले पुराना rule (FS से शेष) चलेगा।
- **S-26 Special case + live toggle (round 2):** कभी-कभी कारीगर की राशि material में जुड़ी होती है — तब MR बनाते समय MB की labour (कारीगर सहित) राशि FS की labour राशि से अधिक हो जाती है। ऐसे case में उसी page पर **live warning** आएगी और एक **toggle**: "FS और MB की labour राशि का minimum rule ignore किया जाए या नहीं?"। Ignore ON पर labour allowable = MB की राशि; बाकी सारे rules (material minimum, rate < BSR, bills योग = CC material) unchanged।
- **S-25 Bill Register:** bills **तिथि-वार (date-wise) list** — हर bill में **bill की तिथि** और **cashbook में payment की तिथि** दिखे। Bill पर tap → S-24 में पूरी detail।
- **S-24 Bill create:** बिल किस तारीख का है, किस तारीख को बही में payment हुआ, बही में किस **पृष्ठ** पर entry हुई (रोकड़ पाना) — यह सब दिखे। **नए कार्य का bill → linkage automatic; पुराने कार्य का bill → manual entry option।**
- **S-26 CC — पूरा विवरण, कुल 7 पृष्ठ (round 3 में 7वाँ पृष्ठ जुड़ा):**
  - **पृष्ठ 1 — Completion Certificate:** कार्य का नाम, **कार्यकारी एजेंसी**, AS/TS/FS details, **वित्तीय लागत**, कार्य **शुरू/पूर्ण तिथि**, **MB संख्या & पृष्ठ संख्या (जहाँ से जहाँ तक measurement लिखा)**, मूल्यांकित Material/Labour(कारीगर)/कुल राशि (**total valuation as per MB**), फिर FS / MB / हमारे गणित का **minimum rule → Total Allowable Expenditure**।
  - **पृष्ठ 2 — Utilisation Certificate।**
  - **पृष्ठ 3 — श्रम मस्टर रोल (पखवाड़ा-वार):** हर पखवाड़े में कितने लेबर/कारीगर चले, उनके **अलग-अलग मान-दिन और wage rate**, पखवाड़े का कुल (लेबर राशि + कारीगर राशि = कुल), और अंत में **सभी पखवाड़ों का कुल योग**।
  - **पृष्ठ 4 — सामग्री विवरण (MB के अनुसार):** MB में दिए गए material के अनुसार मद-वार detail — कौन-सी सामग्री, कितनी मात्रा, BSR rate, मूल्यांकन; कुल सामग्री मूल्यांकन; सभी bills के योग से match (validation)।
  - **पृष्ठ 5 — तकनीकी जाँच रिपोर्ट:** पंचायत समिति के **सहायक अभियंता / कनिष्ठ अभियंता / Junior Technical Assistant (JTA)** द्वारा **भौतिक सत्यापन** के बाद प्रमाणित किया जाता है कि कार्य **पंचायती राज विभाग के निर्देशों के अनुरूप** किया गया है एवं **गुणवत्ता प्रमाणित** की जाती है — नीचे उनके नाम/पद/दिनांक/हस्ताक्षर।
  - **पृष्ठ 6 — कार्य पूर्णता का फोटो:** फोटो (camera/gallery से attach) के नीचे **सरपंच, ग्राम विकास अधिकारी और JTA/अभियंता** के हस्ताक्षर।
  - **पृष्ठ 7 — कार्य से पूर्व और कार्य के दौरान के फोटो (नया):** दोनों के अलग-अलग placeholders, multiple photos allowed — खुदाई/निर्माण दौरान के milestone photos तकनीकी जाँच और social audit में सबूत के रूप में काम आते हैं। इस तरह CC के 7 पृष्ठ complete।

## 16.4 Bank Statement
- **S-14:** PDF upload करते ही app **statement का महीना खुद पहचान ले** (auto-detect)। पहचान न हो या गलत हो तो **upload करते समय महीना चुनने का option**।
- **Re-upload block rule (नया):** जिस महीने का (1) statement upload हो चुका हो, (2) cashbook में entries लिखी जा चुकी हों, और (3) entries **verify** हो चुकी हों — उस महीने का statement **दोबारा upload नहीं होगा** (entries बिगड़ने का खतरा)। S-13 में ऐसे months पर 🔒 LOCKED।

## 16.5 गोशवारा (S-27)
- **cashbook की तरह दोनों तरफ़:** बाईं तरफ़ **विभिन्न income मद** (SFC, FFC, पट्टा, शुल्क, ब्याज…), दाईं तरफ़ **विभिन्न expenditure मद**। नीचे योग / अंतिम शेष / महायोग।
- **किसी भी मद पर tap → उस मद का ledger** खुलेगा — साल भर में उस मद पर आय/व्यय की **date-wise सारी entries**।

## 16.6 Prototype status
- HTML prototype **v0.2** — उस वक़्त 45 screens गिने गए थे, सभी ऊपर के changes लागू। File: `APP_PROTOTYPE.html`। *(screen numbers Round 4 में final हुए — Section 18.2 देखें)*
- **अगला कदम:** अब screen-by-screen discussion — user के सुझाव इसी क्रम में final होंगे।

---

# PART B — SECTION 17: Round 3 — Suggestions Review FINAL (19-09-2026)

*(10 suggestions दिए गए — **9 approve, 1 reject (Demo mode)**। Prototype v0.5 में लागू।)*

## 17.1 Approved — नए features

1. **वित्तीय वर्ष समापन (FY Closing) — नया screen S-45 (App Flow):**
   - 31 मार्च को wizard खुलेगी (S-05 से भी button): (1) सभी pages जाँचा-परखा verified हों, (2) सभी महीनों के bank statements uploaded + बही entries verified, (3) missing attachments की सूची (remark के साथ आगे बढ़ना possible), (4) final गोशवारा (31-03) generate, (5) operation-prior safe backup (कभी delete नहीं)।
   - सब पूरा → FY lock → **श्री पोते (fund-wise नकद + बैंक शेष) अपने आप नए FY की opening balance** बन जाएगी।
   - बंद साल read-only archive — देखा जा सकता है, correction नहीं।
2. **नकद और बैंक के नियम (FINAL — real practice):**
   - **GP कभी बैंक से नकद नहीं निकालती** — bank→cash entry type बिल्कुल नहीं होगा।
   - नकद शुल्क (जन्म/मृत्यु/विवाह/पट्टा) की राशि का **मिश्रित उपयोग** — कुछ हिस्सा daily खर्च, कुछ बैंक में जमा; दोनों चल सकते हैं।
   - **हर नकद राशि बैंक में जमा करना ज़रूरी नहीं** — जमा आंशिक और optional।
   - **"नकद से बैंक जमा" entry type** (S-09 में तीसरा option): नकद घटेगा, बैंक बढ़ेगा — यह आय/व्यय नहीं।
3. **रसीद/पर्ची + वाउचर print:** हाँ — पर **user अपना format देंगे, उसी के अनुसार** set होगा (amount शब्दों में सहित)। Format आने तक pending।
4. **Repeat/बार-बार वाली entries:** आय (S-08) और व्यय (S-09) दोनों में "पिछली entry से copy" (template) — विद्युत शुल्क, सफाई आदि मासिक entries के लिए।
5. **Entry रद्द (cancel) — S-10 में:** reason अनिवार्य (जैसे double entry) · print में **लाल काटकर (strikethrough)** दिखेगी · totals में से हटेगी · audit trail में बनी रहेगी।
6. **मासिक जाँच checklist — S-06 (FY Home) पर:** unverified pages, untagged bank entries, missing bill attachments, pending bank statements — महीने की बही बंद होने से पहले।
7. **CC का 7वाँ पृष्ठ:** कार्य से पूर्व का फोटो + कार्य के दौरान का फोटो — दोनों (Section 16.3 अपडेट हो गया)।
8. **नया फ़ोन transfer wizard — अलग screen S-46:** पुराने फ़ोन से backup zip + **4-अंकों का restore code** → नए फ़ोन में guided restore — operator को zip files समझने की ज़रूरत नहीं। *(Round 4 में S-42 Backup&Restore से अलग करके अपना screen number दिया गया, ताकि S-42 सिर्फ़ manual backup/restore पर केंद्रित रहे.)*
9. **मासिक गोशवारा reminder — S-27 में:** हर महीने की 5 तारीख़ notification — गोशवारा ready, one-tap WhatsApp share (पं.समि./BDO को PDF)।

## 17.2 Rejected
- **Demo mode (नमूना डेटा वाला training mode) — नहीं जोड़ना।**

## 17.3 Status
- Prototype v0.5 (इतिहास के तौर पर दर्ज) — उस वक़्त कुल 46 screens गिने गए थे। **Round 4 में नंबरिंग आगे ठीक हुई है — नीचे देखें।**
- Section 14 के लंबित निर्णयों में से कोई इस round में resolve नहीं हुआ (rate band Round 4 में resolve हुआ — नीचे देखें)।

---

# PART B — SECTION 18: Round 4 — Corrections & Final Cleanup (19-09-2026)

*(User द्वारा दी गई suggestions/corrections की review के बाद ये changes finalize हुए।)*

## 18.1 Cashbook line-structure — टकराव ठीक हुआ
- Section 2.2 अब **FINAL**: income side पर श्री पोते दो बार आने के कारण वहाँ **26 transaction lines**, expense side पर **27 transaction lines** — दोनों तरफ़ कुल 30-30 (पूरा detail Section 2.2 में)।

## 18.2 Screen count — FINAL: 47 screens (S-01 → S-47)
- मौजूदा S-01 → S-44 जस के तस।
- **S-45 — वित्तीय वर्ष समापन (FY Closing wizard)** — Section 17.1(1) से।
- **S-46 — नया फ़ोन Transfer Wizard** — Section 17.1(8) से, अब अपना अलग screen (पहले S-42 का हिस्सा माना गया था)।
- **S-47 — App Settings (Main Settings)** — Section 16.1 से, अब हमेशा **सबसे आख़िरी screen number** रहेगा — कोई भी future screen इसके पहले ही जुड़ेगा, App Settings हमेशा last.
- नई rows Part C, नए **Part 8** में जोड़ी गई हैं (नीचे देखें)।

## 18.3 Rate band — FINAL (conditional)
- कोई single fixed % तय नहीं होगा — हर कार्य के case हिसाब से operator BSR के 10–20% कम वाले band में तय करेगा (Section 14, row 4 अपडेट)।

## 18.4 Rounding rules — नया, FINAL
- Cashbook में हमेशा 2-decimal (paise) सटीकता; बाक़ी जगह display में nearest रुपया round (Section 12.7, नया)।

## 18.5 Privacy note — softened
- Bank/estimate data cloud AI को जाना ठीक है — GP का data वैसे भी public-domain/RTI के तहत उपलब्ध रहता है, अलग sensitive-handling policy अभी ज़रूरी नहीं (Section 11.1 अपडेट)।

## 18.6 जान-बूझकर टाले गए (deferred, scope से बाहर — अभी नहीं)
- TDS/GST deduction — नहीं जोड़ना।
- Multi-device/multi-operator sync — नहीं जोड़ना।
(दोनों future-features list, Section 13, item 17–18 में नोट हो गए हैं, ताकि भूलें नहीं — जब चाहें तब उठाए जा सकते हैं।)

## 18.7 Build status
- इस round के बाद **पहला Android source-code MVP** बनाया गया — scope: App-flow screens (S-01–S-06) + core Cashbook engine (S-07–S-10 के बराबर की functionality: page view, income/expense entry, dynamic fund columns, 26/27-line split, carry-forward, आय/व्यय योग, श्री/बचत पोते, महायोग)। यही क्रम दस्तावेज़ के अपने Section 25 (Recommended implementation order) और "Discussion order" से मेल खाता है। बाक़ी modules (Works/MB/Bills/CC/Bank Reader/Ledgers/Reports/Settings) आगे इसी क्रम में जुड़ेंगे — detail README में।

## 18.8 Source cross-check & corrections (19-09-2026)

Original MVP ZIP की `PROJECT_MASTER.md` features के खिलाफ review की गई। मिली मुख्य गलतियाँ ठीक की गईं और नया source ZIP तैयार किया गया:

1. **Per-fund श्री पोते / carry-forward (critical bug)**  
   पुराने code में `PageEntity` पर सिर्फ़ एक total `openingShriPotePaise` था और `getPageTotals` / page-creation में opening map खाली/zero भेजा जाता था → multi-fund book और page-2+ openings गलत हो जाते।  
   **Fix:** नया entity `PageOpeningEntity` (pageId + fundColumnId + amountPaise). Page 1 openings = `FundColumn.openingBalancePaise` (Section 2.1). Page N+1 = previous page की `bachatPotePerFund` (Section 4.1). Repository अब real openings load करता है।

2. **Default user seed** — Section 16.1 का default user “Harish Patidar — Operator” first FY start पर seed होता है।

3. **AndroidManifest** — missing `@mipmap/ic_launcher` reference हटाया (build crash रोकने के लिए)।

4. **Cleanup** — गलत empty directory `{data,engine,...}` हटाया; `exportSchema = false` MVP के लिए।

Engine unit tests (26/27 lines, demo PDF numbers, carry-forward, multi-fund mahayog equality, display rounding) पहले से सही थे — कोई change नहीं।

**Status unchanged:** MVP scope अभी भी S-01–S-06 flow + S-07–S-09 cashbook core ही है; बाक़ी modules document के Section 25 order में आगे जुड़ेंगे।


---

# PART B — SECTION 19: Round 5 — Admin-only, Settings hierarchy, Cashbook UX & Empty-state fixes (20-09-2026)

*(User feedback round — navigation, settings placement, scheme defaults, cashbook presentation, non-working screens. Existing Sections 1–18 rules **remain**; नीचे वाले points उन्हें **refine / extend** करते हैं। जहाँ conflict था, Round 5 FINAL लिखा गया।)*

## 19.1 Roles — Admin only (CURRENT PRODUCT)

- App **केवल Admin** चलाएगा। Admin के पास **सारी permissions** (entry, edit, cancel, masters, settings, backup, export, FY lock, column/scheme changes).
- Part A Section 18 की multi-role list (Operator / Checker / Approver / Viewer) **भविष्य के लिए document में रहती है** — UI/flow में अभी enable नहीं।
- Login (S-01): सिर्फ़ Admin identity + PIN/password (+ optional biometric).

## 19.2 Navigation hierarchy & Settings placement

### 19.2.1 Flow (supersedes multi-role wording in 15.2; screen numbers same)

```text
S-01 Login (Admin)
  → S-02 Panchayat Selection  +  [App Settings]
       → S-05 Financial Year Page  +  [Panchayat / FY Settings]
            → S-06 FY Home
                 → Cashbook / Bank / Works / गोशवारा / Ledgers / Reports / …
```

### 19.2.2 S-02 — Panchayat page पर App Settings

- Login के बाद Panchayat select वाले page पर **Settings** option अनिवार्य।
- Settings से **पूरी app की universal settings** manage:
  - Theme, logo, UI language, screen-number badge (S-47 / Section 16.1 से link)
  - Global backup defaults, font packs, आदि
- **उसी Settings में Panchayat master:**
  - Add / Edit / Correction / Delete
  - **Edit / Correction / Delete** पर save से पहले **Login password re-confirm** (confirmation dialog → सही password पर ही data save / delete)
  - Add नए panchayat पर password confirm optional (recommended on) — implementation default: destructive + edit पर confirm compulsory

### 19.2.3 S-05 — FY page पर Panchayat / FY Settings

Panchayat select करने के बाद FY page पर, FY list/status के **साथ** Settings:

1. **Financial Year CRUD** — add / edit / correction / delete (delete/edit पर password re-confirm recommended; same pattern as panchayat)
2. **Scheme (fund head) management — उस FY के लिए:**
   - Scheme add / edit / delete (**delete केवल उसी FY से** — अन्य वर्षों की schemes पर असर नहीं — Section 19.5)
   - Scheme-wise **opening balance** edit
3. **Cashbook line-count** — total lines per side (default **30**). बदलने पर **केवल बीच की transaction lines** घटती/बढ़ती हैं:
   - **नहीं बदलें:** ऊपर श्री पोते (income line 1) / expense parallel blank line
   - **नहीं बदलें:** नीचे की 3 lines — आय/व्यय योग, श्री/बचत पोते, महायोग
   - उदाहरण: 30 → 25 = बीच की transaction capacity कम; fixed header/footer lines intact (Section 19.4 से aligned)
4. **Blank-line gap between entries** — दोनों sides:
   - Option A: हर entry के बाद **1 खाली line** छोड़कर अगली entry
   - Option B: हर entry के बाद **2 खाली lines** छोड़कर अगली entry
   - Default: implementation choice document — **1 blank line** suggested; user settings में बदल सकते हैं
5. **Scheme balance may go negative?** — per-FY toggle:
   - **OFF (default recommended):** किसी scheme का balance minus में नहीं जा सकता (warning/block)
   - **ON:** particular scheme minus allow; **फिर भी** दिन का कुल expense महायोग नियम (19.6) लागू रहेगा ताकि **overall (सभी schemes मिलाकर) cashbook balance minus न हो**

## 19.3 Back navigation (system + in-app) — FINAL

- **Phone system Back** और **in-app back / up navigation** दोनों:
  - **Parent path** पर जाएँ (navigation stack pop)
  - **App बंद करके phone Home पर न जाएँ** (जब तक user root/Login पर Back न दबाए — root पर confirm-exit optional)
- Cashbook page (S-07) के ऊपर back भी parent (page list / FY Home) पर ले जाए — no-op नहीं।

## 19.4 Cashbook page structure refinements (extends Section 2.2 / 18.1)

### 19.4.1 Fixed vs variable lines

| Zone | Content | Editable manually? | Scales with line-count setting? |
|------|---------|--------------------|----------------------------------|
| Top line 1 (Income) | श्री पोते (light red) | **No** — automatic | No (always present) |
| Top line 1 (Expense) | **Always blank** — no entry ever | N/A | No (always blank parallel row) |
| Middle | Transaction lines | Via entry forms only | **Yes** — only this zone grows/shrinks |
| Bottom-3 | योग / श्री\|बचत पोते / महायोग | **No** — automatic formulas | No (always 3 lines) |

- Expense entries **line 1 के नीचे** से शुरू (Section 2.2 के 27 transaction count में line-1 blank consume हो तो effective transaction slots = configured middle lines; engine implementation: expense middle starts at row 2).
- **श्री पोते, आय/व्यय योग, बचत पोते, महायोग — manual edit UI नहीं** (Section 9 formulas only).

### 19.4.2 Extra pages after last entry date

- जिस date तक entries हैं, उसके **बाद 2 additional blank pages** automatic create/reserve — operator को तुरंत आगे लिखने की जगह मिले।

### 19.4.3 Visual / print settings (Cashbook Settings — FY or App Settings में “Cashbook appearance”)

| Setting | Default | Notes |
|---------|---------|--------|
| Page background colour | हल्का हरा (Section 2.3) | पूरा page एक ही colour; print hybrid options पहले से Section 2.3 |
| Transaction entry font colour (both sides) | **Blue** (ball-pen ink) | Income + expense entry text |
| श्री पोते (income top) font colour | **Light red** | सिर्फ़ income top श्री पोते |
| Expense top parallel line | Blank | Never holds an entry |
| Top श्री पोते + bottom-3 lines | **Bold**; font size = entry size **+ 1** | Emphasis |
| Bottom-3 lines font colour | Configurable | Cashbook settings में अलग choose |
| Other safe customizations | Optional | Column width hints, show/hide ledger folio, आदि — **detailed on-screen instructions** प्रत्येक option के साथ |

- PDF/Excel share of page or page-range: **plain white background** (screen green tint print/share में नहीं — Section 19.10).

## 19.5 Fund / Scheme heads (extends Section 8)

- Dynamic fund columns / Active fund heads पर tap **काम करे** (no dead clicks).
- **Edit** layout: opening-balance field **visible** (previous layout bug — fixed requirement).
- Edit control के पास **red Delete**:
  - Delete = **उस Financial Year से scheme हटाना**
  - **सभी वर्षों से global delete नहीं**
- New scheme mid-year / next-year:
  - वर्षांत closing → अगले वर्ष opening carry-forward (Section 2 / 4.1 / 17.1)
  - यदि **नई scheme** अगले वर्ष जुड़ती है तो Page 1 श्री पोते row पर **indicator**:
    - **Carry-forward** (पिछले वर्ष से आया)
    - **Manually added** (नया opening इस वर्ष set किया)
  - Indicator print + screen दोनों पर readable (icon/text badge).

## 19.6 Income / Expense entry rules (extends Sections 5–6, 9)

1. **Default scheme = SFC** both income and expense forms.
2. अन्य schemes **dropdown** से; **बिना scheme select entry save नहीं** (validation block).
3. **Same-day total expense (all schemes) ≤ उसी दिन income-side महायोग**  
   - इससे **overall (सभी schemes) cashbook balance minus में नहीं** जाता।
4. Per-scheme minus allow/deny = FY Settings toggle (19.2.3 point 5); overall rule (point 3) हमेशा लागू।

## 19.7 Empty states & non-working clicks — FINAL UX rule

जहाँ report/data उपलब्ध नहीं:

- Click **silent no-op नहीं**
- Screen/dialog में **हिंदी+English brief note**:
  - यह report/data अभी क्यों नहीं है
  - पाने के लिए **पहले कौन-से steps** ज़रूरी (उदा. “पहले कम से कम एक income entry करें”, “Bank statement upload + tag करें”, “Page verify करें”)

Applies at minimum to:

- Monthly check (S-06 checklist)
- गोशवारा till date (S-27)
- Reports Hub / contextual reports (S-34+)
- Ledgers (S-28–S-32)
- Backup & Restore (S-42 / related)
- Fund head tiles जब empty
- Bank Statement module entry points

## 19.8 Monthly check (extends 17.1.6)

- Monthly check खोलने पर warnings/list दिखे।
- किसी **warning पर tap → सीधे related entry** (S-10 edit/correct/cancel flow)।
- Empty होने पर 19.7 empty-state note।

## 19.9 Module availability (must not be dead ends)

निम्न modules **reachable + usable** होने चाहिए (placeholder click = 19.7 note minimum; ideally full MVP path):

| Area | Requirement |
|------|-------------|
| गोशवारा till date | Open classified till-date view; empty-state if no data |
| Reports & Ledgers | Open hub/ledger; empty-state + how to populate |
| Backup & Restore | Full options: backup / restore / export / list / retention status (Section 4 + 20) |
| **Bank Statement** | Upload PDF, unlock, AI/OCR read, editable grid, tagging, auto cashbook entry per Section 11 rules — **feature must exist in navigation** (previously missing in running app) |

## 19.10 Share page / page-range (Cashbook)

- किसी FY की cashbook में **page या page-range → PDF और Excel share**
- Share/export layout: **plain white background** (register green tint नहीं)
- Formulas/totals export-time recompute; Hindi font rules Section 1 / 15.1 apply

## 19.11 Summary lines non-editable (re-affirm)

- श्री पोते, आय योग, व्यय योग, बचत पोते, महायोग — **no manual edit controls** anywhere on page grid
- Values केवल engine (Section 9 + 2.2 + carry-forward) से

## 19.12 Screen index deltas (Part C remains S-01…S-47; behaviour updates)

| Screen | Round 5 change |
|--------|----------------|
| S-01 | Admin-only login |
| S-02 | + App Settings (universal + Panchayat CRUD + password confirm) |
| S-05 | + Panchayat/FY Settings (FY/scheme/lines/gap/minus-policy) |
| S-06 | Monthly check → tappable warnings; all tiles obey 19.7 |
| S-07 | Structure 19.4; back nav 19.3; share 19.10; appearance from settings |
| S-08/S-09 | Default SFC; scheme required; expense ≤ day महायोग |
| S-13–S-16 | Bank module must be present per Section 11 |
| S-27/S-28–S-34/S-42 | No dead clicks; empty-states |
| S-35 / fund UI | Edit opening balance visible; red delete = FY-scoped |
| S-47 | Still last; linked from S-02 App Settings |

## 19.13 Contradiction resolution log

| Topic | Resolution |
|-------|------------|
| Multi-role vs Admin-only | Admin-only **current**; multi-role text kept as deferred |
| Expense line 1 vs 27 transactions | Line 1 expense **blank**; transactions start below; middle-zone count follows line-count setting |
| Line-count 25 vs 30 | Only middle transaction zone changes; top/bottom fixed |
| Scheme minus vs overall minus | Overall day expense ≤ income महायोग **always**; per-scheme minus optional per FY |
| Green page vs white share | On-screen default green; **PDF/Excel share white** |
| App Settings location | Entry from **S-02**; S-47 remains canonical settings screen number |

## 19.14 Implementation priority (suggested)

1. Back navigation (19.3) + kill dead clicks / empty-states (19.7)
2. Admin-only + Settings hierarchy (19.1–19.2)
3. Scheme default SFC + validations (19.6)
4. Fund head edit/delete UX (19.5)
5. Cashbook appearance + non-editable summary lines (19.4, 19.11)
6. Monthly check deep-link (19.8)
7. Bank statement module surface (19.9 / Section 11)
8. Page-range PDF/Excel white share (19.10)
9. Auto +2 pages after last entry date (19.4.2)

