# Gram Panchayat Cashbook — Android (Expo MVP)

Aligned to **PROJECT_MASTER.md** including **Section 19 (Round 5, 20-09-2026)**.

## Implemented in this build

- **Admin-only** login + PIN setup (S-01)
- **Hardware / header Back → parent stack** (not Android Home) — §19.3
- **S-02 Panchayat** + App Settings (panchayat CRUD + PIN confirm) — §19.2
- **S-05 FY page** + FY Settings (line-count, blank gap, scheme-minus, schemes, opening balance) — §19.2.3
- **S-06 FY Home** with reachable modules + **empty-state guidance** — §19.7
- **Cashbook** (S-07): default **SFC**, scheme required, expense ≤ day महायोग, blue entry ink, red श्री पोते, summary auto-only — §19.4 / 19.6 / 19.11
- **Fund heads** edit opening (visible) + **red Delete** (FY-scoped disable) — §19.5
- **Monthly check** list / warnings — §19.8
- Placeholders with **why + steps** for गोशवारा, Reports, Backup, Bank Statement — §19.9

## Data

Offline **AsyncStorage** (`gram-panchayat-cashbook-v2`). Production SAF `Documents/Cashbook` backup still per master doc §3–4.

## Run

```bash
cd cashbook-mobile
pnpm install   # or npm install
npx expo start
```

## Note on package.json

Replit `catalog:` / `workspace:*` deps are replaced with npm pins (`@tanstack/react-query`, `zod`). Internal `@workspace/api-client-react` removed (not used by MVP screens).
