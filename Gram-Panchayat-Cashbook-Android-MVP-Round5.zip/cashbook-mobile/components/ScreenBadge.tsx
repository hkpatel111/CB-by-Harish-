import React from 'react';
import { StyleSheet, Text } from 'react-native';
import { useColors } from '@/hooks/useColors';

export function ScreenBadge({ label }: { label: string }) {
  const colors = useColors();
  return <Text style={[styles.badge, { color: colors.mutedForeground }]}>{label}</Text>;
}

const styles = StyleSheet.create({
  badge: { fontSize: 10, letterSpacing: 1, fontWeight: '600' },
});
