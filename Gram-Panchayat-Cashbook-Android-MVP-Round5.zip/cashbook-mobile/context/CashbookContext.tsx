import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

/** PROJECT_MASTER.md — fund / scheme head (Section 8 + 19.5) */
export type Fund = {
  id: string;
  name: string;
  shortName: string;
  openingBalance: number;
  enabled: boolean;
  /** Opening source for Page-1 श्री पोते indicator (Section 19.5) */
  openingSource?: 'carry-forward' | 'manual';
};

export type TransactionType = 'income' | 'expense';

export type Transaction = {
  id: string;
  type: TransactionType;
  date: string;
  reference: string;
  party: string;
  detail: string;
  /** Primary scheme id — required (Section 19.6) */
  schemeId: string;
  amounts: Record<string, number>;
  note: string;
  status: 'active' | 'cancelled';
  createdAt: string;
};

export type Panchayat = {
  id: string;
  name: string;
  block: string;
  district: string;
};

export type FinancialYear = {
  id: string;
  label: string;
  start: string;
  end: string;
};

/** Per-FY cashbook appearance & rules (Section 19.2.3, 19.4.3) */
export type FySettings = {
  lineCount: number; // total lines per side, default 30
  blankLineGap: 1 | 2;
  allowSchemeNegative: boolean;
  pageBackground: string;
  entryFontColor: string;
  shriPoteColor: string;
  summaryFontColor: string;
};

export type CashbookData = {
  panchayats: Panchayat[];
  activePanchayatId: string;
  financialYears: FinancialYear[];
  activeFinancialYearId: string;
  funds: Fund[];
  transactions: Transaction[];
  pin: string | null;
  setupComplete: boolean;
  fySettings: FySettings;
  adminName: string;
};

type CashbookContextValue = CashbookData & {
  hydrated: boolean;
  activePanchayat: Panchayat;
  activeFinancialYear: FinancialYear;
  activeFunds: Fund[];
  totalOpening: number;
  totalIncome: number;
  totalExpense: number;
  currentBalance: number;
  setPin: (pin: string) => Promise<void>;
  verifyPin: (pin: string) => boolean;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt' | 'status'>) => Promise<{ ok: true } | { ok: false; error: string }>;
  cancelTransaction: (id: string) => Promise<void>;
  addFund: (name: string, openingBalance: number, openingSource?: 'carry-forward' | 'manual') => Promise<void>;
  updateOpeningBalance: (fundId: string, openingBalance: number, openingSource?: 'carry-forward' | 'manual') => Promise<void>;
  deleteFundFromFy: (fundId: string) => Promise<void>;
  setActivePanchayatId: (id: string) => void;
  setActiveFinancialYearId: (id: string) => void;
  addPanchayat: (p: Omit<Panchayat, 'id'>) => Promise<void>;
  updatePanchayat: (id: string, patch: Partial<Omit<Panchayat, 'id'>>) => Promise<void>;
  deletePanchayat: (id: string) => Promise<{ ok: true } | { ok: false; error: string }>;
  addFinancialYear: (fy: Omit<FinancialYear, 'id'>) => Promise<void>;
  updateFySettings: (patch: Partial<FySettings>) => Promise<void>;
  dayMahayog: (date: string) => number;
  dayExpenseTotal: (date: string) => number;
};

const STORAGE_KEY = 'gram-panchayat-cashbook-v2';

const defaultFySettings: FySettings = {
  lineCount: 30,
  blankLineGap: 1,
  allowSchemeNegative: false,
  pageBackground: '#E9F4E9',
  entryFontColor: '#1565C0', // blue ball-pen (Section 19.4.3)
  shriPoteColor: '#C62828', // light/strong red for श्री पोते
  summaryFontColor: '#1B5E20',
};

const seedFunds: Fund[] = [
  { id: 'cash', name: 'Cash / नकद', shortName: 'Cash', openingBalance: 0, enabled: true, openingSource: 'manual' },
  { id: 'sfc', name: 'SFC', shortName: 'SFC', openingBalance: 0, enabled: true, openingSource: 'manual' },
  { id: 'ffc', name: 'FFC', shortName: 'FFC', openingBalance: 0, enabled: true, openingSource: 'manual' },
  { id: 'own', name: 'Own Fund / Interest', shortName: 'Own Fund', openingBalance: 0, enabled: true, openingSource: 'manual' },
  { id: 'mp', name: 'MP / MLA / TAD', shortName: 'MP/MLA', openingBalance: 0, enabled: true, openingSource: 'manual' },
];

const seedPanchayat: Panchayat = {
  id: 'gp-mal',
  name: 'ग्राम पंचायत माल',
  block: 'साबला',
  district: 'डूंगरपुर',
};

const seedFy: FinancialYear = {
  id: 'fy-2026-27',
  label: '2026–27',
  start: '2026-04-01',
  end: '2027-03-31',
};

const defaultData: CashbookData = {
  panchayats: [seedPanchayat],
  activePanchayatId: seedPanchayat.id,
  financialYears: [seedFy],
  activeFinancialYearId: seedFy.id,
  funds: seedFunds,
  transactions: [],
  pin: null,
  setupComplete: false,
  fySettings: defaultFySettings,
  adminName: 'Admin',
};

const CashbookContext = createContext<CashbookContextValue | null>(null);

function amountOf(transactions: Transaction[], type: TransactionType, funds: Fund[]) {
  const ids = new Set(funds.map((f) => f.id));
  return transactions
    .filter((t) => t.status === 'active' && t.type === type)
    .reduce((sum, t) => sum + Object.entries(t.amounts).reduce((s, [fid, a]) => (ids.has(fid) ? s + a : s), 0), 0);
}

function sumAmounts(amounts: Record<string, number>) {
  return Object.values(amounts).reduce((s, a) => s + (Number(a) || 0), 0);
}

export function formatINR(n: number) {
  const neg = n < 0;
  const abs = Math.abs(Math.round(n * 100) / 100);
  const [r, p] = abs.toFixed(2).split('.');
  const withComma = r.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${neg ? '-' : ''}₹${withComma}.${p}`;
}

export function CashbookProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<CashbookData>(defaultData);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!raw) return;
        const parsed = JSON.parse(raw);
        // migrate v1 shapes softly
        if (parsed && !parsed.panchayats && parsed.panchayat) {
          setData({
            ...defaultData,
            pin: parsed.pin ?? null,
            setupComplete: !!parsed.setupComplete,
            funds: parsed.funds ?? seedFunds,
            transactions: (parsed.transactions ?? []).map((t: any) => ({
              schemeId: t.schemeId || 'sfc',
              ...t,
            })),
            adminName: 'Admin',
          });
        } else {
          setData({
            ...defaultData,
            ...parsed,
            fySettings: { ...defaultFySettings, ...(parsed.fySettings || {}) },
            funds: parsed.funds?.length ? parsed.funds : seedFunds,
            panchayats: parsed.panchayats?.length ? parsed.panchayats : [seedPanchayat],
            financialYears: parsed.financialYears?.length ? parsed.financialYears : [seedFy],
          });
        }
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (hydrated) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(data)).catch(() => undefined);
  }, [data, hydrated]);

  const value = useMemo<CashbookContextValue>(() => {
    const activeFunds = data.funds.filter((f) => f.enabled);
    const totalOpening = activeFunds.reduce((s, f) => s + f.openingBalance, 0);
    const totalIncome = amountOf(data.transactions, 'income', activeFunds);
    const totalExpense = amountOf(data.transactions, 'expense', activeFunds);
    const activePanchayat = data.panchayats.find((p) => p.id === data.activePanchayatId) || data.panchayats[0] || seedPanchayat;
    const activeFinancialYear = data.financialYears.find((f) => f.id === data.activeFinancialYearId) || data.financialYears[0] || seedFy;

    const dayMahayog = (date: string) => {
      // Simplified day महायोग: opening + income up to and including date − expense before date + income that day
      // For MVP validation: opening + all income on date (same-day pool)
      const dayIncome = data.transactions
        .filter((t) => t.status === 'active' && t.type === 'income' && t.date === date)
        .reduce((s, t) => s + sumAmounts(t.amounts), 0);
      // Use running: totalOpening + income before/on date - expense before date is ideal;
      // Section 19.6: same-day total expense ≤ same-day income-side महायोग
      // Approximate महायोग for the day as: scheme openings allocated + day's income
      // Practical MVP: day's income + (opening only on first use) — use opening + cumulative income to date - prior expense
      const priorIncome = data.transactions
        .filter((t) => t.status === 'active' && t.type === 'income' && t.date <= date)
        .reduce((s, t) => s + sumAmounts(t.amounts), 0);
      const priorExpense = data.transactions
        .filter((t) => t.status === 'active' && t.type === 'expense' && t.date < date)
        .reduce((s, t) => s + sumAmounts(t.amounts), 0);
      return totalOpening + priorIncome - priorExpense;
    };

    const dayExpenseTotal = (date: string) =>
      data.transactions
        .filter((t) => t.status === 'active' && t.type === 'expense' && t.date === date)
        .reduce((s, t) => s + sumAmounts(t.amounts), 0);

    return {
      ...data,
      hydrated,
      activePanchayat,
      activeFinancialYear,
      activeFunds,
      totalOpening,
      totalIncome,
      totalExpense,
      currentBalance: totalOpening + totalIncome - totalExpense,
      dayMahayog,
      dayExpenseTotal,
      setPin: async (pin) => setData((p) => ({ ...p, pin, setupComplete: true, adminName: p.adminName || 'Admin' })),
      verifyPin: (pin) => !!data.pin && data.pin === pin,
      addTransaction: async (transaction) => {
        if (!transaction.schemeId) return { ok: false as const, error: 'Scheme (निधि) चुनना अनिवार्य है — Section 19.6' };
        const lineTotal = sumAmounts(transaction.amounts);
        if (lineTotal <= 0) return { ok: false as const, error: 'कम से कम एक राशि दर्ज करें' };

        if (transaction.type === 'expense') {
          const mahayog = dayMahayog(transaction.date);
          const already = dayExpenseTotal(transaction.date);
          if (already + lineTotal > mahayog + 0.001) {
            return {
              ok: false as const,
              error: `व्यय योग इस दिन के आय-महायोग (₹${mahayog.toFixed(2)}) से अधिक नहीं हो सकता — Section 19.6`,
            };
          }
          if (!data.fySettings.allowSchemeNegative) {
            const fund = activeFunds.find((f) => f.id === transaction.schemeId);
            const schemeOpen = fund?.openingBalance ?? 0;
            const schemeIn = data.transactions
              .filter((t) => t.status === 'active' && t.type === 'income' && t.schemeId === transaction.schemeId)
              .reduce((s, t) => s + sumAmounts(t.amounts), 0);
            const schemeOut = data.transactions
              .filter((t) => t.status === 'active' && t.type === 'expense' && t.schemeId === transaction.schemeId)
              .reduce((s, t) => s + sumAmounts(t.amounts), 0);
            const bal = schemeOpen + schemeIn - schemeOut - lineTotal;
            if (bal < -0.001) {
              return { ok: false as const, error: `Scheme "${fund?.shortName ?? transaction.schemeId}" का balance minus नहीं हो सकता (FY setting).` };
            }
          }
        }

        setData((previous) => ({
          ...previous,
          transactions: [
            ...previous.transactions,
            {
              ...transaction,
              id: Date.now().toString() + Math.random().toString(36).slice(2, 8),
              createdAt: new Date().toISOString(),
              status: 'active',
            },
          ],
        }));
        return { ok: true as const };
      },
      cancelTransaction: async (id) => {
        setData((previous) => ({
          ...previous,
          transactions: previous.transactions.map((item) => (item.id === id ? { ...item, status: 'cancelled' } : item)),
        }));
      },
      addFund: async (name, openingBalance, openingSource = 'manual') => {
        const normalized = name.trim();
        if (!normalized) return;
        setData((previous) => ({
          ...previous,
          funds: [
            ...previous.funds,
            {
              id: Date.now().toString(),
              name: normalized,
              shortName: normalized.slice(0, 12),
              openingBalance,
              enabled: true,
              openingSource,
            },
          ],
        }));
      },
      updateOpeningBalance: async (fundId, openingBalance, openingSource) => {
        setData((previous) => ({
          ...previous,
          funds: previous.funds.map((fund) =>
            fund.id === fundId
              ? { ...fund, openingBalance, openingSource: openingSource ?? fund.openingSource ?? 'manual' }
              : fund
          ),
        }));
      },
      deleteFundFromFy: async (fundId) => {
        // FY-scoped soft disable (Section 19.5) — does not wipe history amounts
        setData((previous) => ({
          ...previous,
          funds: previous.funds.map((f) => (f.id === fundId ? { ...f, enabled: false } : f)),
        }));
      },
      setActivePanchayatId: (id) => setData((p) => ({ ...p, activePanchayatId: id })),
      setActiveFinancialYearId: (id) => setData((p) => ({ ...p, activeFinancialYearId: id })),
      addPanchayat: async (panchayat) => {
        const id = 'gp-' + Date.now().toString(36);
        setData((previous) => ({
          ...previous,
          panchayats: [...previous.panchayats, { ...panchayat, id }],
          activePanchayatId: id,
        }));
      },
      updatePanchayat: async (id, patch) => {
        setData((previous) => ({
          ...previous,
          panchayats: previous.panchayats.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        }));
      },
      deletePanchayat: async (id) => {
        if (data.panchayats.length <= 1) return { ok: false as const, error: 'कम से कम एक पंचायत रहनी चाहिए' };
        setData((previous) => {
          const next = previous.panchayats.filter((p) => p.id !== id);
          return {
            ...previous,
            panchayats: next,
            activePanchayatId: previous.activePanchayatId === id ? next[0].id : previous.activePanchayatId,
          };
        });
        return { ok: true as const };
      },
      addFinancialYear: async (fy) => {
        const id = 'fy-' + Date.now().toString(36);
        setData((previous) => ({
          ...previous,
          financialYears: [...previous.financialYears, { ...fy, id }],
          activeFinancialYearId: id,
        }));
      },
      updateFySettings: async (patch) => {
        setData((previous) => ({
          ...previous,
          fySettings: { ...previous.fySettings, ...patch },
        }));
      },
    };
  }, [data, hydrated]);

  return <CashbookContext.Provider value={value}>{children}</CashbookContext.Provider>;
}

export function useCashbook() {
  const context = useContext(CashbookContext);
  if (!context) throw new Error('useCashbook must be used inside CashbookProvider');
  return context;
}
