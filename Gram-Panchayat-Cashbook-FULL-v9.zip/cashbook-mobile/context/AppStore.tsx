import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type {
  AppSettings,
  AuditLog,
  BsrRate,
  BankAccount,
  BankLine,
  Bill,
  CashbookPage,
  CategoryNode,
  FinancialYear,
  Fund,
  FySettings,
  HolidayEntry,
  ItemMaster,
  MandayCalc,
  MbLine,
  PakhwadaRoll,
  Panchayat,
  RootData,
  Transaction,
  TxType,
  Vendor,
  WorkerRate,
  Work,
} from '@/types/models';
import {
  dayExpenseTotal,
  dayMahayog,
  formatINR,
  isValidIsoDate,
  monthLastDay,
  schemeBalance,
  sumAmounts,
  toIsoLocal,
  transactionLineCount,
} from '@/services/pageEngine';

const STORAGE = 'gpc-cashbook-v5';

const defaultFySettings: FySettings = {
  lineCount: 25,
  blankLineGap: 1,
  allowSchemeNegative: false,
  pageBackground: '#E9F4E9',
  entryFontColor: '#1565C0',
  shriPoteColor: '#C62828',
  summaryFontColor: '#1B5E20',
  /* instruction #10 — default ON (edit chalu); audit lock ke time OFF kar dena */
  allowBackDateEdit: true,
};

const seedFunds: Fund[] = [
  { id: 'cash', name: 'Cash / नकद', shortName: 'Cash', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 0 },
  { id: 'sfc', name: 'SFC', shortName: 'SFC', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 1 },
  { id: 'ffc', name: 'FFC', shortName: 'FFC', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 2 },
  { id: 'own', name: 'Own Fund / Interest', shortName: 'Own', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 3 },
  { id: 'mp', name: 'MP / MLA / TAD', shortName: 'MP/MLA', openingBalance: 0, enabled: true, openingSource: 'manual', sortOrder: 4 },
];

/** instruction #19 — कार्य की वित्त पोषण एजेंसी (dropdown; यहीं से add/edit/delete) */
const seedFundingAgencies = [
  { id: 'fa-gp', name: 'Panchayat (ग्राम पंचायत)' },
  { id: 'fa-ps', name: 'Panchayat Samiti (पंचायत समिति)' },
  { id: 'fa-zp', name: 'Jila Parishad (जिला परिषद)' },
  { id: 'fa-mp', name: 'MP Fund (सांसद निधि)' },
  { id: 'fa-mla', name: 'MLA Fund (विधायक निधि)' },
  { id: 'fa-tad', name: 'TAD Fund' },
  { id: 'fa-state', name: 'State Government (राज्य शासन)' },
  { id: 'fa-central', name: 'Central Government (केंद्र शासन)' },
];

const seedCategories: CategoryNode[] = [
  /* instruction #5/#7 — SFC, FFC यहाँ नहीं: वे योजना (fund) हैं, श्रेणी नहीं */
  { id: 'inc-fee', kind: 'income', name: 'शुल्क', parentId: null, level: 1, archived: false },
  { id: 'inc-fee-birth', kind: 'income', name: 'जन्म प्रमाण', parentId: 'inc-fee', level: 2, archived: false },
  { id: 'inc-fee-death', kind: 'income', name: 'मृत्यु प्रमाण', parentId: 'inc-fee', level: 2, archived: false },
  { id: 'inc-fee-marriage', kind: 'income', name: 'विवाह पंजीयन', parentId: 'inc-fee', level: 2, archived: false },
  { id: 'exp-stat', kind: 'expense', name: 'Stationery', parentId: null, level: 1, archived: false },
  { id: 'exp-power', kind: 'expense', name: 'बिजली शुल्क', parentId: null, level: 1, archived: false },
  { id: 'exp-clean', kind: 'expense', name: 'सफाई कार्य', parentId: null, level: 1, archived: false },
  { id: 'exp-work', kind: 'expense', name: 'Work / कार्य', parentId: null, level: 1, archived: false },
];

const seedPanchayat: Panchayat = { id: 'gp-mal', name: 'ग्राम पंचायत माल', block: 'साबला', district: 'डूंगरपुर' };
const seedFy: FinancialYear = { id: 'fy-2026-27', label: '2026–27', start: '2026-04-01', end: '2027-03-31', locked: false };

const defaultData: RootData = {
  version: 5,
  app: {
    pin: null,
    biometricEnabled: false,
    setupComplete: false,
    adminName: 'Admin',
    themeId: 'green',
    logoId: 'book',
    language: 'hinglish',
    showScreenBadge: true,
  },
  fySettings: defaultFySettings,
  panchayats: [seedPanchayat],
  activePanchayatId: seedPanchayat.id,
  financialYears: [seedFy],
  activeFinancialYearId: seedFy.id,
  funds: seedFunds,
  categories: seedCategories,
  transactions: [],
  works: [],
  fundingAgencies: seedFundingAgencies,
  mbLines: [],
  bills: [],
  bankAccounts: [{ id: 'ba1', name: 'GP Main', accountNo: 'XXXX1234', bankName: 'SBI' }],
  bankLines: [],
  pages: [],
  workerRolls: [],
  bsrRates: [],
  itemMasters: [],
  vendors: [],
  holidays: [],
  workerRates: [],
  mandayCalcs: [],
  auditLogs: [],
};

/**
 * Instruction #4: BSR page par items pehle se listed hon — labour + material
 * (cement, रेत, गिट्टी 40/20/12 मिमी, पत्थर, ईंट…). Sirf us saal ki rate bharni ho;
 * item yahin se add/edit/delete ho sakte hain (itemMasters me seed hote hain).
 */
export const BSR_TEMPLATE: { name: string; unit: string; kind: 'labour' | 'material' }[] = [
  { name: 'श्रमिक', unit: 'दिन', kind: 'labour' },
  { name: 'कारीगर', unit: 'दिन', kind: 'labour' },
  { name: 'मेट', unit: 'दिन', kind: 'labour' },
  { name: 'सीमेंट', unit: 'बोरी', kind: 'material' },
  { name: 'रेत', unit: 'घन मी', kind: 'material' },
  { name: 'गिट्टी 40 मिमी', unit: 'घन मी', kind: 'material' },
  { name: 'गिट्टी 20 मिमी', unit: 'घन मी', kind: 'material' },
  { name: 'गिट्टी 12 मिमी', unit: 'घन मी', kind: 'material' },
  { name: 'पत्थर', unit: 'घन मी', kind: 'material' },
  { name: 'ईंट', unit: 'नग', kind: 'material' },
  { name: 'सरिया', unit: 'किग्रा', kind: 'material' },
  { name: 'पानी टेंकर', unit: 'नग', kind: 'material' },
  { name: 'पौधे', unit: 'नग', kind: 'material' },
  { name: 'ट्री गार्ड', unit: 'नग', kind: 'material' },
];

/** पहली बार (ya jab list khaali ho) template se itemMasters seed */
function seedBsrItems(d: RootData): RootData {
  if (d.itemMasters.length) return d;
  return {
    ...d,
    itemMasters: BSR_TEMPLATE.filter((t) => t.kind === 'material').map((t) => ({
      id: 'it_' + t.name.replace(/\s+/g, '_').toLowerCase(),
      name: t.name,
      wholeNumberOnly: t.name === 'सीमेंट' || t.name === 'ईंट',
      lastBillOnly: t.name === 'पानी टेंकर',
      basicItem: ['सीमेंट', 'रेत', 'गिट्टी 40 मिमी', 'गिट्टी 20 मिमी', 'गिट्टी 12 मिमी', 'पत्थर', 'ईंट'].includes(t.name),
    })),
  };
}

/** भुगतान side par भी आता है (नकद→बैंक जमा), capacity expense side me count hoti hai */
const sideOf = (ty: TxType): 'income' | 'expense' => (ty === 'transfer' ? 'expense' : ty);

type Store = RootData & {
  hydrated: boolean;
  activePanchayat: Panchayat;
  activeFy: FinancialYear;
  activeFunds: Fund[];
  /** STRICT FY filter — only current FY transactions */
  fyTransactions: Transaction[];
  totalOpening: number;
  totalIncome: number;
  totalExpense: number;
  currentBalance: number;
  /** D17: is FY ka fund opening (legacy FY par fund.openingBalance) */
  fundOpening: (f: Fund) => number;
  setPin: (pin: string) => Promise<void>;
  verifyPin: (pin: string) => boolean;
  setBiometricEnabled: (v: boolean) => Promise<void>;
  updateApp: (p: Partial<AppSettings>) => Promise<void>;
  updateFySettings: (p: Partial<FySettings>) => Promise<void>;
  setActivePanchayatId: (id: string) => void;
  setActiveFinancialYearId: (id: string) => void;
  addPanchayat: (p: Omit<Panchayat, 'id'>) => Promise<void>;
  updatePanchayat: (id: string, p: Partial<Panchayat>) => Promise<void>;
  deletePanchayat: (id: string) => Promise<{ ok: boolean; error?: string }>;
  addFinancialYear: (label: string, start: string, end: string) => Promise<{ ok: boolean; error?: string }>;
  closeFinancialYearCarryForward: (fromFyId: string, toLabel: string, toStart: string, toEnd: string) => Promise<{ ok: boolean; error?: string }>;
  addFund: (name: string, opening: number, source?: 'carry-forward' | 'manual') => Promise<void>;
  updateFundOpening: (id: string, opening: number, source?: 'carry-forward' | 'manual') => Promise<void>;
  deleteFundFy: (id: string) => Promise<void>;
  addCategory: (kind: 'income' | 'expense', name: string, parentId: string | null) => Promise<void>;
  archiveCategory: (id: string) => Promise<void>;
  renameCategory: (id: string, name: string) => Promise<void>;
  addTransaction: (
    t: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'fyId' | 'pageId'> & {
      /** v9 #3 — user ने कोई ख़ास पन्ना चुना हो तो यहाँ */
      pageId?: string | null;
    }
  ) => Promise<{ ok: true } | { ok: false; error: string }>;
  updateTransaction: (id: string, patch: Partial<Transaction>) => Promise<{ ok: true } | { ok: false; error: string }>;
  /** D4: reason अनिवार्य */
  cancelTransaction: (id: string, reason: string) => Promise<{ ok: boolean; error?: string }>;
  /** returns new work id (dropdown-se inline add ke liye) */
  addWork: (w: Omit<Work, 'id'>) => Promise<string>;
  /* instruction #19 — वित्त पोषण एजेंसी master */
  fundingAgencies: { id: string; name: string }[];
  addFundingAgency: (name: string) => Promise<void>;
  renameFundingAgency: (id: string, name: string) => Promise<void>;
  deleteFundingAgency: (id: string) => Promise<void>;
  updateWork: (id: string, patch: Partial<Work>) => Promise<void>;
  addMbLine: (line: Omit<MbLine, 'id'>) => Promise<void>;
  addBill: (b: Omit<Bill, 'id'>) => Promise<void>;
  /* Vendor / party master (instruction #5 — bills me dropdown) */
  addVendor: (v: Omit<Vendor, 'id' | 'archived'>) => Promise<void>;
  updateVendor: (id: string, patch: Partial<Vendor>) => Promise<void>;
  deleteVendor: (id: string) => Promise<{ ok: boolean; error?: string }>;
  addBankLine: (line: Omit<BankLine, 'id'>) => Promise<void>;
  updateBankLine: (id: string, patch: Partial<BankLine>) => Promise<void>;
  postBankLineToCashbook: (lineId: string) => Promise<{ ok: boolean; error?: string }>;
  /* Pages (manual Excel-style pagination) */
  fyPages: CashbookPage[];
  addPage: (label?: string) => void;
  /** instruction #15(b) — FY के हर महीने की month-end page automatic */
  syncMonthlyPages: () => void;
  /**
   * v9 #3 — तारीख़ डालते ही दो विकल्प:
   *  • `hasOwnPage` — उस तारीख़ का अपना पन्ना पहले से है
   *  • `next` — उस तारीख़ के बाद का अगला उपलब्ध पन्ना (+ उसकी तारीख़ suggestion में)
   */
  pageOptionsForDate: (date: string) => {
    hasOwnPage: boolean;
    next: { pageId: string; date: string; label: string; pageNo: number } | null;
  };
  /** इस तारीख़ का पन्ना लौटाओ; नहीं है तो बना दो → pageId */
  ensurePageForDate: (date: string) => string | null;
  /** pageId → उस पन्ने का दिनांक */
  pageDateOf: (pageId: string | null) => string;
  insertPageAfter: (pageId: string, label?: string) => void;
  deletePage: (pageId: string) => void;
  assignTxnToPage: (txnId: string, pageId: string) => void;
  /* Worker rolls (CC labour) */
  addWorkerRoll: (r: Omit<PakhwadaRoll, 'id'>) => Promise<string>;
  /* Masters (old master B §5–§7) + instruction #4 (BSR add/edit/delete) */
  addBsrRate: (r: Omit<BsrRate, 'id'>) => Promise<void>;
  updateBsrRate: (id: string, patch: Partial<BsrRate>) => Promise<void>;
  deleteBsrRate: (id: string) => Promise<void>;
  addItemMaster: (i: Omit<ItemMaster, 'id'>) => Promise<void>;
  updateItemMaster: (id: string, patch: Partial<ItemMaster>) => Promise<void>;
  deleteItemMaster: (id: string) => Promise<void>;
  addHoliday: (h: Omit<HolidayEntry, 'id'>) => Promise<void>;
  addWorkerRate: (w: Omit<WorkerRate, 'id'>) => Promise<void>;
  addMandayCalc: (c: Omit<MandayCalc, 'id' | 'createdAt'>) => Promise<string>;
  deleteMandayCalc: (id: string) => Promise<void>;
  /* Repeat template + transfer */
  getTransaction: (id: string) => Transaction | null;
  addTransferCashToBank: (date: string, amount: number, bankFundId: string, note?: string) => Promise<{ ok: boolean; error?: string }>;
  /* Backup / restore */
  exportBackupJson: () => string;
  importBackupJson: (json: string) => { ok: boolean; error?: string };
  exportCsvForFy: () => string;
};

const Ctx = createContext<Store | null>(null);

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

type AuditInput = Omit<AuditLog, 'id' | 'time'>;
/** L.3 audit trail — newest first, capped (storage size control) */
function pushLog(logs: AuditLog[], e: AuditInput): AuditLog[] {
  return [{ ...e, id: uid(), time: new Date().toISOString() }, ...logs].slice(0, 1000);
}

/** Har backup/restore + first-load par same merge (purane backups me naye fields safe) */
function mergeRaw(parsed: Partial<RootData> & Record<string, unknown>): RootData {
  const p = parsed as Partial<RootData>;
  return {
    ...defaultData,
    ...p,
    version: 5,
    app: { ...defaultData.app, ...(p.app || {}) },
    fySettings: { ...defaultFySettings, ...(p.fySettings || {}) },
    funds: p.funds?.length ? p.funds : seedFunds,
    categories: p.categories?.length ? p.categories : seedCategories,
    financialYears: p.financialYears?.length ? p.financialYears : [seedFy],
    panchayats: p.panchayats?.length ? p.panchayats : [seedPanchayat],
    transactions: p.transactions || [],
    works: p.works || [],
    fundingAgencies: p.fundingAgencies?.length ? p.fundingAgencies : seedFundingAgencies,
    mbLines: p.mbLines || [],
    bills: p.bills || [],
    bankAccounts: p.bankAccounts?.length ? p.bankAccounts : defaultData.bankAccounts,
    bankLines: p.bankLines || [],
    pages: p.pages || [],
    workerRolls: p.workerRolls || [],
    bsrRates: p.bsrRates || [],
    itemMasters: p.itemMasters || [],
    vendors: p.vendors || [],
    holidays: p.holidays || [],
    workerRates: p.workerRates || [],
    mandayCalcs: p.mandayCalcs || [],
    auditLogs: p.auditLogs || [],
  };
}

/** D17/K.3: legacy data = sab FY ko same opening mila tha; ab har FY ka snapshot bana do */
function withOpeningsSnapshot(d: RootData): RootData {
  if (d.financialYears.every((fy) => fy.openings)) return d;
  const openings: Record<string, number> = {};
  for (const f of d.funds) openings[f.id] = f.openingBalance;
  return {
    ...d,
    financialYears: d.financialYears.map((fy) => (fy.openings ? fy : { ...fy, openings: { ...openings } })),
  };
}

/**
 * v9 #3 — पुराने pages में `date` भर दो। month-end page = उस महीने की आख़िरी तारीख़,
 * legacy पन्ने = createdAt की तारीख़। (एक पृष्ठ पर सिर्फ़ एक दिनांक।)
 */
function withPageDates(d: RootData): RootData {
  let changed = false;
  const pages = d.pages.map((p) => {
    if (p.date && isValidIsoDate(p.date)) return p;
    const raw = p.month ? monthLastDay(p.month) : (p.createdAt || '').slice(0, 10);
    changed = true;
    return { ...p, date: isValidIsoDate(raw) ? raw : '' };
  });
  return changed ? { ...d, pages } : d;
}

/** D9: har active txn ko page par assign karo (purane data migration) + stale pageId fix */
function migratePages(d: RootData): RootData {
  const txnMax = transactionLineCount(d.fySettings.lineCount);
  let pages = d.pages;
  let changed = false;
  const transactions = d.transactions.map((t) => ({ ...t }));
  for (const fy of d.financialYears) {
    let fyPages = pages.filter((p) => p.fyId === fy.id).sort((a, b) => a.pageNo - b.pageNo);
    const fyTx = transactions.filter((t) => t.fyId === fy.id);
    for (const t of fyTx) {
      if (t.pageId && !pages.some((p) => p.id === t.pageId)) {
        t.pageId = null;
        changed = true;
      }
    }
    if (!fyPages.length) {
      const np: CashbookPage = { id: uid(), fyId: fy.id, pageNo: 1, label: 'पृष्ठ 1', createdAt: new Date().toISOString() };
      pages = [...pages, np];
      fyPages = [np];
      changed = true;
    }
    const countOn = (pid: string, side: 'income' | 'expense') =>
      fyTx.filter((t) => t.pageId === pid && sideOf(t.type) === side).length;
    for (const type of ['income', 'expense', 'transfer'] as const) {
      const side = sideOf(type);
      let idx = 0;
      const unassigned = fyTx
        .filter((t) => t.type === type && !t.pageId)
        .sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt));
      for (const t of unassigned) {
        while (idx < fyPages.length && countOn(fyPages[idx].id, side) >= txnMax) idx++;
        if (idx >= fyPages.length) {
          const pageNo = fyPages.length + 1;
          const np: CashbookPage = { id: uid(), fyId: fy.id, pageNo, label: `पृष्ठ ${pageNo}`, createdAt: new Date().toISOString() };
          pages = [...pages, np];
          fyPages = [...fyPages, np];
          changed = true;
        }
        t.pageId = fyPages[idx].id;
        changed = true;
      }
    }
  }
  return changed ? { ...d, pages, transactions } : d;
}

/**
 * instruction #5 + #7 — **SFC / FFC योजना (scheme) हैं, श्रेणी (category) नहीं।**
 * इन्हें category tree से हटा दो — जो पुराने data में बने हों वे भी (साथ ही उनके
 * बच्चे और जिन entries पर ये चुने हुए थे, उनका path साफ़ कर दो — user फिर से चुनेगा)।
 */
function stripSchemeCats(d: RootData): RootData {
  const bad = new Set(
    d.categories
      .filter(
        (c) =>
          c.kind === 'income' &&
          (c.id === 'inc-sfc' || c.id === 'inc-ffc' || /^(sfc|ffc)$/i.test((c.name || '').trim()))
      )
      .map((c) => c.id)
  );
  if (!bad.size) return d;
  let grew = true;
  while (grew) {
    grew = false;
    for (const c of d.categories) {
      if (c.parentId && bad.has(c.parentId) && !bad.has(c.id)) {
        bad.add(c.id);
        grew = true;
      }
    }
  }
  return {
    ...d,
    categories: d.categories.filter((c) => !bad.has(c.id)),
    transactions: d.transactions.map((t) =>
      t.categoryId && bad.has(t.categoryId)
        ? { ...t, categoryId: null, subcategoryId: null, subSubcategoryId: null }
        : t
    ),
  };
}

export function AppStoreProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<RootData>(defaultData);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE)
      .then((raw) => {
        if (!raw) return;
        const parsed = JSON.parse(raw);
        setData(stripSchemeCats(migratePages(withPageDates(withOpeningsSnapshot(seedBsrItems(mergeRaw(parsed)))))));
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (hydrated) AsyncStorage.setItem(STORAGE, JSON.stringify(data)).catch(() => undefined);
  }, [data, hydrated]);

  const value = useMemo<Store>(() => {
    const activePanchayat = data.panchayats.find((p) => p.id === data.activePanchayatId) || data.panchayats[0];
    const activeFy = data.financialYears.find((f) => f.id === data.activeFinancialYearId) || data.financialYears[0];
    // K.3: delete = "this FY only" → disabledFunds per FY
    const activeFunds = data.funds
      .filter((f) => f.enabled && !(activeFy.disabledFunds || []).includes(f.id))
      .sort((a, b) => a.sortOrder - b.sortOrder);
    // D17: FY-wise opening snapshot
    const fundOpening = (f: Fund) =>
      activeFy.openings && f.id in activeFy.openings ? activeFy.openings[f.id] : f.openingBalance;
    // CRITICAL: FY isolation — only this FY's transactions
    const fyTransactions = data.transactions.filter((t) => t.fyId === activeFy.id);
    const fyPages = data.pages.filter((p) => p.fyId === activeFy.id).sort((a, b) => a.pageNo - b.pageNo);
    const totalOpening = activeFunds.reduce((s, f) => s + fundOpening(f), 0);
    const totalIncome = fyTransactions
      .filter((t) => t.status === 'active' && t.type === 'income')
      .reduce((s, t) => s + sumAmounts(t.amounts), 0);
    const totalExpense = fyTransactions
      .filter((t) => t.status === 'active' && t.type === 'expense')
      .reduce((s, t) => s + sumAmounts(t.amounts), 0);

    /** Part M validations — add/edit/bank-post sab yahin se guzarte hain */
    const validateTxn = (
      t: Pick<Transaction, 'type' | 'date' | 'schemeId' | 'amounts'>,
      selfId: string | null,
      opening: number
    ): string | null => {
      if (t.type === 'transfer') return null; // transfer ki apni validation
      if (!t.schemeId) return 'Scheme चुनना अनिवार्य है';
      if (!isValidIsoDate(t.date)) return `अमान्य दिनांक "${t.date}" — YYYY-MM-DD जैसे 2026-09-24`;
      if (t.date < activeFy.start || t.date > activeFy.end)
        return `दिनांक FY ${activeFy.label} (${activeFy.start} → ${activeFy.end}) के बाहर है`;
      const vals = Object.values(t.amounts || {});
      for (const v of vals) {
        if (!Number.isFinite(v)) return 'राशि अमान्य है';
        if (v < 0) return 'राशि ऋणात्मक नहीं हो सकती — अलग column me डालें';
      }
      const lineTotal = vals.reduce((s, v) => s + v, 0);
      if (lineTotal <= 0) return 'कम से कम एक राशि > 0';
      const others = fyTransactions.filter((x) => x.id !== selfId);
      if (t.type === 'expense') {
        const mahayog = dayMahayog(opening, others, t.date);
        const already = dayExpenseTotal(others, t.date);
        if (already + lineTotal > mahayog + 0.001) {
          return `व्यय इस दिन के महायोग (${formatINR(mahayog)}) से अधिक नहीं`;
        }
        if (!data.fySettings.allowSchemeNegative) {
          const fund = data.funds.find((f) => f.id === t.schemeId);
          const open = fund ? fundOpening(fund) : 0;
          const bal = schemeBalance(t.schemeId, open, others) - lineTotal;
          if (bal < -0.001) return `Scheme ${fund?.shortName || t.schemeId} minus नहीं`;
        }
      }
      return null;
    };

    /** instruction #15(b) — page label: DD-MM-YYYY */
    const dateLabel = (iso: string) => {
      const [y, m, d] = iso.split('-');
      if (!y || !m || !d) return iso;
      return `${d}-${m}-${y}`;
    };

    /**
     * v9 #3 — एक पृष्ठ पर सिर्फ़ एक ही दिनांक। पुराने month pages का दिनांक =
     * उस महीने की आख़िरी तारीख़; legacy pages का = createdAt की तारीख़।
     */
    const pageDate = (p: CashbookPage) => p.date || (p.month ? monthLastDay(p.month) : '');

    /** naya एक-दिनांक page `idx` par daalo (baaki pageNo renumber) */
    const insertDatePage = (d: RootData, idx: number, date: string, now: string) => {
      const fyPages = d.pages
        .filter((p) => p.fyId === d.activeFinancialYearId)
        .sort((a, b) => a.pageNo - b.pageNo);
      const pageNo = idx <= 0 ? 1 : (fyPages[idx - 1]?.pageNo ?? 0) + 1;
      const np: CashbookPage = {
        id: uid(),
        fyId: d.activeFinancialYearId,
        pageNo,
        label: dateLabel(date),
        createdAt: now,
        month: date.slice(0, 7),
        date,
      };
      const rest = d.pages.map((p) =>
        p.fyId === d.activeFinancialYearId && p.pageNo >= pageNo ? { ...p, pageNo: p.pageNo + 1 } : p
      );
      return { pages: [...rest, np], pageId: np.id };
    };

    /**
     * D9 + v9 #3 — txn की तारीख़ का ही पन्ना (एक पृष्ठ पर सारे दिनांक एक जैसे)।
     * उस तारीख़ का page नहीं है तो chronological जगह पर नया page बना दो।
     */
    const assignPageFor = (
      d: RootData,
      type: TxType,
      now: string,
      txnDate?: string
    ): { pages: CashbookPage[]; pageId: string } => {
      const txnMax = transactionLineCount(d.fySettings.lineCount);
      const side = sideOf(type);
      const date = (txnDate || now).slice(0, 10);
      const fyPages = d.pages
        .filter((p) => p.fyId === d.activeFinancialYearId)
        .sort((a, b) => a.pageNo - b.pageNo);
      const countOn = (pid: string) =>
        d.transactions.filter((t) => t.pageId === pid && sideOf(t.type) === side).length;

      const same = fyPages.filter((p) => pageDate(p) === date);
      for (const p of same) if (countOn(p.id) < txnMax) return { pages: d.pages, pageId: p.id };
      if (same.length) {
        const last = same[same.length - 1];
        return insertDatePage(d, fyPages.indexOf(last) + 1, date, now);
      }
      let idx = fyPages.findIndex((p) => pageDate(p) > date);
      if (idx < 0) idx = fyPages.length;
      return insertDatePage(d, idx, date, now);
    };

    return {
      ...data,
      hydrated,
      activePanchayat,
      activeFy,
      activeFunds,
      fundOpening,
      fyTransactions,
      fyPages,
      addPage: (label) =>
        setData((d) => {
          const pageNo = d.pages.filter((p) => p.fyId === d.activeFinancialYearId).length + 1;
          return {
            ...d,
            pages: [
              ...d.pages,
              { id: uid(), fyId: d.activeFinancialYearId, pageNo, label: label || `पृष्ठ ${pageNo}`, createdAt: new Date().toISOString() },
            ],
          };
        }),
      /**
       * instruction v9 #3 — month-end page **सिर्फ़ तभी** जब उस महीने की आख़िरी तारीख़
       * निकल चुकी हो। भविष्य के महीनों के pages आगे से नहीं बनते — कैशबुक खोलने पर
       * हमेशा **आज की तारीख़** वाला पन्ना ही खुलता है (ensurePageForDate)।
       */
      syncMonthlyPages: () =>
        setData((d) => {
          const fy =
            d.financialYears.find((f) => f.id === d.activeFinancialYearId) || d.financialYears[0];
          if (!fy) return d;
          const months: string[] = [];
          const [sy, sm] = fy.start.slice(0, 7).split('-').map(Number);
          const [ey, em] = fy.end.slice(0, 7).split('-').map(Number);
          let y = sy;
          let m = sm;
          while ((y < ey || (y === ey && m <= em)) && months.length < 60) {
            months.push(`${y}-${String(m).padStart(2, '0')}`);
            m += 1;
            if (m > 12) {
              m = 1;
              y += 1;
            }
          }
          const today = toIsoLocal(new Date());
          const pdate = (p: CashbookPage) => p.date || (p.month ? monthLastDay(p.month) : '');
          /* v9 #3 — आज के बाद के auto month-end pages हटा दो (वैसे पन्नों पर कोई entry नहीं होनी चाहिए) */
          const stale = d.pages.filter(
            (p) =>
              p.fyId === d.activeFinancialYearId &&
              !!p.month &&
              pdate(p) > today &&
              !d.transactions.some((t) => t.pageId === p.id)
          );
          const staleIds = new Set(stale.map((p) => p.id));
          const base = staleIds.size ? d.pages.filter((p) => !staleIds.has(p.id)) : d.pages;

          const fyPages = base.filter((p) => p.fyId === d.activeFinancialYearId);
          const have = new Set(fyPages.map((p) => p.month).filter(Boolean) as string[]);
          // सिर्फ़ वही महीना जिसकी आख़िरी तारीख़ आज से पहले निकल चुकी हो
          const missing = months.filter((mo) => !have.has(mo) && monthLastDay(mo) < today);
          if (!missing.length && !staleIds.size) return d;

          const legacy = fyPages
            .filter((p) => !p.month)
            .sort((a, b) => a.pageNo - b.pageNo)
            .map((p) => ({ ...p }));
          const withMonth = fyPages
            .filter((p) => !!p.month)
            .map((p) => ({ ...p }))
            .sort((a, b) => String(a.month).localeCompare(String(b.month)) || a.pageNo - b.pageNo);
          for (const mo of missing) {
            const lastDay = monthLastDay(mo);
            withMonth.push({
              id: uid(),
              fyId: d.activeFinancialYearId,
              pageNo: 0,
              label: dateLabel(lastDay),
              createdAt: new Date().toISOString(),
              month: mo,
              date: lastDay,
            });
          }
          const ordered = [...legacy, ...withMonth].map((p, i) => ({ ...p, pageNo: i + 1 }));
          const others = base.filter((p) => p.fyId !== d.activeFinancialYearId);
          return { ...d, pages: [...others, ...ordered] };
        }),
      /** v9 #3 — तारीख़ डालते ही दोनों विकल्प (नई entry form से) */
      pageOptionsForDate: (date) => {
        const fyPages = data.pages
          .filter((p) => p.fyId === data.activeFinancialYearId)
          .sort((a, b) => a.pageNo - b.pageNo);
        const txnMax = transactionLineCount(data.fySettings.lineCount);
        const hasOwnPage = fyPages.some((p) => pageDate(p) === date);
        let next: { pageId: string; date: string; label: string; pageNo: number } | null = null;
        for (const p of fyPages) {
          if (!(pageDate(p) > date)) continue;
          const used = data.transactions.filter((t) => t.pageId === p.id).length;
          if (used < txnMax) {
            next = { pageId: p.id, date: pageDate(p), label: p.label, pageNo: p.pageNo };
            break;
          }
        }
        return { hasOwnPage, next };
      },
      /** इस तारीख़ का पन्ना — न हो तो बना दो (कैशबुक खोलने पर आज का पन्ना) */
      ensurePageForDate: (date) => {
        if (!isValidIsoDate(date)) return null;
        const pool = data.pages
          .filter((p) => p.fyId === data.activeFinancialYearId)
          .sort((a, b) => a.pageNo - b.pageNo);
        const hit = pool.find((p) => pageDate(p) === date);
        if (hit) return hit.id;
        // कोई अन-डेटेड ख़ाली पन्ना हो तो उसी को इस तारीख़ का बना दो (पन्ना 1 जैसा)
        const empty = pool.find(
          (p) => !p.date && !data.transactions.some((t) => t.pageId === p.id)
        );
        if (empty) {
          setData((d) => ({
            ...d,
            pages: d.pages.map((p) =>
              p.id === empty.id
                ? { ...p, date, month: date.slice(0, 7), label: dateLabel(date) }
                : p
            ),
          }));
          return empty.id;
        }
        const np: CashbookPage = {
          id: uid(),
          fyId: data.activeFinancialYearId,
          pageNo: 1,
          label: dateLabel(date),
          createdAt: new Date().toISOString(),
          month: date.slice(0, 7),
          date,
        };
        setData((d) => {
          const fyPages = d.pages
            .filter((p) => p.fyId === d.activeFinancialYearId)
            .sort((a, b) => a.pageNo - b.pageNo);
          if (fyPages.some((p) => pageDate(p) === date)) return d; // कोई और बना चुका है
          const at = fyPages.findIndex((p) => pageDate(p) > date);
          const pageNo = at <= 0 ? 1 : (fyPages[at - 1]?.pageNo ?? 0) + 1;
          const rest = d.pages.map((p) =>
            p.fyId === d.activeFinancialYearId && p.pageNo >= pageNo
              ? { ...p, pageNo: p.pageNo + 1 }
              : p
          );
          return { ...d, pages: [...rest, { ...np, pageNo }] };
        });
        return np.id;
      },
      pageDateOf: (pageId) => {
        const p = pageId ? data.pages.find((x) => x.id === pageId) : null;
        if (!p) return '';
        return pageDate(p);
      },
      insertPageAfter: (pageId, label) =>
        setData((d) => {
          const idx = d.pages.findIndex((p) => p.id === pageId);
          if (idx < 0) return d;
          const after = d.pages[idx];
          const renumbered = d.pages.map((p) =>
            p.fyId === after.fyId && p.pageNo > after.pageNo ? { ...p, pageNo: p.pageNo + 1 } : p
          );
          const newPage: CashbookPage = {
            id: uid(),
            fyId: after.fyId,
            pageNo: after.pageNo + 1,
            label: label || `पृष्ठ ${after.pageNo + 1}`,
            createdAt: new Date().toISOString(),
          };
          return { ...d, pages: [...renumbered.slice(0, idx + 1), newPage, ...renumbered.slice(idx + 1)] };
        }),
      deletePage: (pageId) =>
        setData((d) => {
          const pg = d.pages.find((p) => p.id === pageId);
          if (!pg) return d;
          const rest = d.pages.filter((p) => p.id !== pageId).map((p) =>
            p.fyId === pg.fyId && p.pageNo > pg.pageNo ? { ...p, pageNo: p.pageNo - 1 } : p
          );
          return {
            ...d,
            pages: rest,
            transactions: d.transactions.map((t) => (t.pageId === pageId ? { ...t, pageId: null } : t)),
          };
        }),
      assignTxnToPage: (txnId, pageId) =>
        setData((d) => ({
          ...d,
          transactions: d.transactions.map((t) => (t.id === txnId ? { ...t, pageId } : t)),
        })),
      /* v9 #10 — id लौटाओ ताकि ManderayCalc में MR id सुरक्षित रहे */
      addWorkerRoll: async (r) => {
        const id = uid();
        setData((d) => ({ ...d, workerRolls: [...d.workerRolls, { ...r, id }] }));
        return id;
      },
      addBsrRate: async (r) => setData((d) => ({ ...d, bsrRates: [...d.bsrRates, { ...r, id: uid() }] })),
      updateBsrRate: async (id, patch) =>
        setData((d) => ({ ...d, bsrRates: d.bsrRates.map((b) => (b.id === id ? { ...b, ...patch } : b)) })),
      deleteBsrRate: async (id) => setData((d) => ({ ...d, bsrRates: d.bsrRates.filter((b) => b.id !== id) })),
      addItemMaster: async (i) => setData((d) => ({ ...d, itemMasters: [...d.itemMasters, { ...i, id: uid() }] })),
      updateItemMaster: async (id, patch) =>
        setData((d) => ({ ...d, itemMasters: d.itemMasters.map((b) => (b.id === id ? { ...b, ...patch } : b)) })),
      deleteItemMaster: async (id) => setData((d) => ({ ...d, itemMasters: d.itemMasters.filter((b) => b.id !== id) })),
      addHoliday: async (h) => setData((d) => ({ ...d, holidays: [...d.holidays, { ...h, id: uid() }] })),
      addWorkerRate: async (w) => setData((d) => ({ ...d, workerRates: [...d.workerRates, { ...w, id: uid() }] })),
      addMandayCalc: async (c) => {
        const id = uid();
        setData((d) => ({ ...d, mandayCalcs: [...d.mandayCalcs, { ...c, id, createdAt: new Date().toISOString() }] }));
        return id;
      },
      deleteMandayCalc: async (id) =>
        setData((d) => {
          /* v9 #10 — उस स्वीकृति से बने Muster Roll भी हटाओ (CC पृष्ठ 3 से) */
          const owned = d.mandayCalcs.find((c) => c.id === id)?.muster?.rolls;
          return {
            ...d,
            mandayCalcs: d.mandayCalcs.filter((c) => c.id !== id),
            /* v9 #10 — उस स्वीकृति से बने Muster Roll भी CC पृष्ठ 3 से हटाओ */
            workerRolls: d.workerRolls.filter(
              (r) => r.sourceId !== id && !(owned && owned.includes(r.id))
            ),
          };
        }),
      getTransaction: (id) => data.transactions.find((t) => t.id === id) || null,
      addTransferCashToBank: async (date, amount, bankFundId, note) => {
        // Part G: cash −, bank +; NOT income/expense; opening balance ko chhoona nahi hai
        if (!(amount > 0)) return { ok: false, error: 'राशि > 0 चाहिए' };
        if (!Number.isFinite(amount)) return { ok: false, error: 'राशि अमान्य है' };
        if (!isValidIsoDate(date)) return { ok: false, error: `अमान्य दिनांक "${date}"` };
        if (date < activeFy.start || date > activeFy.end)
          return { ok: false, error: `दिनांक FY ${activeFy.label} के बाहर है` };
        const cashFund = data.funds.find((f) => f.id === 'cash');
        if (!cashFund) return { ok: false, error: 'नकद (Cash) fund नहीं मिला' };
        if (bankFundId === 'cash') return { ok: false, error: 'बैंक fund चुनें' };
        if (!data.funds.some((f) => f.id === bankFundId)) return { ok: false, error: 'बैंक fund नहीं मिला' };
        const cashBal = schemeBalance('cash', fundOpening(cashFund), fyTransactions);
        if (!data.fySettings.allowSchemeNegative && cashBal - amount < -0.001)
          return { ok: false, error: `नकद पर्याप्त नहीं (उपलब्ध ${formatINR(cashBal)})` };
        const now = new Date().toISOString();
        const txnId = uid();
        setData((d) => {
          const { pages, pageId } = assignPageFor(d, 'transfer', now, date);
          return {
            ...d,
            pages,
            transactions: [
              ...d.transactions,
              {
                id: txnId,
                fyId: d.activeFinancialYearId,
                type: 'transfer' as const,
                date,
                pageId,
                reference: 'TRANSFER',
                ledgerFolio: '',
                party: 'नकद से बैंक जमा',
                detail: note || 'नकद → बैंक अंतरण (आय/व्यय नहीं)',
                note: note || '',
                schemeId: bankFundId,
                // signed: नकद घटेगा, बैंक बढ़ेगा — कुल net 0
                amounts: { cash: -amount, [bankFundId]: amount },
                categoryId: null,
                subcategoryId: null,
                subSubcategoryId: null,
                workId: null,
                expenseKind: null,
                status: 'active' as const,
                createdAt: now,
                updatedAt: now,
              },
            ],
            auditLogs: pushLog(d.auditLogs, {
              fyId: d.activeFinancialYearId,
              entity: 'transaction',
              entityId: txnId,
              action: 'create',
              newV: `transfer ${date} ₹${amount} cash→${bankFundId}`,
            }),
          };
        });
        return { ok: true };
      },
      exportBackupJson: () => JSON.stringify({ ...data, exportedAt: new Date().toISOString() }, null, 2),
      importBackupJson: (json) => {
        try {
          const parsed = JSON.parse(json);
          if (!parsed || typeof parsed !== 'object' || !('app' in parsed)) return { ok: false, error: 'Invalid backup' };
          // bug fix: pehle version:4 stamp hota tha aur naye fields default merge nahi hote the
          setData(stripSchemeCats(migratePages(withPageDates(withOpeningsSnapshot(seedBsrItems(mergeRaw(parsed)))))));
          return { ok: true };
        } catch (e) {
          return { ok: false, error: String(e) };
        }
      },
      totalOpening,
      totalIncome,
      totalExpense,
      currentBalance: totalOpening + totalIncome - totalExpense,
      setPin: async (pin) => setData((d) => ({ ...d, app: { ...d.app, pin, setupComplete: true } })),
      verifyPin: (pin) => !!data.app.pin && data.app.pin === pin,
      setBiometricEnabled: async (v) => setData((d) => ({ ...d, app: { ...d.app, biometricEnabled: v } })),
      updateApp: async (p) => setData((d) => ({ ...d, app: { ...d.app, ...p } })),
      updateFySettings: async (p) => setData((d) => ({ ...d, fySettings: { ...d.fySettings, ...p } })),
      setActivePanchayatId: (id) => setData((d) => ({ ...d, activePanchayatId: id })),
      setActiveFinancialYearId: (id) =>
        setData((d) => {
          const fy = d.financialYears.find((f) => f.id === id);
          if (fy && !fy.openings) {
            const openings: Record<string, number> = {};
            for (const f of d.funds) openings[f.id] = f.openingBalance;
            return {
              ...d,
              activeFinancialYearId: id,
              financialYears: d.financialYears.map((x) => (x.id === id ? { ...x, openings } : x)),
            };
          }
          return { ...d, activeFinancialYearId: id };
        }),
      addPanchayat: async (p) => {
        const id = 'gp-' + uid();
        setData((d) => ({
          ...d,
          panchayats: [...d.panchayats, { ...p, id }],
          activePanchayatId: id,
          auditLogs: pushLog(d.auditLogs, {
            fyId: d.activeFinancialYearId,
            entity: 'panchayat',
            entityId: id,
            action: 'create',
            newV: p.name,
          }),
        }));
      },
      updatePanchayat: async (id, p) =>
        setData((d) => ({ ...d, panchayats: d.panchayats.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
      deletePanchayat: async (id) => {
        if (data.panchayats.length <= 1) return { ok: false, error: 'कम से कम एक पंचायत' };
        setData((d) => {
          const panchayats = d.panchayats.filter((x) => x.id !== id);
          return {
            ...d,
            panchayats,
            activePanchayatId: d.activePanchayatId === id ? panchayats[0].id : d.activePanchayatId,
            auditLogs: pushLog(d.auditLogs, {
              fyId: d.activeFinancialYearId,
              entity: 'panchayat',
              entityId: id,
              action: 'archive',
              reason: 'user delete',
            }),
          };
        });
        return { ok: true };
      },
      addFinancialYear: async (label, start, end) => {
        if (!isValidIsoDate(start) || !isValidIsoDate(end)) return { ok: false, error: 'FY दिनांक अमान्य (YYYY-MM-DD)' };
        if (end <= start) return { ok: false, error: 'FY अंतिम दिनांक प्रारंभ से बाद होना चाहिए' };
        if (data.financialYears.some((f) => f.label === label)) return { ok: false, error: `FY ${label} पहले से है` };
        const id = 'fy-' + uid();
        setData((d) => ({
          ...d,
          financialYears: [...d.financialYears, { id, label, start, end, locked: false, openings: {}, disabledFunds: [] }],
          activeFinancialYearId: id,
          auditLogs: pushLog(d.auditLogs, { fyId: id, entity: 'fy', entityId: id, action: 'create', newV: label }),
        }));
        return { ok: true };
      },
      closeFinancialYearCarryForward: async (fromFyId, toLabel, toStart, toEnd) => {
        const fromFy = data.financialYears.find((f) => f.id === fromFyId);
        if (!fromFy) return { ok: false, error: 'FY नहीं मिली' };
        if (fromFy.locked) return { ok: false, error: 'यह FY पहले से locked है' };
        if (!isValidIsoDate(toStart) || !isValidIsoDate(toEnd)) return { ok: false, error: 'नए FY की तारीख अमान्य' };
        if (data.financialYears.some((f) => f.label === toLabel)) return { ok: false, error: `FY ${toLabel} पहले से है` };
        // D17: sirf balances carry — entries kabhi nahi
        const fromTx = data.transactions.filter((t) => t.fyId === fromFyId && t.status === 'active');
        const fromOpening = (f: Fund) =>
          fromFy.openings && f.id in fromFy.openings ? fromFy.openings[f.id] : f.openingBalance;
        const newId = 'fy-' + uid();
        setData((d) => {
          const closings: Record<string, number> = {};
          const funds = d.funds.map((f) => {
            const bal = schemeBalance(f.id, fromOpening(f), fromTx);
            closings[f.id] = bal;
            return { ...f, openingBalance: bal, openingSource: 'carry-forward' as const };
          });
          return {
            ...d,
            funds,
            financialYears: [
              ...d.financialYears.map((fy) => (fy.id === fromFyId ? { ...fy, locked: true, openings: { ...closings } } : fy)),
              { id: newId, label: toLabel, start: toStart, end: toEnd, locked: false, openings: { ...closings }, disabledFunds: [] },
            ],
            activeFinancialYearId: newId,
            auditLogs: pushLog(d.auditLogs, {
              fyId: fromFyId,
              entity: 'fy',
              entityId: fromFyId,
              action: 'lock',
              newV: `→ ${toLabel}`,
              reason: 'year close carry-forward',
            }),
          };
        });
        return { ok: true };
      },
      addFund: async (name, opening, source = 'manual') => {
        const n = name.trim();
        if (!n) return;
        const id = uid();
        setData((d) => ({
          ...d,
          funds: [
            ...d.funds,
            {
              id,
              name: n,
              shortName: n.slice(0, 10),
              openingBalance: opening,
              enabled: true,
              openingSource: source,
              sortOrder: d.funds.length,
            },
          ],
          financialYears: d.financialYears.map((fy) =>
            fy.id === d.activeFinancialYearId
              ? { ...fy, openings: { ...(fy.openings || {}), [id]: opening } }
              : fy
          ),
        }));
      },
      updateFundOpening: async (id, opening, source) =>
        setData((d) => ({
          ...d,
          funds: d.funds.map((f) =>
            f.id === id ? { ...f, openingBalance: opening, openingSource: source ?? f.openingSource } : f
          ),
          // K.3: sirf is FY ka opening badle
          financialYears: d.financialYears.map((fy) =>
            fy.id === d.activeFinancialYearId
              ? { ...fy, openings: { ...(fy.openings || {}), [id]: opening } }
              : fy
          ),
          auditLogs: pushLog(d.auditLogs, {
            fyId: d.activeFinancialYearId,
            entity: 'fund',
            entityId: id,
            action: 'update',
            field: 'openingBalance',
            newV: String(opening),
          }),
        })),
      deleteFundFy: async (id) =>
        setData((d) => ({
          ...d,
          // K.3: red delete = "this FY only" → global fund disable nahi
          financialYears: d.financialYears.map((fy) =>
            fy.id === d.activeFinancialYearId
              ? { ...fy, disabledFunds: [...new Set([...(fy.disabledFunds || []), id])] }
              : fy
          ),
          auditLogs: pushLog(d.auditLogs, {
            fyId: d.activeFinancialYearId,
            entity: 'fund',
            entityId: id,
            action: 'archive',
            reason: 'FY-wise delete',
          }),
        })),
      addCategory: async (kind, name, parentId) => {
        const n = name.trim();
        if (!n) return;
        const parent = parentId ? data.categories.find((c) => c.id === parentId) : null;
        const level = parent ? ((parent.level + 1) as 1 | 2 | 3) : 1;
        if (level > 3) return;
        setData((d) => ({
          ...d,
          categories: [...d.categories, { id: uid(), kind, name: n, parentId, level, archived: false }],
        }));
      },
      archiveCategory: async (id) =>
        setData((d) => ({
          ...d,
          categories: d.categories.map((c) => (c.id === id ? { ...c, archived: true } : c)),
        })),
      renameCategory: async (id, name) =>
        setData((d) => ({
          ...d,
          categories: d.categories.map((c) => (c.id === id ? { ...c, name } : c)),
        })),
      addTransaction: async (t) => {
        const err = validateTxn(t, null, totalOpening);
        if (err) return { ok: false as const, error: err };
        const now = new Date().toISOString();
        const txnId = uid();
        const forcedPageId = t.pageId || null;
        setData((d) => {
          /* v9 #3 — user ने कोई पन्ना चुना तो वही; वरना तारीख़ का पन्ना खुद चुनो/बनो */
          const { pages, pageId } = forcedPageId
            ? { pages: d.pages, pageId: forcedPageId }
            : assignPageFor(d, t.type, now, t.date);
          return {
            ...d,
            pages,
            transactions: [
              ...d.transactions,
              {
                ...t,
                ledgerFolio: t.ledgerFolio ?? '',
                assetPage: t.assetPage ?? '',
                id: txnId,
                pageId,
                fyId: d.activeFinancialYearId,
                status: 'active',
                createdAt: now,
                updatedAt: now,
              },
            ],
            auditLogs: pushLog(d.auditLogs, {
              fyId: d.activeFinancialYearId,
              entity: 'transaction',
              entityId: txnId,
              action: 'create',
              newV: `${t.type} ${t.date} ₹${sumAmounts(t.amounts)} ${t.party}`,
            }),
          };
        });
        return { ok: true as const };
      },
      updateTransaction: async (id, patch) => {
        const existing = data.transactions.find((t) => t.id === id);
        if (!existing) return { ok: false as const, error: 'Entry नहीं मिली' };
        if (existing.status === 'cancelled')
          return { ok: false as const, error: 'रद्द entry संपादित नहीं हो सकती — नई entry बनाएँ' };
        const merged: Transaction = { ...existing, ...patch };
        const err = validateTxn(merged, id, totalOpening);
        if (err) return { ok: false as const, error: err };
        // L.3: field-level old/new audit
        const tracked: (keyof Transaction)[] = [
          'date', 'party', 'detail', 'note', 'reference', 'ledgerFolio', 'assetPage',
          'schemeId', 'categoryId', 'subcategoryId', 'subSubcategoryId', 'amounts',
        ];
        const changes = tracked
          .filter((k) => JSON.stringify(existing[k]) !== JSON.stringify(merged[k]))
          .map((k) => ({ k, oldV: JSON.stringify(existing[k]), newV: JSON.stringify(merged[k]) }));
        setData((d) => ({
          ...d,
          transactions: d.transactions.map((t) =>
            t.id === id ? { ...t, ...patch, updatedAt: new Date().toISOString() } : t
          ),
          auditLogs: changes.reduce(
            (logs, c) =>
              pushLog(logs, {
                fyId: existing.fyId,
                entity: 'transaction',
                entityId: id,
                action: 'update',
                field: String(c.k),
                oldV: c.oldV,
                newV: c.newV,
              }),
            d.auditLogs
          ),
        }));
        return { ok: true as const };
      },
      cancelTransaction: async (id, reason) => {
        const r = (reason || '').trim();
        if (!r) return { ok: false, error: 'रद्द करने का कारण अनिवार्य है (D4)' };
        const tx = data.transactions.find((t) => t.id === id);
        if (!tx) return { ok: false, error: 'Entry नहीं मिली' };
        setData((d) => ({
          ...d,
          transactions: d.transactions.map((t) =>
            t.id === id
              ? { ...t, status: 'cancelled', cancelReason: r, updatedAt: new Date().toISOString() }
              : t
          ),
          auditLogs: pushLog(d.auditLogs, {
            fyId: tx.fyId,
            entity: 'transaction',
            entityId: id,
            action: 'cancel',
            reason: r,
          }),
        }));
        return { ok: true };
      },
      addWork: async (w) => {
        const id = uid();
        setData((d) => ({ ...d, works: [...d.works, { ...w, id }] }));
        return id;
      },
      updateWork: async (id, patch) =>
        setData((d) => ({ ...d, works: d.works.map((w) => (w.id === id ? { ...w, ...patch } : w)) })),
      /* instruction #19 — वित्त पोषण एजेंसी add / rename / delete */
      addFundingAgency: async (name) => {
        const n = name.trim();
        if (!n) return;
        setData((d) =>
          d.fundingAgencies.some((f) => f.name.toLowerCase() === n.toLowerCase())
            ? d
            : { ...d, fundingAgencies: [...d.fundingAgencies, { id: uid(), name: n }] }
        );
      },
      renameFundingAgency: async (id, name) =>
        setData((d) => ({ ...d, fundingAgencies: d.fundingAgencies.map((f) => (f.id === id ? { ...f, name } : f)) })),
      deleteFundingAgency: async (id) =>
        setData((d) => ({ ...d, fundingAgencies: d.fundingAgencies.filter((f) => f.id !== id) })),
      addMbLine: async (line) => setData((d) => ({ ...d, mbLines: [...d.mbLines, { ...line, id: uid() }] })),
      addBill: async (b) => setData((d) => ({ ...d, bills: [...d.bills, { ...b, id: uid() }] })),
      addVendor: async (v) => setData((d) => ({ ...d, vendors: [...d.vendors, { ...v, id: uid(), archived: false }] })),
      updateVendor: async (id, patch) =>
        setData((d) => ({ ...d, vendors: d.vendors.map((v) => (v.id === id ? { ...v, ...patch } : v)) })),
      deleteVendor: async (id) => {
        const name = data.vendors.find((v) => v.id === id)?.name;
        // Bill register me already use hua vendor delete = tootega → archive karo
        if (name && data.bills.some((b) => b.vendor.trim() === name.trim())) {
          setData((d) => ({ ...d, vendors: d.vendors.map((v) => (v.id === id ? { ...v, archived: true } : v)) }));
          return { ok: false, error: 'बिल में उपयोग होने के कारण vendor केवल archive हुआ (dropdown से हट जाएगा)' };
        }
        setData((d) => ({ ...d, vendors: d.vendors.filter((v) => v.id !== id) }));
        return { ok: true };
      },
      addBankLine: async (line) => setData((d) => ({ ...d, bankLines: [...d.bankLines, { ...line, id: uid() }] })),
      updateBankLine: async (id, patch) =>
        setData((d) => ({
          ...d,
          bankLines: d.bankLines.map((l) => (l.id === id ? { ...l, ...patch } : l)),
        })),
      postBankLineToCashbook: async (lineId) => {
        const line = data.bankLines.find((l) => l.id === lineId);
        if (!line || line.ignored) return { ok: false, error: 'Line invalid / ignored' };
        if (!line.schemeId) return { ok: false, error: 'Scheme tag required' };
        if (line.postedTxnId) return { ok: false, error: 'Already posted' };
        if (!(line.amount > 0)) return { ok: false, error: 'राशि > 0 चाहिए' };
        const type = line.side === 'credit' ? ('income' as const) : ('expense' as const);
        // Old-master §11.2: debit → D−1 date jab us din ka balance sufficient ho, warna statement date.
        // bug fix: UTC toISOString IST me D−2 bana deta tha + FY window check
        let postDate = line.date;
        if (type === 'expense') {
          const dMinus1 = new Date(line.date + 'T00:00:00');
          dMinus1.setDate(dMinus1.getDate() - 1);
          const cand = toIsoLocal(dMinus1);
          if (cand >= activeFy.start) {
            const candMahayog = dayMahayog(totalOpening, fyTransactions, cand);
            if (candMahayog >= Math.abs(line.amount)) postDate = cand;
          }
        }
        const draft: Transaction = {
          id: '',
          fyId: activeFy.id,
          type,
          date: postDate,
          pageId: null,
          reference: line.instrument,
          ledgerFolio: '',
          party: line.narration.slice(0, 40),
          detail: 'Bank auto-entry',
          note: `Bank ${line.statementMonth}`,
          schemeId: line.schemeId,
          amounts: { [line.schemeId]: Math.abs(line.amount) },
          categoryId: null,
          subcategoryId: null,
          subSubcategoryId: null,
          workId: line.workId,
          expenseKind: line.workId ? 'work' : 'other',
          status: 'active',
          createdAt: '',
          updatedAt: '',
        };
        // bank post ab bhi sab guards se guzarta hai (pehle bypass ho jata tha)
        const err = validateTxn(draft, null, totalOpening);
        if (err) return { ok: false, error: err };
        const now = new Date().toISOString();
        const txnId = uid();
        setData((d) => {
          const { pages, pageId } = assignPageFor(d, type, now, draft.date);
          return {
            ...d,
            pages,
            transactions: [
              ...d.transactions,
              { ...draft, id: txnId, pageId, fyId: d.activeFinancialYearId, createdAt: now, updatedAt: now },
            ],
            bankLines: d.bankLines.map((l) => (l.id === lineId ? { ...l, postedTxnId: txnId } : l)),
            auditLogs: pushLog(d.auditLogs, {
              fyId: d.activeFinancialYearId,
              entity: 'transaction',
              entityId: txnId,
              action: 'create',
              newV: `bank ${line.side} ${postDate} ₹${line.amount}`,
            }),
          };
        });
        return { ok: true };
      },
      exportCsvForFy: () => {
        const rows = [['id', 'type', 'date', 'LF', 'party', 'scheme', 'total', 'category', 'status', 'cancelReason']];
        for (const t of fyTransactions) {
          rows.push([
            t.id,
            t.type,
            t.date,
            t.ledgerFolio || '',
            t.party,
            t.schemeId,
            String(sumAmounts(t.amounts)),
            [t.categoryId, t.subcategoryId, t.subSubcategoryId].filter(Boolean).join('/'),
            t.status,
            t.cancelReason || '',
          ]);
        }
        return rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
      },
    };
  }, [data, hydrated]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useStore outside provider');
  return v;
}

export { formatINR };
