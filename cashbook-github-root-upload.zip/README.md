# Cashbook Android Starter

यह GitHub-ready starter project है। यह production-ready accounting app नहीं है; आगे database, business rules, reports, PDF/Excel export, authentication और tests implement करने होंगे।

## GitHub Actions
`.github/workflows/android.yml` workflow Android build करेगा, APK upload करेगा और failure पर पूरा diagnostic log artifact upload करेगा।
