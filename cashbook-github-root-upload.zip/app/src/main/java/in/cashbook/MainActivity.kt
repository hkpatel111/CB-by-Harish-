package in.cashbook

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { CashbookHome() } }
}

@Composable
fun CashbookHome() {
    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Cashbook") }) }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp)) {
                Text("Digital Cashbook", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(12.dp))
                Text("30-line pages • Income • Expense • Reports")
                Spacer(Modifier.height(20.dp))
                Button(onClick = {}) { Text("Open current page") }
            }
        }
    }
}
