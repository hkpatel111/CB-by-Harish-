/**
 * Gram Panchayat Cashbook — Phase 1 full UI
 * PROJECT_MASTER.md (20-09-2026 FINAL)
 */
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  Alert,
  BackHandler,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import colors from '@/constants/colors';
import { formatINR, useStore } from '@/context/AppStore';
import { ScreenBadge } from '@/components/ScreenBadge';
import {
  categoryPathLabel,
  isValidIsoDate,
  isPathIncomplete,
  pageOpenings,
  schemeBalance,
  sumAmounts,
  toIsoLocal,
  transactionLineCount,
} from '@/services/pageEngine';
import { pakhwadaWorkingDays, rateCheck, referenceRate, suggestCombos } from '@/services/mandays';
import {
  bankStatementCsv,
  buildGoswara,
  buildLedger,
  buildPrapt1,
  buildPrapt4,
  ccBuild,
  ccCsv,
  goswaraCsv,
  ledgerCsv,
  prapt1Csv,
  prapt4Csv,
  CC_INSTRUCTIONS,
} from '@/services/formats';
import type { Transaction } from '@/types/models';

const C = colors.light;

/** 8 finance logos (old doc §16.1) — Feather icons */
const LOGO_CHOICES: { id: string; icon: keyof typeof Feather.glyphMap; name: string }[] = [
  { id: 'book', icon: 'book-open', name: 'बही' },
  { id: 'rupee', icon: 'dollar-sign', name: '₹' },
  { id: 'coin', icon: 'circle', name: 'सिक्का' },
  { id: 'bank', icon: 'home', name: 'बैंक' },
  { id: 'bill', icon: 'file-text', name: 'बिल' },
  { id: 'chart', icon: 'bar-chart-2', name: 'चार्ट' },
  { id: 'wallet', icon: 'credit-card', name: 'पैसा' },
  { id: 'scroll', icon: 'layers', name: 'पंजिका' },
];

type Stage =
  | 'login'
  | 'panchayat'
  | 'appSettings'
  | 'fy'
  | 'fySettings'
  | 'home'
  | 'cashbook'
  | 'entry'
  | 'funds'
  | 'categories'
  | 'monthly'
  | 'goswara'
  | 'reports'
  | 'ledgers'
  | 'backup'
  | 'bank'
  | 'works'
  | 'workDetail'
  | 'mb'
  | 'bills'
  | 'cc'
  | 'formats'
  | 'masters'
  | 'closing';

function Btn({
  label,
  onPress,
  variant = 'primary',
  icon,
  disabled,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'soft' | 'outline' | 'danger';
  icon?: keyof typeof Feather.glyphMap;
  disabled?: boolean;
}) {
  const bg =
    variant === 'primary' ? C.primary : variant === 'danger' ? C.expenseSoft : variant === 'soft' ? C.primarySoft : 'transparent';
  const fg = variant === 'primary' ? '#fff' : variant === 'danger' ? C.expense : C.primary;
  return (
    <Pressable
      disabled={disabled}
      onPress={() => {
        Haptics.selectionAsync();
        onPress();
      }}
      style={({ pressed }) => [
        styles.btn,
        { backgroundColor: bg, borderColor: variant === 'outline' ? C.border : bg, opacity: disabled ? 0.4 : pressed ? 0.85 : 1 },
      ]}
    >
      {icon ? <Feather name={icon} size={16} color={fg} /> : null}
      <Text style={[styles.btnText, { color: fg }]}>{label}</Text>
    </Pressable>
  );
}

function IconBtn({ name, onPress }: { name: keyof typeof Feather.glyphMap; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.iconBtn}>
      <Feather name={name} size={18} color="#fff" />
    </Pressable>
  );
}

function Header({
  title,
  eyebrow,
  onBack,
  badge,
  action,
}: {
  title: string;
  eyebrow?: string;
  onBack?: () => void;
  badge?: string;
  action?: React.ReactNode;
}) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.header, { paddingTop: (Platform.OS === 'web' ? 40 : insets.top) + 6 }]}>
      <View style={styles.headerRow}>
        {onBack ? <IconBtn name="arrow-left" onPress={onBack} /> : <View style={styles.mark}><Feather name="book-open" size={16} color="#fff" /></View>}
        <View style={{ flex: 1 }}>
          {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
          <Text style={styles.hTitle}>{title}</Text>
        </View>
        {action}
        {badge ? <ScreenBadge label={badge} /> : null}
      </View>
    </View>
  );
}

function Field({
  label,
  value,
  onChangeText,
  keyboardType = 'default',
  secureTextEntry,
  multiline,
  placeholder,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  keyboardType?: 'default' | 'numeric';
  secureTextEntry?: boolean;
  multiline?: boolean;
  placeholder?: string;
}) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        multiline={multiline}
        placeholder={placeholder}
        placeholderTextColor={C.mutedForeground}
        style={[styles.field, multiline && { minHeight: 70, textAlignVertical: 'top' }]}
      />
    </View>
  );
}

function Empty({ title, why, steps }: { title: string; why: string; steps: string[] }) {
  return (
    <View style={styles.empty}>
      <Feather name="info" size={20} color={C.primary} />
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyWhy}>{why}</Text>
      {steps.map((s, i) => (
        <Text key={i} style={styles.emptyStep}>
          {i + 1}. {s}
        </Text>
      ))}
    </View>
  );
}

function PinModal({
  open,
  title,
  onCancel,
  onOk,
}: {
  open: boolean;
  title: string;
  onCancel: () => void;
  onOk: () => void;
}) {
  const { verifyPin } = useStore();
  const [pin, setPin] = useState('');
  // bug fix: cancel hone par pin field reset (warna purana PIN dikhta rehta tha)
  React.useEffect(() => {
    if (!open) setPin('');
  }, [open]);
  return (
    <Modal visible={open} transparent animationType="fade">
      <View style={styles.modalBg}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>{title}</Text>
          <Field label="Admin PIN" value={pin} onChangeText={setPin} secureTextEntry keyboardType="numeric" />
          <View style={styles.row}>
            <Btn label="Cancel" variant="outline" onPress={onCancel} />
            <Btn
              label="Confirm"
              onPress={() => {
                if (!verifyPin(pin)) {
                  Alert.alert('गलत PIN');
                  return;
                }
                setPin('');
                onOk();
              }}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* D4: रद्द करने का कारण अनिवार्य — यहीं माँगा जाता है */
function CancelModal({
  txn,
  onCancel,
  onConfirm,
}: {
  txn: Transaction;
  onCancel: () => void;
  onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState('');
  return (
    <Modal visible transparent animationType="fade">
      <View style={styles.modalBg}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>शुद्धि — कारण आवश्यक</Text>
          <Text style={styles.meta}>
            {txn.date} · {txn.party} · {formatINR(sumAmounts(txn.amounts))}
          </Text>
          <Field label="रद्द करने का कारण *" value={reason} onChangeText={setReason} multiline />
          <Text style={styles.meta}>
            Entry audit में रहेगी, totals से बाहर होगी, print में लाल strike-through दिखेगा (D4)।
          </Text>
          <View style={styles.row}>
            <Btn label="वापस" variant="outline" onPress={onCancel} />
            <Btn label="रद्द करें" variant="danger" disabled={!reason.trim()} onPress={() => onConfirm(reason)} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

/* ——— LOGIN ——— */
function LoginScreen({ onDone }: { onDone: () => void }) {
  const { app, setPin, verifyPin, updateApp } = useStore();
  const [pin, setPinLocal] = useState('');
  const [confirm, setConfirm] = useState('');
  const [err, setErr] = useState('');
  const [showLogos, setShowLogos] = useState(!app.setupComplete);

  // First-run: 8 finance logo chooser (old doc §16.1) — saved via updateApp on submit
  const [logoId, setLogoId] = useState(app.logoId || 'book');

  const submit = async () => {
    if (!app.setupComplete || !app.pin) {
      if (pin.length < 4) return setErr('PIN ≥ 4');
      if (pin !== confirm) return setErr('PIN match नहीं');
      await updateApp({ logoId });
      await setPin(pin);
      onDone();
      return;
    }
    if (!verifyPin(pin)) return setErr('गलत PIN');
    onDone();
  };

  return (
    <View style={styles.dark}>
      <StatusBar style="light" />
      <View style={styles.loginPad}>
        <Text style={styles.brand}>ADMIN · PHASE 1</Text>
        <Text style={styles.loginHi}>{!app.pin ? 'PIN सेट करें' : 'Login'}</Text>
        <Text style={styles.loginSub}>PIN + optional biometric (Settings से toggle)</Text>
        <Field label="PIN" value={pin} onChangeText={setPinLocal} secureTextEntry keyboardType="numeric" />
        {!app.pin ? <Field label="Confirm PIN" value={confirm} onChangeText={setConfirm} secureTextEntry keyboardType="numeric" /> : null}
        {err ? <Text style={styles.err}>{err}</Text> : null}
        {showLogos ? (
          <View>
            <Text style={styles.loginSub}>ऐप का चिन्ह चुनें (बाद में App Settings से बदल सकते हैं)</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {LOGO_CHOICES.map((l) => (
                <Pressable
                  key={l.id}
                  onPress={() => setLogoId(l.id)}
                  style={{
                    width: 60,
                    height: 60,
                    borderRadius: 14,
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderWidth: 2,
                    borderColor: logoId === l.id ? '#f0b429' : 'rgba(255,255,255,0.2)',
                    backgroundColor: logoId === l.id ? 'rgba(240,180,41,0.15)' : 'rgba(255,255,255,0.08)',
                  }}
                >
                  <Feather name={l.icon} size={24} color={logoId === l.id ? '#f0b429' : '#fff'} />
                  <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 9, marginTop: 2 }}>{l.name}</Text>
                </Pressable>
              ))}
            </View>
            <Btn label="चिन्ह सहेज लिया — आगे बढ़ें ✓" variant="soft" onPress={() => setShowLogos(false)} />
          </View>
        ) : null}
        <Btn label={!app.pin ? 'Save & Continue' : 'Login with PIN'} icon="log-in" onPress={submit} />
        {null}
        <ScreenBadge label="S-01" />
      </View>
    </View>
  );
}

function PanchayatScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { panchayats, activePanchayatId, setActivePanchayatId, activePanchayat } = useStore();
  return (
    <View style={styles.page}>
      <Header title="Panchayat" eyebrow="Select" onBack={onBack} badge="S-02" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>⚙ App Settings — PIN/biometric, पंचायत CRUD</Text>
        {panchayats.map((p) => (
          <Pressable key={p.id} onPress={() => setActivePanchayatId(p.id)} style={[styles.card, activePanchayatId === p.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <Text style={styles.meta}>{p.block} · {p.district}</Text>
          </Pressable>
        ))}
        <Btn label="Continue" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Active: {activePanchayat.name}</Text>
      </ScrollView>
    </View>
  );
}

function AppSettingsScreen({ onBack }: { onBack: () => void }) {
  const { app, updateApp, setBiometricEnabled, setPin, panchayats, addPanchayat, deletePanchayat, updatePanchayat } = useStore();
  const [name, setName] = useState('');
  const [block, setBlock] = useState('');
  const [dist, setDist] = useState('');
  const [newPin, setNewPin] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  const [pending, setPending] = useState<null | (() => void)>(null);

  return (
    <View style={styles.page}>
      <Header title="App Settings" onBack={onBack} badge="S-Last" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.section}>Security</Text>
        <Field label="Change PIN (new)" value={newPin} onChangeText={setNewPin} secureTextEntry keyboardType="numeric" />
        <Btn
          label="Update PIN"
          onPress={() => {
            if (newPin.length < 4) return Alert.alert('PIN ≥ 4');
            setPending(() => async () => {
              await setPin(newPin);
              setNewPin('');
              Alert.alert('PIN updated');
            });
            setPinOpen(true);
          }}
        />
        <Btn
          label="Biometric (next build)"
          variant="outline"
          onPress={() => Alert.alert('Biometric', 'Is build me PIN login stable rakhne ke liye biometric native module band hai.')}
        />
        <Btn
          label={`Screen badges: ${app.showScreenBadge ? 'ON' : 'OFF'}`}
          variant="outline"
          onPress={() => updateApp({ showScreenBadge: !app.showScreenBadge })}
        />

        <Text style={styles.section}>App logo (8 चिन्ह)</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {LOGO_CHOICES.map((l) => (
            <Pressable
              key={l.id}
              onPress={() => updateApp({ logoId: l.id })}
              style={{
                width: 52,
                height: 52,
                borderRadius: 12,
                alignItems: 'center',
                justifyContent: 'center',
                borderWidth: 2,
                borderColor: app.logoId === l.id ? C.primary : C.border,
                backgroundColor: app.logoId === l.id ? C.primarySoft : C.card,
              }}
            >
              <Feather name={l.icon} size={20} color={app.logoId === l.id ? C.primary : C.mutedForeground} />
              <Text style={{ fontSize: 8, color: C.mutedForeground, marginTop: 2 }}>{l.name}</Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.section}>Panchayat master</Text>
        <Field label="Name" value={name} onChangeText={setName} />
        <Field label="Block" value={block} onChangeText={setBlock} />
        <Field label="District" value={dist} onChangeText={setDist} />
        <Btn label="Add panchayat" icon="plus" onPress={() => name.trim() && addPanchayat({ name: name.trim(), block: block || '—', district: dist || '—' })} />
        {panchayats.map((p) => (
          <View key={p.id} style={styles.card}>
            <Text style={styles.cardTitle}>{p.name}</Text>
            <View style={styles.row}>
              <Btn
                label="Delete"
                variant="danger"
                onPress={() => {
                  setPending(() => async () => {
                    const r = await deletePanchayat(p.id);
                    if (!r.ok) Alert.alert(r.error || 'Error');
                  });
                  setPinOpen(true);
                }}
              />
            </View>
          </View>
        ))}
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm Admin PIN" onCancel={() => setPinOpen(false)} onOk={() => { setPinOpen(false); pending?.(); setPending(null); }} />
    </View>
  );
}

function FYScreen({ onContinue, onBack, onSettings }: { onContinue: () => void; onBack: () => void; onSettings: () => void }) {
  const { financialYears, activeFinancialYearId, setActiveFinancialYearId, activeFy, activePanchayat, totalOpening, totalIncome, totalExpense, currentBalance, fyTransactions } = useStore();
  return (
    <View style={styles.page}>
      <Header title="वित्तीय वर्ष" eyebrow={activePanchayat.name} onBack={onBack} badge="S-05" action={<IconBtn name="settings" onPress={onSettings} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>Entries are FY-scoped. Only balances carry to next year — not old entries.</Text>
        {financialYears.map((fy) => (
          <Pressable key={fy.id} onPress={() => setActiveFinancialYearId(fy.id)} style={[styles.card, activeFinancialYearId === fy.id && styles.cardOn]}>
            <Text style={styles.cardTitle}>{fy.label} {fy.locked ? '🔒' : ''}</Text>
            <Text style={styles.meta}>{fy.start} → {fy.end}</Text>
          </Pressable>
        ))}
        <View style={styles.stats}>
          <Stat label="Opening" v={formatINR(totalOpening)} />
          <Stat label="Income" v={formatINR(totalIncome)} />
          <Stat label="Expense" v={formatINR(totalExpense)} />
          <Stat label="Balance" v={formatINR(currentBalance)} />
          <Stat label="Txns (this FY)" v={String(fyTransactions.length)} />
        </View>
        <Btn label="FY Home" icon="arrow-right" onPress={onContinue} />
        <Text style={styles.meta}>Selected {activeFy.label}</Text>
      </ScrollView>
    </View>
  );
}

function Stat({ label, v }: { label: string; v: string }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.meta}>{label}</Text>
      <Text style={styles.cardTitle}>{v}</Text>
    </View>
  );
}

/** Next FY derive — hardcoded '2027–28' bug fix (FY hamesha current FY ke baad) */
function nextFyParts(fy: { end: string }): { label: string; start: string; end: string } {
  const endYear = parseInt(fy.end.slice(0, 4), 10) || new Date().getFullYear();
  const startY = endYear;
  const start = `${startY}-04-01`;
  const end = `${startY + 1}-03-31`;
  const label = `${startY}–${String((startY + 1) % 100).padStart(2, '0')}`;
  return { label, start, end };
}

function FYSettingsScreen({ onBack }: { onBack: () => void }) {
  const {
    fySettings,
    updateFySettings,
    activeFunds,
    addFund,
    updateFundOpening,
    deleteFundFy,
    addFinancialYear,
    closeFinancialYearCarryForward,
    activeFy,
    fundOpening,
  } = useStore();
  const [fn, setFn] = useState('');
  const [fo, setFo] = useState('0');
  const [editId, setEditId] = useState<string | null>(null);
  const [bal, setBal] = useState('');
  const [pinOpen, setPinOpen] = useState(false);
  // pending ko deliberately loose rakha hai: kuch actions Promise<void>, kuch
  // Promise<{ok,error}> return karte hain — dono chalayein
  const [pending, setPending] = useState<null | (() => unknown)>(null);
  // bug fix: controlled Field store value se render hota tha — range check reject hote hi
  // field reset ho jati thi, isliye user kabhi naya number type hi nahi kar pata tha
  const [lineInput, setLineInput] = useState(String(fySettings.lineCount));
  const lineNum = parseInt(lineInput, 10);
  const lineValid = Number.isFinite(lineNum) && lineNum >= 16 && lineNum <= 40;
  const nx = nextFyParts(activeFy);

  const runPending = async () => {
    setPinOpen(false);
    const fnToDo = pending;
    setPending(null);
    if (!fnToDo) return;
    const r: unknown = await fnToDo();
    if (r && typeof r === 'object' && 'ok' in r && !(r as { ok: boolean }).ok) {
      Alert.alert('नहीं हुआ', String((r as { error?: string }).error || '—'));
    }
  };

  return (
    <View style={styles.page}>
      <Header title="FY / Cashbook Settings" onBack={onBack} badge="S-05" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.section}>Lines (txn = L−4)</Text>
        <Field
          label="Total lines (16–40, default 25)"
          value={lineInput}
          onChangeText={(v) => {
            setLineInput(v);
            const n = parseInt(v, 10);
            if (Number.isFinite(n) && n >= 16 && n <= 40) updateFySettings({ lineCount: n });
          }}
          keyboardType="numeric"
        />
        {!lineValid ? <Text style={styles.err}>16–40 के बीच डालें — मान तभी लागू होगा</Text> : null}
        <Text style={styles.meta}>Transaction lines now: {transactionLineCount(lineValid ? lineNum : fySettings.lineCount)}</Text>
        <View style={styles.row}>
          <Btn label="Gap 1" variant={fySettings.blankLineGap === 1 ? 'primary' : 'outline'} onPress={() => updateFySettings({ blankLineGap: 1 })} />
          <Btn label="Gap 2" variant={fySettings.blankLineGap === 2 ? 'primary' : 'outline'} onPress={() => updateFySettings({ blankLineGap: 2 })} />
        </View>
        <Btn
          label={fySettings.allowSchemeNegative ? 'Scheme minus: ON' : 'Scheme minus: OFF'}
          variant="soft"
          onPress={() => updateFySettings({ allowSchemeNegative: !fySettings.allowSchemeNegative })}
        />
        <Field label="Entry colour" value={fySettings.entryFontColor} onChangeText={(v) => updateFySettings({ entryFontColor: v })} />
        <Field label="श्री पोते colour" value={fySettings.shriPoteColor} onChangeText={(v) => updateFySettings({ shriPoteColor: v })} />
        <Field label="Page bg" value={fySettings.pageBackground} onChangeText={(v) => updateFySettings({ pageBackground: v })} />

        <Text style={styles.section}>Schemes (this device book)</Text>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>
              {formatINR(fundOpening(f))} · {f.openingSource === 'carry-forward' ? '↩ CF' : '✎ Manual'} · इस FY का opening
            </Text>
            <View style={styles.row}>
              <Btn
                label="Edit opening"
                variant="outline"
                onPress={() => {
                  setEditId(f.id);
                  setBal(String(fundOpening(f)));
                }}
              />
              <Btn
                label="Delete (इस FY से)"
                variant="danger"
                onPress={() => {
                  setPending(() => () => deleteFundFy(f.id));
                  setPinOpen(true);
                }}
              />
            </View>
            {editId === f.id ? (
              <>
                <Field label="Opening balance" value={bal} onChangeText={setBal} keyboardType="numeric" />
                <Btn
                  label="Save"
                  onPress={() => {
                    updateFundOpening(f.id, parseFloat(bal) || 0, 'manual');
                    setEditId(null);
                  }}
                />
              </>
            ) : null}
          </View>
        ))}
        <Field label="New scheme" value={fn} onChangeText={setFn} />
        <Field label="Opening" value={fo} onChangeText={setFo} keyboardType="numeric" />
        <Btn label="Add scheme" icon="plus" onPress={() => { addFund(fn, parseFloat(fo) || 0, 'manual'); setFn(''); setFo('0'); }} />

        <Text style={styles.section}>New FY (empty entries)</Text>
        <Text style={styles.meta}>
          अगला FY: {nx.label} ({nx.start} → {nx.end}) — current FY {activeFy.label} से derive
        </Text>
        {/* C11 decision: FY add/lock par bhi PIN re-confirm compulsory */}
        <Btn
          label={`Add FY ${nx.label} (empty) — PIN confirm`}
          onPress={() => {
            setPending(() => () => addFinancialYear(nx.label, nx.start, nx.end));
            setPinOpen(true);
          }}
        />
        <Btn
          label={`Close current FY → carry balances only to ${nx.label} — PIN confirm`}
          variant="soft"
          onPress={() => {
            setPending(() => () => closeFinancialYearCarryForward(activeFy.id, nx.label, nx.start, nx.end));
            setPinOpen(true);
          }}
        />
      </ScrollView>
      <PinModal open={pinOpen} title="Confirm" onCancel={() => { setPinOpen(false); setPending(null); }} onOk={runPending} />
    </View>
  );
}

function HomeScreen({ go, back }: { go: (s: Stage) => void; back: () => void }) {
  const {
    activeFy, activePanchayat, currentBalance, totalIncome, totalExpense, fyTransactions,
    totalOpening, categories, bankLines,
  } = useStore();
  // J.1 — dashboard flags: incomplete category paths + untagged/open bank lines
  const incompleteCount = fyTransactions.filter(
    (t) => t.status === 'active' && (!t.schemeId || isPathIncomplete(t, categories))
  ).length;
  const openBankLines = bankLines.filter((l) => l.fyId === activeFy.id && !l.postedTxnId && !l.ignored).length;
  return (
    <View style={styles.page}>
      <Header title={`FY ${activeFy.label}`} eyebrow={activePanchayat.name} onBack={back} badge="S-06" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.stats}>
          <Stat label="Opening" v={formatINR(totalOpening)} />
          <Stat label="Balance" v={formatINR(currentBalance)} />
          <Stat label="Income" v={formatINR(totalIncome)} />
          <Stat label="Expense" v={formatINR(totalExpense)} />
          <Stat label="Entries" v={String(fyTransactions.filter((t) => t.status === 'active').length)} />
        </View>
        {incompleteCount > 0 ? (
          <Text style={[styles.err, { marginBottom: 6 }]}>
            ⚠ {incompleteCount} entries incomplete (scheme/category path missing) — Monthly check → Incomplete
          </Text>
        ) : null}
        {openBankLines > 0 ? (
          <Text style={[styles.meta, { marginBottom: 6 }]}>⚠ {openBankLines} bank lines pending tag/post</Text>
        ) : null}
        {[
          ['cashbook', 'book', 'Cashbook', '25-line Option A · dual grid'],
          ['entry', 'plus-circle', 'Add Income / Expense', 'Multi-column + scheme'],
          ['funds', 'layers', 'Fund heads', 'Opening + delete'],
          ['categories', 'git-branch', 'Categories 3-level', 'Income & expense trees'],
          ['monthly', 'check-circle', 'Monthly check', 'All txns + fix missing'],
          ['goswara', 'pie-chart', 'गोशवारा', 'Till-date auto'],
          ['ledgers', 'list', 'Ledgers', 'Auto from entries'],
          ['reports', 'bar-chart-2', 'Reports hub', 'CSV share'],
          ['bank', 'credit-card', 'Bank statement', 'Tag + post'],
          ['works', 'briefcase', 'Works / MB / Bills / CC', 'Full stack'],
          ['backup', 'hard-drive', 'Backup / Export', 'JSON + CSV'],
          ['closing', 'lock', 'FY समापन wizard', 'जाँच → गोशवारा → backup → lock'],
          ['formats', 'file-text', 'प्रपत्र / Formats Centre', 'गोशवारा, प्रपत्र-1/4, Ledger, Bank, CC'],
          ['masters', 'sliders', 'Masters (BSR/Items/Holiday/Worker)', 'दर सूची + flags'],
          // bug fix: 'closing' tile pehle DO baar tha (duplicate key + duplicate entry)
        ].map(([id, icon, title, sub]) => (
          <Pressable key={id} style={styles.homeRow} onPress={() => go(id as Stage)}>
            <View style={styles.homeIcon}><Feather name={icon as any} size={18} color={C.primary} /></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{title}</Text>
              <Text style={styles.meta}>{sub}</Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

function CashbookScreen({ back, go, onEdit }: { back: () => void; go: (s: Stage) => void; onEdit: (txnId: string) => void }) {
  const {
    fyTransactions, activeFunds, fySettings, activePanchayat, activeFy, cancelTransaction,
    exportCsvForFy, fyPages, addPage, insertPageAfter, deletePage, fundOpening,
  } = useStore();
  const [pageIdx, setPageIdx] = useState(0);
  const [cancelTxn, setCancelTxn] = useState<Transaction | null>(null);

  // +2 blank pages auto-reserve after last entry date (old master 19.4.2)
  React.useEffect(() => {
    const activeCount = fyTransactions.filter((t) => t.status === 'active').length;
    const needed = activeCount > 0 ? 2 : 1;
    if (fyPages.length < needed) {
      // bug fix: label loop-index se clash karta tha — addPage apna pageNo khud assign karta hai
      for (let i = fyPages.length; i < needed; i++) addPage();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fyTransactions.length, fyPages.length]);

  const L = fySettings.lineCount;
  const txnMax = transactionLineCount(L);
  const gap = fySettings.blankLineGap;

  const safeIdx = Math.min(pageIdx, Math.max(0, fyPages.length - 1));
  const curPage = fyPages[safeIdx] || null;
  const isLastPage = safeIdx >= fyPages.length - 1;

  const sortTx = (a: Transaction, b: Transaction) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt);
  const sideOfTx = (t: Transaction) => (t.type === 'transfer' ? 'expense' : t.type);

  /**
   * C.3/C.7 — इस page के दोनों zones:
   * assigned txn अपने page पर; unassigned last page पर (legacy fallback).
   * Cancelled txns भी line घेरते हैं (print पर लाल strike) — totals से बाहर रहते हैं.
   * D1/C.8 — blankLineGap 2 = हर entry के बाद 1 खाली line.
   */
  const zoneFor = (side: 'income' | 'expense'): (Transaction | null)[] => {
    const list = fyTransactions
      .filter((t) => {
        if (sideOfTx(t) !== side) return false;
        if (t.pageId) return t.pageId === curPage?.id;
        return isLastPage;
      })
      .sort(sortTx);
    const zone: (Transaction | null)[] = [];
    for (const t of list) {
      if (zone.length >= txnMax) break;
      zone.push(t);
      if (gap === 2 && zone.length < txnMax) zone.push(null);
    }
    while (zone.length < txnMax) zone.push(null);
    return zone;
  };

  const zoneInc = zoneFor('income');
  const zoneExp = zoneFor('expense');
  const activeInc = zoneInc.filter((t): t is Transaction => !!t && t.status === 'active');
  const activeExp = zoneExp.filter((t): t is Transaction => !!t && t.status === 'active');

  const fundIds = activeFunds.map((f) => f.id);

  // C.6 — इस page का श्री पोते = पिछले page की बचत पोते (page 1 = FY opening) + D17 CF/Manual
  const openingByFund = pageOpenings(
    activeFunds.map((f) => ({ id: f.id, openingBalance: fundOpening(f) })),
    fyPages,
    fyTransactions,
    safeIdx
  );
  const prevLastDate =
    safeIdx <= 0
      ? activeFy.start
      : (() => {
          const prev = fyPages[safeIdx - 1];
          const tx = fyTransactions.filter((t) => t.pageId === prev.id && t.status === 'active').sort(sortTx);
          return tx.length ? tx[tx.length - 1].date : '';
        })();
  const cfLabel =
    safeIdx > 0
      ? 'Carry-forward — पिछले पृष्ठ की बचत पोते'
      : activeFunds.some((f) => f.openingSource === 'carry-forward')
        ? 'Carry-forward — पिछले FY की समापन शेष'
        : 'Manual — हाथ से भरा';

  // C.5 — हर amount column के लिए नीचे के 3 row
  const aay: Record<string, number> = {};
  const vyay: Record<string, number> = {};
  for (const f of fundIds) {
    aay[f] = activeInc.reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
    vyay[f] = activeExp.reduce((s, t) => s + (Number(t.amounts[f]) || 0), 0);
  }
  const shriOf = (f: string) => openingByFund[f] || 0;
  const aayOf = (f: string) => aay[f] || 0;
  const vyayOf = (f: string) => vyay[f] || 0;
  const mahayogLOf = (f: string) => shriOf(f) + aayOf(f);
  const bachatOf = (f: string) => mahayogLOf(f) - vyayOf(f);
  const mahayogROf = (f: string) => vyayOf(f) + bachatOf(f);

  /* ── C.3 column layout — fixed text columns + रकम group (dynamic funds + कुल) ── */
  type Col = { key: string; label: string; w: number };
  const amtCols: Col[] = [
    ...activeFunds.map((f) => ({ key: f.id, label: f.shortName, w: 64 })),
    { key: '_tot', label: 'कुल', w: 70 },
  ];
  const leftCols: Col[] = [
    { key: 'date', label: 'दिनांक', w: 54 },
    { key: 'ref', label: 'चेक, DD, इन्वॉइस न. व दिनांक', w: 76 },
    { key: 'party', label: 'किस से प्राप्त किया', w: 90 },
    { key: 'detail', label: 'विवरण', w: 84 },
    { key: 'lf', label: 'L.F.', w: 26 },
  ];
  const rightCols: Col[] = [
    { key: 'date', label: 'दिनांक', w: 54 },
    { key: 'ref', label: 'वाउचर नं. व दिनांक', w: 76 },
    { key: 'party', label: 'भुगतान किसको किया गया', w: 94 },
    { key: 'detail', label: 'किस कार्य पेटे भुगतान', w: 88 },
    { key: 'lf', label: 'L.F.', w: 26 },
    { key: 'asset', label: 'परि. रजि. पृ.', w: 40 },
  ];

  type RowKind = 'shri' | 'txn' | 'aayYog' | 'poorvPote' | 'mahayogL' | 'vyayYog' | 'bachat' | 'mahayogR';

  const kindBg = (kind: string) =>
    kind === 'shri'
      ? 'rgba(198,40,40,0.06)'
      : ['aayYog', 'poorvPote', 'mahayogL', 'vyayYog', 'bachat', 'mahayogR'].includes(kind)
        ? 'rgba(27,94,32,0.08)'
        : undefined;
  const kindColor = (kind: string) => {
    if (kind === 'shri' || kind === 'poorvPote') return fySettings.shriPoteColor;
    if (['aayYog', 'vyayYog', 'bachat', 'mahayogL', 'mahayogR'].includes(kind)) return fySettings.summaryFontColor;
    if (kind === 'txn') return fySettings.entryFontColor;
    return C.mutedForeground;
  };

  const cell = (
    k: string,
    w: number,
    text: string,
    o: { bold?: boolean; right?: boolean; color?: string; bg?: string; strike?: boolean; lines?: number; sub?: string } = {}
  ) => (
    <View
      key={k}
      style={{
        width: w,
        borderRightWidth: StyleSheet.hairlineWidth,
        borderRightColor: '#a9c6b2',
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: '#a9c6b2',
        paddingHorizontal: 3,
        paddingVertical: 2,
        justifyContent: 'center',
        backgroundColor: o.bg,
      }}
    >
      <Text
        numberOfLines={o.lines ?? 1}
        style={{
          fontSize: 9,
          fontWeight: o.bold ? '800' : '600',
          color: o.color || C.foreground,
          textAlign: o.right ? 'right' : 'left',
          textDecorationLine: o.strike ? 'line-through' : undefined,
        }}
      >
        {text}
      </Text>
      {o.sub ? (
        <Text
          numberOfLines={1}
          style={{
            fontSize: 8,
            color: o.color || C.mutedForeground,
            textDecorationLine: o.strike ? 'line-through' : undefined,
          }}
        >
          {o.sub}
        </Text>
      ) : null}
    </View>
  );

  const amtCells = (k: string, get: (f: string) => number, kind: string, showZero: boolean) => {
    const wOf = (id: string) => (amtCols.find((c) => c.key === id) || { w: 70 }).w;
    const mk = (id: string) => {
      const v = id === '_tot' ? fundIds.reduce((s, f) => s + get(f), 0) : get(id);
      const txt = v === 0 && !showZero ? '' : formatINR(v);
      return cell(`${k}-${id}`, wOf(id), txt, {
        right: true,
        bold: kind !== 'txn',
        color: kind === 'txn' ? fySettings.entryFontColor : kindColor(kind),
        bg: kindBg(kind),
      });
    };
    return [...fundIds.map(mk), mk('_tot')];
  };

  const txnTextCell = (c: Col, t: Transaction, i: number) => {
    const cancelled = t.status === 'cancelled';
    const val =
      c.key === 'date'
        ? t.date
        : c.key === 'ref'
          ? t.reference || ''
          : c.key === 'party'
            ? t.type === 'transfer'
              ? `⇄ ${t.party}`
              : t.party
            : c.key === 'detail'
              ? t.detail || ''
              : c.key === 'lf'
                ? t.ledgerFolio || ''
                : c.key === 'asset'
                  ? t.assetPage || ''
                  : '';
    return cell(`t${i}-${c.key}`, c.w, val, {
      color: cancelled ? C.expense : fySettings.entryFontColor,
      strike: cancelled,
      sub: cancelled ? `रद्द: ${t.cancelReason || '—'}` : undefined,
    });
  };

  const onTxnAction = (t: Transaction) => {
    if (t.status === 'cancelled') {
      Alert.alert(
        'रद्द शुद्धि',
        `${t.date} · ${t.party}\n${formatINR(sumAmounts(t.amounts))}\nकारण: ${t.cancelReason || '—'}`,
        [{ text: 'ठीक है' }]
      );
      return;
    }
    Alert.alert('शुद्धि', `${t.date} · ${t.party}\n${formatINR(sumAmounts(t.amounts))}`, [
      { text: 'बंद', style: 'cancel' },
      { text: 'सुधारें (Edit)', onPress: () => onEdit(t.id) },
      { text: 'रद्द करें…', style: 'destructive', onPress: () => setCancelTxn(t) },
    ]);
  };

  /** C.3/C.7 — Excel-register style table: line# + text cols + रकम group */
  const renderTable = (side: 'L' | 'R') => {
    const textCols = side === 'L' ? leftCols : rightCols;
    const zone = side === 'L' ? zoneInc : zoneExp;
    const totalTextW = 16 + textCols.reduce((s, c) => s + c.w, 0);
    const totalAmtW = amtCols.reduce((s, c) => s + c.w, 0);

    type FRow = { line: number; kind: RowKind; label: string; get: (f: string) => number };
    const footers: FRow[] =
      side === 'L'
        ? [
            { line: L - 2, kind: 'aayYog', label: 'आय योग', get: aayOf },
            { line: L - 1, kind: 'poorvPote', label: 'पूर्व पोते', get: shriOf },
            { line: L, kind: 'mahayogL', label: 'महायोग', get: mahayogLOf },
          ]
        : [
            { line: L - 2, kind: 'vyayYog', label: 'व्यय योग', get: vyayOf },
            { line: L - 1, kind: 'bachat', label: 'बचत पोते', get: bachatOf },
            { line: L, kind: 'mahayogR', label: 'महायोग', get: mahayogROf },
          ];

    return (
      <View style={{ flex: 1, borderRightWidth: side === 'L' ? 2 : 0, borderRightColor: '#1e6048' }}>
        <View style={{ backgroundColor: side === 'L' ? '#1e6048' : '#3d5a4a', paddingVertical: 5, paddingHorizontal: 4 }}>
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: 11, textAlign: 'center' }}>
            {side === 'L' ? 'प्राप्ति (आय)' : 'भुगतान (व्यय)'}
          </Text>
        </View>

        {/* header row 1 — रकम group spans amount columns */}
        <View style={{ flexDirection: 'row', backgroundColor: '#dceee4' }}>
          {cell('h1-span', totalTextW, '', { bold: true })}
          {cell('h1-amt', totalAmtW, 'रकम (₹)', { bold: true, right: true })}
        </View>
        {/* header row 2 — column labels */}
        <View style={{ flexDirection: 'row', backgroundColor: '#eaf5ec' }}>
          {cell('h2-line', 16, '#', { bold: true, lines: 2 })}
          {textCols.map((c) => cell(`h2-${c.key}`, c.w, c.label, { bold: true, lines: 3 }))}
          {amtCols.map((c) => cell(`h2a-${c.key}`, c.w, c.label, { bold: true, right: true, lines: 2 }))}
        </View>

        {/* line 1 — श्री पोते राशि (प्राप्ति side) / खाली (भुगतान side) */}
        <View style={{ flexDirection: 'row' }}>
          {cell('s-line', 16, '1', { bold: true, color: '#78909c', bg: kindBg('shri') })}
          {textCols.map((c) =>
            side === 'L' && c.key === 'party'
              ? cell('s-party', c.w, 'श्री पोते राशि', {
                  bold: true,
                  color: fySettings.shriPoteColor,
                  bg: kindBg('shri'),
                  sub: cfLabel,
                  lines: 2,
                })
              : cell(`s-${c.key}`, c.w, side === 'L' && c.key === 'date' ? prevLastDate : '', { bg: kindBg('shri') })
          )}
          {side === 'L' ? amtCells('s', shriOf, 'shri', true) : amtCells('s', () => 0, 'txn', false)}
        </View>

        {/* txn zone (D3: txnMax lines; blank cell tap = नई entry) */}
        {zone.map((t, i) => {
          const lineNo = i + 2;
          const key = `z${side}-${i}`;
          if (!t) {
            return (
              <Pressable key={key} onPress={() => go('entry')} style={{ flexDirection: 'row' }}>
                {cell('bl', 16, String(lineNo), { color: '#78909c' })}
                {textCols.map((c) => cell(`bt-${c.key}`, c.w, ''))}
                {amtCols.map((c) => cell(`ba-${c.key}`, c.w, ''))}
              </Pressable>
            );
          }
          const cancelled = t.status === 'cancelled';
          return (
            <Pressable
              key={key}
              onLongPress={() => onTxnAction(t)}
              style={{ flexDirection: 'row', backgroundColor: cancelled ? 'rgba(163,78,70,0.07)' : undefined }}
            >
              {cell('tl', 16, String(lineNo), { color: '#78909c' })}
              {textCols.map((c) => txnTextCell(c, t, i))}
              {amtCells(`t${i}`, (f) => Number(t.amounts[f]) || 0, 'txn', false)}
            </Pressable>
          );
        })}

        {/* bottom 3 rows — C.5 formulas per column */}
        {footers.map((fr) => (
          <View key={`f-${fr.kind}`} style={{ flexDirection: 'row', backgroundColor: kindBg(fr.kind) }}>
            {cell('fl', 16, String(fr.line), { bold: true, color: '#78909c', bg: kindBg(fr.kind) })}
            {textCols.map((c) =>
              c.key === 'party'
                ? cell(`fp-${fr.kind}`, c.w, fr.label, {
                    bold: true,
                    color: kindColor(fr.kind),
                    bg: kindBg(fr.kind),
                    lines: 2,
                  })
                : cell(`ft-${fr.kind}-${c.key}`, c.w, '', { bg: kindBg(fr.kind) })
            )}
            {amtCells(`f${fr.kind}`, fr.get, fr.kind, true)}
          </View>
        ))}
      </View>
    );
  };

  return (
    <View style={[styles.page, { backgroundColor: fySettings.pageBackground }]}>
      <Header
        title="Cashbook"
        eyebrow={`${activePanchayat.name} · ${activeFy.label} · पृष्ठ ${curPage ? curPage.pageNo : '—'}`}
        onBack={back}
        badge="S-07"
        action={
          <IconBtn
            name="share-2"
            onPress={async () => {
              const csv = exportCsvForFy();
              await Share.share({ message: csv, title: 'Cashbook CSV' });
            }}
          />
        }
      />
      {/* Page navigator — Excel-style manual pagination (user request #1) */}
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 6, backgroundColor: '#0e3d2e' }}>
        <Pressable
          onPress={() => setPageIdx(Math.max(0, safeIdx - 1))}
          style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>◀</Text>
        </Pressable>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 12, flex: 1, textAlign: 'center' }}>
          {curPage ? `${curPage.label} · ${safeIdx + 1}/${fyPages.length}` : 'कोई page नहीं'}
        </Text>
        <Pressable
          onPress={() => setPageIdx(Math.min(fyPages.length - 1, safeIdx + 1))}
          style={{ paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8, backgroundColor: 'rgba(255,255,255,0.15)' }}
        >
          <Text style={{ color: '#fff', fontWeight: '800' }}>▶</Text>
        </Pressable>
        <Pressable
          onPress={() =>
            Alert.alert('Page', 'क्या करना है?', [
              { text: 'अगला page जोड़ें', onPress: () => addPage() },
              { text: 'इस page के बाद insert', onPress: () => curPage && insertPageAfter(curPage.id) },
              { text: 'इस page को हटाएँ', style: 'destructive', onPress: () => curPage && deletePage(curPage.id) },
              { text: 'रद्द', style: 'cancel' },
            ])
          }
          style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, backgroundColor: '#f0b429' }}
        >
          <Text style={{ color: '#123b2c', fontWeight: '800', fontSize: 12 }}>+ Page</Text>
        </Pressable>
      </View>
      <ScrollView horizontal contentContainerStyle={{ minWidth: '100%' }}>
        <ScrollView contentContainerStyle={{ padding: 8, paddingBottom: 40, minWidth: 420 }}>
          <Text style={styles.hint}>
            {L} lines · txn lines {txnMax} · C.3 dual grid: दिनांक / चेक / विवरण / L.F. + नकद व बैंक columns · bottom-3 auto (C.5)
          </Text>
          <View style={styles.row}>
            <Btn label="+ Entry" icon="plus" onPress={() => go('entry')} />
          </View>

          {/* Fund strip — current balance + CF/Manual indicator (D17) */}
          <ScrollView horizontal style={{ marginBottom: 6 }}>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              {activeFunds.map((f) => (
                <View
                  key={f.id}
                  style={{
                    backgroundColor: '#fff',
                    borderWidth: 1,
                    borderColor: '#c9dfca',
                    borderRadius: 8,
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                  }}
                >
                  <Text style={{ fontSize: 10, fontWeight: '800', color: fySettings.shriPoteColor }}>
                    {f.shortName} {f.openingSource === 'carry-forward' ? '↩CF' : '✎'}
                  </Text>
                  <Text style={{ fontSize: 10, color: C.foreground }}>
                    {formatINR(schemeBalance(f.id, fundOpening(f), fyTransactions))}
                  </Text>
                </View>
              ))}
            </View>
          </ScrollView>

          {/* Dual page — side-by-side प्राप्ति | भुगतान grid (C.7) */}
          <View
            style={{
              flexDirection: 'row',
              backgroundColor: '#f3faf3',
              borderWidth: 2,
              borderColor: '#1e6048',
              minHeight: 400,
            }}
          >
            {renderTable('L')}
            {renderTable('R')}
          </View>

          <Text style={[styles.meta, { marginTop: 8 }]}>
            Long-press = सुधार/रद्द · खाली cell tap = नई entry · Summary lines auto · Page {safeIdx + 1}/{fyPages.length} · + Page (Excel जैसा, बीच में भी insert)
          </Text>
        </ScrollView>
      </ScrollView>
      {cancelTxn ? (
        <CancelModal
          txn={cancelTxn}
          onCancel={() => setCancelTxn(null)}
          onConfirm={async (reason) => {
            const r = await cancelTransaction(cancelTxn.id, reason);
            setCancelTxn(null);
            if (!r.ok) Alert.alert(r.error || 'रद्द नहीं हुआ');
          }}
        />
      ) : null}
    </View>
  );
}

function EntryScreen({ back, editTxnId, onClearEdit }: { back: () => void; editTxnId?: string | null; onClearEdit?: () => void }) {
  const {
    activeFunds, addTransaction, updateTransaction, categories, fyTransactions, addTransferCashToBank,
    activeFy, getTransaction,
  } = useStore();
  const editTxn = editTxnId ? getTransaction(editTxnId) : null;
  const [type, setType] = useState<'income' | 'expense'>(editTxn ? (editTxn.type === 'expense' ? 'expense' : 'income') : 'income');
  const [date, setDate] = useState(editTxn?.date || toIsoLocal(new Date()));
  const [party, setParty] = useState(editTxn?.party || '');
  const [detail, setDetail] = useState(editTxn?.detail || '');
  const [note, setNote] = useState(editTxn?.note || '');
  const [schemeId, setSchemeId] = useState(editTxn?.schemeId || 'sfc');
  const [amounts, setAmounts] = useState<Record<string, string>>(() => {
    if (!editTxn) return {};
    const a: Record<string, string> = {};
    for (const k of Object.keys(editTxn.amounts)) a[k] = String(editTxn.amounts[k]);
    return a;
  });
  const [cat1, setCat1] = useState<string | null>(editTxn?.categoryId || null);
  const [cat2, setCat2] = useState<string | null>(editTxn?.subcategoryId || null);
  const [cat3, setCat3] = useState<string | null>(editTxn?.subSubcategoryId || null);
  const [assetPage, setAssetPage] = useState(editTxn?.assetPage || '');
  const [ledgerFolio, setLedgerFolio] = useState(editTxn?.ledgerFolio || '');
  const [reference, setReference] = useState(editTxn?.reference || '');
  const [bankFundId, setBankFundId] = useState(() => {
    const first = activeFunds.find((f) => f.id !== 'cash');
    return first ? first.id : 'sfc';
  });
  const [err, setErr] = useState('');
  const roots = categories.filter((c) => c.kind === type && c.level === 1 && !c.archived);
  const categoryNames: Record<string, string> = {};
  for (const c of categories) categoryNames[c.id] = c.name;
  // E: cascading L2/L3 chips
  const level2 = categories.filter((c) => c.parentId === cat1 && !c.archived);
  const level3 = categories.filter((c) => c.parentId === cat2 && !c.archived);

  // switching type invalidates non-applicable path
  React.useEffect(() => {
    setCat2(null);
    setCat3(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type]);

  const parseAmounts = (): { am: Record<string, number> } | { error: string } => {
    const am: Record<string, number> = {};
    for (const f of activeFunds) {
      const raw = (amounts[f.id] || '').trim();
      if (!raw) continue;
      const n = Number(raw);
      if (!Number.isFinite(n)) return { error: `${f.shortName}: \"${raw}\" अमान्य राशि है (सिर्फ़ अंक)` };
      if (n < 0) return { error: `${f.shortName}: राशि ऋणात्मक नहीं हो सकती` };
      if (n > 0) am[f.id] = n;
    }
    return { am };
  };

  const save = async () => {
    const parsed = parseAmounts();
    if ('error' in parsed) return setErr(parsed.error);
    const am = parsed.am;
    setErr('');

    // Part M duplicate voucher warning — save से पहले पुष्टि
    const dup = fyTransactions.find(
      (t) =>
        t.id !== editTxnId &&
        t.status === 'active' &&
        t.type === type &&
        reference.trim() &&
        t.reference === reference.trim()
    );
    const doSave = async () => {
      if (editTxnId) {
        const r = await updateTransaction(editTxnId, {
          type,
          date,
          reference: reference.trim(),
          ledgerFolio: ledgerFolio.trim(),
          party: party.trim(),
          detail: detail.trim(),
          note: note.trim(),
          schemeId,
          amounts: am,
          categoryId: cat1,
          subcategoryId: cat2,
          subSubcategoryId: cat3,
          assetPage: assetPage.trim(),
        });
        if (!r.ok) return setErr(r.error);
        onClearEdit?.();
        return back();
      }
      const r = await addTransaction({
        type,
        date,
        reference: reference.trim(),
        ledgerFolio: ledgerFolio.trim(),
        party: party.trim(),
        detail: detail.trim(),
        note: note.trim(),
        schemeId,
        amounts: am,
        categoryId: cat1,
        subcategoryId: cat2,
        subSubcategoryId: cat3,
        assetPage: assetPage.trim(),
        workId: null,
        expenseKind: type === 'expense' ? 'other' : null,
      });
      if (!r.ok) return setErr(r.error);
      back();
    };

    if (dup) {
      Alert.alert(
        'संभावित दोहरा वाउचर',
        `वाउचर/रसीद \"${dup.reference}\" पहले से है:\n${dup.date} · ${dup.party} · ${formatINR(
          Object.values(dup.amounts).reduce((s, v) => s + v, 0)
        )}\n\nफिर भी सहेजना है?`,
        [
          { text: 'वापस', style: 'cancel' },
          { text: 'हाँ, सहेजें', onPress: doSave },
        ]
      );
      return;
    }
    await doSave();
  };

  const close = () => {
    onClearEdit?.();
    back();
  };

  return (
    <View style={styles.page}>
      <Header title={editTxn ? 'Entry — सुधार' : 'Add entry'} onBack={close} badge={type === 'income' ? 'S-08' : 'S-09'} />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="Income" variant={type === 'income' ? 'primary' : 'outline'} onPress={() => setType('income')} />
          <Btn label="Expense" variant={type === 'expense' ? 'danger' : 'outline'} onPress={() => setType('expense')} />
        </View>
        <Text style={styles.hint}>
          Scheme required (default SFC) · multi-column amounts · तारीख FY ({activeFy.start} → {activeFy.end}) के भीतर
        </Text>
        <Btn
          label="⧉ पिछली entry से copy (repeat template)"
          variant="soft"
          onPress={() => {
            const last = fyTransactions.filter((t) => t.type === type && t.status === 'active').slice(-1)[0];
            if (!last) return Alert.alert('कोई पिछली entry नहीं', 'पहले एक entry बनाएँ');
            setParty(last.party);
            setDetail(last.detail);
            setNote(last.note);
            setSchemeId(last.schemeId);
            const am: Record<string, string> = {};
            for (const f of activeFunds) am[f.id] = last.amounts[f.id] ? String(last.amounts[f.id]) : '';
            setAmounts(am);
            setCat1(last.categoryId);
            setCat2(last.subcategoryId);
            setCat3(last.subSubcategoryId);
            setReference('');
            Alert.alert('Copy हो गया', 'दिनांक/राशि जाँच कर Save करें');
          }}
        />
        <Btn
          label="⇄ नकद से बैंक जमा (transfer — आय/व्यय नहीं)"
          variant="outline"
          onPress={() => {
            const total = Number((amounts['cash'] || '').trim());
            const bankFund = activeFunds.find((f) => f.id === bankFundId);
            if (!Number.isFinite(total) || !(total > 0)) return Alert.alert('नकद (Cash) column में राशि डालें');
            if (!isValidIsoDate(date)) return Alert.alert('अमान्य दिनांक', 'YYYY-MM-DD जैसे 2026-09-24 भरें');
            if (!bankFund) return Alert.alert('कोई बैंक fund नहीं');
            Alert.alert('नकद → बैंक जमा', `₹${total} को ${bankFund.shortName} में जमा करें?\n(नकद घटेगा, बैंक बढ़ेगा — आय/व्यय नहीं)`, [
              { text: 'नहीं', style: 'cancel' },
              {
                text: 'जमा करें',
                onPress: async () => {
                  const r = await addTransferCashToBank(date, total, bankFund.id, note || detail);
                  if (r.ok) close();
                  else Alert.alert(r.error || 'Fail');
                },
              },
            ]);
          }}
        />
        <Text style={styles.section}>बैंक fund (transfer destination)</Text>
        <View style={styles.chips}>
          {activeFunds
            .filter((f) => f.id !== 'cash')
            .map((f) => (
              <Pressable key={f.id} onPress={() => setBankFundId(f.id)} style={[styles.chip, bankFundId === f.id && styles.chipOn]}>
                <Text style={{ color: bankFundId === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
              </Pressable>
            ))}
        </View>
        <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} />
        {!isValidIsoDate(date) ? <Text style={styles.err}>तारीख format अमान्य — जैसे 2026-09-24</Text> : null}
        <Field label={type === 'income' ? 'किससे प्राप्त' : 'किसको भुगतान'} value={party} onChangeText={setParty} />
        <Field label="Detail" value={detail} onChangeText={setDetail} />
        <Field
          label={type === 'income' ? 'रसीद/चेक क्रमांक' : 'वाउचर/चेक क्रमांक'}
          value={reference}
          onChangeText={setReference}
        />
        <Field
          label="L.F. (Ledger Folio — ledger से cross-verify होगा)"
          value={ledgerFolio}
          onChangeText={setLedgerFolio}
          placeholder="जैसे 12"
        />
        <Field label="Note" value={note} onChangeText={setNote} multiline />
        <Text style={styles.section}>Scheme *</Text>
        <View style={styles.chips}>
          {activeFunds.map((f) => (
            <Pressable key={f.id} onPress={() => setSchemeId(f.id)} style={[styles.chip, schemeId === f.id && styles.chipOn]}>
              <Text style={{ color: schemeId === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={styles.section}>Amounts by fund</Text>
        {activeFunds.map((f) => (
          <Field
            key={f.id}
            label={f.shortName}
            value={amounts[f.id] || ''}
            onChangeText={(v) => setAmounts((a) => ({ ...a, [f.id]: v }))}
            keyboardType="numeric"
          />
        ))}
        {type === 'expense' ? (
          <Field
            label="परिसंपत्ति रजिस्टर पृष्ठ संख्या (C.3.2)"
            value={assetPage}
            onChangeText={setAssetPage}
            placeholder="जैसे 4"
          />
        ) : null}
        <Text style={styles.section}>Category path (L1 → L2 → L3)</Text>
        <View style={styles.chips}>
          {roots.map((c) => (
            <Pressable key={c.id} onPress={() => { setCat1(c.id); setCat2(null); setCat3(null); }} style={[styles.chip, cat1 === c.id && styles.chipOn]}>
              <Text style={{ color: cat1 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
            </Pressable>
          ))}
        </View>
        {level2.length ? (
          <View style={styles.chips}>
            {level2.map((c) => (
              <Pressable key={c.id} onPress={() => { setCat2(c.id); setCat3(null); }} style={[styles.chip, cat2 === c.id && styles.chipOn]}>
                <Text style={{ color: cat2 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}
        {level3.length ? (
          <View style={styles.chips}>
            {level3.map((c) => (
              <Pressable key={c.id} onPress={() => setCat3(c.id)} style={[styles.chip, cat3 === c.id && styles.chipOn]}>
                <Text style={{ color: cat3 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}
        {cat1 ? (
          <Text style={styles.meta}>
            Path: {categoryPathLabel({ categoryId: cat1, subcategoryId: cat2, subSubcategoryId: cat3 }, categoryNames)}
          </Text>
        ) : null}
        {err ? <Text style={styles.err}>{err}</Text> : null}
        <Btn label={editTxn ? 'सुधार सहेजें' : 'Save'} icon="check" onPress={save} />
        {editTxn ? <Btn label="रद्द करें" variant="outline" onPress={close} /> : null}
      </ScrollView>
    </View>
  );
}

function CategoriesScreen({ back }: { back: () => void }) {
  const { categories, addCategory, archiveCategory, renameCategory } = useStore();
  const [kind, setKind] = useState<'income' | 'expense'>('income');
  const [name, setName] = useState('');
  const [parentId, setParentId] = useState<string | null>(null);
  const list = categories.filter((c) => c.kind === kind && !c.archived);

  return (
    <View style={styles.page}>
      <Header title="Categories" onBack={back} badge="S-Cat" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="Income tree" variant={kind === 'income' ? 'primary' : 'outline'} onPress={() => setKind('income')} />
          <Btn label="Expense tree" variant={kind === 'expense' ? 'primary' : 'outline'} onPress={() => setKind('expense')} />
        </View>
        {list.map((c) => (
          <View key={c.id} style={styles.card}>
            <Text style={styles.cardTitle}>{'  '.repeat(c.level - 1)}{c.name} <Text style={styles.meta}>L{c.level}</Text></Text>
            <View style={styles.row}>
              <Btn label="Add child" variant="outline" onPress={() => setParentId(c.id)} />
              <Btn label="Archive" variant="danger" onPress={() => archiveCategory(c.id)} />
            </View>
          </View>
        ))}
        <Field label="New name" value={name} onChangeText={setName} />
        <Text style={styles.meta}>Parent: {parentId || 'root (level 1)'}</Text>
        <Btn
          label="Add node"
          onPress={() => {
            addCategory(kind, name, parentId);
            setName('');
            setParentId(null);
          }}
        />
      </ScrollView>
    </View>
  );
}

function MastersScreen({ back }: { back: () => void }) {
  const { bsrRates, itemMasters, holidays, workerRates, addBsrRate, addItemMaster, addHoliday, addWorkerRate, activeFy } = useStore();
  const [tab, setTab] = useState<'bsr' | 'items' | 'holiday' | 'workers'>('bsr');
  const [bItem, setBItem] = useState('');
  const [bUnit, setBUnit] = useState('');
  const [bRate, setBRate] = useState('');
  const [iName, setIName] = useState('');
  const [iWhole, setIWhole] = useState(true);
  const [iLast, setILast] = useState(false);
  const [iBasic, setIBasic] = useState(false);
  const [hDate, setHDate] = useState('');
  const [hName, setHName] = useState('');
  const [wRole, setWRole] = useState<'karigar' | 'labour' | 'mate'>('labour');
  const [wName, setWName] = useState('');
  const [wRate, setWRate] = useState('');
  return (
    <View style={styles.page}>
      <Header title="Masters" onBack={back} badge="S-36" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="BSR" variant={tab === 'bsr' ? 'primary' : 'outline'} onPress={() => setTab('bsr')} />
          <Btn label="Items" variant={tab === 'items' ? 'primary' : 'outline'} onPress={() => setTab('items')} />
          <Btn label="Holiday" variant={tab === 'holiday' ? 'primary' : 'outline'} onPress={() => setTab('holiday')} />
          <Btn label="Workers" variant={tab === 'workers' ? 'primary' : 'outline'} onPress={() => setTab('workers')} />
        </View>
        {tab === 'bsr' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>BSR — वार्षिक दर सूची ({bsrRates.length})</Text>
            <Text style={styles.meta}>पुराने साल read-only. Rate band: BSR−10…−20% safe.</Text>
            {bsrRates.map((b) => (
              <Text key={b.id} style={styles.meta}>
                {b.year} · {b.itemName} · {b.unit || '—'} · ₹{b.rate}
              </Text>
            ))}
            <Field label={`Item (${activeFy.label})`} value={bItem} onChangeText={setBItem} />
            <View style={styles.row}>
              <Field label="Unit" value={bUnit} onChangeText={setBUnit} />
              <Field label="Rate" value={bRate} onChangeText={setBRate} keyboardType="numeric" />
            </View>
            <Btn
              label="BSR rate जोड़ें"
              onPress={() => {
                if (!bItem.trim() || !(parseFloat(bRate) > 0)) return Alert.alert('Item + rate चाहिए');
                addBsrRate({ year: activeFy.label, itemName: bItem.trim(), unit: bUnit.trim(), rate: parseFloat(bRate) });
                setBItem('');
                setBRate('');
              }}
            />
          </View>
        ) : null}
        {tab === 'items' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Item master ({itemMasters.length})</Text>
            {itemMasters.map((i) => (
              <Text key={i.id} style={styles.meta}>
                {i.name} · {i.wholeNumberOnly ? 'पूर्ण संख्या' : 'दशमलव'}{i.lastBillOnly ? ' · अंतिम-बिल' : ''}{i.basicItem ? ' · आधारभूत' : ''}
              </Text>
            ))}
            <Field label="Item name" value={iName} onChangeText={setIName} />
            <View style={styles.row}>
              <Btn label={`पूर्ण: ${iWhole ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setIWhole(!iWhole)} />
              <Btn label={`अंतिम-बिल: ${iLast ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setILast(!iLast)} />
              <Btn label={`आधारभूत: ${iBasic ? 'हाँ' : 'नहीं'}`} variant="outline" onPress={() => setIBasic(!iBasic)} />
            </View>
            <Btn
              label="Item जोड़ें"
              onPress={() => {
                if (!iName.trim()) return Alert.alert('नाम चाहिए');
                addItemMaster({ name: iName.trim(), wholeNumberOnly: iWhole, lastBillOnly: iLast, basicItem: iBasic });
                setIName('');
              }}
            />
          </View>
        ) : null}
        {tab === 'holiday' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Holiday master ({holidays.length})</Text>
            <Text style={styles.meta}>पखवाड़ा गणना में रविवार + ये छुट्टियाँ घटेंगी</Text>
            {holidays.map((h) => (
              <Text key={h.id} style={styles.meta}>{h.date} · {h.name}</Text>
            ))}
            <View style={styles.row}>
              <Field label="दिनांक" value={hDate} onChangeText={setHDate} />
              <Field label="नाम" value={hName} onChangeText={setHName} />
            </View>
            <Btn
              label="छुट्टी जोड़ें"
              onPress={() => {
                if (!hDate) return Alert.alert('दिनांक चाहिए');
                addHoliday({ year: hDate.slice(0, 4), date: hDate, name: hName || 'छुट्टी' });
                setHDate('');
                setHName('');
              }}
            />
          </View>
        ) : null}
        {tab === 'workers' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Workers / Role rates ({workerRates.length})</Text>
            {workerRates.map((w) => (
              <Text key={w.id} style={styles.meta}>
                {w.year} · {w.role} · {w.name || '(group)'} · ₹{w.dailyRate}/दिन
              </Text>
            ))}
            <View style={styles.row}>
              <Btn label="मेट" variant={wRole === 'mate' ? 'primary' : 'outline'} onPress={() => setWRole('mate')} />
              <Btn label="कारीगर" variant={wRole === 'karigar' ? 'primary' : 'outline'} onPress={() => setWRole('karigar')} />
              <Btn label="लेबर" variant={wRole === 'labour' ? 'primary' : 'outline'} onPress={() => setWRole('labour')} />
            </View>
            <View style={styles.row}>
              <Field label="नाम (optional)" value={wName} onChangeText={setWName} />
              <Field label={`दर (${activeFy.label})`} value={wRate} onChangeText={setWRate} keyboardType="numeric" />
            </View>
            <Btn
              label="Worker rate जोड़ें"
              onPress={() => {
                if (!(parseFloat(wRate) > 0)) return Alert.alert('दर चाहिए');
                addWorkerRate({ role: wRole, name: wName.trim(), year: activeFy.label, dailyRate: parseFloat(wRate) });
                setWName('');
                setWRate('');
              }}
            />
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}

function MonthlyScreen({ back }: { back: () => void }) {
  const { fyTransactions, updateTransaction, cancelTransaction, activeFunds, categories } = useStore();
  const [filter, setFilter] = useState<'all' | 'incomplete' | 'cancelled'>('all');
  const [editId, setEditId] = useState<string | null>(null);
  const [cancelTarget, setCancelTarget] = useState<Transaction | null>(null);
  const [editParty, setEditParty] = useState('');
  const [editDetail, setEditDetail] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editNote, setEditNote] = useState('');
  const [editScheme, setEditScheme] = useState('');
  const [editRef, setEditRef] = useState('');
  const [editAsset, setEditAsset] = useState('');
  const [editCat, setEditCat] = useState<string | null>(null);
  const [editCat2, setEditCat2] = useState<string | null>(null);
  const [editCat3, setEditCat3] = useState<string | null>(null);
  const [editAmounts, setEditAmounts] = useState<Record<string, string>>({});
  const [editFolio, setEditFolio] = useState('');
  const [editErr, setEditErr] = useState('');
  const [month, setMonth] = useState('');

  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;

  const list = fyTransactions.filter((t) => {
    if (month && !t.date.startsWith(month)) return false;
    // J.2 — incomplete = scheme ya category path ka deepest level missing
    if (filter === 'incomplete')
      return t.status === 'active' && (!t.schemeId || isPathIncomplete(t, categories));
    if (filter === 'cancelled') return t.status === 'cancelled';
    return true;
  });

  const openEdit = (t: Transaction) => {
    setEditId(t.id);
    setEditErr('');
    setEditParty(t.party);
    setEditDetail(t.detail);
    setEditDate(t.date);
    setEditNote(t.note);
    setEditScheme(t.schemeId);
    setEditCat(t.categoryId);
    setEditCat2(t.subcategoryId);
    setEditCat3(t.subSubcategoryId);
    setEditRef(t.reference || '');
    setEditAsset(t.assetPage || '');
    setEditFolio(t.ledgerFolio || '');
    const am: Record<string, string> = {};
    for (const f of activeFunds) am[f.id] = t.amounts[f.id] ? String(t.amounts[f.id]) : '';
    setEditAmounts(am);
  };

  const saveEdit = async () => {
    if (!editId) return;
    // Part M: non-numeric / negative amount block (pehle chup-chaap skip ho jata tha)
    const am: Record<string, number> = {};
    for (const f of activeFunds) {
      const raw = (editAmounts[f.id] || '').trim();
      if (!raw) continue;
      const n = Number(raw);
      if (!Number.isFinite(n)) return setEditErr(`${f.shortName}: \"${raw}\" अमान्य राशि`);
      if (n < 0) return setEditErr(`${f.shortName}: ऋणात्मक राशि अनुमति नहीं`);
      if (n > 0) am[f.id] = n;
    }
    const r = await updateTransaction(editId, {
      party: editParty.trim(),
      detail: editDetail.trim(),
      date: editDate,
      note: editNote.trim(),
      reference: editRef.trim(),
      schemeId: editScheme,
      categoryId: editCat,
      subcategoryId: editCat2,
      subSubcategoryId: editCat3,
      ledgerFolio: editFolio.trim(),
      assetPage: editAsset.trim(),
      amounts: am,
    });
    // bug fix: pehle result check hi nahi hota tha — guard violation chup-chaap save ho jata tha
    if (!r.ok) return setEditErr(r.error || 'सहेजा नहीं जा सका');
    setEditId(null);
    Alert.alert('सुधार सहेज लिया', undefined, [{ text: 'OK' }]);
  };

  const editing = fyTransactions.find((t) => t.id === editId);
  const editRoots = editing ? categories.filter((c) => c.kind === editing.type && c.level === 1 && !c.archived) : [];
  const editL2 = categories.filter((c) => c.parentId === editCat && !c.archived);
  const editL3 = categories.filter((c) => c.parentId === editCat2 && !c.archived);

  return (
    <View style={styles.page}>
      <Header title="Monthly check" onBack={back} badge="S-MC" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Field label="महीना filter (YYYY-MM, खाली = सब)" value={month} onChangeText={setMonth} placeholder="2026-09" />
        <View style={styles.row}>
          <Btn label="All" variant={filter === 'all' ? 'primary' : 'outline'} onPress={() => setFilter('all')} />
          <Btn label="Incomplete" variant={filter === 'incomplete' ? 'primary' : 'outline'} onPress={() => setFilter('incomplete')} />
          <Btn label="Cancelled" variant={filter === 'cancelled' ? 'primary' : 'outline'} onPress={() => setFilter('cancelled')} />
        </View>
        {list.length === 0 ? (
          <Empty title="No rows" why="Is FY/filter me entries nahi" steps={['Add cashbook entry', 'Filter badlein']} />
        ) : null}
        {list.map((t) => (
          <View key={t.id} style={styles.card}>
            <Text
              style={[
                styles.cardTitle,
                t.status === 'cancelled' ? { textDecorationLine: 'line-through', color: C.expense } : null,
              ]}
            >
              {t.date} · {t.type} · {t.party || '(no party)'} {t.status === 'cancelled' ? '· रद्द' : ''}
            </Text>
            <Text style={styles.meta}>
              {formatINR(sumAmounts(t.amounts))} · scheme={t.schemeId || 'MISSING'} ·{' '}
              {categoryPathLabel(t, catNames) || 'cat=MISSING'}
            </Text>
            {t.status === 'cancelled' ? (
              <Text style={[styles.meta, { color: C.expense }]}>कारण: {t.cancelReason || '—'}</Text>
            ) : null}
            <View style={styles.row}>
              <Btn label="✏ Edit" onPress={() => openEdit(t)} />
              {t.status === 'active' ? (
                <Btn label="Cancel entry" variant="danger" onPress={() => setCancelTarget(t)} />
              ) : null}
            </View>
          </View>
        ))}
      </ScrollView>

      {cancelTarget ? (
        <CancelModal
          txn={cancelTarget}
          onCancel={() => setCancelTarget(null)}
          onConfirm={async (reason) => {
            const r = await cancelTransaction(cancelTarget.id, reason);
            setCancelTarget(null);
            if (!r.ok) Alert.alert(r.error || 'रद्द नहीं हुआ');
          }}
        />
      ) : null}

      {/* Full edit modal — har transaction par sudhaar */}
      <Modal visible={!!editId} animationType="slide">
        <View style={[styles.page, { paddingTop: 50 }]}>
          <Header title="Entry सुधारें" onBack={() => setEditId(null)} badge="S-MC" />
          <ScrollView contentContainerStyle={styles.pad}>
            <Field label="दिनांक" value={editDate} onChangeText={setEditDate} />
            {!isValidIsoDate(editDate) ? <Text style={styles.err}>तारीख format अमान्य — जैसे 2026-09-24</Text> : null}
            <Field label={editing?.type === 'income' ? 'किससे प्राप्त' : 'किसको भुगतान'} value={editParty} onChangeText={setEditParty} />
            <Field label="Detail" value={editDetail} onChangeText={setEditDetail} />
            <Field
              label={editing?.type === 'income' ? 'रसीद/चेक क्रमांक' : 'वाउचर/चेक क्रमांक'}
              value={editRef}
              onChangeText={setEditRef}
            />
            <Field label="L.F. (Ledger Folio)" value={editFolio} onChangeText={setEditFolio} />
            {editing?.type === 'expense' ? (
              <Field label="परिसंपत्ति रजिस्टर पृष्ठ" value={editAsset} onChangeText={setEditAsset} />
            ) : null}
            <Field label="Note" value={editNote} onChangeText={setEditNote} multiline />
            <Text style={styles.section}>Scheme *</Text>
            <View style={styles.chips}>
              {activeFunds.map((f) => (
                <Pressable key={f.id} onPress={() => setEditScheme(f.id)} style={[styles.chip, editScheme === f.id && styles.chipOn]}>
                  <Text style={{ color: editScheme === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
                </Pressable>
              ))}
            </View>
            <Text style={styles.section}>Amounts by fund</Text>
            {activeFunds.map((f) => (
              <Field
                key={f.id}
                label={f.shortName}
                value={editAmounts[f.id] || ''}
                onChangeText={(v) => setEditAmounts((a) => ({ ...a, [f.id]: v }))}
                keyboardType="numeric"
              />
            ))}
            <Text style={styles.section}>Category path (L1 → L2 → L3)</Text>
            <View style={styles.chips}>
              {editRoots.map((c) => (
                <Pressable key={c.id} onPress={() => { setEditCat(c.id); setEditCat2(null); setEditCat3(null); }} style={[styles.chip, editCat === c.id && styles.chipOn]}>
                  <Text style={{ color: editCat === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                </Pressable>
              ))}
            </View>
            {editL2.length ? (
              <View style={styles.chips}>
                {editL2.map((c) => (
                  <Pressable key={c.id} onPress={() => { setEditCat2(c.id); setEditCat3(null); }} style={[styles.chip, editCat2 === c.id && styles.chipOn]}>
                    <Text style={{ color: editCat2 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
            {editL3.length ? (
              <View style={styles.chips}>
                {editL3.map((c) => (
                  <Pressable key={c.id} onPress={() => setEditCat3(c.id)} style={[styles.chip, editCat3 === c.id && styles.chipOn]}>
                    <Text style={{ color: editCat3 === c.id ? '#fff' : C.foreground, fontSize: 12 }}>{c.name}</Text>
                  </Pressable>
                ))}
              </View>
            ) : null}
            {editCat ? (
              <Text style={styles.meta}>
                Path: {categoryPathLabel({ categoryId: editCat, subcategoryId: editCat2, subSubcategoryId: editCat3 }, catNames)}
              </Text>
            ) : null}
            {editErr ? <Text style={styles.err}>{editErr}</Text> : null}
            <View style={styles.row}>
              <Btn label="Save" icon="check" onPress={saveEdit} />
              <Btn label="Cancel" variant="outline" onPress={() => setEditId(null)} />
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

function GoswaraScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, activeFunds, totalOpening, categories, activePanchayat, activeFy } = useStore();
  const active = fyTransactions.filter((t) => t.status === 'active');
  if (active.length === 0) {
    return (
      <View style={styles.page}>
        <Header title="गोशवारा" onBack={back} badge="S-27" />
        <View style={styles.pad}>
          <Empty title="गोशवारा खाली" why="Is FY me abhi koi entry nahi" steps={['Cashbook me income/expense add karein', 'Ledgers auto update ho jayenge']} />
        </View>
      </View>
    );
  }
  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;
  const g = buildGoswara(fyTransactions, catNames, totalOpening);
  const share = async () => {
    const csv = goswaraCsv(g, {
      panchayat: activePanchayat.name,
      block: activePanchayat.block,
      district: activePanchayat.district,
      fy: activeFy.label,
      formName: 'वार्षिक आय - व्यय सामान्य रोकड़ बही (गोशवारा) — till date',
    });
    await Share.share({ message: csv, title: 'गोशवारा CSV' });
  };
  return (
    <View style={styles.page}>
      <Header title="गोशवारा till date" onBack={back} badge="S-27" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>वार्षिक आय-व्यय सामान्य रोकड़ बही (audit demo format) — हर entry पर auto-update</Text>
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', borderBottomWidth: 1, borderColor: C.border, paddingBottom: 4 }}>
            <Text style={[styles.gosHead, { flex: 2 }]}>नाम मद</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>आय</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>व्यय</Text>
          </View>
          {g.rows.map((r, i) => (
            <View key={i} style={{ flexDirection: 'row', paddingVertical: 3, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: C.border }}>
              <Text style={{ flex: 2, fontSize: 12, color: C.foreground }}>{r.name}</Text>
              <Text style={{ flex: 1, fontSize: 12, textAlign: 'right', color: C.foreground }}>{r.inc ? formatINR(r.inc) : ''}</Text>
              <Text style={{ flex: 1, fontSize: 12, textAlign: 'right', color: C.foreground }}>{r.exp ? formatINR(r.exp) : ''}</Text>
            </View>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.sumLine}>आय योग: {formatINR(g.aayYog)}</Text>
          <Text style={styles.sumLine}>व्यय योग: {formatINR(g.vyayYog)}</Text>
          <Text style={styles.sumLine}>प्रारम्भिक शेष नगद: {formatINR(g.prarambhikNagad)}</Text>
          <Text style={styles.sumLine}>महायोग: {formatINR(g.mahayog)}</Text>
          <Text style={styles.sumLine}>अंतिम शेष नगद: {formatINR(g.antSheshNagad)}</Text>
          <Text style={styles.meta}>प्रारम्भिक/अंतिम शेष बैंक — Bank module linked (statement posted hone par auto)</Text>
        </View>
        <View style={styles.row}>
          <Btn label="Share CSV" icon="share-2" onPress={share} />
          <Btn label="Formats Centre" variant="outline" onPress={() => go('formats')} />
        </View>
        <View style={styles.card}>
          <Text style={styles.meta}>हस्ताक्षर: ______ सरपंच        ______ ग्राम विकास अधिकारी</Text>
        </View>
      </ScrollView>
    </View>
  );
}

function LedgersScreen({ back }: { back: () => void }) {
  const { fyTransactions, activeFunds, totalOpening, activePanchayat, activeFy, fundOpening } = useStore();
  const [fundId, setFundId] = useState<string>('');
  const active = fyTransactions.filter((t) => t.status === 'active');
  const sel = fundId || 'all';
  // D17: fund-wise श्री पोते = is FY ka opening snapshot (global openingBalance nahi)
  const opening = fundId
    ? (() => {
        const f = activeFunds.find((x) => x.id === fundId);
        return f ? fundOpening(f) : 0;
      })()
    : totalOpening;
  const rows = buildLedger(opening, fyTransactions, fundId || undefined);
  const share = async () => {
    const csv = ledgerCsv(rows, {
      panchayat: activePanchayat.name,
      block: activePanchayat.block,
      district: activePanchayat.district,
      fy: activeFy.label,
      formName: `खाता बही — ${fundId ? activeFunds.find((f) => f.id === fundId)?.name || fundId : 'सभी योजनाएँ'}`,
    });
    await Share.share({ message: csv, title: 'Ledger CSV' });
  };
  return (
    <View style={styles.page}>
      <Header title="Ledgers (खाता बही)" onBack={back} badge="S-28" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>Ledger.pdf format — श्री पोते → जमा/नाम → शेष (हर entry पर auto-update)</Text>
        <View style={styles.chips}>
          <Pressable onPress={() => setFundId('')} style={[styles.chip, sel === 'all' && styles.chipOn]}>
            <Text style={{ color: sel === 'all' ? '#fff' : C.foreground, fontWeight: '700' }}>सभी</Text>
          </Pressable>
          {activeFunds.map((f) => (
            <Pressable key={f.id} onPress={() => setFundId(f.id)} style={[styles.chip, sel === f.id && styles.chipOn]}>
              <Text style={{ color: sel === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
            </Pressable>
          ))}
        </View>
        <View style={styles.card}>
          <View style={{ flexDirection: 'row', borderBottomWidth: 1, borderColor: C.border, paddingBottom: 4 }}>
            <Text style={[styles.gosHead, { flex: 1 }]}>दिनांक</Text>
            <Text style={[styles.gosHead, { flex: 2 }]}>किस से/किस को</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>जमा</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>नाम</Text>
            <Text style={[styles.gosHead, { flex: 1, textAlign: 'right' }]}>शेष</Text>
          </View>
          {rows.map((r, i) => (
            <View key={i} style={{ flexDirection: 'row', paddingVertical: 3, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: C.border }}>
              <Text style={{ flex: 1, fontSize: 11, color: C.foreground }}>{r.date.slice(5)}</Text>
              <Text numberOfLines={1} style={{ flex: 2, fontSize: 11, color: C.foreground, paddingHorizontal: 2 }}>{r.party}</Text>
              <Text style={{ flex: 1, fontSize: 11, textAlign: 'right', color: C.primary }}>{r.credit ? formatINR(r.credit) : ''}</Text>
              <Text style={{ flex: 1, fontSize: 11, textAlign: 'right', color: C.expense }}>{r.debit ? formatINR(r.debit) : ''}</Text>
              <Text style={{ flex: 1, fontSize: 11, textAlign: 'right', fontWeight: '700', color: C.foreground }}>{formatINR(r.running)}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

function ReportsScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { exportCsvForFy, fyTransactions, auditLogs, activeFy } = useStore();
  const fyLogs = auditLogs.filter((l) => l.fyId === activeFy.id).slice(0, 25);
  return (
    <View style={styles.page}>
      <Header title="Reports hub" onBack={back} badge="S-34" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>{fyTransactions.length} rows in FY · Share CSV (Excel-readable). PDF layout uses white background per spec.</Text>
        <Btn
          label="Share FY CSV (Excel)"
          icon="share-2"
          onPress={async () => Share.share({ message: exportCsvForFy() })}
        />
        <View style={styles.row}>
          <Btn label="गोशवारा" variant="outline" onPress={() => go('goswara')} />
          <Btn label="Ledger" variant="outline" onPress={() => go('ledgers')} />
        </View>
        <View style={styles.row}>
          <Btn label="प्रपत्र Centre" variant="outline" onPress={() => go('formats')} />
          <Btn label="Monthly check" variant="outline" onPress={() => go('monthly')} />
        </View>

        {/* L.3 audit trail — create / update / cancel sab record */}
        <Text style={styles.section}>Audit trail (L.3 — नवीनतम {fyLogs.length})</Text>
        {fyLogs.length === 0 ? (
          <Text style={styles.meta}>अभी कोई log नहीं — entry बनाने/सुधारने/रद्द करने पर यहाँ दिखेगा।</Text>
        ) : (
          fyLogs.map((l) => (
            <View key={l.id} style={styles.card}>
              <Text style={styles.cardTitle}>
                {l.time.slice(0, 16).replace('T', ' ')} · {l.entity} · {l.action}
              </Text>
              <Text style={styles.meta}>
                {l.field ? `${l.field}: ${l.oldV || '—'} → ${l.newV || '—'}` : l.newV || ''}
                {l.reason ? ` · कारण: ${l.reason}` : ''}
              </Text>
            </View>
          ))
        )}
        <Empty
          title="PDF print layout"
          why="Native PDF renderer hooks to same dataset; CSV share works offline now."
          steps={['Use Share FY CSV in Excel', 'Page PDF engine binds to Option A layout in print module']}
        />
      </ScrollView>
    </View>
  );
}

function BankScreen({ back }: { back: () => void }) {
  const { bankAccounts, bankLines, addBankLine, updateBankLine, postBankLineToCashbook, activeFunds, activeFy } = useStore();
  const [narr, setNarr] = useState('');
  const [amt, setAmt] = useState('');
  const [instr, setInstr] = useState('');
  const [side, setSide] = useState<'credit' | 'debit'>('credit');
  const [date, setDate] = useState(toIsoLocal(new Date()));
  const fyLines = bankLines.filter((l) => l.fyId === activeFy.id);

  const addLine = () => {
    // Part G: जमा + नाम दोनों; invalid date / zero amount block
    if (!isValidIsoDate(date)) return Alert.alert('अमान्य दिनांक', 'YYYY-MM-DD जैसे 2026-09-24');
    const n = Number(amt.trim());
    if (!Number.isFinite(n) || !(n > 0)) return Alert.alert('राशि > 0 चाहिए');
    if (!narr.trim()) return Alert.alert('Narration भरें');
    addBankLine({
      accountId: bankAccounts[0]?.id || 'ba1',
      fyId: activeFy.id,
      statementMonth: date.slice(0, 7),
      date,
      narration: narr.trim(),
      amount: n,
      side,
      instrument: instr.trim(),
      schemeId: null,
      workId: null,
      ignored: false,
      postedTxnId: null,
    });
    setNarr('');
    setAmt('');
    setInstr('');
  };

  return (
    <View style={styles.page}>
      <Header title="Bank statement" onBack={back} badge="S-13" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          Line add करें → scheme tag → Post (D−1 rule debit पर). OCR/PDF import device build में (Part U).
        </Text>
        {bankAccounts.map((a) => (
          <Text key={a.id} style={styles.meta}>{a.name} · {a.bankName} · {a.accountNo}</Text>
        ))}
        <View style={styles.row}>
          <Btn label="जमा (credit)" variant={side === 'credit' ? 'primary' : 'outline'} onPress={() => setSide('credit')} />
          <Btn label="नाम (debit)" variant={side === 'debit' ? 'danger' : 'outline'} onPress={() => setSide('debit')} />
        </View>
        <Field label="Narration" value={narr} onChangeText={setNarr} />
        <Field label="Amount" value={amt} onChangeText={setAmt} keyboardType="numeric" />
        <Field label="Instrument (चेक/DD/IMPS no.)" value={instr} onChangeText={setInstr} />
        <Field label="Date" value={date} onChangeText={setDate} />
        <Btn
          label={side === 'credit' ? 'Add credit line' : 'Add debit line'}
          icon="plus"
          onPress={addLine}
        />
        {fyLines.map((l) => (
          <View key={l.id} style={styles.card}>
            <Text style={styles.cardTitle}>{l.date} · {l.narration}</Text>
            <Text style={styles.meta}>
              {l.side === 'credit' ? 'जमा' : 'नाम'} {formatINR(l.amount)}
              {l.instrument ? ` · ${l.instrument}` : ''} · {l.ignored ? 'IGNORED' : l.postedTxnId ? 'POSTED' : 'open'}
            </Text>
            <Text style={styles.meta}>scheme tag:</Text>
            <View style={styles.chips}>
              {activeFunds.map((f) => (
                <Pressable
                  key={f.id}
                  style={[styles.chip, l.schemeId === f.id && styles.chipOn]}
                  onPress={() => updateBankLine(l.id, { schemeId: f.id })}
                >
                  <Text style={{ color: l.schemeId === f.id ? '#fff' : C.foreground, fontSize: 11 }}>{f.shortName}</Text>
                </Pressable>
              ))}
            </View>
            <View style={styles.row}>
              {!l.postedTxnId && !l.ignored ? (
                <Btn
                  label="Post to cashbook"
                  onPress={async () => {
                    const r = await postBankLineToCashbook(l.id);
                    if (!r.ok) Alert.alert('Post नहीं हुआ', r.error || 'Fail');
                  }}
                />
              ) : null}
              {!l.postedTxnId && !l.ignored ? (
                <Btn label="Ignore" variant="outline" onPress={() => updateBankLine(l.id, { ignored: true })} />
              ) : null}
              {l.ignored ? (
                <Btn label="Un-ignore" variant="outline" onPress={() => updateBankLine(l.id, { ignored: false })} />
              ) : null}
            </View>
          </View>
        ))}
        {fyLines.length === 0 ? (
          <Empty title="कोई statement line नहीं" why="अभी कोई bank line add नहीं हुई" steps={['ऊपर narration/amount/date भरें', 'जमा या नाम चुनकर line जोड़ें']} />
        ) : null}
      </ScrollView>
    </View>
  );
}

function WorksScreen({ back, go }: { back: () => void; go: (s: Stage, workId?: string) => void }) {
  const { works, addWork, activeFy, activeFunds } = useStore();
  const [name, setName] = useState('');
  const [ward, setWard] = useState('');
  const [sanction, setSanction] = useState('');
  const [fs, setFs] = useState('');
  const [schemeId, setSchemeId] = useState(activeFunds[1]?.id || 'sfc');
  const fyWorks = works.filter((w) => w.fyId === activeFy.id);
  return (
    <View style={styles.page}>
      <Header title="Works" onBack={back} badge="S-17" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>D.2 — नाम अनिवार्य; master select/add; optional code, ward, sanction, FS राशि</Text>
        <Field label="Work name *" value={name} onChangeText={setName} />
        <Field label="Ward / location" value={ward} onChangeText={setWard} />
        <Field label="Sanction reference (स्वीकृति सं.)" value={sanction} onChangeText={setSanction} />
        <Field label="FS वित्तीय स्वीकृति (₹) — प्रपत्र-1 + CC min() rule" value={fs} onChangeText={setFs} keyboardType="numeric" />
        <Text style={styles.section}>Fund / scheme</Text>
        <View style={styles.chips}>
          {activeFunds.map((f) => (
            <Pressable key={f.id} onPress={() => setSchemeId(f.id)} style={[styles.chip, schemeId === f.id && styles.chipOn]}>
              <Text style={{ color: schemeId === f.id ? '#fff' : C.foreground, fontWeight: '700' }}>{f.shortName}</Text>
            </Pressable>
          ))}
        </View>
        <Btn
          label="Add work"
          onPress={() => {
            if (!name.trim()) return Alert.alert('Work name अनिवार्य');
            const fsNum = Number(fs.trim());
            addWork({
              fyId: activeFy.id,
              name: name.trim(),
              schemeId,
              ward: ward.trim(),
              sanctionRef: sanction.trim(),
              fsAmount: Number.isFinite(fsNum) && fsNum > 0 ? fsNum : undefined,
              materialPrior: 0,
              labourPrior: 0,
              status: 'ongoing',
            });
            setName('');
            setWard('');
            setSanction('');
            setFs('');
          }}
        />
        {fyWorks.map((w) => (
          <Pressable key={w.id} style={styles.homeRow} onPress={() => go('workDetail', w.id)}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{w.name}</Text>
              <Text style={styles.meta}>
                {w.status} · scheme {w.schemeId}
                {w.ward ? ` · ward ${w.ward}` : ''}
                {w.sanctionRef ? ` · ${w.sanctionRef}` : ''}
                {w.fsAmount ? ` · FS ${formatINR(w.fsAmount)}` : ''}
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={C.mutedForeground} />
          </Pressable>
        ))}
        {fyWorks.length === 0 ? <Empty title="No works" why="Is FY me work nahi" steps={['Add work name above', 'Open for MB / Bills / CC']} /> : null}
      </ScrollView>
    </View>
  );
}

function WorkDetailScreen({ back, workId, go }: { back: () => void; workId: string; go: (s: Stage) => void }) {
  const { works, mbLines, bills } = useStore();
  const w = works.find((x) => x.id === workId);
  if (!w) {
    // K.5: dead click nahi — empty state + steps
    return (
      <View style={styles.page}>
        <Header title="Work" onBack={back} badge="S-18" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="यह work delete/hide हो गया होगा" steps={['Works list पर वापस जाएँ', 'दूसरा work चुनें']} />
        </View>
      </View>
    );
  }
  const mb = mbLines.filter((m) => m.workId === workId);
  const bl = bills.filter((b) => b.workId === workId);
  const mbVal = mb.reduce((s, m) => s + m.qty * m.rate, 0);
  return (
    <View style={styles.page}>
      <Header title={w.name} onBack={back} badge="S-19" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.meta}>FS वित्तीय स्वीकृति: {w.fsAmount ? formatINR(w.fsAmount) : '— (Works me जोड़ें)'} · sanction {w.sanctionRef || '—'} · ward {w.ward || '—'}</Text>
        <Text style={styles.meta}>Prior material {formatINR(w.materialPrior)} · labour {formatINR(w.labourPrior)}</Text>
        <Text style={styles.cardTitle}>MB valuation {formatINR(mbVal)} ({mb.length} lines)</Text>
        <Text style={styles.meta}>Bills {bl.length}</Text>
        <Btn label="MB entry" onPress={() => go('mb')} />
        <Btn label="Bills" variant="soft" onPress={() => go('bills')} />
        <Btn label="CC (7 pages summary)" variant="outline" onPress={() => go('cc')} />
      </ScrollView>
    </View>
  );
}

function MbScreen({ back, workId }: { back: () => void; workId: string }) {
  const { addMbLine, mbLines, bsrRates, holidays, activeFy, addMandayCalc, mandayCalcs, workerRates, works } = useStore();
  const work = works.find((x) => x.id === workId);
  const [item, setItem] = useState('');
  const [qty, setQty] = useState('1');
  const [rate, setRate] = useState('0');
  const [kind, setKind] = useState<'material' | 'labour' | 'artisan'>('material');
  const [calcRole, setCalcRole] = useState<'karigar' | 'labour' | 'mate'>('labour');
  const [calcWorkers, setCalcWorkers] = useState('1');
  const [calcDays, setCalcDays] = useState('12');
  const [calcRate, setCalcRate] = useState('');
  const [calcBsr, setCalcBsr] = useState('');
  const [calcFrom, setCalcFrom] = useState(toIsoLocal(new Date()));
  const [calcTo, setCalcTo] = useState(toIsoLocal(new Date()));
  const lines = mbLines.filter((m) => m.workId === workId);
  const mbComponent = lines.filter((m) => m.kind === calcRole).reduce((s, m) => s + m.qty * m.rate, 0);
  // B §6/B §7: labour role ka reference BSR me nahi milta → Worker master year-wise rate
  const ref = referenceRate(bsrRates, workerRates, activeFy.label, calcRole);
  const bsr = calcBsr ? parseFloat(calcBsr) : ref.rate;
  const rc = calcRate ? rateCheck(parseFloat(calcRate), bsr) : { ok: true, warn: null as string | null };
  const w = parseInt(calcWorkers) || 0;
  const d = parseInt(calcDays) || 0;
  const r = parseFloat(calcRate) || 0;
  const amount = w * d * r;
  const pw = pakhwadaWorkingDays(calcFrom, calcTo, holidays);
  const combos = bsr ? suggestCombos(mbComponent, Math.round(bsr * 0.85), 20, pw.working || 12, calcRole) : [];
  const calcList = mandayCalcs.filter((c) => c.workId === workId);
  if (!work) {
    return (
      <View style={styles.page}>
        <Header title="MB entry" onBack={back} badge="S-21" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="MB के लिए पहले work चुनें" steps={['Works list खोलें', 'कोई work चुनें']} />
        </View>
      </View>
    );
  }
  return (
    <View style={styles.page}>
      <Header title="MB entry" onBack={back} badge="S-21" />
      <ScrollView contentContainerStyle={styles.pad}>
        <View style={styles.row}>
          <Btn label="सामग्री" variant={kind === 'material' ? 'primary' : 'outline'} onPress={() => setKind('material')} />
          <Btn label="कारीगर" variant={kind === 'artisan' ? 'primary' : 'outline'} onPress={() => setKind('artisan')} />
          <Btn label="लेबर" variant={kind === 'labour' ? 'primary' : 'outline'} onPress={() => setKind('labour')} />
        </View>
        <Field label="Item / मद" value={item} onChangeText={setItem} />
        <View style={styles.row}>
          <Field label="Qty" value={qty} onChangeText={setQty} keyboardType="numeric" />
          <Field label="Rate" value={rate} onChangeText={setRate} keyboardType="numeric" />
        </View>
        <Btn
          label="MB line जोड़ें"
          onPress={() => {
            if (!item.trim()) return Alert.alert('मद चाहिए');
            addMbLine({ workId, itemName: item, qty: parseFloat(qty) || 0, rate: parseFloat(rate) || 0, kind });
            setItem('');
          }}
        />
        {lines.map((m) => (
          <Text key={m.id} style={styles.meta}>
            {m.itemName} · {m.qty} × {formatINR(m.rate)} = {formatINR(m.qty * m.rate)} ({m.kind === 'material' ? 'सामग्री' : m.kind === 'artisan' ? 'कारीगर' : 'लेबर'})
          </Text>
        ))}
        <Text style={styles.section}>मान-दिवस calculator ({calcRole})</Text>
        <Text style={styles.meta}>MB {calcRole} component: {formatINR(mbComponent)}</Text>
        <View style={styles.row}>
          <Btn label="मेट" variant={calcRole === 'mate' ? 'primary' : 'outline'} onPress={() => setCalcRole('mate')} />
          <Btn label="कारीगर" variant={calcRole === 'karigar' ? 'primary' : 'outline'} onPress={() => setCalcRole('karigar')} />
          <Btn label="लेबर" variant={calcRole === 'labour' ? 'primary' : 'outline'} onPress={() => setCalcRole('labour')} />
        </View>
        <View style={styles.row}>
          <Field label="दिनांक से" value={calcFrom} onChangeText={setCalcFrom} />
          <Field label="दिनांक तक" value={calcTo} onChangeText={setCalcTo} />
        </View>
        <Text style={styles.meta}>
          पखवाड़ा: {pw.total} दिन − {pw.sundays} रविवार − {pw.holidays} छुट्टी = <Text style={{ fontWeight: '800' }}>{pw.working} working days</Text>
        </Text>
        <View style={styles.row}>
          <Field label="Workers" value={calcWorkers} onChangeText={setCalcWorkers} keyboardType="numeric" />
          <Field label="दिन (full man-days)" value={calcDays} onChangeText={setCalcDays} keyboardType="numeric" />
          <Field label="दर" value={calcRate} onChangeText={setCalcRate} keyboardType="numeric" />
        </View>
        {bsr ? (
          <Text style={styles.meta}>
            Reference दर ₹{bsr} ({ref.source === 'BSR' ? 'BSR' : ref.source === 'Worker' ? 'Worker master' : 'manual'}) · safe band ₹
            {Math.round(bsr * 0.8)}–₹{Math.round(bsr * 0.9)} (BSR−20%…−10%)
          </Text>
        ) : null}
        {rc.warn ? <Text style={styles.err}>{rc.warn}</Text> : null}
        {amount > mbComponent && mbComponent > 0 ? <Text style={styles.err}>राशि {formatINR(amount)} MB component ({formatINR(mbComponent)}) से अधिक — अनुमति नहीं</Text> : null}
        <Text style={styles.sumLine}>= {w} × {d} × ₹{r} = {formatINR(amount)}</Text>
        {amount > 0 && amount <= mbComponent + 0.001 && rc.ok ? (
          <Btn
            label="गणना save करें (audit trail)"
            onPress={() => addMandayCalc({ workId, role: calcRole, workers: w, days: d, rate: r, bsrYear: activeFy.label, amount, mbComponentAmount: mbComponent })}
          />
        ) : null}
        {combos.length > 0 ? (
          <View style={styles.card}>
            <Text style={styles.meta}>Auto-suggest combos (BSR−15% दर से, MB component {formatINR(mbComponent)} के भीतर):</Text>
            {combos.map((c, i) => (
              <Text key={i} style={styles.meta}>
                {c.workers} × {c.days} × ₹{c.rate} = {formatINR(c.amount)} (शेष {formatINR(c.remaining)})
              </Text>
            ))}
          </View>
        ) : null}
        {calcList.map((c) => (
          <Text key={c.id} style={styles.meta}>
            📋 {c.role}: {c.workers}×{c.days}×₹{c.rate} = {formatINR(c.amount)} · BSR {c.bsrYear}
          </Text>
        ))}
      </ScrollView>
    </View>
  );
}

function BillsScreen({ back, workId }: { back: () => void; workId: string }) {
  const { addBill, bills, activeFy } = useStore();
  const [vendor, setVendor] = useState('');
  const [amount, setAmount] = useState('');
  const [billDate, setBillDate] = useState(toIsoLocal(new Date()));
  const [payDate, setPayDate] = useState('');
  const [pageRef, setPageRef] = useState('');
  const [note, setNote] = useState('');
  const list = bills.filter((b) => b.workId === workId);
  return (
    <View style={styles.page}>
      <Header title="Bills" onBack={back} badge="S-25" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>H — Bill register date-wise: bill date + cashbook payment date + page ref</Text>
        <Field label="Vendor" value={vendor} onChangeText={setVendor} />
        <Field label="Amount" value={amount} onChangeText={setAmount} keyboardType="numeric" />
        <Field label="Bill date (YYYY-MM-DD)" value={billDate} onChangeText={setBillDate} />
        <Field label="Cashbook payment date (YYYY-MM-DD, भुगतान के बाद)" value={payDate} onChangeText={setPayDate} placeholder="2026-09-24" />
        <Field label="Cashbook page ref" value={pageRef} onChangeText={setPageRef} placeholder="पृष्ठ 3" />
        <Field label="Note" value={note} onChangeText={setNote} multiline />
        <Btn
          label="Add bill"
          onPress={() => {
            if (!vendor.trim()) return Alert.alert('Vendor चाहिए');
            const n = Number(amount.trim());
            if (!Number.isFinite(n) || !(n > 0)) return Alert.alert('राशि > 0 चाहिए');
            if (!isValidIsoDate(billDate)) return Alert.alert('Bill date अमान्य (YYYY-MM-DD)');
            if (payDate && !isValidIsoDate(payDate)) return Alert.alert('Payment date अमान्य (YYYY-MM-DD)');
            addBill({
              workId,
              fyId: activeFy.id,
              billDate,
              paymentDate: payDate || billDate,
              pageRef: pageRef.trim(),
              vendor: vendor.trim(),
              amount: n,
              note: note.trim(),
            });
            setVendor('');
            setAmount('');
            setPageRef('');
            setNote('');
          }}
        />
        {list.map((b) => (
          <View key={b.id} style={styles.card}>
            <Text style={styles.cardTitle}>
              {b.billDate} · {b.vendor} · {formatINR(b.amount)}
            </Text>
            <Text style={styles.meta}>
              भुगतान {b.paymentDate || '—'} · page {b.pageRef || '—'} {b.note ? ` · ${b.note}` : ''}
            </Text>
          </View>
        ))}
        {list.length === 0 ? <Empty title="कोई bill नहीं" why="इस work पर अभी bill add नहीं हुआ" steps={['Vendor + amount भरें', 'Add bill']} /> : null}
      </ScrollView>
    </View>
  );
}

function CcScreen({ back, workId }: { back: () => void; workId: string }) {
  const { works, mbLines, bills, workerRolls, fyTransactions, activePanchayat, activeFy, addWorkerRoll } = useStore();
  const w0 = works.find((x) => x.id === workId);
  const [fs, setFs] = useState(w0?.fsAmount ? String(w0.fsAmount) : '');
  const [asAmt, setAsAmt] = useState('');
  const [as, setAs] = useState('');
  const [from, setFrom] = useState(toIsoLocal(new Date()));
  const [to, setTo] = useState(toIsoLocal(new Date()));
  const [rollNo, setRollNo] = useState('');
  const [mate, setMate] = useState('0');
  const [skilled, setSkilled] = useState('0');
  const [unskilled, setUnskilled] = useState('0');
  const [days, setDays] = useState('1');
  const [wMate, setWMate] = useState('0');
  const [wSkilled, setWSkilled] = useState('0');
  const [wUnskilled, setWUnskilled] = useState('0');
  const w = works.find((x) => x.id === workId);
  if (!w) {
    return (
      <View style={styles.page}>
        <Header title="CC (7 pages)" onBack={back} badge="S-26" />
        <View style={styles.pad}>
          <Empty title="Work नहीं मिला" why="CC के लिए पहले work चुनें" steps={['Works list खोलें', 'कोई work चुनें']} />
        </View>
      </View>
    );
  }
  const rolls = workerRolls.filter((r) => r.workId === workId);
  const c = ccBuild({ work: w, mbLines, bills, rolls, txs: fyTransactions, fsAmount: parseFloat(fs) || w.fsAmount || 0, asAmount: parseFloat(asAmt) || 0 });
  const share = async () => {
    const csv = ccCsv(c, {
      panchayat: activePanchayat.name,
      block: activePanchayat.block,
      district: activePanchayat.district,
      fy: activeFy.label,
      formName: 'कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ)',
    }, { name: w.name, sanctionRef: w.sanctionRef, ward: w.ward });
    await Share.share({ message: csv, title: `CC - ${w.name}` });
  };
  const num = (s: string) => parseFloat(s) || 0;
  return (
    <View style={styles.page}>
      <Header title="CC (7 pages)" onBack={back} badge="S-26" action={<IconBtn name="share-2" onPress={share} />} />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.cardTitle}>{w.name}</Text>
        <Text style={styles.hint}>{CC_INSTRUCTIONS}</Text>
        <View style={styles.row}>
          <Field label="FS राशि (वित्तीय स्वीकृति)" value={fs} onChangeText={setFs} keyboardType="numeric" />
        </View>
        <View style={styles.row}>
          <Field label="AS/TS राशि (min limit)" value={asAmt} onChangeText={setAsAmt} keyboardType="numeric" />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 1 — कार्य पूर्णता प्रमाण पत्र</Text>
          <Text style={styles.meta}>वास्तविक व्यय (लेखे अनुसार): {formatINR(c.actualExpense)}</Text>
          <Text style={styles.meta}>मूल्यांकन राशि (MB): {formatINR(c.mulyaankan)}</Text>
          <Text style={styles.meta}>श्रम: {formatINR(c.labour)} · सामग्री: {formatINR(c.material)}</Text>
          <Text style={styles.cardTitle}>कुल अनुमत राशि = min(FS, AS/TS, मूल्यांकन, वास्तविक व्यय)</Text>
          <Text style={styles.sumLine}>{formatINR(c.allowable)}</Text>
          <Text style={styles.meta}>भुगतान योग्य शेष (अनुमत − payments): {formatINR(c.residualMaterial)}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 3 — श्रमिक विवरण (पाक्षिक मस्टरोल)</Text>
          <Text style={styles.meta}>मानव दिवस = श्रमिक संख्या × दिन; व्यय = मानव दिवस × मजदूरी दर (निर्देशिका 2010 अनुसार)</Text>
          {rolls.map((r) => (
            <Text key={r.id} style={styles.meta}>
              {r.fromDate}→{r.toDate} roll {r.rollNo || '—'}: मेट {r.mateCount}×{r.days}द · कुशल {r.skilledCount}×{r.days}द · अकुशल {r.unskilledCount}×{r.days}द ={' '}
              {formatINR(r.mateCount * r.days * r.wageMate + r.skilledCount * r.days * r.wageSkilled + r.unskilledCount * r.days * r.wageUnskilled)}
            </Text>
          ))}
          <Text style={styles.sumLine}>कुल श्रम व्यय (rolls): {formatINR(c.mandays.wage)}</Text>
          <Text style={styles.meta}>MB श्रम मद: {formatINR(c.labour)}</Text>
          <Field label="मस्टरोल क्रमांक" value={rollNo} onChangeText={setRollNo} />
          <View style={styles.row}>
            <Field label="दिनांक से" value={from} onChangeText={setFrom} />
            <Field label="दिनांक तक" value={to} onChangeText={setTo} />
          </View>
          <View style={styles.row}>
            <Field label="मेट संख्या" value={mate} onChangeText={setMate} keyboardType="numeric" />
            <Field label="कुशल" value={skilled} onChangeText={setSkilled} keyboardType="numeric" />
            <Field label="अकुशल" value={unskilled} onChangeText={setUnskilled} keyboardType="numeric" />
          </View>
          <View style={styles.row}>
            <Field label="दिन" value={days} onChangeText={setDays} keyboardType="numeric" />
            <Field label="मेट दर" value={wMate} onChangeText={setWMate} keyboardType="numeric" />
          </View>
          <View style={styles.row}>
            <Field label="कुशल दर" value={wSkilled} onChangeText={setWSkilled} keyboardType="numeric" />
            <Field label="अकुशल दर" value={wUnskilled} onChangeText={setWUnskilled} keyboardType="numeric" />
          </View>
          <Btn
            label="पाक्षिक roll जोड़ें"
            onPress={() =>
              addWorkerRoll({
                workId,
                fyId: activeFy.id,
                fromDate: from,
                toDate: to,
                rollNo,
                mateCount: num(mate),
                skilledCount: num(skilled),
                unskilledCount: num(unskilled),
                days: num(days) || 1,
                wageMate: num(wMate),
                wageSkilled: num(wSkilled),
                wageUnskilled: num(wUnskilled),
              })
            }
          />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 4 — सामग्री विवरण (MB अनुसार)</Text>
          {mbLines.filter((m) => m.workId === workId && m.kind === 'material').map((m) => (
            <Text key={m.id} style={styles.meta}>
              {m.itemName} · {m.qty} × {formatINR(m.rate)} = {formatINR(m.qty * m.rate)}
            </Text>
          ))}
          <Text style={styles.sumLine}>सामग्री योग: {formatINR(c.material)}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>पृष्ठ 2 · 5 · 6 · 7</Text>
          <Text style={styles.meta}>2 — उपयोगिता प्रमाण पत्र: व्यय {formatINR(c.actualExpense)} / अनुमत {formatINR(c.allowable)}</Text>
          <Text style={styles.meta}>5 — तकनीकी निरीक्षण: ग्रामीण कार्य निर्देशिका 2010 प्रावधानों अनुसार मूल्यांकन सत्यापित</Text>
          <Text style={styles.meta}>6 — पूर्ण कार्य फोटो + हस्ताक्षर (सरपंच, VDO, कनिष्ठ अभियंता)</Text>
          <Text style={styles.meta}>7 — पहले व कार्य के दौरान फोटो</Text>
        </View>
        <Btn label="Share CC CSV (7 pages)" icon="share-2" onPress={share} />
      </ScrollView>
    </View>
  );
}

function FormatsScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { fyTransactions, categories, activeFunds, totalOpening, activePanchayat, activeFy, works, mbLines, bills, bankLines, workerRolls } = useStore();
  const catNames: Record<string, string> = {};
  for (const c of categories) catNames[c.id] = c.name;
  const fundNames: Record<string, string> = {};
  for (const f of activeFunds) fundNames[f.id] = f.name;
  const hdr = {
    panchayat: activePanchayat.name,
    block: activePanchayat.block,
    district: activePanchayat.district,
    fy: activeFy.label,
  };
  const share = async (csv: string, title: string) => Share.share({ message: csv, title });
  const g = buildGoswara(fyTransactions, catNames, totalOpening);
  const p1 = buildPrapt1(works.filter((w) => w.fyId === activeFy.id), mbLines, fyTransactions, fundNames, (w) => w.materialPrior + w.labourPrior);
  const p4 = buildPrapt4(mbLines);
  const fyBankLines = bankLines.filter((l) => l.fyId === activeFy.id);
  return (
    <View style={styles.page}>
      <Header title="प्रपत्र / Formats Centre" onBack={back} badge="S-28" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          आपकी demo files के अनुसार — हर format entries से auto-update होता है (ledger की तरह, कोई generate step नहीं)। Share/Excel me kholen.
        </Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>गोशवारा — वार्षिक आय-व्यय सामान्य रोकड़ बही</Text>
          <Text style={styles.meta}>
            मद {g.rows.length} · आय योग {formatINR(g.aayYog)} · व्यय योग {formatINR(g.vyayYog)} · अंतिम शेष {formatINR(g.antSheshNagad)}
          </Text>
          <View style={styles.row}>
            <Btn label="Share" icon="share-2" onPress={() => share(goswaraCsv(g, { ...hdr, formName: 'वार्षिक आय-व्यय सामान्य रोकड़ बही' }), 'गोशवारा CSV')} />
            <Btn label="Open" variant="outline" onPress={() => go('goswara')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Ledger — खाता बही</Text>
          <Text style={styles.meta}>श्री पोते → जमा/नाम → शेष (ledger.pdf layout)</Text>
          <View style={styles.row}>
            <Btn label="Open" onPress={() => go('ledgers')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-1 — SFC/TFC/FFC/BRGF कार्य विवरण</Text>
          <Text style={styles.meta}>कार्य {p1.length} · FS/व्यय/मूल्यांकन/स्थिति auto</Text>
          <View style={styles.row}>
            <Btn label="Share" icon="share-2" onPress={() => share(prapt1Csv(p1, { ...hdr, formName: 'SFC/TFC/FFC/BRGF योजनाओं में कार्यों का विवरण — प्रपत्र-1' }), 'प्रपत्र-1 CSV')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>प्रपत्र-4 — निर्माण सामग्री विवरण</Text>
          <Text style={styles.meta}>सामग्री मद {p4.length} · योग {formatINR(p4.reduce((s, r) => s + r.cost, 0))}</Text>
          <View style={styles.row}>
            <Btn label="Share" icon="share-2" onPress={() => share(prapt4Csv(p4, { ...hdr, formName: 'निर्माण कार्यों पर व्यय सामग्री — प्रपत्र-4' }), 'प्रपत्र-4 CSV')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Bank statement grid</Text>
          <Text style={styles.meta}>Lines {fyBankLines.length} · tag + post status सहित</Text>
          <View style={styles.row}>
            <Btn
              label="Share"
              icon="share-2"
              onPress={() =>
                share(bankStatementCsv(fyBankLines, { ...hdr, formName: 'बैंक विवरण' }), 'Bank statement CSV')
              }
            />
            <Btn label="Open" variant="outline" onPress={() => go('bank')} />
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>CC — कार्य पूर्णता प्रमाण पत्र (7 पृष्ठ)</Text>
          <Text style={styles.meta}>Works {works.filter((w) => w.fyId === activeFy.id).length} · पाक्षिक rolls {workerRolls.length} — work detail se open karein</Text>
          <View style={styles.row}>
            <Btn label="Open Works" variant="outline" onPress={() => go('works')} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function ClosingScreen({ back, go }: { back: () => void; go: (s: Stage) => void }) {
  const { activeFy, fyTransactions, activePanchayat, bankLines, exportBackupJson, closeFinancialYearCarryForward, totalOpening } = useStore();
  const [ack, setAck] = useState({ pages: false, bank: false, attach: false });
  const nx = nextFyParts(activeFy);
  const cancelled = fyTransactions.filter((t) => t.status === 'cancelled').length;
  const untagged = bankLines.filter((l) => l.fyId === activeFy.id && !l.postedTxnId && !l.ignored).length;
  const ready = ack.pages && ack.bank && ack.attach;
  return (
    <View style={styles.page}>
      <Header title={`वित्तीय वर्ष समापन — ${activeFy.label}`} onBack={back} badge="S-45" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>FY lock se pehle: sab jagah janch, final गोशवारा, safe backup (kabhi delete nahi), phir lock.</Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>1. जाँच सूची</Text>
          {[
            ['pages', 'सभी pages जाँचा-परखा (मैन्युअल रूप से सत्यापित)'],
            ['bank', `बैंक statements upload + verify (${untagged} untagged lines बाकी)`],
            ['attach', `Missing attachments की सूची देखी (${cancelled} cancelled entries)`],
          ].map(([k, label]) => (
            <Pressable key={k} onPress={() => setAck((a) => ({ ...a, [k]: !a[k as keyof typeof ack] }))} style={styles.homeRow}>
              <Feather name={ack[k as keyof typeof ack] ? 'check-square' : 'square'} size={18} color={C.primary} />
              <Text style={{ flex: 1, fontSize: 12, color: C.foreground }}>{label}</Text>
            </Pressable>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>2. Final गोशवारा</Text>
          <Text style={styles.meta}>31-03 annual गोशवारा Formats Centre / गोशवारा screen se verify karein</Text>
          <Btn label="गोशवारा खोलें" variant="outline" onPress={() => go('goswara')} />
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>3. Operation-पूर्व safe backup</Text>
          <Text style={styles.meta}>यह backup कभी auto-delete नहीं होगा</Text>
          <Btn label="Safe backup share/save" icon="download" onPress={() => Share.share({ message: exportBackupJson(), title: `SAFE-BACKUP-${activeFy.label}` })} />
        </View>
        <Btn
          label="4. FY Lock → नए वर्ष की opening carry-forward"
          variant="danger"
          disabled={!ready}
          onPress={() =>
            Alert.alert(
              'FY lock?',
              `${activeFy.label} read-only archive हो जाएगा. Closing balances (opening ${formatINR(totalOpening)} से गणित) नए FY ${nx.label} की opening बनेंगी.`,
              [
                { text: 'नहीं', style: 'cancel' },
                {
                  text: 'Lock करें',
                  style: 'destructive',
                  onPress: async () => {
                    // bug fix: pehle result check nahi hota tha + hardcoded 2027–28
                    const r = await closeFinancialYearCarryForward(activeFy.id, nx.label, nx.start, nx.end);
                    if (!r.ok) return Alert.alert('FY lock नहीं हुआ', r.error || '—');
                    Alert.alert('FY lock हो गया', `नया FY ${nx.label} खुल गया — opening balances carry-forward`);
                    back();
                  },
                },
              ]
            )
          }
        />
        {!ready ? <Text style={styles.meta}>उपरोक्त तीनों जाँच ✓ करने के बाद ही lock सक्रिय होगा</Text> : null}
      </ScrollView>
    </View>
  );
}

function BackupScreen({ back }: { back: () => void }) {
  const { exportCsvForFy, exportBackupJson, importBackupJson, activePanchayat, activeFy } = useStore();
  const [restoreText, setRestoreText] = useState('');
  const now = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  const backupName = `Cashbook-Backup-${activePanchayat.name.replace(/\s+/g, '_')}-${now}`;
  return (
    <View style={styles.page}>
      <Header title="Backup & export" onBack={back} badge="S-42" />
      <ScrollView contentContainerStyle={styles.pad}>
        <Text style={styles.hint}>
          SAF path: Documents/Cashbook/{activePanchayat.name}/{activeFy.label}/backups — share se kisi bhi app (WhatsApp/Drive/Files) me save karein.
        </Text>
        <Btn
          label="⬇ Full JSON Backup (saare data) — Share/Save"
          icon="download"
          onPress={async () => {
            const json = exportBackupJson();
            await Share.share({ message: json, title: `${backupName}.json` });
          }}
        />
        <Btn
          label="Share FY CSV (Excel)"
          icon="share-2"
          onPress={() => Share.share({ message: exportCsvForFy() })}
        />
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Restore (phone transfer)</Text>
          <Text style={styles.meta}>Naye phone par: backup JSON ka text paste karke Restore dabayen. Ya WhatsApp se aayi file ka content copy karein.</Text>
          <Field label="Backup JSON paste karein" value={restoreText} onChangeText={setRestoreText} multiline />
          <Btn
            label="Restore data"
            variant="danger"
            onPress={() => {
              if (!restoreText.trim()) return Alert.alert('JSON paste karein');
              Alert.alert('Restore?', 'Maujuda data replace ho jayega. Pehle backup le lein.', [
                { text: 'नहीं', style: 'cancel' },
                {
                  text: 'Restore',
                  style: 'destructive',
                  onPress: () => {
                    const r = importBackupJson(restoreText);
                    if (r.ok) {
                      setRestoreText('');
                      Alert.alert('Restore safal', 'Data load ho gaya');
                    } else Alert.alert('Restore fail', r.error || 'Invalid');
                  },
                },
              ]);
            }}
          />
        </View>
        <Empty
          title="SAF folder (device build)"
          why="Release APK me expo-file-system + SAF se seedha Documents/Cashbook/ me file likhi jayegi."
          steps={['Abhi: Share button se kisi app me save karein', 'Device build: SAF auto-save']}
        />
      </ScrollView>
    </View>
  );
}

function FundsScreen({ back }: { back: () => void }) {
  const { activeFunds, updateFundOpening, deleteFundFy, addFund } = useStore();
  const [name, setName] = useState('');
  const [open, setOpen] = useState('0');
  return (
    <View style={styles.page}>
      <Header title="Fund heads" onBack={back} badge="S-35" />
      <ScrollView contentContainerStyle={styles.pad}>
        {activeFunds.map((f) => (
          <View key={f.id} style={styles.card}>
            <Text style={styles.cardTitle}>{f.name}</Text>
            <Text style={styles.meta}>{formatINR(f.openingBalance)} · {f.openingSource}</Text>
            <Btn label="Delete (FY)" variant="danger" onPress={() => deleteFundFy(f.id)} />
          </View>
        ))}
        <Field label="New" value={name} onChangeText={setName} />
        <Field label="Opening" value={open} onChangeText={setOpen} keyboardType="numeric" />
        <Btn label="Add" onPress={() => { addFund(name, parseFloat(open) || 0); setName(''); }} />
      </ScrollView>
    </View>
  );
}

function Shell() {
  const [stage, setStage] = useState<Stage>('login');
  const [workId, setWorkId] = useState<string>('');
  const [editTxnId, setEditTxnId] = useState<string | null>(null);
  const { hydrated } = useStore();

  // bug fix: pehle stack state ke andar Alert/setStage (side-effects) chalte the —
  // StrictMode me updater 2 baar chalta hai = duplicate Exit dialog + double nav.
  // Ab navigation-stack ki ek authoritative copy ref me; re-render setStage karta hai.
  const stackRef = useRef<Stage[]>(['login']);

  const go = useCallback((s: Stage, wid?: string) => {
    if (wid) setWorkId(wid);
    stackRef.current = [...stackRef.current, s];
    setStage(s);
  }, []);

  const exitConfirm = useCallback(() => {
    Alert.alert('Exit?', undefined, [
      { text: 'Stay', style: 'cancel' },
      { text: 'Exit', style: 'destructive', onPress: () => BackHandler.exitApp() },
    ]);
  }, []);

  const back = useCallback(() => {
    if (stackRef.current.length <= 1) {
      exitConfirm();
      return;
    }
    stackRef.current = stackRef.current.slice(0, -1);
    setStage(stackRef.current[stackRef.current.length - 1]);
  }, [exitConfirm]);

  React.useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      back();
      return true;
    });
    return () => sub.remove();
  }, [back]);

  if (!hydrated) {
    return (
      <View style={[styles.page, { alignItems: 'center', justifyContent: 'center' }]}>
        <Text>Loading…</Text>
      </View>
    );
  }

  switch (stage) {
    case 'login':
      return <LoginScreen onDone={() => go('panchayat')} />;
    case 'panchayat':
      return <PanchayatScreen onContinue={() => go('fy')} onBack={back} onSettings={() => go('appSettings')} />;
    case 'appSettings':
      return <AppSettingsScreen onBack={back} />;
    case 'fy':
      return <FYScreen onContinue={() => go('home')} onBack={back} onSettings={() => go('fySettings')} />;
    case 'fySettings':
      return <FYSettingsScreen onBack={back} />;
    case 'home':
      return <HomeScreen go={go} back={back} />;
    case 'cashbook':
      return <CashbookScreen back={back} go={go} onEdit={(id) => { setEditTxnId(id); go('entry'); }} />;
    case 'entry':
      return <EntryScreen back={back} editTxnId={editTxnId} onClearEdit={() => setEditTxnId(null)} />;
    case 'funds':
      return <FundsScreen back={back} />;
    case 'categories':
      return <CategoriesScreen back={back} />;
    case 'monthly':
      return <MonthlyScreen back={back} />;
    case 'goswara':
      return <GoswaraScreen back={back} go={go} />;
    case 'ledgers':
      return <LedgersScreen back={back} />;
    case 'reports':
      return <ReportsScreen back={back} go={go} />;
    case 'bank':
      return <BankScreen back={back} />;
    case 'works':
      return <WorksScreen back={back} go={go} />;
    case 'workDetail':
      return <WorkDetailScreen back={back} workId={workId} go={go} />;
    case 'mb':
      return <MbScreen back={back} workId={workId} />;
    case 'bills':
      return <BillsScreen back={back} workId={workId} />;
    case 'cc':
      return <CcScreen back={back} workId={workId} />;
    case 'formats':
      return <FormatsScreen back={back} go={go} />;
    case 'masters':
      return <MastersScreen back={back} />;
    case 'closing':
      return <ClosingScreen back={back} go={go} />;
    case 'backup':
      return <BackupScreen back={back} />;
    default:
      return <HomeScreen go={go} back={back} />;
  }
}

export default function Index() {
  return <Shell />;
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.background },
  dark: { flex: 1, backgroundColor: C.darkForest, padding: 24, justifyContent: 'center' },
  loginPad: { gap: 8 },
  brand: { color: C.accent, letterSpacing: 2, fontWeight: '800', fontSize: 12 },
  loginHi: { color: '#fff', fontSize: 28, fontWeight: '800' },
  loginSub: { color: 'rgba(255,255,255,0.7)', marginBottom: 12 },
  header: { backgroundColor: C.primary, paddingHorizontal: 12, paddingBottom: 10 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  eyebrow: { color: 'rgba(255,255,255,0.75)', fontSize: 11 },
  hTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  mark: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  iconBtn: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center' },
  pad: { padding: 14, paddingBottom: 40 },
  btn: { flex: 1, flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', paddingVertical: 11, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, marginVertical: 4 },
  btnText: { fontWeight: '800', fontSize: 13 },
  fieldWrap: { marginBottom: 10 },
  fieldLabel: { fontSize: 11, fontWeight: '700', color: C.mutedForeground, marginBottom: 4 },
  field: { borderWidth: 1, borderColor: C.border, borderRadius: 12, padding: 11, backgroundColor: C.card, color: C.foreground },
  err: { color: C.expense, marginBottom: 8 },
  hint: { color: C.mutedForeground, fontSize: 12, marginBottom: 10, lineHeight: 17 },
  section: { fontWeight: '800', marginTop: 12, marginBottom: 8, color: C.foreground },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  cardOn: { borderColor: C.primary, backgroundColor: C.primarySoft },
  cardTitle: { fontWeight: '800', color: C.foreground, fontSize: 14 },
  meta: { color: C.mutedForeground, fontSize: 11, marginTop: 3 },
  gosHead: { fontSize: 12, fontWeight: '800', color: C.foreground },
  row: { flexDirection: 'row', gap: 8, marginVertical: 6 },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  stat: { width: '47%', backgroundColor: C.card, borderRadius: 12, borderWidth: 1, borderColor: C.border, padding: 10 },
  homeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: 14, padding: 12, marginBottom: 8 },
  homeIcon: { width: 38, height: 38, borderRadius: 11, backgroundColor: C.primarySoft, alignItems: 'center', justifyContent: 'center' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  chip: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 16, borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
  chipOn: { backgroundColor: C.primary, borderColor: C.primary },
  summary: { marginTop: 14, padding: 12, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.8)', borderWidth: 1, borderColor: C.border },
  sumLine: { fontWeight: '800', marginBottom: 4 },
  empty: { backgroundColor: C.card, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: C.border, gap: 6 },
  emptyTitle: { fontWeight: '800', fontSize: 15 },
  emptyWhy: { color: C.mutedForeground, fontSize: 12, lineHeight: 18 },
  emptyStep: { fontSize: 12 },
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 22 },
  modalCard: { backgroundColor: C.card, borderRadius: 16, padding: 16, gap: 8 },
  modalTitle: { fontWeight: '800', fontSize: 16 },
});
