/** PROJECT_MASTER — core domain types (Phase 1) */

export type Id = string;

/** Cashbook page (Excel-register style manual pagination) */
export type CashbookPage = {
  id: Id;
  fyId: Id;
  pageNo: number;
  label: string;
  createdAt: string;
};

/** पाक्षिक मस्टरोल — labour mandays + wage rate (CC page 3) */
export type PakhwadaRoll = {
  id: Id;
  workId: Id;
  fyId: Id;
  fromDate: string;
  toDate: string;
  rollNo: string;
  mateCount: number;
  skilledCount: number;
  unskilledCount: number;
  days: number;
  wageMate: number;
  wageSkilled: number;
  wageUnskilled: number;
};

export type Fund = {
  id: Id;
  name: string;
  shortName: string;
  openingBalance: number;
  enabled: boolean;
  openingSource: 'carry-forward' | 'manual';
  sortOrder: number;
};

export type CategoryKind = 'income' | 'expense';

export type CategoryNode = {
  id: Id;
  kind: CategoryKind;
  name: string;
  parentId: Id | null;
  level: 1 | 2 | 3;
  archived: boolean;
};

export type Panchayat = {
  id: Id;
  name: string;
  block: string;
  district: string;
};

export type FinancialYear = {
  id: Id;
  label: string;
  start: string;
  end: string;
  locked: boolean;
  /**
   * Per-FY fund openings (D17 / K.3): हर FY का apna opening snapshot.
   * Absent = legacy data → fund.openingBalance use hota hai.
   */
  openings?: Record<string, number>;
  /** Is FY me archived (disabled) funds — delete = "this FY only" (K.3) */
  disabledFunds?: string[];
};

/** 'transfer' = नकद→बैंक जमा (Part G: cash−, bank+; NOT income/expense) */
export type TxType = 'income' | 'expense' | 'transfer';

export type Transaction = {
  id: Id;
  fyId: Id;
  type: TxType;
  date: string;
  pageId: Id | null;
  reference: string;
  /** L.F. — ledger folio number (ledger cross-verification ke liye, old doc §3.1) */
  ledgerFolio: string;
  party: string;
  detail: string;
  note: string;
  /** परिसंपत्ति रजिस्टर पृष्ठ संख्या (Part C.3.2 — expense side column 6) */
  assetPage?: string;
  /** रद्द करने का कारण (D4 — reason required, audit me rehta hai) */
  cancelReason?: string;
  schemeId: Id;
  amounts: Record<string, number>;
  categoryId: Id | null;
  subcategoryId: Id | null;
  subSubcategoryId: Id | null;
  workId: Id | null;
  expenseKind: 'work' | 'other' | null;
  status: 'active' | 'cancelled';
  createdAt: string;
  updatedAt: string;
};

export type Work = {
  id: Id;
  fyId: Id;
  name: string;
  schemeId: Id;
  ward: string;
  sanctionRef: string;
  /** FS — वित्तीय स्वीकृति राशि (प्रपत्र-1 + CC min() rule) */
  fsAmount?: number;
  materialPrior: number;
  labourPrior: number;
  status: 'ongoing' | 'completed';
};

/** L.3 audit trail: user, time, entity, action, field, old/new, reason */
export type AuditLog = {
  id: Id;
  fyId: Id;
  time: string;
  entity: 'transaction' | 'fy' | 'fund' | 'panchayat';
  entityId: Id;
  action: 'create' | 'update' | 'cancel' | 'lock' | 'archive';
  field?: string;
  oldV?: string;
  newV?: string;
  reason?: string;
};

export type MbLine = {
  id: Id;
  workId: Id;
  itemName: string;
  qty: number;
  rate: number;
  kind: 'material' | 'labour' | 'artisan';
};

export type Bill = {
  id: Id;
  workId: Id;
  fyId: Id;
  billDate: string;
  paymentDate: string;
  pageRef: string;
  vendor: string;
  amount: number;
  note: string;
};

export type BankAccount = {
  id: Id;
  name: string;
  accountNo: string;
  bankName: string;
};

export type BankLine = {
  id: Id;
  accountId: Id;
  fyId: Id;
  statementMonth: string;
  date: string;
  narration: string;
  amount: number;
  side: 'credit' | 'debit';
  instrument: string;
  schemeId: Id | null;
  workId: Id | null;
  ignored: boolean;
  postedTxnId: Id | null;
};

export type FySettings = {
  lineCount: number;
  blankLineGap: 1 | 2;
  allowSchemeNegative: boolean;
  pageBackground: string;
  entryFontColor: string;
  shriPoteColor: string;
  summaryFontColor: string;
};

export type AppSettings = {
  pin: string | null;
  biometricEnabled: boolean;
  setupComplete: boolean;
  adminName: string;
  themeId: string;
  /** 8 finance logos me se chosen (old doc §16.1) — Feather icon name */
  logoId: string;
  language: 'hi' | 'en' | 'hinglish';
  showScreenBadge: boolean;
};

/** BSR Master — वार्षिक दर सूची (old master B §5) */
export type BsrRate = {
  id: Id;
  year: string; // e.g. '2026-27'
  itemName: string;
  unit: string;
  rate: number;
};

/** Item Master — qty flags (old master B §8.3) */
export type ItemMaster = {
  id: Id;
  name: string;
  wholeNumberOnly: boolean; // cement/brick = poorn sankhya only
  lastBillOnly: boolean; // पानी/टेंकर/मशीनरी… sirf last bill
  basicItem: boolean; // cement/रेत/गिट्टी front-load suggestion
};

/** Holiday Master — साल-वार छुट्टियाँ (old master B §7.1) */
export type HolidayEntry = { id: Id; year: string; date: string; name: string };

/** Worker Master — कारीगर/लेबर year-wise rates (old master B §6) */
export type WorkerRate = {
  id: Id;
  role: 'karigar' | 'labour' | 'mate';
  name: string;
  year: string;
  dailyRate: number;
};

/** Man-days calculation audit (old master B §7.3.5) */
export type MandayCalc = {
  id: Id;
  workId: Id;
  role: 'karigar' | 'labour' | 'mate';
  workers: number;
  days: number;
  rate: number;
  bsrYear: string;
  amount: number;
  mbComponentAmount: number;
  createdAt: string;
};

export type RootData = {
  version: 5;
  app: AppSettings;
  fySettings: FySettings;
  panchayats: Panchayat[];
  activePanchayatId: Id;
  financialYears: FinancialYear[];
  activeFinancialYearId: Id;
  funds: Fund[];
  categories: CategoryNode[];
  transactions: Transaction[];
  works: Work[];
  mbLines: MbLine[];
  bills: Bill[];
  bankAccounts: BankAccount[];
  bankLines: BankLine[];
  pages: CashbookPage[];
  workerRolls: PakhwadaRoll[];
  bsrRates: BsrRate[];
  itemMasters: ItemMaster[];
  holidays: HolidayEntry[];
  workerRates: WorkerRate[];
  mandayCalcs: MandayCalc[];
  auditLogs: AuditLog[];
};
