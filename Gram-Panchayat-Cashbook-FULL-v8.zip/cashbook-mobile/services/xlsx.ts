/**
 * xlsx.ts — instruction #17 (+ #20)
 * Mobile par `.xls` (HTML wrapper) file khulti nahi thi → isliye असली **.xlsx** banao.
 *
 * Ye ek chhota OOXML/ZIP writer hai:
 *  • ZIP container STORE method (bina compression) — valid Excel/Google Sheets/Drive chalata hai.
 *  • Har sheet = `<table>` HTML se — isliye saare purane format builders (exportHtml.ts)
 *    bina badle Excel ban jaate hain; colspan/rowspan bhi theek jate hain.
 *  • Koi naya dependency nahi (SheetJS etc. ki zarurat nahi pade).
 */

/* ───────────────────────── ZIP (STORE) ───────────────────────── */

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

/** UTF-8 bytes (Hermes me TextEncoder pakka nahi hota — isliye manual) */
function utf8(s: string): Uint8Array {
  const out: number[] = [];
  for (let i = 0; i < s.length; i++) {
    let c = s.charCodeAt(i);
    if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) {
      const c2 = s.charCodeAt(i + 1);
      if (c2 >= 0xdc00 && c2 <= 0xdfff) {
        c = 0x10000 + ((c - 0xd800) << 10) + (c2 - 0xdc00);
        i++;
      }
    }
    if (c < 0x80) out.push(c);
    else if (c < 0x800) out.push(0xc0 | (c >> 6), 0x80 | (c & 63));
    else if (c < 0x10000) out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    else out.push(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
  }
  return new Uint8Array(out);
}

function writeU16(arr: number[], v: number) {
  arr.push(v & 0xff, (v >>> 8) & 0xff);
}
function writeU32(arr: number[], v: number) {
  arr.push(v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff);
}

type ZipEntry = { name: string; data: Uint8Array };

/** ZIP archive banao (local headers + central directory + EOCD), sab STORE method */
export function buildZipArchive(entries: { name: string; data: Uint8Array | string }[]): Uint8Array {
  return buildZip(entries.map((e) => ({ name: e.name, data: typeof e.data === 'string' ? utf8(e.data) : e.data })));
}
function buildZip(entries: ZipEntry[]): Uint8Array {
  const out: number[] = [];
  const central: number[] = [];
  let count = 0;

  for (const e of entries) {
    const nameBytes = utf8(e.name);
    const crc = crc32(e.data);
    const offset = out.length;

    writeU32(out, 0x04034b50); // local file header
    writeU16(out, 20); // version needed
    writeU16(out, 0); // flags
    writeU16(out, 0); // method = STORE
    writeU16(out, 0); // mod time
    writeU16(out, 0x2821); // mod date (2000-01-01)
    writeU32(out, crc);
    writeU32(out, e.data.length); // compressed size
    writeU32(out, e.data.length); // uncompressed size
    writeU16(out, nameBytes.length);
    writeU16(out, 0); // extra len
    for (let i = 0; i < nameBytes.length; i++) out.push(nameBytes[i]);
    for (let i = 0; i < e.data.length; i++) out.push(e.data[i]);

    writeU32(central, 0x02014b50); // central directory header
    writeU16(central, 20);
    writeU16(central, 20);
    writeU16(central, 0);
    writeU16(central, 0);
    writeU16(central, 0);
    writeU16(central, 0x2821);
    writeU32(central, crc);
    writeU32(central, e.data.length);
    writeU32(central, e.data.length);
    writeU16(central, nameBytes.length);
    writeU16(central, 0); // extra
    writeU16(central, 0); // comment
    writeU16(central, 0); // disk
    writeU16(central, 0); // internal attrs
    writeU32(central, 0); // external attrs
    writeU32(central, offset);
    for (let i = 0; i < nameBytes.length; i++) central.push(nameBytes[i]);
    count++;
  }

  const cdOffset = out.length;
  for (let i = 0; i < central.length; i++) out.push(central[i]);

  writeU32(out, 0x06054b50); // EOCD
  writeU16(out, 0);
  writeU16(out, 0);
  writeU16(out, count);
  writeU16(out, count);
  writeU32(out, central.length);
  writeU32(out, cdOffset);
  writeU16(out, 0);

  return new Uint8Array(out);
}

/* ───────────────────────── XLSX parts ───────────────────────── */

export type SheetCell = string | number | boolean | null | undefined;
/** rows = cell arrays; har sheet ek `<table>` se aa sakta hai */
export type SheetDef = { name: string; rows: SheetCell[][] };

export function xmlEsc(s: unknown): string {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/** 0 → A, 25 → Z, 26 → AA … */
function colName(idx: number): string {
  let n = idx;
  let s = '';
  do {
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26) - 1;
  } while (n >= 0);
  return s;
}

/** Sheet naam ke restriction (31 char, kuch chars mana hain) */
function safeSheetName(name: string, idx: number): string {
  const cleaned = (name || `Sheet${idx + 1}`)
    .replace(/[\[\]\*\?\/\\:]/g, ' ')
    .trim()
    .slice(0, 31);
  return cleaned || `Sheet${idx + 1}`;
}

const NUM_RE = /^-?\d{1,3}(,\d{2,3})*(\.\d+)?$/;
const PLAIN_NUM_RE = /^-?\d+(\.\d+)?$/;

/** Excel-friendly value: numbers numeric, baaki inline string */
function normalize(v: SheetCell): { t: 'n' | 's' | 'b'; v: string } {
  if (v === null || v === undefined || v === '') return { t: 's', v: '' };
  if (typeof v === 'number') return Number.isFinite(v) ? { t: 'n', v: String(v) } : { t: 's', v: String(v) };
  if (typeof v === 'boolean') return { t: 'b', v: v ? '1' : '0' };
  const raw = String(v);
  const noSym = raw.replace(/[₹\s]/g, '');
  if (PLAIN_NUM_RE.test(noSym)) return { t: 'n', v: noSym };
  if (NUM_RE.test(noSym)) {
    const n = Number(noSym.replace(/,/g, ''));
    if (Number.isFinite(n)) return { t: 'n', v: String(n) };
  }
  return { t: 's', v: raw };
}

function sheetXml(rows: SheetCell[][]): string {
  const maxCols = rows.reduce((m, r) => Math.max(m, r.length), 1);
  const cols: string[] = [];
  for (let i = 0; i < maxCols; i++) cols.push(`<col min="${i + 1}" max="${i + 1}" width="16" customWidth="1"/>`);

  const body: string[] = [];
  rows.forEach((row, r) => {
    const cells: string[] = [];
    row.forEach((raw, c) => {
      const ref = `${colName(c)}${r + 1}`;
      const n = normalize(raw);
      if (n.t === 's') {
        if (n.v === '') return; // khali cell chhod do
        cells.push(`<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xmlEsc(n.v)}</t></is></c>`);
      } else if (n.t === 'b') {
        cells.push(`<c r="${ref}" t="b"><v>${n.v}</v></c>`);
      } else {
        cells.push(`<c r="${ref}"><v>${n.v}</v></c>`);
      }
    });
    body.push(`<row r="${r + 1}">${cells.join('')}</row>`);
  });

  return (
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
    `<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>` +
    `<sheetFormatPr defaultRowHeight="15"/>` +
    (cols.length ? `<cols>${cols.join('')}</cols>` : '') +
    `<sheetData>${body.join('')}</sheetData>` +
    `</worksheet>`
  );
}

/** HTML (jo PDF me bhi use hota hai) → sheet rows */
export function htmlToRows(html: string): SheetCell[][] {
  const rows: SheetCell[][] = [];
  const rowRe = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  const cellRe = /<(td|th)([^>]*)>([\s\S]*?)<\/\1>/gi;
  const decode = (s: string) =>
    s
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&#x27;/gi, "'")
      .replace(/\s+/g, ' ')
      .trim();

  // rowspan lagu karne ke liye pending map: rowIndex → col → value
  const pending = new Map<number, Map<number, SheetCell>>();

  let rowMatch: RegExpExecArray | null;
  let r = 0;
  while ((rowMatch = rowRe.exec(html))) {
    const rowHtml = rowMatch[1];
    const cells: SheetCell[][] = [];
    let cm: RegExpExecArray | null;
    while ((cm = cellRe.exec(rowHtml))) {
      const attrs = cm[2] || '';
      const cs = parseInt(/colspan\s*=\s*["']?(\d+)/i.exec(attrs)?.[1] || '1', 10) || 1;
      const rs = parseInt(/rowspan\s*=\s*["']?(\d+)/i.exec(attrs)?.[1] || '1', 10) || 1;
      cells.push([decode(cm[3]), cs, rs] as unknown as SheetCell[]);
    }

    const line: SheetCell[] = [];
    const occupied = (col: number) => {
      for (let rr = r; rr <= r + 6; rr++) {
        const m = pending.get(rr);
        if (m && m.has(col)) return true;
      }
      return false;
    };

    let col = 0;
    for (const [text, cs, rs] of cells as unknown as [string, number, number][]) {
      while (occupied(col)) {
        const m = pending.get(r);
        line.push(m?.get(col) ?? '');
        col++;
      }
      line.push(text);
      for (let k = 1; k < cs; k++) line.push('');
      if (rs > 1) {
        for (let rr = r + 1; rr < r + rs; rr++) {
          if (!pending.has(rr)) pending.set(rr, new Map());
          pending.get(rr)!.set(col, text);
        }
      }
      col += cs;
    }
    // row ke shuru me jo rowspan abhi bhi pending hai use bhar do
    const pre = pending.get(r);
    if (pre) {
      for (const [cc, val] of pre) {
        while (line.length < cc) line.push('');
        line[cc] = val;
      }
      pending.delete(r);
    }
    rows.push(line);
    r++;
    cellRe.lastIndex = 0;
  }
  return rows;
}

/** HTML body (hamare export builders) → ek sheet */
export function sheetFromHtml(name: string, html: string): SheetDef {
  return { name, rows: htmlToRows(html) };
}

/** पूरी workbook (.xlsx) bytes */
export function buildXlsx(sheets: SheetDef[]): Uint8Array {
  const list = sheets.length ? sheets : [{ name: 'Sheet1', rows: [] as SheetCell[][] }];
  const valid = list.map((s, i) => ({ ...s, name: safeSheetName(s.name, i) }));

  const contentTypes =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
    `<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>` +
    `<Default Extension="xml" ContentType="application/xml"/>` +
    `<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>` +
    `<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>` +
    valid
      .map(
        (_, i) =>
          `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`
      )
      .join('') +
    `<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>` +
    `<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>` +
    `</Types>`;

  const rootRels =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    `<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>` +
    `<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>` +
    `<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>` +
    `</Relationships>`;

  const workbook =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">` +
    `<sheets>` +
    valid
      .map(
        (s, i) =>
          `<sheet name="${xmlEsc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`
      )
      .join('') +
    `</sheets></workbook>`;

  const wbRels =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
    valid
      .map(
        (_, i) =>
          `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`
      )
      .join('') +
    `<Relationship Id="rId${valid.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
    `</Relationships>`;

  const styles =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
    `<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>` +
    `<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>` +
    `<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>` +
    `<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>` +
    `<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>` +
    `</styleSheet>`;

  const now = new Date().toISOString();
  const core =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" ` +
    `xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" ` +
    `xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">` +
    `<dc:title>${xmlEsc(valid[0]?.name || 'Cashbook')}</dc:title>` +
    `<dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created>` +
    `</cp:coreProperties>`;

  const app =
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` +
    `<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">` +
    `<Application>Gram Panchayat Cashbook</Application></Properties>`;

  const entries: ZipEntry[] = [
    { name: '[Content_Types].xml', data: utf8(contentTypes) },
    { name: '_rels/.rels', data: utf8(rootRels) },
    { name: 'docProps/core.xml', data: utf8(core) },
    { name: 'docProps/app.xml', data: utf8(app) },
    { name: 'xl/workbook.xml', data: utf8(workbook) },
    { name: 'xl/_rels/workbook.xml.rels', data: utf8(wbRels) },
    { name: 'xl/styles.xml', data: utf8(styles) },
    ...valid.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: utf8(sheetXml(s.rows)) })),
  ];

  return buildZip(entries);
}
