/**
 * exportDoc.ts — instructions #6, #11, #12, #13, #17, #21
 * Har format ka export/share:
 *   • **PDF** — expo-print, हमेशा A4 + orientation ka option (portrait / landscape).
 *   • **Excel** — असली `.xlsx` (services/xlsx.ts) — mobile par ab khul jaati hai.
 * HTML table hi dono jagah chalta hai → format ek hi jagah likho, do share button.
 *
 * D14: print/PDF white background hi (screen ka green tint share me nahi jata).
 */
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { File, Paths } from 'expo-file-system';
import { buildXlsx, buildZipArchive, sheetFromHtml, type SheetDef } from './xlsx';

export const DOC_CSS = `
  * { box-sizing: border-box; }
  html, body {
    font-family: 'Noto Sans Devanagari', 'Mangal', 'Nirmala UI', 'Segoe UI', sans-serif;
    font-size: 12px; color: #111; background: #fff; margin: 0; padding: 0;
  }
  h1 { font-size: 16px; text-align: center; margin: 6px 0 2px; }
  .head { text-align: center; line-height: 1.5; margin-bottom: 6px; }
  .head .sm { font-size: 11px; color: #333; }
  table { border-collapse: collapse; width: 100%; margin-bottom: 8px; table-layout: fixed; }
  th, td { border: 1px solid #444; padding: 3px 5px; font-size: 11px; vertical-align: top; word-wrap: break-word; overflow-wrap: break-word; }
  th { background: #e8f2ec; font-weight: 700; text-align: center; }
  .r { text-align: right; }
  .c { text-align: center; }
  .b { font-weight: 700; }
  .pg { page-break-before: always; }
  .sign td { height: 46px; vertical-align: bottom; font-size: 11px; }
  .note { font-size: 10px; color: #333; margin-top: 4px; }
  .two td { width: 50%; }
  @page { size: A4 portrait; margin: 10mm; }
  @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
`;

export type DocOpts = {
  title: string;
  body: string;
  /** register/goswara jaise chaude formats ke liye landscape */
  landscape?: boolean;
};

/** Printable HTML document (PDF yahi leta hai) — hamesha A4 + chosen orientation */
export function docHtml({ title, body, landscape }: DocOpts): string {
  const pageRule = landscape
    ? '@page { size: A4 landscape; margin: 8mm; }'
    : '@page { size: A4 portrait; margin: 10mm; }';
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(title)}</title>
<style>${DOC_CSS}${pageRule}</style>
</head><body>${body}</body></html>`;
}

export function esc(s: unknown): string {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function shareUri(uri: string, fileName: string, mime: string) {
  const ok = await Sharing.isAvailableAsync();
  if (!ok) throw new Error('इस device पर share उपलब्ध नहीं');
  await Sharing.shareAsync(uri, { mimeType: mime, dialogTitle: fileName });
}

/** HTML → PDF file → system share sheet (hamesha A4 + chosen orientation) */
export async function sharePdf(doc: DocOpts): Promise<void> {
  const html = docHtml(doc);
  const { uri } = await Print.printToFileAsync({ html, base64: false });
  await shareUri(uri, `${doc.title}.pdf`, 'application/pdf');
}

function safeName(s: string): string {
  return (s || 'format').replace(/[\\/:*?"<>|]/g, ' ').trim().slice(0, 80) || 'format';
}

/** HTML table → असली **.xlsx** file → system share sheet (instruction #17) */
export async function shareExcel(title: string, body: string): Promise<void> {
  const name = `${safeName(title)}.xlsx`;
  await writeWorkbook(name, [sheetFromHtml(title.slice(0, 31) || 'Sheet1', body)]);
}

/**
 * Multi-sheet workbook (instruction #20) — जैसे "audit formet demo.xlsx":
 * एक ही file में भरे हुए सारे formats की sheets.
 */
export async function shareWorkbook(title: string, sheets: { name: string; html: string }[]): Promise<void> {
  const name = `${safeName(title)}.xlsx`;
  await writeWorkbook(
    name,
    sheets.map((s) => sheetFromHtml(s.name, s.html))
  );
}

async function writeWorkbook(name: string, sheets: SheetDef[]): Promise<void> {
  const bytes = buildXlsx(sheets);
  const file = new File(Paths.cache, name);
  file.create({ overwrite: true, intermediates: true });
  file.write(bytes);
  await shareUri(file.uri, name, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

/**
 * कोई भी फ़ाइल share करो (json / zip / csv / txt) — instruction #28:
 * FY समापन का safe backup अब *text message* नहीं, असली **फ़ाइल** है।
 */
export async function shareRawFile(fileName: string, content: string | Uint8Array, mime: string): Promise<void> {
  const name = safeName(fileName);
  const file = new File(Paths.cache, name);
  file.create({ overwrite: true, intermediates: true });
  file.write(content);
  await shareUri(file.uri, name, mime);
}

/**
 * ZIP bundle share (instruction #28) — एक ही .zip में पूरा database backup,
 * गोशवारा, खाता बही और audit की 6 sheets (सारे HTML जो PDF/Excel में भी जाते हैं)।
 */
export async function shareZipBundle(
  title: string,
  files: { name: string; content: string | Uint8Array }[]
): Promise<void> {
  const name = `${safeName(title)}.zip`;
  const bytes = buildZipArchive(files.map((f) => ({ name: f.name, data: f.content })));
  const file = new File(Paths.cache, name);
  file.create({ overwrite: true, intermediates: true });
  file.write(bytes);
  await shareUri(file.uri, name, 'application/zip');
}

/** PDF — default A4, orientation ka option (instruction #21) */
async function chooseOrientationThenShare(title: string, body: string, suggested: boolean): Promise<void> {
  const { Alert } = await import('react-native');
  await new Promise<void>((resolve) => {
    const go = async (landscape: boolean) => {
      try {
        await sharePdf({ title, body, landscape });
      } catch (e) {
        Alert.alert('PDF fail', String((e as Error).message || e));
      } finally {
        resolve();
      }
    };
    Alert.alert(
      `${title} — PDF`,
      'A4 size में बनेगा — orientation चुनें:',
      [
        { text: suggested ? 'A4 · Landscape (सुझाव)' : 'A4 · Landscape', onPress: () => go(true) },
        { text: suggested ? 'A4 · Portrait' : 'A4 · Portrait (सुझाव)', onPress: () => go(false) },
        { text: 'रद्द', style: 'cancel', onPress: () => resolve() },
      ],
      { cancelable: true }
    );
  });
}

/** Form screen: user poochhe PDF / Excel (instructions #6, #11, #12, #17, #21) */
export async function askAndShare(title: string, body: string, landscape = false): Promise<void> {
  const { Alert } = await import('react-native');
  await new Promise<void>((resolve) => {
    const done = async (fn: () => Promise<void>, label: string) => {
      try {
        await fn();
      } catch (e) {
        Alert.alert(`${label} fail`, String((e as Error).message || e));
      } finally {
        resolve();
      }
    };
    Alert.alert(
      `${title}`,
      'किस format में भेजें? (Excel = असली .xlsx · PDF = A4)',
      [
        { text: 'PDF (A4)', onPress: () => done(() => chooseOrientationThenShare(title, body, landscape), 'PDF') },
        { text: 'Excel (.xlsx)', onPress: () => done(() => shareExcel(title, body), 'Excel') },
        { text: 'रद्द', style: 'cancel', onPress: () => resolve() },
      ],
      { cancelable: true }
    );
  });
}

/** कुल योग row जैसी helper — table string बनाने में */
export function th(cells: string[]): string {
  return `<tr>${cells.map((c) => `<th>${esc(c)}</th>`).join('')}</tr>`;
}

export function tr(cells: (string | number)[], cls?: string): string {
  return `<tr class="${cls || ''}">${cells
    .map((c) => `<td class="${typeof c === 'number' ? 'r' : ''}">${esc(c)}</td>`)
    .join('')}</tr>`;
}
